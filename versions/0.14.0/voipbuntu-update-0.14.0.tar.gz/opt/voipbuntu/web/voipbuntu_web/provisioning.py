"""Provisionnement automatique des téléphones SIP (Yealink, Snom, Grandstream, Fanvil).

La console associe un téléphone (marque, modèle, adresse MAC) à un poste et tient la
liste dans /var/lib/voipbuntu/provisioning.json ; voipbuntu-provision (root) génère un
fichier par téléphone au format du fabricant, dans un dossier par téléphone servi par
nginx sous /prov/ avec une authentification HTTP propre à ce téléphone.

Le mot de passe de provisionnement n'est montré qu'une fois : seule son empreinte
{SSHA} (format accepté par auth_basic_user_file de nginx) est conservée.
"""

import base64
import hashlib
import json
import os
import re
import secrets
import string
import time
from xml.sax.saxutils import escape

DEFAULT_STATE = "/var/lib/voipbuntu/provisioning.json"
FILES_DIR = "/srv/voipbuntu/provisioning/phones"
HTPASSWD = "/etc/nginx/voipbuntu-prov.htpasswd"
ACCESS_LOG = "/var/log/nginx/voipbuntu-prov.log"
HTTPS_PORT = 8443
HTTP_PORT = 80
MAX_PHONES = 200
TIMEZONE = "Europe/Paris"
DEFAULT_NTP = "fr.pool.ntp.org"
VOICEMAIL = "*97"
NUMBER_RE = re.compile(r"^[1-9][0-9]{1,5}$")
HOST_RE = re.compile(r"^(?=.{1,253}$)[A-Za-z0-9](?:[A-Za-z0-9-]{0,62}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,62}[A-Za-z0-9])?)*$")
MODEL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9+-]{0,23}$")
HASH_RE = re.compile(r"^\{SSHA\}[A-Za-z0-9+/=]{20,80}$")
FILE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")

# Modèles proposés par la console ; un autre modèle de la marque peut être saisi.
VENDORS = {
    "yealink": {"label": "Yealink", "models": ["T31P", "T31G", "T33G", "T34W", "T43U", "T44U", "T46U", "T48U", "T53",
                                               "T53W", "T54W", "T57W", "T58W", "W73P", "W76P"]},
    "snom": {"label": "Snom", "models": ["D120", "D140", "D150", "D315", "D335", "D385", "D713", "D717", "D735",
                                         "D765", "D785", "D812", "D815", "D862", "D865"]},
    "grandstream": {"label": "Grandstream", "models": ["GRP2601", "GRP2602", "GRP2603", "GRP2604", "GRP2612", "GRP2613",
                                                       "GRP2614", "GRP2615", "GRP2616", "GXP1610", "GXP1625",
                                                       "GXP2135", "GXP2160", "GXP2170", "WP810"]},
    "fanvil": {"label": "Fanvil", "models": ["X1S", "X1SP", "X3S", "X3SP", "X3U", "X4U", "X5U", "X6U", "X7", "X7C",
                                             "V62", "V63", "V64", "V65", "V67"]},
}
LDAP_DEFAULTS = {"name_filter": "(|(cn=%)(sn=%)(givenName=%)(o=%))",
                 "number_filter": "(|(telephoneNumber=%)(mobile=%)(homePhone=%))"}


class ProvisioningError(ValueError):
    pass


# ------------------------------------------------------------------ état
def normalize_mac(value):
    """Adresse MAC en 12 chiffres hexadécimaux minuscules, séparateurs : - . ou espace admis."""
    raw = re.sub(r"[\s:.-]", "", str(value or "")).lower()
    if not re.match(r"^[0-9a-f]{12}$", raw):
        raise ProvisioningError("adresse MAC invalide")
    if raw in ("000000000000", "ffffffffffff") or int(raw[1], 16) & 1:
        raise ProvisioningError("adresse MAC invalide")  # nulle, diffusion ou multidiffusion
    return raw


def new_password(length=20):
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def ssha(password, salt=None):
    """Empreinte {SSHA} lue par nginx (auth_basic_user_file) : SHA-1 salé, mot de passe aléatoire de 20 caractères."""
    salt = salt if salt is not None else os.urandom(8)
    digest = hashlib.sha1(password.encode("utf-8") + salt).digest()
    return "{SSHA}" + base64.b64encode(digest + salt).decode("ascii")


def check_ssha(password, stored):
    try:
        raw = base64.b64decode(stored[6:])
    except (ValueError, TypeError):
        return False
    return secrets.compare_digest(ssha(password, raw[20:]), stored)


def empty():
    return {"phones": [], "http": False, "server": "", "ntp": ""}


def validate_settings(data):
    server = str(data.get("server") or "").strip()
    ntp = str(data.get("ntp") or "").strip()
    if server and not HOST_RE.match(server):
        raise ProvisioningError("adresse du serveur invalide")
    if ntp and not HOST_RE.match(ntp):
        raise ProvisioningError("serveur NTP invalide")
    return {"http": bool(data.get("http", False)), "server": server, "ntp": ntp}


def validate_phone(p):
    if not isinstance(p, dict):
        raise ProvisioningError("téléphone invalide")
    number = str(p.get("number", ""))
    if not NUMBER_RE.match(number):
        raise ProvisioningError("poste invalide")
    vendor = str(p.get("vendor", ""))
    if vendor not in VENDORS:
        raise ProvisioningError("marque inconnue")
    model = str(p.get("model", "")).strip().upper()
    if not MODEL_RE.match(model):
        raise ProvisioningError("modèle invalide")
    pw_hash = str(p.get("hash", ""))
    if not HASH_RE.match(pw_hash):
        raise ProvisioningError("empreinte invalide")
    created = p.get("created")
    return {"number": number, "vendor": vendor, "model": model, "mac": normalize_mac(p.get("mac")),
            "hash": pw_hash, "created": int(created) if isinstance(created, (int, float)) else 0}


def validate(data):
    if not isinstance(data, dict):
        raise ProvisioningError("format invalide")
    phones = data.get("phones", [])
    if not isinstance(phones, list) or len(phones) > MAX_PHONES:
        raise ProvisioningError("liste de téléphones invalide")
    out, macs, numbers = [], set(), set()
    for p in phones:
        p = validate_phone(p)
        if p["mac"] in macs:
            raise ProvisioningError("adresse MAC déjà associée")
        if p["number"] in numbers:
            raise ProvisioningError("poste déjà associé à un téléphone")
        macs.add(p["mac"])
        numbers.add(p["number"])
        out.append(p)
    out.sort(key=lambda p: (len(p["number"]), p["number"]))
    state = validate_settings(data)
    state["phones"] = out
    return state


def load(path=DEFAULT_STATE):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
    except FileNotFoundError:
        return empty()
    except (OSError, ValueError) as exc:
        raise ProvisioningError("provisionnement illisible : %s" % exc.__class__.__name__) from None
    return validate(data)


def save(state, path=DEFAULT_STATE):
    state = validate(state)
    tmp = path + ".tmp"
    old = os.umask(0o077)
    try:
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(state, handle, indent=1, sort_keys=True)
        os.replace(tmp, path)
    finally:
        os.umask(old)
    return state


def associate(state, number, vendor, model, mac, now=None):
    """Associe (ou réassocie) un téléphone au poste : renvoie (état, mot de passe en clair à montrer une fois)."""
    mac = normalize_mac(mac)
    other = next((p for p in state["phones"] if p["mac"] == mac and p["number"] != number), None)
    if other:
        raise ProvisioningError("adresse MAC déjà associée au poste %s" % other["number"])
    password = new_password()
    phone = validate_phone({"number": number, "vendor": vendor, "model": model, "mac": mac, "hash": ssha(password),
                            "created": int(now if now is not None else time.time())})
    phones = [p for p in state["phones"] if p["number"] != number] + [phone]
    return validate(dict(state, phones=phones)), password


def renew(state, mac):
    mac = normalize_mac(mac)
    phone = next((p for p in state["phones"] if p["mac"] == mac), None)
    if phone is None:
        raise ProvisioningError("téléphone introuvable")
    password = new_password()
    phone["hash"] = ssha(password)
    return validate(state), password


def prune(state, numbers):
    """Retire les téléphones dont le poste n'existe plus."""
    kept = [p for p in state["phones"] if p["number"] in numbers]
    return dict(state, phones=kept), len(state["phones"]) - len(kept)


def file_names(phone):
    """Fichiers demandés par le téléphone, dans l'ordre : le premier est le fichier principal."""
    mac, model = phone["mac"], phone["model"]
    if phone["vendor"] == "yealink":
        return [mac + ".cfg"]
    if phone["vendor"] == "grandstream":
        return ["cfg%s.xml" % mac]
    if phone["vendor"] == "fanvil":
        return [mac + ".cfg"]
    # Snom : XML par MAC, et le nom demandé par défaut avec l'URL de l'option 66 (snom<modèle>.htm)
    return [mac.upper() + ".xml", "snom%s.htm" % model]


def public(state, numbers=None):
    """Vue de la console : jamais l'empreinte du mot de passe."""
    phones = []
    for p in state["phones"]:
        phones.append({"number": p["number"], "vendor": p["vendor"], "model": p["model"], "mac": p["mac"],
                       "mac_display": ":".join(p["mac"][i:i + 2] for i in range(0, 12, 2)),
                       "user": p["mac"], "created": p["created"], "files": file_names(p),
                       "orphan": numbers is not None and p["number"] not in numbers})
    return {"phones": phones, "settings": {"http": state["http"], "server": state["server"], "ntp": state["ntp"]},
            "vendors": VENDORS, "https_port": HTTPS_PORT, "http_port": HTTP_PORT}


def urls(host, http=False):
    out = {"https": "https://%s:%d/prov/" % (host, HTTPS_PORT)} if host else {}
    if host and http:
        out["http"] = "http://%s/prov/" % host
    return out


# ------------------------------------------------------------------ rendu
def context(ext, server, ntp, ldap=None):
    """Réglages communs à tous les fabricants pour un poste de pbx.json."""
    if not HOST_RE.match(server or ""):
        raise ProvisioningError("adresse du serveur invalide")
    ldap = dict(LDAP_DEFAULTS, **ldap) if ldap else None
    if ldap:
        ldap["host"] = server
        ldap["port"] = int(ldap.get("port") or 389)
    return {"number": ext["number"], "name": ext["name"], "user": ext["sip_user"], "secret": ext["secret"],
            "server": server, "port": 5060, "ntp": ntp or DEFAULT_NTP, "voicemail": VOICEMAIL if ext.get("voicemail", True) else "",
            "ldap": ldap}


def clean(value):
    """Valeur sur une ligne, sans caractère de contrôle (fichiers clé = valeur)."""
    return re.sub(r"[\x00-\x1f\x7f]", "", str(value))


def render_yealink(c):
    """Fichier <mac>.cfg (format « #!version:1.0.0.1 », clés de la documentation Yealink)."""
    lines = ["#!version:1.0.0.1",
             "## Généré par VOIPbuntu pour le poste %s" % c["number"],
             "account.1.enable = 1",
             "account.1.label = %s" % c["number"],
             "account.1.display_name = %s" % c["name"],
             "account.1.auth_name = %s" % c["user"],
             "account.1.user_name = %s" % c["user"],
             "account.1.password = %s" % c["secret"],
             "account.1.sip_server.1.address = %s" % c["server"],
             "account.1.sip_server.1.port = %d" % c["port"],
             "account.1.sip_server.1.transport_type = 0",
             "voice_mail.number.1 = %s" % c["voicemail"],
             "lang.gui = French",
             "lang.wui = French",
             "local_time.time_zone = +1",
             "local_time.time_zone_name = France(Paris)",
             "local_time.summer_time = 2",
             "local_time.manual_ntp_srv_prior = 1",
             "local_time.ntp_server1 = %s" % c["ntp"],
             "local_time.time_format = 1",
             "local_time.date_format = 5"]
    ldap = c["ldap"]
    if ldap:
        lines += ["ldap.enable = 1",
                  "ldap.name = Annuaire",
                  "ldap.host = %s" % ldap["host"],
                  "ldap.port = %d" % ldap["port"],
                  "ldap.base = %s" % ldap["base"],
                  "ldap.user = %s" % ldap.get("user", ""),
                  "ldap.password = %s" % ldap.get("password", ""),
                  "ldap.version = 3",
                  "ldap.name_filter = %s" % ldap["name_filter"],
                  "ldap.number_filter = %s" % ldap["number_filter"],
                  "ldap.name_attr = cn sn givenName o",
                  "ldap.numb_attr = telephoneNumber mobile homePhone",
                  "ldap.display_name = %cn",
                  "ldap.max_hits = 50",
                  "ldap.call_in_lookup = 1",
                  "ldap.ldap_sort = 1"]
    else:
        lines.append("ldap.enable = 0")
    return ("\n".join(clean(line) for line in lines) + "\n").encode("utf-8")


def xml_lines(tag_values, indent="  "):
    return [indent + "<%s%s>%s</%s>" % (tag, attrs, escape(str(value)), tag) for tag, attrs, value in tag_values]


def render_snom(c):
    """Réglages Snom au format XML (<settings><phone-settings>), un poste sur l'identité 1."""
    one = ' idx="1" perm=""'
    rw = ' perm=""'
    values = [("language", rw, "Francais"), ("web_language", rw, "Francais"), ("timezone", rw, "FRA+1"),
              ("ntp_server", rw, c["ntp"]), ("date_us_format", rw, "off"), ("time_24_format", rw, "on"),
              ("user_active", one, "on"), ("user_realname", one, c["name"]), ("user_name", one, c["user"]),
              ("user_pname", one, c["user"]), ("user_pass", one, c["secret"]),
              ("user_host", one, "%s:%d" % (c["server"], c["port"])), ("user_mailbox", one, c["voicemail"])]
    ldap = c["ldap"]
    if ldap:
        values += [("ldap_server", rw, ldap["host"]), ("ldap_port", rw, ldap["port"]), ("ldap_base", rw, ldap["base"]),
                   ("ldap_username", rw, ldap.get("user", "")), ("ldap_password", rw, ldap.get("password", "")),
                   ("ldap_search_filter", rw, ldap["name_filter"]), ("ldap_number_filter", rw, ldap["number_filter"]),
                   ("ldap_name_attributes", rw, "cn sn givenName o"),
                   ("ldap_number_attributes", rw, "telephoneNumber mobile homePhone"),
                   ("ldap_display_name", rw, "%cn"), ("ldap_max_hits", rw, "50"), ("ldap_lookup_ringing", rw, "on")]
    body = ['<?xml version="1.0" encoding="utf-8"?>', "<!-- Généré par VOIPbuntu pour le poste %s -->" % escape(c["number"]),
            "<settings>", ' <phone-settings e="2">'] + xml_lines(values) + [" </phone-settings>", "</settings>"]
    return ("\n".join(body) + "\n").encode("utf-8")


def render_grandstream(c, mac):
    """Fichier cfg<mac>.xml (gs_provision, valeurs P de la documentation Grandstream GXP/GRP)."""
    values = [("P271", "", "1"), ("P270", "", c["number"]), ("P47", "", "%s:%d" % (c["server"], c["port"])),
              ("P35", "", c["user"]), ("P36", "", c["user"]), ("P34", "", c["secret"]), ("P3", "", c["name"]),
              ("P33", "", c["voicemail"]), ("P1362", "", "fr"),
              ("P64", "", "CET-1CEST-2,M3.5.0/02:00:00,M10.5.0/03:00:00"), ("P30", "", c["ntp"])]
    ldap = c["ldap"]
    if ldap:
        values += [("P8020", "", ldap["host"]), ("P8021", "", ldap["port"]), ("P8022", "", ldap["base"]),
                   ("P8023", "", ldap.get("user", "")), ("P8024", "", ldap.get("password", "")),
                   ("P8025", "", ldap["number_filter"]), ("P8026", "", ldap["name_filter"]), ("P8027", "", "1"),
                   ("P8028", "", "cn sn givenName o"), ("P8029", "", "telephoneNumber mobile homePhone"),
                   ("P8030", "", "%cn"), ("P8031", "", "50"), ("P8035", "", "1")]
    body = ['<?xml version="1.0" encoding="UTF-8"?>', "<!-- Généré par VOIPbuntu pour le poste %s -->" % escape(c["number"]),
            '<gs_provision version="1">', "  <mac>%s</mac>" % mac, '  <config version="1">'] + \
        xml_lines(values, "    ") + ["  </config>", "</gs_provision>"]
    return ("\n".join(body) + "\n").encode("utf-8")


def render_fanvil(c):
    """Fichier <mac>.cfg au format texte Fanvil (<<VOIP CONFIG FILE>>, modules, « Clé :valeur »)."""
    def kv(key, value):
        return "%-24s:%s" % (key, clean(value))
    lines = ["<<VOIP CONFIG FILE>>Version:2.0002", "",
             "<GLOBAL CONFIG MODULE>",
             kv("Enable SNTP", 1), kv("SNTP Server", c["ntp"]), kv("Time Zone", 4), kv("Time Zone Name", "UTC+1"),
             kv("Enable DST", 2), kv("Location", "France"), kv("Time Format", 1), "",
             "<LCD CONFIG MODULE>", kv("Language", "fr"), "",
             "<MMI CONFIG MODULE>", kv("Web Language", "fr"), "",
             "<SIP CONFIG MODULE>", kv("SIP  Port", 5060), "--SIP Line List--  :",
             kv("SIP1 Phone Number", c["user"]), kv("SIP1 Display Name", c["name"]), kv("SIP1 Sip Name", c["number"]),
             kv("SIP1 Register Addr", c["server"]), kv("SIP1 Register Port", c["port"]),
             kv("SIP1 Register User", c["user"]), kv("SIP1 Register Pswd", c["secret"]), kv("SIP1 Register TTL", 3600),
             kv("SIP1 Enable Reg", 1), kv("SIP1 Transport", 0), kv("SIP1 VoiceMail Number", c["voicemail"])]
    ldap = c["ldap"]
    if ldap:
        lines += ["", "<LDAP CONFIG MODULE>", kv("LDAP1 Title", "Annuaire"), kv("LDAP1 Server Address", ldap["host"]),
                  kv("LDAP1 Server Port", ldap["port"]), kv("LDAP1 Base", ldap["base"]),
                  kv("LDAP1 User Name", ldap.get("user", "")), kv("LDAP1 Password", ldap.get("password", "")),
                  kv("LDAP1 Name Filter", ldap["name_filter"]), kv("LDAP1 Number Filter", ldap["number_filter"]),
                  kv("LDAP1 Name Attributes", "cn sn givenName o"),
                  kv("LDAP1 Number Attributes", "telephoneNumber mobile homePhone"),
                  kv("LDAP1 Display Name", "cn"), kv("LDAP1 Version", 3), kv("LDAP1 Max Hits", 50),
                  kv("LDAP1 Incoming Call Lookup", 1)]
    lines += ["", "<<END OF FILE>>"]
    return ("\n".join(lines) + "\n").encode("utf-8")


def render(phone, ext, server, ntp, ldap=None):
    """{nom de fichier: contenu} pour un téléphone associé au poste ext (entrée de pbx.json)."""
    c = context(ext, server, ntp, ldap)
    if phone["vendor"] == "yealink":
        body = render_yealink(c)
    elif phone["vendor"] == "snom":
        body = render_snom(c)
    elif phone["vendor"] == "grandstream":
        body = render_grandstream(c, phone["mac"])
    else:
        body = render_fanvil(c)
    return {name: body for name in file_names(phone)}


def htpasswd(state, numbers):
    """Un identifiant par téléphone (sa MAC) : nginx n'accepte que son propre dossier."""
    return "".join("%s:%s\n" % (p["mac"], p["hash"]) for p in state["phones"] if p["number"] in numbers)


def nginx_allow(phone_nets, enabled=True):
    """Restriction nginx de /prov/ aux réseaux des téléphones (en plus du pare-feu)."""
    import ipaddress
    lines = ["# Écrit par voipbuntu-provision : réseaux des téléphones (PHONE_NETS)"]
    if enabled:
        for item in (phone_nets or "").replace(",", " ").split():
            try:
                lines.append("allow %s;" % ipaddress.ip_network(item, strict=False))
            except ValueError:
                continue
    lines.append("deny all;")
    return "\n".join(lines) + "\n"


# ------------------------------------------------------------------ journal
LOG_FIELDS = ("ts", "ip", "user", "uri", "status", "bytes", "ua")


def parse_log(text, limit=200):
    """Journal JSON de nginx (log_format voipbuntu_prov) : téléchargements, du plus récent au plus ancien."""
    out = []
    for line in text.splitlines():
        try:
            e = json.loads(line)
        except ValueError:
            continue
        if not isinstance(e, dict):
            continue
        uri = str(e.get("uri", ""))
        name = uri.rsplit("/", 1)[-1][:64]
        user = str(e.get("user", ""))
        mac = user if re.match(r"^[0-9a-f]{12}$", user) else ""
        if not mac:
            m = re.search(r"([0-9a-fA-F]{12})", name)
            mac = m.group(1).lower() if m else ""
        try:
            status = int(e.get("status", 0))
        except (TypeError, ValueError):
            status = 0
        try:
            size = int(e.get("bytes", 0))
        except (TypeError, ValueError):
            size = 0
        out.append({"ts": str(e.get("ts", ""))[:25], "ip": str(e.get("ip", ""))[:45], "mac": mac,
                    "file": name if FILE_RE.match(name) else "", "status": status, "bytes": size,
                    "ok": status == 200, "ua": clean(e.get("ua", ""))[:80]})
    return list(reversed(out))[:limit]


def read_entries(lines, limit=200):
    """Lignes de « voipbuntu-provision log » relues par la console (revalidées, la plus récente en tête)."""
    out = []
    for line in lines:
        try:
            e = json.loads(line)
        except (TypeError, ValueError):
            continue
        if not isinstance(e, dict) or not isinstance(e.get("status"), int):
            continue
        mac = str(e.get("mac", ""))
        name = str(e.get("file", ""))
        out.append({"ts": str(e.get("ts", ""))[:25], "ip": str(e.get("ip", ""))[:45],
                    "mac": mac if re.match(r"^[0-9a-f]{12}$", mac) else "",
                    "file": name if FILE_RE.match(name) else "", "status": e["status"],
                    "bytes": e["bytes"] if isinstance(e.get("bytes"), int) else 0, "ok": e["status"] == 200,
                    "ua": clean(e.get("ua", ""))[:80]})
    return list(reversed(out))[:limit]
