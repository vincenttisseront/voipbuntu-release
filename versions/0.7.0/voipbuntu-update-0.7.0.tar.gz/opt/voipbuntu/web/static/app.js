/* Console VOIPbuntu : navigation par onglets, API JSON, graphiques SVG.
   Aucun innerHTML : tout le contenu dynamique passe par textContent. */
(function () {
  "use strict";
  var t = function (s) { return window.I18N.t(s); };
  var state = { csrf: "", range: "1h", metric: "cpu", timer: null, series: null };
  var SCREENS = { tableau: ["indicateurs", "services"], telephonie: ["postes", "etat", "reseaux", "groupes", "ligne", "messagerie", "appels"], systeme: ["general", "maj", "taches", "sauvegarde", "journaux", "compte", "journal"] };
  var SVG = "http://www.w3.org/2000/svg";

  function $(id) { return document.getElementById(id); }
  function el(tag, text, cls) {
    var node = document.createElement(tag);
    if (text !== undefined && text !== null) { node.textContent = text; }
    if (cls) { node.className = cls; }
    return node;
  }
  function svg(tag, attrs) {
    var node = document.createElementNS(SVG, tag);
    Object.keys(attrs || {}).forEach(function (k) { node.setAttribute(k, attrs[k]); });
    return node;
  }

  function api(method, path, body) {
    var opts = { method: method, credentials: "same-origin", headers: { "Accept": "application/json" } };
    if (body !== undefined) {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(body);
    }
    if (method !== "GET") { opts.headers["X-CSRF-Token"] = state.csrf; }
    return fetch(path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (data) {
        if (r.status === 401 && path !== "/api/login") { showLogin(); }
        if (!r.ok) { var e = new Error(data.error || t("Erreur interne.")); e.status = r.status; throw e; }
        return data;
      });
    });
  }

  function toast(message) {
    var box = $("toast");
    box.textContent = message;
    box.hidden = false;
    clearTimeout(toast.timer);
    toast.timer = setTimeout(function () { box.hidden = true; }, 4000);
  }

  function confirmDialog(title, text) {
    var dialog = $("dialog");
    $("dialog-title").textContent = title;
    $("dialog-text").textContent = text;
    return new Promise(function (resolve) {
      dialog.addEventListener("close", function handler() {
        dialog.removeEventListener("close", handler);
        resolve(dialog.returnValue === "ok");
      });
      dialog.showModal();
    });
  }

  /* ---------------------------------------------------------- formats */
  function fmtBytes(v) {
    if (v === null || v === undefined) { return "–"; }
    var units = ["o", "Ko", "Mo", "Go", "To"];
    var i = 0;
    while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
    return (i ? v.toFixed(1) : Math.round(v)) + " " + t(units[i]);
  }
  function fmtDuration(s) {
    var d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
    return (d ? d + " " + t("j") + " " : "") + h + " h " + m + " min";
  }
  function fmtTime(ts) {
    return new Date(ts * 1000).toLocaleString(window.I18N.lang() === "en" ? "en-GB" : "fr-FR");
  }
  function last(values) {
    for (var i = values.length - 1; i >= 0; i--) { if (values[i] !== null) { return values[i]; } }
    return null;
  }

  /* ---------------------------------------------------------- navigation */
  function route() {
    var parts = (location.hash || "#tableau").slice(1).split("/");
    var screen = SCREENS[parts[0]] ? parts[0] : "tableau";
    var tab = SCREENS[screen].indexOf(parts[1]) >= 0 ? parts[1] : SCREENS[screen][0];
    document.querySelectorAll(".screen").forEach(function (s) { s.hidden = s.getAttribute("data-screen") !== screen; });
    document.querySelectorAll("nav a").forEach(function (a) {
      if (a.getAttribute("data-screen") === screen) { a.setAttribute("aria-current", "page"); }
      else { a.removeAttribute("aria-current"); }
    });
    var current = document.querySelector('.screen[data-screen="' + screen + '"]');
    current.querySelectorAll('[role="tab"]').forEach(function (b) {
      var on = b.getAttribute("data-tab") === tab;
      b.setAttribute("aria-selected", on ? "true" : "false");
      b.tabIndex = on ? 0 : -1;
    });
    current.querySelectorAll('[role="tabpanel"]').forEach(function (p) { p.hidden = p.getAttribute("data-tab") !== tab; });
    refresh(screen, tab);
  }

  function bindTabs() {
    /* état ARIA initial, y compris pour les écrans pas encore ouverts */
    document.querySelectorAll('[role="tab"]').forEach(function (b) { b.setAttribute("aria-selected", "false"); b.tabIndex = -1; });
    document.querySelectorAll('[role="tablist"]').forEach(function (list) {
      var screen = list.closest(".screen").getAttribute("data-screen");
      list.addEventListener("click", function (ev) {
        var b = ev.target.closest('[role="tab"]');
        if (b) { location.hash = screen + "/" + b.getAttribute("data-tab"); }
      });
      list.addEventListener("keydown", function (ev) {
        if (ev.key !== "ArrowRight" && ev.key !== "ArrowLeft") { return; }
        var tabs = Array.prototype.slice.call(list.querySelectorAll('[role="tab"]'));
        var i = tabs.indexOf(document.activeElement);
        var next = tabs[(i + (ev.key === "ArrowRight" ? 1 : tabs.length - 1)) % tabs.length];
        next.focus();
        location.hash = screen + "/" + next.getAttribute("data-tab");
      });
    });
  }

  /* ---------------------------------------------------------- données */
  function refresh(screen, tab) {
    clearInterval(state.timer);
    var first = true;
    var run = function () {
      if (screen === "tableau") { loadStatus(); if (tab === "indicateurs") { loadMetrics(); } }
      if (screen === "telephonie") {
        if (tab === "appels") { loadCalls(); } else if (tab === "reseaux") { if (first) { loadNetworks(); } }
        else if (tab === "ligne") { loadLine(first); } else if (tab === "groupes") { loadGroups(first); }
        else if (tab === "messagerie") { if (first) { loadMail(); } } else { loadPbx(); }
      }
      if (screen === "systeme") {
        if (tab === "journaux" && (first || $("log-follow").checked)) { loadLogs(); }
        if (tab === "general") { loadStatus(); }
        if (tab === "maj") { loadUpdate(); }
        if (tab === "taches") { loadJobs(); }
        if (tab === "journal") { loadAudit(); }
        if (tab === "sauvegarde") { loadBackups(first); }
      }
    };
    run();
    first = false;
    state.timer = setInterval(run, screen === "systeme" && tab === "journaux" ? 5000 : 15000);
  }

  function loadStatus() {
    return api("GET", "/api/status").then(function (s) {
      $("kpi-mem").textContent = s.memory.percent + " %";
      $("kpi-disk").textContent = s.disk.percent + " %";
      $("kpi-uptime").textContent = fmtDuration(s.uptime);
      $("sys-hostname").textContent = s.hostname;
      $("sys-version").textContent = s.version;
      $("sys-os").textContent = s.os;
      $("sys-addresses").textContent = s.addresses.map(function (a) { return a.interface + " " + a.address; }).join(", ") || "–";
      var body = $("services-body");
      body.textContent = "";
      s.services.forEach(function (svc) {
        var tr = el("tr");
        tr.appendChild(el("td", svc.name));
        var td = el("td");
        var badge = el("span", t(svc.state === "active" ? "actif" : svc.state === "inactive" ? "inactif" : svc.state === "failed" ? "en échec" : "inconnu"),
          "state " + (svc.state === "active" ? "ok" : svc.state === "failed" ? "bad" : "warn"));
        td.appendChild(badge);
        tr.appendChild(td);
        body.appendChild(tr);
      });
    }).catch(function () {});
  }

  function loadPbx() {
    return api("GET", "/api/pbx").then(function (p) {
      var body = $("ext-body"), reg = $("reg-body"), count = 0;
      body.textContent = "";
      reg.textContent = "";
      state.extensions = p.extensions;
      $("ext-empty").hidden = p.extensions.length > 0;
      p.extensions.forEach(function (x) {
        var tr = el("tr");
        tr.appendChild(el("td", x.number));
        tr.appendChild(el("td", x.name));
        tr.appendChild(el("td", x.sip_user, x.sip_user === x.number ? "muted" : ""));
        tr.appendChild(el("td", x.voicemail ? (x.email ? t("oui") + ", " + x.email : t("oui")) : t("non")));
        var st = el("td");
        st.appendChild(el("span", x.registered ? t("enregistré") : t("non enregistré"), "state " + (x.registered ? "ok" : "warn")));
        tr.appendChild(st);
        var act = el("td");
        var show = el("button", t("Fiche"), "ghost small");
        show.type = "button";
        show.setAttribute("aria-label", t("Fiche du poste") + " " + x.number);
        show.addEventListener("click", function () { revealSecret(x.number, false); });
        var edit = el("button", t("Modifier"), "ghost small");
        edit.type = "button";
        edit.setAttribute("aria-label", t("Modifier le poste") + " " + x.number);
        edit.addEventListener("click", function () { openEdit(x); });
        var renew = el("button", t("Nouveau mot de passe"), "ghost small");
        renew.type = "button";
        renew.addEventListener("click", function () {
          confirmDialog(t("Nouveau mot de passe"), t("Le poste devra être reconfiguré avec le nouveau mot de passe SIP. Continuer ?")).then(function (ok) {
            if (ok) { revealSecret(x.number, true); }
          });
        });
        var del = el("button", t("Supprimer"), "danger small");
        del.type = "button";
        del.addEventListener("click", function () {
          confirmDialog(t("Supprimer"), t("Supprimer le poste") + " " + x.number + " ?").then(function (ok) {
            if (!ok) { return; }
            api("POST", "/api/pbx/delete", { number: x.number }).then(function () {
              toast(t("Poste supprimé."));
              loadPbx();
            }).catch(function (e) { toast(e.message); });
          });
        });
        act.appendChild(show); act.appendChild(edit); act.appendChild(renew); act.appendChild(del);
        tr.appendChild(act);
        body.appendChild(tr);
        if (x.registered) {
          count += 1;
          var r = el("tr");
          r.appendChild(el("td", x.number));
          r.appendChild(el("td", x.name));
          r.appendChild(el("td", x.user_agent || "–"));
          r.appendChild(el("td", x.network ? (x.network_label ? x.network_label + " (" + x.network + ")" : x.network) : t("hors réseaux déclarés")));
          r.appendChild(el("td", x.address || "–"));
          r.appendChild(el("td", x.rtt ? Math.round(parseFloat(x.rtt)) + " ms" : "–"));
          reg.appendChild(r);
        }
      });
      var run = $("pbx-running");
      run.textContent = "";
      run.appendChild(el("span", p.running ? t("actif") : p.running === false ? t("arrêté") : t("inconnu"),
        "state " + (p.running ? "ok" : "bad")));
      $("pbx-count").textContent = count + " / " + p.extensions.length;
      $("reg-empty").hidden = count > 0;
      var att = $("att-body");
      att.textContent = "";
      (p.attempts || []).forEach(function (a) {
        var tr = el("tr");
        tr.appendChild(el("td", a.user));
        tr.appendChild(el("td", a.address));
        tr.appendChild(el("td", a.network ? (a.network_label || a.network) : t("hors réseaux déclarés")));
        var why = el("td");
        why.appendChild(el("span", a.reason === "auth" ? t("mot de passe refusé") + " (" + a.extension + ")" : t("identifiant inconnu"), "state warn"));
        tr.appendChild(why);
        tr.appendChild(el("td", a.last + " (" + a.count + "×)"));
        var act = el("td");
        var b;
        if (a.reason === "auth") {
          b = el("button", t("Fiche"), "ghost small");
          b.addEventListener("click", function () { revealSecret(a.extension, false); });
        } else {
          b = el("button", t("Attribuer un numéro"), "primary small");
          b.addEventListener("click", function () {
            location.hash = "telephonie/postes";
            $("ext-sip").value = a.user;
            if (/^[1-9][0-9]{1,5}$/.test(a.user)) { $("ext-number").value = a.user; }
            $("ext-name").focus();
          });
        }
        b.type = "button";
        act.appendChild(b);
        tr.appendChild(act);
        att.appendChild(tr);
      });
      $("att-empty").hidden = (p.attempts || []).length > 0;
      $("pbx-calls").textContent = p.calls === null || p.calls === undefined ? "–" : String(p.calls);
    }).catch(function () {});
  }

  var DISPOSITIONS = { "ANSWERED": "répondu", "NO ANSWER": "sans réponse", "BUSY": "occupé", "FAILED": "échec", "CONGESTION": "échec" };

  var DIRECTIONS = { "interne": "interne", "sortant": "sortant", "entrant": "entrant" };

  function fmtCallDuration(s) {
    var m = Math.floor(s / 60), r = s % 60;
    return m + ":" + (r < 10 ? "0" : "") + r;
  }

  function loadCalls() {
    return api("GET", "/api/pbx/calls").then(function (d) {
      var body = $("calls-body");
      body.textContent = "";
      $("calls-empty").hidden = d.calls.length > 0;
      d.calls.forEach(function (c) {
        var tr = el("tr");
        tr.appendChild(el("td", c.start));
        tr.appendChild(el("td", t(DIRECTIONS[c.direction] || "interne")));
        tr.appendChild(el("td", c.src + (c.src_name ? " (" + c.src_name + ")" : "")));
        tr.appendChild(el("td", c.dst));
        tr.appendChild(el("td", c.disposition === "ANSWERED" ? fmtCallDuration(c.billsec) : "–"));
        var st = el("td");
        var label = c.voicemail ? t("messagerie") : t(DISPOSITIONS[c.disposition] || "échec");
        st.appendChild(el("span", label, "state " + (c.disposition === "ANSWERED" && !c.voicemail ? "ok" : c.voicemail ? "warn" : "bad")));
        tr.appendChild(st);
        body.appendChild(tr);
      });
    }).catch(function (e) { toast(e.message); });
  }

  function loadLogs() {
    var source = $("log-source").value;
    return api("GET", "/api/logs?source=" + encodeURIComponent(source)).then(function (d) {
      var box = $("log-lines");
      var atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 30;
      box.textContent = d.lines.length ? d.lines.join("\n") : t("Journal vide.");
      if (atBottom || box.dataset.source !== source) { box.scrollTop = box.scrollHeight; }
      box.dataset.source = source;
    }).catch(function (e) { toast(e.message); });
  }

  function bindOps() {
    $("log-source").addEventListener("change", loadLogs);
    $("restore-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("restore-message");
      msg.textContent = "";
      msg.className = "";
      var file = $("restore-file").files[0];
      if (!file) { msg.textContent = t("Choisissez un fichier de sauvegarde."); msg.className = "error"; return; }
      if (file.size > 900 * 1024) { msg.textContent = t("Ce fichier n'est pas une sauvegarde VOIPbuntu."); msg.className = "error"; return; }
      file.text().then(function (text) {
        var data;
        try { data = JSON.parse(text); } catch (e) { throw new Error(t("Ce fichier n'est pas une sauvegarde VOIPbuntu.")); }
        var count = data && data.pbx && Array.isArray(data.pbx.extensions) ? data.pbx.extensions.length : 0;
        return confirmDialog(t("Restaurer"), t("Remplacer la configuration actuelle par celle de la sauvegarde") + " (" + count + " " + (count === 1 ? t("poste") : t("postes")) + ") ?").then(function (ok) {
          if (!ok) { return; }
          return api("POST", "/api/restore", data).then(function (r) {
            ev.target.reset();
            msg.textContent = restoreDone(r);
          });
        });
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  function restoreDone(r) {
    return t("Configuration restaurée") + " : " + r.extensions + " " + (r.extensions === 1 ? t("poste") : t("postes")) +
      (r.networks !== null && r.networks !== undefined ? ", " + r.networks + " " + t("réseau(x) des téléphones") : "") + ".";
  }

  function loadBackups(fill) {
    return api("GET", "/api/backups").then(function (d) {
      var s = d.settings, st = d.status, last = $("auto-last");
      if (fill || !state.autoDirty) {
        $("auto-enabled").checked = s.enabled;
        $("auto-hour").value = s.hour;
        $("auto-keep").value = s.keep;
        $("auto-email").value = s.email;
      }
      last.textContent = "";
      if (st && st.last_run) {
        last.appendChild(el("span", fmtTime(st.last_run) + " : " + (st.ok ? (st.mail_failed ? t("faite, copie par e-mail en échec") : t("réussie")) : t("en échec")),
                            "state " + (st.ok && !st.mail_failed ? "ok" : st.ok ? "warn" : "bad")));
        if (st.message) { last.appendChild(el("div", st.message, "muted")); }
      } else {
        last.textContent = t("aucune pour l'instant");
      }
      var body = $("auto-body");
      body.textContent = "";
      $("auto-empty").hidden = d.backups.length > 0;
      d.backups.forEach(function (b) {
        var tr = el("tr");
        tr.appendChild(el("td", fmtTime(b.created)));
        tr.appendChild(el("td", b.name));
        tr.appendChild(el("td", fmtBytes(b.size)));
        var act = el("td"), dl = el("a", t("Télécharger"), "button ghost small"), rs = el("button", t("Restaurer"), "danger small");
        dl.href = "/api/backups/file?name=" + encodeURIComponent(b.name);
        dl.setAttribute("download", b.name);
        rs.type = "button";
        rs.setAttribute("aria-label", t("Restaurer") + " " + b.name);
        rs.addEventListener("click", function () {
          confirmDialog(t("Restaurer"), t("Remplacer la configuration actuelle par la sauvegarde du") + " " + fmtTime(b.created) + " ?").then(function (ok) {
            if (!ok) { return; }
            api("POST", "/api/backups/restore", { name: b.name }).then(function (r) { toast(restoreDone(r)); })
              .catch(function (e) { toast(e.message); });
          });
        });
        act.appendChild(dl); act.appendChild(rs); tr.appendChild(act);
        body.appendChild(tr);
      });
    }).catch(function (e) { toast(e.message); });
  }

  function bindBackups() {
    $("auto-form").addEventListener("input", function () { state.autoDirty = true; });
    $("auto-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("auto-message"), hour = parseInt($("auto-hour").value, 10), keep = parseInt($("auto-keep").value, 10);
      msg.textContent = ""; msg.className = "";
      api("POST", "/api/backups/settings", { enabled: $("auto-enabled").checked, hour: isNaN(hour) ? -1 : hour,
                                             keep: isNaN(keep) ? 0 : keep, email: $("auto-email").value.trim() }).then(function () {
        state.autoDirty = false;
        msg.textContent = t("Réglages enregistrés.");
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
    $("auto-now").addEventListener("click", function () {
      var msg = $("auto-message");
      api("POST", "/api/jobs", { action: "backup-run" }).then(function () {
        msg.textContent = t("Sauvegarde demandée : elle apparaît ci-dessous dans quelques secondes."); msg.className = "";
        setTimeout(function () { loadBackups(false); }, 4000);
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  function showSheet(d, title) {
    $("sheet-title").textContent = title + " " + d.number;
    $("sheet-server").textContent = (d.servers && d.servers.length ? d.servers.join(t(" ou ")) : location.hostname);
    $("sheet-port").textContent = d.port + " / " + d.transport;
    $("sheet-user").textContent = d.sip_user || d.number;
    $("sheet-auth").textContent = d.sip_user || d.number;
    $("sheet-secret").textContent = d.secret;
    $("sheet-name").textContent = d.name;
    $("sheet-vm").textContent = d.voicemail ? d.voicemail_code + " · " + t("Code de messagerie") + " : " + d.pin : t("non");
    $("sheet").showModal();
  }

  function revealSecret(number, renew) {
    api("POST", "/api/pbx/secret", { number: number, renew: renew }).then(function (d) {
      showSheet(d, t("Fiche du poste"));
      if (renew) { loadPbx(); }
    }).catch(function (e) { toast(e.message); });
  }

  function openEdit(x) {
    state.editing = x.number;
    $("edit-title").textContent = t("Modifier le poste") + " " + x.number;
    $("edit-number").value = x.number;
    $("edit-name").value = x.name;
    $("edit-voicemail").checked = x.voicemail;
    $("edit-email").value = x.email || "";
    $("edit-message").textContent = "";
    $("edit").showModal();
    $("edit-number").focus();
  }

  /* ---------------------------------------------------------- réseaux */
  function netRow(n) {
    var tr = el("tr");
    tr.dataset.cidr = n.cidr;
    tr.appendChild(el("td", n.cidr));
    var td = el("td");
    var input = el("input");
    input.value = n.label || "";
    input.maxLength = 40;
    input.className = "net-label";
    input.setAttribute("aria-label", t("Nom") + " " + n.cidr);
    td.appendChild(input);
    tr.appendChild(td);
    var st = el("td");
    st.appendChild(el("span", n.removing ? t("retrait en attente") : n.applied ? t("appliqué") : t("à appliquer"),
      "state " + (n.applied && !n.removing ? "ok" : "warn")));
    tr.appendChild(st);
    var act = el("td");
    var del = el("button", t("Retirer"), "danger small");
    del.type = "button";
    del.addEventListener("click", function () { state.netDirty = true; tr.remove(); });
    input.addEventListener("input", function () { state.netDirty = true; });
    act.appendChild(del);
    tr.appendChild(act);
    return tr;
  }

  function loadNetworks() {
    return api("GET", "/api/networks").then(function (d) {
      if (state.netDirty) { return; }  /* modifications en cours : ne pas les écraser */
      var body = $("net-body");
      body.textContent = "";
      d.networks.forEach(function (n) {
        if (d.pending_removal.indexOf(n.cidr) < 0) { body.appendChild(netRow(n)); }
      });
    }).catch(function (e) { toast(e.message); });
  }

  function bindNetworks() {
    $("net-add").addEventListener("click", function () {
      var cidr = $("net-cidr").value.trim(), msg = $("net-message");
      msg.textContent = ""; msg.className = "";
      if (!/^[0-9a-fA-F.:]+(\/[0-9]{1,3})?$/.test(cidr)) { msg.textContent = t("Réseau invalide, par exemple 192.168.20.0/24."); msg.className = "error"; return; }
      state.netDirty = true;
      $("net-body").appendChild(netRow({ cidr: cidr, label: $("net-label").value.trim(), applied: false }));
      $("net-cidr").value = ""; $("net-label").value = "";
    });
    $("net-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("net-message");
      msg.textContent = ""; msg.className = "";
      var list = Array.prototype.map.call($("net-body").querySelectorAll("tr"), function (tr) {
        return { cidr: tr.dataset.cidr, label: tr.querySelector(".net-label").value.trim() };
      });
      var go = list.length ? Promise.resolve(true)
        : confirmDialog(t("Réseaux des téléphones"), t("Sans aucun réseau, plus aucun téléphone ne pourra joindre la téléphonie. Continuer ?"));
      go.then(function (ok) {
        if (!ok) { return; }
        return api("POST", "/api/networks", { networks: list }).then(function (r) {
          state.netDirty = false;
          msg.textContent = r.applied ? t("Réseaux enregistrés : application en cours (pare-feu).") : t("Réseaux enregistrés, mais la file d'attente est indisponible.");
          setTimeout(loadNetworks, 4000);
        });
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  /* ------------------------------------------------ ligne et accueil */
  var DAY_LABELS = [["mon", "lun."], ["tue", "mar."], ["wed", "mer."], ["thu", "jeu."], ["fri", "ven."], ["sat", "sam."], ["sun", "dim."]];
  var TRUNK_STATES = { "registered": ["enregistrée auprès de l'opérateur", "ok"], "unregistered": ["en cours d'enregistrement", "warn"],
                       "rejected": ["refusée par l'opérateur : vérifiez l'identifiant et le mot de passe", "bad"] };

  function trunkState(p) {
    var box = $("trunk-state"), tr = p.trunk;
    box.textContent = "";
    if (!tr.enabled) { box.appendChild(el("span", t("désactivée"), "state")); return; }
    if (!tr.register) { box.appendChild(el("span", t("active, sans enregistrement"), "state ok")); return; }
    var st = TRUNK_STATES[tr.state] || ["inconnu", "warn"];
    box.appendChild(el("span", t(st[0]), "state " + st[1]));
  }

  function fillLine(p) {
    var tr = p.trunk, rec = p.reception;
    $("trunk-enabled").checked = tr.enabled;
    $("trunk-host").value = tr.host;
    $("trunk-port").value = tr.port;
    $("trunk-user").value = tr.username;
    $("trunk-auth").value = tr.auth_username;
    $("trunk-pass").value = "";
    $("trunk-pass").placeholder = tr.password_set ? t("inchangé") : "";
    $("trunk-cid").value = tr.caller_id;
    $("trunk-public").value = tr.public_address;
    $("trunk-register").checked = tr.register;
    $("trunk-intl").checked = tr.international;
    var members = $("rec-members"), box = $("rec-box");
    members.textContent = "";
    p.extensions.forEach(function (x) {
      var label = el("label", null, "check"), input = el("input");
      input.type = "checkbox"; input.value = x.number; input.checked = rec.members.indexOf(x.number) >= 0;
      label.appendChild(input);
      label.appendChild(el("span", x.number + " " + x.name));
      members.appendChild(label);
    });
    if (!p.extensions.length) { members.appendChild(el("p", t("Aucun poste : créez d'abord les postes."), "muted")); }
    box.textContent = "";
    var none = el("option", t("aucune (raccrocher)")); none.value = ""; box.appendChild(none);
    p.extensions.forEach(function (x) {
      if (!x.voicemail) { return; }
      var o = el("option", x.number + " " + x.name); o.value = x.number; box.appendChild(o);
    });
    box.value = rec.voicemail_box;
    $("rec-ring").value = rec.ring_seconds;
    $("rec-hours-on").checked = !!rec.hours;
    var days = rec.hours ? rec.hours.days : ["mon", "tue", "wed", "thu", "fri"];
    $("rec-days").querySelectorAll("input").forEach(function (i) { i.checked = days.indexOf(i.value) >= 0; });
    $("rec-start").value = rec.hours ? rec.hours.start : "09:00";
    $("rec-end").value = rec.hours ? rec.hours.end : "18:00";
    $("rec-hours").hidden = !rec.hours;
  }

  function loadLine(fill) {
    return api("GET", "/api/pbx").then(function (p) {
      trunkState(p);
      if (fill || !state.lineDirty) { fillLine(p); }
    }).catch(function (e) { toast(e.message); });
  }

  function bindLine() {
    var days = $("rec-days");
    DAY_LABELS.forEach(function (d) {
      var label = el("label", null, "check"), input = el("input");
      input.type = "checkbox"; input.value = d[0];
      label.appendChild(input);
      label.appendChild(el("span", d[1]));
      label.lastChild.setAttribute("data-i18n", "");
      days.appendChild(label);
    });
    ["trunk-form", "rec-form"].forEach(function (id) {
      $(id).addEventListener("input", function () { state.lineDirty = true; });
      $(id).addEventListener("change", function () { state.lineDirty = true; });
    });
    $("rec-hours-on").addEventListener("change", function () { $("rec-hours").hidden = !$("rec-hours-on").checked; });
    $("trunk-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("trunk-message");
      msg.textContent = ""; msg.className = "";
      var port = parseInt($("trunk-port").value, 10);
      api("POST", "/api/pbx/trunk", {
        enabled: $("trunk-enabled").checked, host: $("trunk-host").value.trim(), port: isNaN(port) ? 0 : port,
        username: $("trunk-user").value.trim(), auth_username: $("trunk-auth").value.trim(),
        password: $("trunk-pass").value, caller_id: $("trunk-cid").value.trim(),
        public_address: $("trunk-public").value.trim(), register: $("trunk-register").checked,
        international: $("trunk-intl").checked
      }).then(function (r) {
        state.lineDirty = false;
        msg.textContent = r.applied ? t("Ligne enregistrée : application en cours.") : t("Ligne enregistrée, mais la file d'attente est indisponible.");
        setTimeout(function () { loadLine(true); }, 4000);
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
    $("rec-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("rec-message");
      msg.textContent = ""; msg.className = "";
      var ring = parseInt($("rec-ring").value, 10);
      var hours = null;
      if ($("rec-hours-on").checked) {
        hours = { days: Array.prototype.filter.call(days.querySelectorAll("input"), function (i) { return i.checked; }).map(function (i) { return i.value; }),
                  start: $("rec-start").value, end: $("rec-end").value };
      }
      api("POST", "/api/pbx/reception", {
        members: Array.prototype.filter.call($("rec-members").querySelectorAll("input"), function (i) { return i.checked; }).map(function (i) { return i.value; }),
        ring_seconds: isNaN(ring) ? 0 : ring, hours: hours, voicemail_box: $("rec-box").value
      }).then(function (r) {
        state.lineDirty = false;
        msg.textContent = r.applied ? t("Accueil enregistré : application en cours.") : t("Accueil enregistré, mais la file d'attente est indisponible.");
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  /* ----------------------------------------------- groupes et renvois */
  var FORWARD_MODES = [["off", "aucun"], ["always", "toujours"], ["noanswer", "sans réponse"]];

  function checkboxes(box, extensions, selected) {
    box.textContent = "";
    extensions.forEach(function (x) {
      var label = el("label", null, "check"), input = el("input");
      input.type = "checkbox"; input.value = x.number; input.checked = selected.indexOf(x.number) >= 0;
      label.appendChild(input);
      label.appendChild(el("span", x.number + " " + x.name));
      box.appendChild(label);
    });
  }

  function boxOptions(select, extensions, value) {
    select.textContent = "";
    var none = el("option", t("aucune (raccrocher)")); none.value = ""; select.appendChild(none);
    extensions.forEach(function (x) {
      if (!x.voicemail) { return; }
      var o = el("option", x.number + " " + x.name); o.value = x.number; select.appendChild(o);
    });
    select.value = value || "";
  }

  function resetGroupForm() {
    $("grp-edit").value = "";
    $("grp-number").value = ""; $("grp-number").disabled = false;
    $("grp-name").value = ""; $("grp-ring").value = "25";
    $("grp-title").textContent = t("Ajouter un groupe");
    $("grp-cancel").hidden = true;
    checkboxes($("grp-members"), state.pbx.extensions, []);
    boxOptions($("grp-box"), state.pbx.extensions, "");
  }

  function editGroup(g) {
    $("grp-edit").value = g.number;
    $("grp-number").value = g.number;
    $("grp-name").value = g.name;
    $("grp-ring").value = g.ring_seconds;
    $("grp-title").textContent = t("Modifier le groupe") + " " + g.number;
    $("grp-cancel").hidden = false;
    checkboxes($("grp-members"), state.pbx.extensions, g.members);
    boxOptions($("grp-box"), state.pbx.extensions, g.voicemail_box);
    $("grp-name").focus();
  }

  function saveGroups(groups, msg, done) {
    msg.textContent = ""; msg.className = "";
    return api("POST", "/api/pbx/groups", { groups: groups }).then(function (r) {
      state.grpDirty = false;
      msg.textContent = r.applied ? t("Groupes enregistrés : application en cours.") : t("Groupes enregistrés, mais la file d'attente est indisponible.");
      if (done) { done(); }
      return loadGroups(true);
    }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
  }

  function forwardRow(x, p) {
    var tr = el("tr"), f = x.forward;
    tr.dataset.number = x.number;
    tr.appendChild(el("td", x.number + " " + x.name));
    var mode = el("select", null, "fwd-mode"), td = el("td");
    mode.setAttribute("aria-label", t("Renvoi du poste") + " " + x.number);
    FORWARD_MODES.forEach(function (m) { var o = el("option", t(m[1])); o.value = m[0]; mode.appendChild(o); });
    mode.value = f.mode;
    td.appendChild(mode); tr.appendChild(td);
    var target = el("input", null, "fwd-target"); td = el("td");
    target.setAttribute("list", "fwd-targets"); target.maxLength = 20; target.value = f.target;
    target.setAttribute("aria-label", t("Destination du renvoi") + " " + x.number);
    td.appendChild(target); tr.appendChild(td);
    var ring = el("input", null, "fwd-ring"); td = el("td");
    ring.inputMode = "numeric"; ring.maxLength = 3; ring.value = f.ring_seconds; ring.size = 3;
    ring.setAttribute("aria-label", t("Durée de sonnerie (secondes)") + " " + x.number);
    td.appendChild(ring); tr.appendChild(td);
    var sync = function () { target.disabled = mode.value === "off"; ring.disabled = mode.value !== "noanswer"; };
    mode.addEventListener("change", function () { state.grpDirty = true; sync(); });
    target.addEventListener("input", function () { state.grpDirty = true; });
    ring.addEventListener("input", function () { state.grpDirty = true; });
    sync();
    var save = el("button", t("Enregistrer"), "ghost small"); td = el("td");
    save.type = "button";
    save.addEventListener("click", function () {
      var msg = $("fwd-message"), secs = parseInt(ring.value, 10);
      msg.textContent = ""; msg.className = "";
      api("POST", "/api/pbx/forward", { number: x.number, mode: mode.value, target: target.value.trim(),
                                         ring_seconds: isNaN(secs) ? 0 : secs }).then(function (r) {
        state.grpDirty = false;
        msg.textContent = t("Renvoi du poste") + " " + x.number + " : " + (r.applied ? t("enregistré, application en cours.") : t("enregistré, mais la file d'attente est indisponible."));
        loadGroups(true);
      }).catch(function (e) { msg.textContent = x.number + " : " + e.message; msg.className = "error"; });
    });
    td.appendChild(save); tr.appendChild(td);
    return tr;
  }

  function loadGroups(fill) {
    return api("GET", "/api/pbx").then(function (p) {
      if (!fill && state.grpDirty) { return; }
      state.pbx = p;
      var body = $("grp-body"), names = {};
      p.extensions.forEach(function (x) { names[x.number] = x.name; });
      body.textContent = "";
      $("grp-empty").hidden = p.groups.length > 0;
      p.groups.forEach(function (g) {
        var tr = el("tr");
        tr.appendChild(el("td", g.number));
        tr.appendChild(el("td", g.name));
        tr.appendChild(el("td", g.members.map(function (m) { return m + " " + (names[m] || ""); }).join(", ")));
        tr.appendChild(el("td", g.ring_seconds + " s"));
        tr.appendChild(el("td", g.voicemail_box || "–"));
        var act = el("td"), edit = el("button", t("Modifier"), "ghost small"), del = el("button", t("Supprimer"), "danger small");
        edit.type = "button"; del.type = "button";
        edit.setAttribute("aria-label", t("Modifier le groupe") + " " + g.number);
        del.setAttribute("aria-label", t("Supprimer le groupe") + " " + g.number);
        edit.addEventListener("click", function () { editGroup(g); });
        del.addEventListener("click", function () {
          confirmDialog(t("Supprimer"), t("Supprimer le groupe") + " " + g.number + " ?").then(function (ok) {
            if (!ok) { return; }
            saveGroups(p.groups.filter(function (o) { return o.number !== g.number; }), $("grp-message"));
          });
        });
        act.appendChild(edit); act.appendChild(del); tr.appendChild(act);
        body.appendChild(tr);
      });
      if (!$("grp-edit").value) { resetGroupForm(); }
      var list = $("fwd-targets");
      list.textContent = "";
      p.extensions.concat(p.groups).forEach(function (x) { var o = el("option"); o.value = x.number; o.label = x.name; list.appendChild(o); });
      var fwd = $("fwd-body");
      fwd.textContent = "";
      p.extensions.forEach(function (x) { fwd.appendChild(forwardRow(x, p)); });
    }).catch(function (e) { toast(e.message); });
  }

  function bindGroups() {
    $("grp-form").addEventListener("input", function () { state.grpDirty = true; });
    $("grp-cancel").addEventListener("click", function () { state.grpDirty = false; resetGroupForm(); });
    $("grp-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var editing = $("grp-edit").value, ring = parseInt($("grp-ring").value, 10);
      var g = { number: $("grp-number").value.trim(), name: $("grp-name").value.trim(),
                members: Array.prototype.filter.call($("grp-members").querySelectorAll("input"), function (i) { return i.checked; }).map(function (i) { return i.value; }),
                ring_seconds: isNaN(ring) ? 0 : ring, voicemail_box: $("grp-box").value };
      var groups = (state.pbx ? state.pbx.groups : []).filter(function (o) { return o.number !== editing; });
      groups.push(g);
      saveGroups(groups, $("grp-message"), resetGroupForm);
    });
  }

  /* ------------------------------------------- messagerie par e-mail */
  function loadMail() {
    return api("GET", "/api/pbx").then(function (p) {
      var m = p.mail;
      $("mail-enabled").checked = m.enabled;
      $("mail-host").value = m.host;
      $("mail-port").value = m.port;
      $("mail-security").value = m.security;
      $("mail-user").value = m.username;
      $("mail-pass").value = "";
      $("mail-pass").placeholder = m.password_set ? t("inchangé") : "";
      $("mail-from").value = m.from_address;
      $("mail-test").disabled = !m.enabled;
      $("mail-form").dataset.loaded = "1";
      var missing = p.extensions.filter(function (x) { return x.voicemail && !x.email; }).length;
      if (m.enabled && missing) {
        $("mail-message").textContent = missing + " " + t("poste(s) avec messagerie sans adresse e-mail : à renseigner dans Postes > Modifier.");
        $("mail-message").className = "";
      }
    }).catch(function (e) { toast(e.message); });
  }

  function bindMail() {
    $("mail-security").addEventListener("change", function () {
      var port = { starttls: "587", tls: "465", none: "25" }[$("mail-security").value];
      if (["587", "465", "25", ""].indexOf($("mail-port").value) >= 0) { $("mail-port").value = port; }
    });
    $("mail-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("mail-message"), port = parseInt($("mail-port").value, 10);
      msg.textContent = ""; msg.className = "";
      api("POST", "/api/pbx/mail", {
        enabled: $("mail-enabled").checked, host: $("mail-host").value.trim(), port: isNaN(port) ? 0 : port,
        security: $("mail-security").value, username: $("mail-user").value.trim(), password: $("mail-pass").value,
        from_address: $("mail-from").value.trim()
      }).then(function (r) {
        msg.textContent = r.applied ? t("Réglages enregistrés : application en cours.") : t("Réglages enregistrés, mais la file d'attente est indisponible.");
        $("mail-pass").value = "";
        $("mail-pass").placeholder = r.mail.password_set ? t("inchangé") : "";
        $("mail-test").disabled = !r.mail.enabled;
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
    $("mail-test").addEventListener("click", function () {
      var msg = $("mail-message");
      api("POST", "/api/jobs", { action: "mail-test" }).then(function () {
        msg.textContent = t("E-mail d'essai demandé : résultat dans Système > Tâches."); msg.className = "";
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  function bindPbx() {
    bindNetworks();
    $("edit-cancel").addEventListener("click", function () { $("edit").close(); });
    $("edit-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("edit-message");
      msg.textContent = ""; msg.className = "";
      api("POST", "/api/pbx/update", { number: state.editing, new_number: $("edit-number").value.trim(),
        name: $("edit-name").value.trim(), voicemail: $("edit-voicemail").checked,
        email: $("edit-email").value.trim() }).then(function () {
        $("edit").close();
        toast(t("Poste modifié."));
        loadPbx();
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
    $("sheet-close").addEventListener("click", function () { $("sheet").close(); });
    $("sheet-print").addEventListener("click", function () { window.print(); });
    $("ext-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("ext-message");
      msg.textContent = "";
      api("POST", "/api/pbx/extensions", {
        number: $("ext-number").value.trim(), name: $("ext-name").value.trim(), voicemail: $("ext-voicemail").checked,
        sip_user: $("ext-sip").value.trim(), email: $("ext-email").value.trim()
      }).then(function (d) {
        $("ext-form").reset();
        loadPbx();
        showSheet(d, t("Poste créé"));
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  function loadUpdate() {
    return api("GET", "/api/update").then(function (u) {
      $("upd-current").textContent = u.current || "–";
      $("upd-latest").textContent = u.latest || "–";
      $("upd-checked").textContent = u.checked ? fmtTime(u.checked) : t("jamais");
      var st = $("upd-state");
      st.textContent = "";
      var label = u.error ? t("vérification en échec") : u.available ? t("nouvelle version disponible") : u.latest ? t("à jour") : t("non vérifié");
      st.appendChild(el("span", label, "state " + (u.error ? "bad" : u.available ? "warn" : u.latest ? "ok" : "warn")));
      if (u.error) { st.appendChild(el("span", " " + u.error, "muted")); }
      $("upd-notes").textContent = u.notes || "–";
      $("upd-apply").disabled = !u.available;
    }).catch(function () {});
  }

  function loadMetrics() {
    return api("GET", "/api/metrics?range=" + encodeURIComponent(state.range)).then(function (m) {
      state.series = m;
      var cpu = last(m.cpu), rx = last(m.rx), tx = last(m.tx);
      $("kpi-cpu").textContent = cpu === null ? "–" : cpu + " %";
      $("kpi-net").textContent = rx === null ? "–" : "↓ " + fmtBytes(rx) + "/s ↑ " + fmtBytes(tx) + "/s";
      drawChart();
    }).catch(function () {});
  }

  function drawChart() {
    var m = state.series;
    var box = $("chart");
    box.textContent = "";
    if (!m) { return; }
    var lines = state.metric === "net" ? [["rx", t("Reçu")], ["tx", t("Émis")]] : [[state.metric, ""]];
    var W = 720, H = 220, L = 56, R = 12, T = 12, B = 28;
    var max = 0;
    lines.forEach(function (l) { m[l[0]].forEach(function (v) { if (v !== null && v > max) { max = v; } }); });
    if (state.metric === "cpu" || state.metric === "mem") { max = 100; }
    if (!max) { max = 1; }
    var n = m.t.length;
    var x = function (i) { return L + (W - L - R) * (i / (n - 1)); };
    var y = function (v) { return T + (H - T - B) * (1 - v / max); };
    var root = svg("svg", { viewBox: "0 0 " + W + " " + H, preserveAspectRatio: "none", "class": "chart-svg" });
    for (var g = 0; g <= 4; g++) {
      var gv = max * g / 4;
      root.appendChild(svg("line", { x1: L, x2: W - R, y1: y(gv), y2: y(gv), "class": "grid" }));
      var label = svg("text", { x: L - 6, y: y(gv) + 4, "text-anchor": "end", "class": "axis" });
      label.textContent = state.metric === "net" ? fmtBytes(gv) : (Math.round(gv * 10) / 10).toString();
      root.appendChild(label);
    }
    [0, Math.floor(n / 2), n - 1].forEach(function (i) {
      var tl = svg("text", { x: x(i), y: H - 8, "text-anchor": i === 0 ? "start" : i === n - 1 ? "end" : "middle", "class": "axis" });
      tl.textContent = new Date(m.t[i] * 1000).toLocaleTimeString(window.I18N.lang() === "en" ? "en-GB" : "fr-FR", { hour: "2-digit", minute: "2-digit" });
      root.appendChild(tl);
    });
    lines.forEach(function (l, li) {
      var values = m[l[0]], d = "", pen = false;
      values.forEach(function (v, i) {
        if (v === null) { pen = false; return; }
        d += (pen ? "L" : "M") + x(i).toFixed(1) + " " + y(v).toFixed(1);
        var isolated = (i === 0 || values[i - 1] === null) && (i === n - 1 || values[i + 1] === null);
        if (isolated) { root.appendChild(svg("circle", { cx: x(i), cy: y(v), r: 2.5, "class": "dot s" + li })); }
        pen = true;
      });
      if (d) { root.appendChild(svg("path", { d: d, "class": "line s" + li })); }
    });
    var cursor = svg("line", { x1: 0, x2: 0, y1: T, y2: H - B, "class": "cursor", visibility: "hidden" });
    root.appendChild(cursor);
    var tip = $("chart-tip");
    root.addEventListener("mousemove", function (ev) {
      var rect = root.getBoundingClientRect();
      var px = (ev.clientX - rect.left) / rect.width * W;
      var i = Math.max(0, Math.min(n - 1, Math.round((px - L) / (W - L - R) * (n - 1))));
      cursor.setAttribute("x1", x(i)); cursor.setAttribute("x2", x(i)); cursor.setAttribute("visibility", "visible");
      var parts = [new Date(m.t[i] * 1000).toLocaleTimeString(window.I18N.lang() === "en" ? "en-GB" : "fr-FR")];
      lines.forEach(function (l) {
        var v = m[l[0]][i];
        parts.push((l[1] ? l[1] + " : " : "") + (v === null ? "–" : state.metric === "net" ? fmtBytes(v) + "/s" : v));
      });
      tip.textContent = parts.join("  ·  ");
      tip.hidden = false;
    });
    root.addEventListener("mouseleave", function () { cursor.setAttribute("visibility", "hidden"); tip.hidden = true; });
    box.appendChild(root);
  }

  function loadJobs() {
    return api("GET", "/api/jobs").then(function (data) {
      var body = $("jobs-body");
      body.textContent = "";
      (data.jobs || []).forEach(function (j) {
        var tr = el("tr");
        tr.appendChild(el("td", String(j.id)));
        tr.appendChild(el("td", t(JOB_LABELS[j.action] || j.action)));
        tr.appendChild(el("td", j.user || "–"));
        var st = el("td");
        st.appendChild(el("span", t(JOB_STATES[j.state] || j.state), "state " + (j.state === "done" ? "ok" : j.state === "failed" ? "bad" : "warn")));
        tr.appendChild(st);
        tr.appendChild(el("td", j.started ? fmtTime(j.started) : "–"));
        tr.tabIndex = 0;
        tr.addEventListener("click", function () { var out = $("job-output"); out.textContent = j.output || ""; out.hidden = !j.output; });
        body.appendChild(tr);
      });
    }).catch(function (e) { toast(e.message); });
  }

  function loadAudit() {
    return api("GET", "/api/audit").then(function (data) {
      var body = $("audit-body");
      body.textContent = "";
      data.events.forEach(function (ev) {
        var tr = el("tr");
        tr.appendChild(el("td", fmtTime(ev.ts)));
        tr.appendChild(el("td", ev.user || "–"));
        tr.appendChild(el("td", ev.remote || "–"));
        tr.appendChild(el("td", ev.event, ev.event.indexOf("failed") >= 0 ? "error-text" : ""));
        body.appendChild(tr);
      });
    }).catch(function () {});
  }

  var JOB_LABELS = {
    "apt-refresh": "Rechercher les mises à jour Ubuntu",
    "update-check": "Rechercher une nouvelle version",
    "update-apply": "Installer la nouvelle version",
    "pbx-apply": "Appliquer la configuration téléphonique",
    "networks-apply": "Appliquer les réseaux des téléphones",
    "mail-test": "Envoyer un e-mail d'essai",
    "backup-run": "Sauvegarder maintenant",
    "apt-security-upgrade": "Installer les correctifs de sécurité",
    "restart-web": "Redémarrer la console",
    "reboot": "Redémarrer l'appliance",
    "poweroff": "Arrêter l'appliance"
  };
  var JOB_STATES = { queued: "en attente", running: "en cours", done: "terminée", failed: "en échec" };

  function bindJobs() {
    document.querySelectorAll("[data-job]").forEach(function (b) {
      b.addEventListener("click", function () {
        var action = b.getAttribute("data-job");
        confirmDialog(t(JOB_LABELS[action]), t("Cette action est ajoutée à la file d'attente. Continuer ?")).then(function (ok) {
          if (!ok) { return; }
          api("POST", "/api/jobs", { action: action }).then(function () {
            toast(t("Tâche ajoutée à la file d'attente."));
            if (location.hash.indexOf("taches") >= 0) { loadJobs(); }
            if (location.hash.indexOf("maj") >= 0) { setTimeout(loadUpdate, 3000); }
          }).catch(function (e) { toast(e.message); });
        });
      });
    });
  }

  /* ---------------------------------------------------------- session */
  function showLogin() {
    clearInterval(state.timer);
    $("app-view").hidden = true;
    $("login-view").hidden = false;
    $("login-user").focus();
  }

  function showApp(session) {
    state.csrf = session.csrf;
    $("whoami").textContent = session.user;
    $("version").textContent = "v" + session.version;
    $("login-view").hidden = true;
    $("app-view").hidden = false;
    route();
  }

  function setLang(lang) {
    document.cookie = "pxb_lang=" + lang + "; Path=/; SameSite=Strict; Secure; Max-Age=31536000";
    return window.I18N.load(lang).then(function () {
      window.I18N.apply();
      $("lang-toggle").textContent = lang === "fr" ? "EN" : "FR";
      if (state.series) { drawChart(); }
    });
  }

  function setTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    try { localStorage.setItem("pxb_theme", theme); } catch (e) { /* stockage indisponible */ }
  }

  function init() {
    var saved = null;
    try { saved = localStorage.getItem("pxb_theme"); } catch (e) { saved = null; }
    if (saved) { setTheme(saved); }
    bindTabs();
    bindJobs();
    bindPbx();
    bindLine();
    bindGroups();
    bindMail();
    bindBackups();
    bindOps();
    window.addEventListener("hashchange", route);
    $("theme-toggle").addEventListener("click", function () {
      var dark = document.documentElement.getAttribute("data-theme") === "dark" ||
        (!document.documentElement.getAttribute("data-theme") && window.matchMedia("(prefers-color-scheme: dark)").matches);
      setTheme(dark ? "light" : "dark");
    });
    $("lang-toggle").addEventListener("click", function () { setLang(window.I18N.lang() === "fr" ? "en" : "fr"); });
    document.querySelectorAll("[data-range]").forEach(function (b) {
      b.addEventListener("click", function () {
        state.range = b.getAttribute("data-range");
        document.querySelectorAll("[data-range]").forEach(function (o) { o.setAttribute("aria-pressed", o === b ? "true" : "false"); });
        loadMetrics();
      });
    });
    $("chart-metric").addEventListener("change", function (ev) { state.metric = ev.target.value; drawChart(); });
    $("login-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      $("login-error").textContent = "";
      api("POST", "/api/login", { username: $("login-user").value.trim(), password: $("login-pass").value })
        .then(function (s) { $("login-pass").value = ""; return api("GET", "/api/session").then(showApp); })
        .catch(function (e) { $("login-error").textContent = e.message; });
    });
    $("logout").addEventListener("click", function () {
      api("POST", "/api/logout", {}).then(showLogin, showLogin);
    });
    $("password-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("pw-message");
      msg.className = "";
      if ($("pw-new").value !== $("pw-confirm").value) {
        msg.textContent = t("Les deux mots de passe ne correspondent pas.");
        msg.className = "error";
        return;
      }
      api("POST", "/api/password", { current: $("pw-current").value, "new": $("pw-new").value }).then(function (r) {
        state.csrf = r.csrf;
        ev.target.reset();
        msg.textContent = t("Mot de passe modifié.");
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });

    api("GET", "/api/session").then(function (s) {
      return setLang(s.lang).then(function () {
        $("login-unconfigured").hidden = s.configured;
        if (s.user) { showApp(s); } else { showLogin(); }
      });
    }).catch(showLogin);
  }

  document.addEventListener("DOMContentLoaded", init);
})();
