"""Serveur LDAP v3 en lecture seule de VOIPbuntu (annuaire des téléphones).

Bibliothèque standard uniquement. Il sert les entrées écrites par voipbuntu-ldap
(base.json) avec les réglages de server.json, relus dès qu'ils changent :
- bind simple avec le compte de lecture (empreinte PBKDF2), ou anonyme si permis ;
- search sur base, un niveau ou sous-arbre, filtres égalité, sous-chaîne, présence,
  >=, <=, approximatif, & | ! ; les numéros sont comparés chiffres seuls, après
  normalisation (+33 6…, 06.…), les noms sans casse ni accents ;
- toute écriture (add, modify, delete, modrdn) est refusée : unwillingToPerform ;
- seules les adresses des réseaux des téléphones (et la boucle locale) sont servies.
"""

import ipaddress
import json
import logging
import os
import re
import socket
import socketserver
import threading
import time
import unicodedata

from . import directory, security

LOG = logging.getLogger("voipbuntu-ldap")
MAX_MESSAGE = 64 * 1024
MAX_CLIENTS = 32
MAX_RESULTS = 250
MAX_FILTER_DEPTH = 12
IDLE_TIMEOUT = 60
# Échecs de bind tolérés par adresse et par minute, au-delà les binds sont refusés d'office
MAX_BIND_FAILURES = 5

# Codes de résultat (RFC 4511)
SUCCESS, OPERATIONS_ERROR, PROTOCOL_ERROR, SIZE_LIMIT = 0, 1, 2, 4
COMPARE_FALSE, COMPARE_TRUE = 5, 6
AUTH_METHOD_NOT_SUPPORTED, UNAVAILABLE_CRITICAL = 7, 12
NO_SUCH_OBJECT, INVALID_DN = 32, 34
INVALID_CREDENTIALS, INSUFFICIENT_ACCESS, UNWILLING = 49, 50, 53

PHONE_ATTRS = {"telephonenumber", "mobile", "homephone"}
ALIASES = {"commonname": "cn", "surname": "sn", "gn": "givenname", "organizationname": "o",
           "mobiletelephonenumber": "mobile", "hometelephonenumber": "homephone", "userid": "uid",
           "objectclass": "objectclass"}


class ProtocolError(Exception):
    pass


# ------------------------------------------------------------------ BER
def read_tlv(data, pos):
    """(étiquette, contenu, position suivante) ; formes de longueur définies seulement (LDAP)."""
    if pos + 2 > len(data):
        raise ProtocolError("message tronqué")
    tag = data[pos]
    if tag & 0x1f == 0x1f:
        raise ProtocolError("étiquette longue")
    length = data[pos + 1]
    pos += 2
    if length & 0x80:
        count = length & 0x7f
        if count == 0 or count > 4 or pos + count > len(data):
            raise ProtocolError("longueur invalide")
        length = int.from_bytes(data[pos:pos + count], "big")
        pos += count
    if pos + length > len(data):
        raise ProtocolError("message tronqué")
    return tag, data[pos:pos + length], pos + length


def children(data):
    out, pos = [], 0
    while pos < len(data):
        tag, value, pos = read_tlv(data, pos)
        out.append((tag, value))
    return out


def to_int(value):
    if not value or len(value) > 8:
        raise ProtocolError("entier invalide")
    return int.from_bytes(value, "big", signed=True)


def to_str(value):
    return value.decode("utf-8", "replace")


def tlv(tag, value):
    n = len(value)
    if n < 0x80:
        head = bytes([tag, n])
    else:
        raw = n.to_bytes((n.bit_length() + 7) // 8, "big")
        head = bytes([tag, 0x80 | len(raw)]) + raw
    return head + value


def ber_int(value, tag=0x02):
    length = max(1, (value.bit_length() + 8) // 8)
    return tlv(tag, value.to_bytes(length, "big", signed=True))


def ber_str(value, tag=0x04):
    return tlv(tag, value.encode("utf-8") if isinstance(value, str) else value)


def seq(*items, tag=0x30):
    return tlv(tag, b"".join(items))


def message(msgid, op):
    return seq(ber_int(msgid), op)


def result(tag, code, text="", matched=""):
    return seq(ber_int(code, 0x0a), ber_str(matched), ber_str(text), tag=tag)


def entry_message(msgid, dn, attrs):
    parts = [seq(ber_str(name), seq(*[ber_str(v) for v in values], tag=0x31)) for name, values in attrs]
    return message(msgid, seq(ber_str(dn), seq(*parts), tag=0x64))


# ------------------------------------------------------------------ comparaisons
def fold(text):
    text = unicodedata.normalize("NFKD", str(text).casefold())
    return re.sub(r"\s+", " ", "".join(ch for ch in text if not unicodedata.combining(ch))).strip()


def digits(text):
    """Numéro comparable : forme composable de l'annuaire si possible, sinon les chiffres seuls."""
    n = directory.normalize_number(text)
    return n if n else re.sub(r"\D", "", str(text))


def norm_attr(name):
    name = name.split(";", 1)[0].strip().lower()
    return ALIASES.get(name, name)


def prepare(entry):
    """Entrée publiée, avec ses valeurs déjà normalisées pour les filtres."""
    attrs = {}
    for name, values in entry["attrs"].items():
        key = norm_attr(name)
        attrs[key] = (name, [str(v) for v in values])
    dn = entry["dn"]
    return {"dn": dn, "ndn": normalize_dn(dn), "attrs": attrs,
            "cmp": {k: [digits(v) if k in PHONE_ATTRS else fold(v) for v in vals] for k, (_, vals) in attrs.items()}}


def normalize_dn(dn):
    if not str(dn).strip():
        return ""
    parts = []
    for rdn in str(dn).split(","):
        if "=" not in rdn:
            return None
        k, v = rdn.split("=", 1)
        parts.append("%s=%s" % (k.strip().lower(), fold(v)))
    return ",".join(parts)


def parse_filter(tag, value, depth=0):
    """Filtre BER vers une structure simple : (op, ...)."""
    if depth > MAX_FILTER_DEPTH:
        raise ProtocolError("filtre trop profond")
    if tag in (0xa0, 0xa1):
        return ("and" if tag == 0xa0 else "or", [parse_filter(t, v, depth + 1) for t, v in children(value)])
    if tag == 0xa2:
        inner = children(value)
        if len(inner) != 1:
            raise ProtocolError("filtre « non » invalide")
        return ("not", parse_filter(inner[0][0], inner[0][1], depth + 1))
    if tag in (0xa3, 0xa5, 0xa6, 0xa8):
        parts = children(value)
        if len(parts) != 2:
            raise ProtocolError("assertion invalide")
        op = {0xa3: "eq", 0xa5: "ge", 0xa6: "le", 0xa8: "approx"}[tag]
        return (op, norm_attr(to_str(parts[0][1])), to_str(parts[1][1]))
    if tag == 0xa4:
        parts = children(value)
        if len(parts) != 2:
            raise ProtocolError("sous-chaîne invalide")
        subs = [({0x80: "initial", 0x81: "any", 0x82: "final"}.get(t), to_str(v)) for t, v in children(parts[1][1])]
        if not subs or any(k is None for k, _ in subs):
            raise ProtocolError("sous-chaîne invalide")
        return ("sub", norm_attr(to_str(parts[0][1])), subs)
    if tag == 0x87:
        return ("present", norm_attr(to_str(value)))
    if tag == 0xa9:
        return ("undefined",)  # extensibleMatch : non géré, jamais vrai
    raise ProtocolError("filtre inconnu")


def cmp_value(attr, value):
    return digits(value) if attr in PHONE_ATTRS else fold(value)


def match_sub(value, subs, attr):
    pos = 0
    for i, (kind, text) in enumerate(subs):
        text = cmp_value(attr, text)
        if not text:
            continue
        if kind == "initial":
            if not value.startswith(text):
                return False
            pos = len(text)
        elif kind == "final":
            if len(value) - len(text) < pos or not value.endswith(text):
                return False
        else:
            found = value.find(text, pos)
            if found < 0:
                return False
            pos = found + len(text)
    return True


def matches(f, entry):
    op = f[0]
    if op == "and":
        return all(matches(x, entry) for x in f[1])
    if op == "or":
        return any(matches(x, entry) for x in f[1])
    if op == "not":
        return not matches(f[1], entry)
    if op == "undefined":
        return False
    values = entry["cmp"].get(f[1])
    if op == "present":
        return values is not None
    if not values:
        return False
    if op == "sub":
        return any(match_sub(v, f[2], f[1]) for v in values)
    wanted = cmp_value(f[1], f[2])
    if not wanted:
        return False
    if op in ("eq", "approx"):
        return wanted in values
    if op == "ge":
        return any(v >= wanted for v in values)
    return any(v <= wanted for v in values)


def in_scope(entry_ndn, base_ndn, scope):
    if base_ndn == "":
        return scope == 2
    if scope == 0:
        return entry_ndn == base_ndn
    if entry_ndn == base_ndn:
        return scope == 2
    if not entry_ndn.endswith("," + base_ndn):
        return False
    return scope == 2 or entry_ndn.count(",") == base_ndn.count(",") + 1


# ------------------------------------------------------------------ données
class Store:
    """server.json et base.json relus quand ils changent ; branches de l'arbre ajoutées."""

    def __init__(self, folder):
        self.folder = folder
        self.lock = threading.Lock()
        self.stamp = None
        self.config = {"enabled": False, "anonymous": False, "bind_hash": "", "networks": []}
        self.networks = []
        self.entries = []

    def files(self):
        return os.path.join(self.folder, "server.json"), os.path.join(self.folder, "base.json")

    def refresh(self):
        conf_path, base_path = self.files()
        try:
            stamp = tuple((os.stat(p).st_mtime_ns, os.stat(p).st_size) for p in (conf_path, base_path))
        except OSError:
            stamp = None
        with self.lock:
            if stamp == self.stamp:
                return
            try:
                with open(conf_path, "r", encoding="utf-8") as h:
                    config = json.load(h)
                with open(base_path, "r", encoding="utf-8") as h:
                    base = json.load(h)
                nets = [ipaddress.ip_network(n, strict=False) for n in config.get("networks", [])]
                entries = [prepare(e) for e in base.get("entries", [])]
            except (OSError, ValueError, KeyError, TypeError, AttributeError) as exc:
                if self.stamp is not None or stamp is not None:
                    LOG.warning("base illisible (%s) : service fermé", exc.__class__.__name__)
                self.config, self.networks, self.entries, self.stamp = {"enabled": False}, [], [], stamp
                return
            self.config, self.networks, self.stamp = config, nets, stamp
            self.entries = self.tree() + entries
            LOG.info("base chargée : %d entrées", len(entries))

    def tree(self):
        base = directory.LDAP_BASE_DN
        out = [prepare({"dn": base, "attrs": {"objectClass": ["top", "domain"], "dc": ["voipbuntu"]}})]
        for dn, ou in ((directory.LDAP_CONTACTS_DN, "contacts"), (directory.LDAP_EXTENSIONS_DN, "postes")):
            out.append(prepare({"dn": dn, "attrs": {"objectClass": ["top", "organizationalUnit"], "ou": [ou]}}))
        return out

    def snapshot(self):
        self.refresh()
        with self.lock:
            return self.config, self.networks, self.entries


class Throttle:
    def __init__(self):
        self.lock = threading.Lock()
        self.failures = {}

    def blocked(self, ip):
        now = time.monotonic()
        with self.lock:
            recent = [t for t in self.failures.get(ip, []) if now - t < 60]
            self.failures[ip] = recent
            return len(recent) >= MAX_BIND_FAILURES

    def fail(self, ip):
        with self.lock:
            self.failures.setdefault(ip, []).append(time.monotonic())
            if len(self.failures) > 4096:
                self.failures.clear()


def client_ip(address):
    ip = ipaddress.ip_address(address[0].split("%", 1)[0])
    if ip.version == 6 and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    return ip


def allowed(ip, networks):
    return ip.is_loopback or any(ip in n for n in networks if n.version == ip.version)


# ------------------------------------------------------------------ session
class Session:
    def __init__(self, store, throttle, ip):
        self.store = store
        self.throttle = throttle
        self.ip = ip
        self.bound = False

    def handle(self, raw):
        """Un LDAPMessage complet ; renvoie (réponses, fermer)."""
        tag, body, _ = read_tlv(raw, 0)
        if tag != 0x30:
            raise ProtocolError("message invalide")
        parts = children(body)
        if len(parts) < 2 or parts[0][0] != 0x02:
            raise ProtocolError("message invalide")
        msgid = to_int(parts[0][1])
        op_tag, op = parts[1]
        critical = self.critical_controls(parts[2:])
        if op_tag == 0x42:  # unbind
            return [], True
        if op_tag == 0x50:  # abandon : pas de réponse
            return [], False
        responses = {0x60: 0x61, 0x63: 0x65, 0x66: 0x67, 0x68: 0x69, 0x4a: 0x6b, 0x6c: 0x6d, 0x6e: 0x6f, 0x77: 0x78}
        if op_tag not in responses:
            raise ProtocolError("opération inconnue")
        if critical:
            return [message(msgid, result(responses[op_tag], UNAVAILABLE_CRITICAL, "contrôle non géré"))], False
        if op_tag == 0x60:
            return [message(msgid, self.bind(op))], False
        if op_tag == 0x63:
            return self.search(msgid, op), False
        if op_tag == 0x77:
            return [message(msgid, result(0x78, PROTOCOL_ERROR, "opération étendue non gérée"))], False
        return [message(msgid, result(responses[op_tag], UNWILLING, "annuaire en lecture seule"))], False

    @staticmethod
    def critical_controls(extra):
        for tag, value in extra:
            if tag != 0xa0:
                continue
            for _, control in children(value):
                fields = children(control)
                if len(fields) > 1 and fields[1][0] == 0x01 and fields[1][1] != b"\x00":
                    return True
        return False

    def bind(self, op):
        parts = children(op)
        if len(parts) < 3 or parts[0][0] != 0x02:
            raise ProtocolError("bind invalide")
        if to_int(parts[0][1]) != 3:
            return result(0x61, PROTOCOL_ERROR, "LDAP v3 seulement")
        name, (auth_tag, secret) = to_str(parts[1][1]).strip(), parts[2]
        self.bound = False
        if auth_tag != 0x80:
            return result(0x61, AUTH_METHOD_NOT_SUPPORTED, "bind simple seulement")
        config, _, _ = self.store.snapshot()
        if not name and not secret:  # anonyme
            return result(0x61, SUCCESS)
        if not secret:  # bind « non authentifié » (RFC 4513 5.1.2) : refusé
            return result(0x61, UNWILLING, "mot de passe vide")
        user = normalize_dn(name) if "=" in name else "cn=" + fold(name) + "," + normalize_dn(directory.LDAP_BASE_DN)
        if self.throttle.blocked(str(self.ip)):
            LOG.warning("bind refusé pour %s : trop d'échecs", self.ip)
            return result(0x61, INVALID_CREDENTIALS)
        stored = config.get("bind_hash") or ""
        password = secret.decode("utf-8", "replace")
        if user == normalize_dn(directory.LDAP_BIND_DN) and stored and security.verify_password(password, stored):
            self.bound = True
            return result(0x61, SUCCESS)
        self.throttle.fail(str(self.ip))
        LOG.warning("bind refusé pour %s (%s)", self.ip, name[:80])
        time.sleep(0.5)
        return result(0x61, INVALID_CREDENTIALS)

    def search(self, msgid, op):
        parts = children(op)
        if len(parts) != 8:
            raise ProtocolError("recherche invalide")
        base = to_str(parts[0][1])
        scope, size = to_int(parts[1][1]), to_int(parts[3][1])
        types_only = parts[5][1] not in (b"", b"\x00")
        flt = parse_filter(parts[6][0], parts[6][1])
        wanted = [to_str(v) for _, v in children(parts[7][1])]
        if scope not in (0, 1, 2):
            raise ProtocolError("portée invalide")
        config, _, entries = self.store.snapshot()
        base_ndn = normalize_dn(base)
        if base_ndn is None:
            return [message(msgid, result(0x65, INVALID_DN, "DN invalide"))]
        if base_ndn == "" and scope == 0:  # Root DSE : utile aux téléphones qui cherchent la base
            attrs = [("objectClass", ["top"]), ("namingContexts", [directory.LDAP_BASE_DN]),
                     ("supportedLDAPVersion", ["3"]), ("vendorName", ["VOIPbuntu"])]
            return [entry_message(msgid, "", self.select(attrs, wanted, types_only)), message(msgid, result(0x65, SUCCESS))]
        if not (self.bound or config.get("anonymous")):
            return [message(msgid, result(0x65, INSUFFICIENT_ACCESS, "connexion avec le compte de lecture requise"))]
        root = normalize_dn(directory.LDAP_BASE_DN)
        if base_ndn != "" and base_ndn != root and not base_ndn.endswith("," + root):
            return [message(msgid, result(0x65, NO_SUCH_OBJECT))]
        if base_ndn != "" and not any(e["ndn"] == base_ndn for e in entries):
            return [message(msgid, result(0x65, NO_SUCH_OBJECT, matched=directory.LDAP_BASE_DN))]
        limit = MAX_RESULTS if size <= 0 else min(size, MAX_RESULTS)
        out, code = [], SUCCESS
        for e in entries:
            if not in_scope(e["ndn"], base_ndn, scope) or not matches(flt, e):
                continue
            if len(out) >= limit:
                code = SIZE_LIMIT
                break
            out.append(entry_message(msgid, e["dn"], self.select(list(e["attrs"].values()), wanted, types_only)))
        out.append(message(msgid, result(0x65, code)))
        return out

    @staticmethod
    def select(attrs, wanted, types_only):
        names = {norm_attr(w) for w in wanted}
        if "1.1" in names and len(names) == 1:
            return []
        if not names or "*" in names:
            chosen = attrs
        else:
            chosen = [(n, v) for n, v in attrs if norm_attr(n) in names]
        return [(n, [] if types_only else v) for n, v in chosen]


# ------------------------------------------------------------------ serveur
def read_message(rfile):
    head = rfile.read(2)
    if len(head) < 2:
        return None
    if head[0] != 0x30:
        raise ProtocolError("message invalide")
    length = head[1]
    extra = b""
    if length & 0x80:
        count = length & 0x7f
        if count == 0 or count > 4:
            raise ProtocolError("longueur invalide")
        extra = rfile.read(count)
        if len(extra) < count:
            return None
        length = int.from_bytes(extra, "big")
    if length > MAX_MESSAGE:
        raise ProtocolError("message trop long")
    body = rfile.read(length)
    if len(body) < length:
        return None
    return head + extra + body


class Handler(socketserver.StreamRequestHandler):
    timeout = IDLE_TIMEOUT

    def handle(self):
        srv = self.server
        try:
            ip = client_ip(self.client_address)
        except ValueError:
            return
        config, networks, _ = srv.store.snapshot()
        if not config.get("enabled") or not allowed(ip, networks):
            LOG.warning("connexion refusée depuis %s (hors des réseaux des téléphones)", ip)
            return
        session = Session(srv.store, srv.throttle, ip)
        while True:
            try:
                raw = read_message(self.rfile)
                if raw is None:
                    return
                replies, close = session.handle(raw)
            except ProtocolError as exc:
                LOG.info("échange interrompu avec %s : %s", ip, exc)
                return
            except (OSError, socket.timeout):
                return
            try:
                for r in replies:
                    self.wfile.write(r)
                self.wfile.flush()
            except OSError:
                return
            if close:
                return


class Server(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 16

    def __init__(self, address, store, family=socket.AF_INET6):
        self.address_family = family
        self.store = store
        self.throttle = Throttle()
        self.slots = threading.BoundedSemaphore(MAX_CLIENTS)
        super().__init__(address, Handler, bind_and_activate=False)
        if family == socket.AF_INET6:
            self.socket.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
        try:
            self.server_bind()
            self.server_activate()
        except BaseException:
            self.server_close()
            raise

    def process_request(self, request, client_address):
        if not self.slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        super().process_request(request, client_address)

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.slots.release()


def make_server(folder, listen="", port=directory.LDAP_PORT):
    """Écoute en IPv6 et IPv4 (socket double pile), ou en IPv4 seul si IPv6 est absent."""
    store = Store(folder)
    store.refresh()
    if listen in ("", "::"):
        try:
            return Server(("::", port), store, socket.AF_INET6)
        except OSError:
            return Server(("0.0.0.0", port), store, socket.AF_INET)
    family = socket.AF_INET6 if ":" in listen else socket.AF_INET
    return Server((listen, port), store, family)
