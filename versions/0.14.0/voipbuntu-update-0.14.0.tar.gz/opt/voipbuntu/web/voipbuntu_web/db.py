"""Base SQLite de la console (comptes, sessions, mesures)."""

import os
import sqlite3
import threading

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
    username TEXT PRIMARY KEY,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'admin',
    created REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions(
    token_hash TEXT PRIMARY KEY,
    username TEXT NOT NULL,
    csrf TEXT NOT NULL,
    created REAL NOT NULL,
    last_seen REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS login_failures(
    key TEXT PRIMARY KEY,
    failures INTEGER NOT NULL,
    locked_until REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS metrics(
    ts INTEGER PRIMARY KEY,
    cpu REAL, mem REAL, disk REAL, rx REAL, tx REAL, load1 REAL
);
CREATE TABLE IF NOT EXISTS login_pending(
    token_hash TEXT PRIMARY KEY,
    username TEXT NOT NULL,
    created REAL NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS audit(
    ts REAL NOT NULL,
    username TEXT,
    remote TEXT,
    event TEXT NOT NULL
);
"""


class Database:
    def __init__(self, path):
        self.path = path
        directory = os.path.dirname(path)
        if directory:
            os.makedirs(directory, mode=0o700, exist_ok=True)
        old_umask = os.umask(0o077)
        try:
            self.conn = sqlite3.connect(path, check_same_thread=False)
        finally:
            os.umask(old_umask)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.executescript(SCHEMA)
        self.migrate()
        self.conn.commit()
        self.lock = threading.RLock()

    # Colonnes ajoutées en 0.9 (comptes multiples, double authentification).
    # Une base 0.8 garde ses comptes : ils restent admin, actifs, sans TOTP.
    USER_COLUMNS = (
        ("disabled", "INTEGER NOT NULL DEFAULT 0"),
        ("totp_secret", "TEXT"),
        ("totp_pending", "TEXT"),
        ("totp_last", "INTEGER NOT NULL DEFAULT 0"),
        ("recovery", "TEXT"),
        ("last_login", "REAL"),
    )

    def migrate(self):
        present = {row[1] for row in self.conn.execute("PRAGMA table_info(users)")}
        for name, decl in self.USER_COLUMNS:
            if name not in present:
                self.conn.execute("ALTER TABLE users ADD COLUMN %s %s" % (name, decl))
        self.conn.execute("UPDATE users SET role='admin' WHERE role IS NULL OR role NOT IN ('admin', 'lecture')")

    def audit(self, event, username=None, remote=None, now=None):
        import time
        with self.lock:
            self.conn.execute(
                "INSERT INTO audit(ts, username, remote, event) VALUES (?,?,?,?)",
                (now or time.time(), username, remote, event),
            )
            self.conn.execute("DELETE FROM audit WHERE rowid NOT IN (SELECT rowid FROM audit ORDER BY ts DESC LIMIT 5000)")
            self.conn.commit()

    def get_user(self, username):
        with self.lock:
            return self.conn.execute(
                "SELECT username, password_hash, role FROM users WHERE username=?", (username,)
            ).fetchone()

    def set_password(self, username, password_hash, role="admin"):
        import time
        with self.lock:
            self.conn.execute(
                "INSERT INTO users(username, password_hash, role, created) VALUES (?,?,?,?) "
                "ON CONFLICT(username) DO UPDATE SET password_hash=excluded.password_hash",
                (username, password_hash, role, time.time()),
            )
            self.conn.commit()

    def has_users(self):
        with self.lock:
            return self.conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] > 0

    # ------------------------------------------------------------ comptes
    ACCOUNT_FIELDS = ("username", "password_hash", "role", "created", "disabled", "totp_secret",
                      "totp_pending", "totp_last", "recovery", "last_login")

    def get_account(self, username):
        with self.lock:
            row = self.conn.execute(
                "SELECT %s FROM users WHERE username=?" % ", ".join(self.ACCOUNT_FIELDS), (username,)
            ).fetchone()
        return dict(zip(self.ACCOUNT_FIELDS, row)) if row else None

    def list_accounts(self):
        with self.lock:
            rows = self.conn.execute(
                "SELECT %s FROM users ORDER BY username" % ", ".join(self.ACCOUNT_FIELDS)).fetchall()
        return [dict(zip(self.ACCOUNT_FIELDS, r)) for r in rows]

    def create_account(self, username, password_hash, role):
        import time
        with self.lock:
            self.conn.execute(
                "INSERT INTO users(username, password_hash, role, created) VALUES (?,?,?,?)",
                (username, password_hash, role, time.time()))
            self.conn.commit()

    def update_account(self, username, **fields):
        allowed = set(self.ACCOUNT_FIELDS) - {"username", "created"}
        if not fields or not set(fields) <= allowed:
            raise ValueError(sorted(fields))
        names = sorted(fields)
        with self.lock:
            self.conn.execute(
                "UPDATE users SET %s WHERE username=?" % ", ".join("%s=?" % n for n in names),
                [fields[n] for n in names] + [username])
            self.conn.commit()

    def delete_account(self, username):
        with self.lock:
            self.conn.execute("DELETE FROM users WHERE username=?", (username,))
            self.conn.execute("DELETE FROM sessions WHERE username=?", (username,))
            self.conn.execute("DELETE FROM login_pending WHERE username=?", (username,))
            self.conn.commit()

    def active_admins(self):
        with self.lock:
            return [r[0] for r in self.conn.execute(
                "SELECT username FROM users WHERE role='admin' AND disabled=0 ORDER BY username")]


# Lot M (Active Directory) : origine du compte. « ad » = compte créé à la première connexion
# d'un membre d'un groupe AD autorisé ; son mot de passe reste dans l'AD (empreinte inutilisable ici).
Database.USER_COLUMNS = Database.USER_COLUMNS + (("source", "TEXT NOT NULL DEFAULT 'local'"),)
Database.ACCOUNT_FIELDS = Database.ACCOUNT_FIELDS + ("source",)
AD_PASSWORD_HASH = "ad$compte-active-directory"


def _active_local_admins(self):
    """Administrateurs locaux actifs : ils restent utilisables quand l'AD est injoignable."""
    with self.lock:
        return [r[0] for r in self.conn.execute(
            "SELECT username FROM users WHERE role='admin' AND disabled=0 AND source!='ad' ORDER BY username")]


def _create_ad_account(self, username, role):
    import time
    with self.lock:
        self.conn.execute(
            "INSERT INTO users(username, password_hash, role, created, source) VALUES (?,?,?,?, 'ad')",
            (username, AD_PASSWORD_HASH, role, time.time()))
        self.conn.commit()


def _ad_accounts(self):
    with self.lock:
        return [r[0] for r in self.conn.execute("SELECT username FROM users WHERE source='ad'")]


Database.active_local_admins = _active_local_admins
Database.create_ad_account = _create_ad_account
Database.ad_accounts = _ad_accounts
