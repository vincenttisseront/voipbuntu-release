"""Messages vocaux dans la console (lot S) : liste, écoute, marquer comme écouté, suppression.

Les messages sont ceux qu'Asterisk dépose dans /var/spool/asterisk/voicemail/default :

    <boîte>/INBOX/msg0000.txt   informations (appelant, date, durée), écrites par Asterisk
    <boîte>/INBOX/msg0000.wav   le son (aussi .WAV et .gsm : format=wav49|gsm|wav)
    <boîte>/Old/...             messages déjà écoutés
    <boîte>/Urgent/...          messages urgents non écoutés

Ce module ne fait confiance à rien de ce dossier : chaque dossier est ouvert sans suivre de
lien symbolique (O_NOFOLLOW à chaque étape), les noms sont générés par Asterisk et contrôlés,
et le texte des fichiers .txt (le nom de l'appelant vient du réseau) est borné et nettoyé.

Les modifications prennent le verrou d'Asterisk sur le dossier (fichier .lock créé par lien,
comme ast_lock_path) : un message n'est jamais déplacé pendant qu'Asterisk l'écrit ou le lit.
"""
import os
import re
import stat
import time

DEFAULT_DIR = "/var/spool/asterisk/voicemail/default"
FOLDERS = ("INBOX", "Urgent", "Old")          # nouveaux, urgents, écoutés
NEW_FOLDERS = ("INBOX", "Urgent")
BOX_RE = re.compile(r"^[1-9][0-9]{1,5}$")
MSG_RE = re.compile(r"^msg([0-9]{4})$")
ID_RE = re.compile(r"^([1-9][0-9]{1,5})/(INBOX|Urgent|Old)/(msg[0-9]{4})$")
FILE_RE = re.compile(r"^msg[0-9]{4}\.(txt|wav|WAV|gsm)$")
MAX_MESSAGES = 2000
MAX_INFO = 8192
LOCK_WAIT = 5.0
CTRL_RE = re.compile(r"[\x00-\x1f\x7f]")


class VoicemailError(ValueError):
    pass


def _open_dir(root, parts):
    """Descripteur du dossier root/parts..., sans suivre aucun lien ; None s'il n'existe pas."""
    try:
        fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
    except OSError:
        return None
    for part in parts:
        try:
            nfd = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
        except OSError:
            os.close(fd)
            return None
        os.close(fd)
        fd = nfd
    return fd


def _read_small(dir_fd, name, limit):
    try:
        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=dir_fd)
    except OSError:
        return None
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_size > limit:
            return None
        return os.read(fd, limit + 1)
    finally:
        os.close(fd)


def clean(text, limit=80):
    return CTRL_RE.sub(" ", text).strip()[:limit]


def parse_info(raw):
    """Fichier msgNNNN.txt d'Asterisk ([message] clé=valeur) : appelant, date, durée."""
    info = {}
    for line in (raw or b"").decode("utf-8", "replace").splitlines():
        if "=" not in line or line.startswith((";", "[")):
            continue
        key, value = line.split("=", 1)
        info[key.strip()] = value.strip()
    caller = clean(info.get("callerid", ""))
    m = re.match(r'^"?([^"<]*)"?\s*<([^>]*)>$', caller)
    name, number = (clean(m.group(1)), clean(m.group(2), 32)) if m else ("", caller[:32])
    if name == number:
        name = ""
    try:
        when = int(info.get("origtime", "0"))
    except ValueError:
        when = 0
    try:
        duration = max(0, min(int(info.get("duration", "0")), 86400))
    except ValueError:
        duration = 0
    return {"caller_name": name, "caller": number if number not in ("Unknown", "unknown") else "",
            "time": when, "duration": duration}


def listing(root=DEFAULT_DIR, boxes=None):
    """Messages présents, du plus récent au plus ancien : {"id", "box", "folder", "msg", "new", ...}."""
    out = []
    base = _open_dir(root, [])
    if base is None:
        return out
    try:
        names = sorted(n for n in os.listdir(base) if BOX_RE.match(n))
    finally:
        os.close(base)
    for box in names:
        if boxes is not None and box not in boxes:
            continue
        for folder in FOLDERS:
            fd = _open_dir(root, [box, folder])
            if fd is None:
                continue
            try:
                files = set(os.listdir(fd))
                for msg in sorted({f.split(".")[0] for f in files if FILE_RE.match(f)}):
                    if msg + ".txt" not in files:
                        continue  # en cours d'écriture par Asterisk
                    item = parse_info(_read_small(fd, msg + ".txt", MAX_INFO))
                    try:
                        st = os.stat(msg + ".wav", dir_fd=fd, follow_symlinks=False)
                        size = st.st_size if stat.S_ISREG(st.st_mode) else None
                    except OSError:
                        size = None
                    item.update({"id": "%s/%s/%s" % (box, folder, msg), "box": box, "folder": folder, "msg": msg,
                                 "new": folder in NEW_FOLDERS, "urgent": folder == "Urgent", "size": size})
                    out.append(item)
            finally:
                os.close(fd)
            if len(out) >= MAX_MESSAGES:
                break
    out.sort(key=lambda m: m["time"], reverse=True)
    return out[:MAX_MESSAGES]


def counts(messages):
    """Par boîte : {"new", "old"}."""
    out = {}
    for m in messages:
        c = out.setdefault(m["box"], {"new": 0, "old": 0})
        c["new" if m["new"] else "old"] += 1
    return out


def parse_id(text):
    m = ID_RE.match(text) if isinstance(text, str) else None
    if not m:
        raise VoicemailError("message inconnu")
    return m.groups()


class Lock:
    """Verrou d'Asterisk sur un dossier de messagerie (ast_lock_path, méthode « lockfile »)."""

    def __init__(self, dir_fd):
        self.fd = dir_fd
        self.tmp = ".lock-%08x" % int.from_bytes(os.urandom(4), "big")

    def __enter__(self):
        fd = os.open(self.tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=self.fd)
        os.write(fd, str(os.getpid()).encode())
        os.close(fd)
        end = time.monotonic() + LOCK_WAIT
        try:
            while True:
                try:
                    os.link(self.tmp, ".lock", src_dir_fd=self.fd, dst_dir_fd=self.fd, follow_symlinks=False)
                    return self
                except FileExistsError:
                    if time.monotonic() > end:
                        raise VoicemailError("messagerie occupée, réessayez") from None
                    time.sleep(0.1)
        finally:
            os.unlink(self.tmp, dir_fd=self.fd)

    def __exit__(self, *exc):
        try:
            os.unlink(".lock", dir_fd=self.fd)
        except OSError:
            pass


def _files(dir_fd, msg):
    return sorted(f for f in os.listdir(dir_fd) if FILE_RE.match(f) and f.split(".")[0] == msg)


def delete(root, ident):
    """Supprime un message (tous ses fichiers). Asterisk renumérote la boîte à sa prochaine ouverture."""
    box, folder, msg = parse_id(ident)
    fd = _open_dir(root, [box, folder])
    if fd is None:
        raise VoicemailError("message introuvable")
    try:
        with Lock(fd):
            files = _files(fd, msg)
            if not files:
                raise VoicemailError("message introuvable")
            for f in files:
                os.unlink(f, dir_fd=fd)
    finally:
        os.close(fd)
    return box


def mark_heard(root, ident):
    """Déplace un message nouveau (INBOX ou Urgent) dans Old, au numéro libre suivant."""
    box, folder, msg = parse_id(ident)
    if folder not in NEW_FOLDERS:
        raise VoicemailError("message déjà écouté")
    src = _open_dir(root, [box, folder])
    if src is None:
        raise VoicemailError("message introuvable")
    try:
        box_fd = _open_dir(root, [box])
        try:
            try:
                os.mkdir("Old", 0o770, dir_fd=box_fd)
                # Créé par root : rendu à Asterisk (propriétaire de la boîte), qui doit pouvoir y écrire
                owner = os.fstat(box_fd)
                try:
                    os.chown("Old", owner.st_uid, owner.st_gid, dir_fd=box_fd, follow_symlinks=False)
                except PermissionError:
                    pass
            except FileExistsError:
                pass
            dst = _open_dir(root, [box, "Old"])
        finally:
            os.close(box_fd)
        if dst is None:
            raise VoicemailError("dossier des messages écoutés illisible")
        try:
            st = os.fstat(src)
            with Lock(src), Lock(dst):
                files = _files(src, msg)
                if not files:
                    raise VoicemailError("message introuvable")
                taken = [int(MSG_RE.match(f.split(".")[0]).group(1)) for f in os.listdir(dst) if FILE_RE.match(f)]
                new = "msg%04d" % (max(taken) + 1 if taken else 0)
                if new == "msg10000":
                    raise VoicemailError("dossier des messages écoutés plein")
                for f in files:
                    target = new + f[len(msg):]
                    os.rename(f, target, src_dir_fd=src, dst_dir_fd=dst)
                    try:
                        os.chown(target, st.st_uid, st.st_gid, dir_fd=dst, follow_symlinks=False)
                    except PermissionError:
                        pass
        finally:
            os.close(dst)
    finally:
        os.close(src)
    return box


def open_audio(root, ident):
    """Fichier .wav d'un message, ouvert sans suivre de lien : (fichier, taille) ou (None, None)."""
    try:
        box, folder, msg = parse_id(ident)
    except VoicemailError:
        return None, None
    fd = _open_dir(root, [box, folder])
    if fd is None:
        return None, None
    try:
        try:
            f = os.open(msg + ".wav", os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd)
        except OSError:
            return None, None
        st = os.fstat(f)
        if not stat.S_ISREG(st.st_mode):
            os.close(f)
            return None, None
        return os.fdopen(f, "rb"), st.st_size
    finally:
        os.close(fd)
