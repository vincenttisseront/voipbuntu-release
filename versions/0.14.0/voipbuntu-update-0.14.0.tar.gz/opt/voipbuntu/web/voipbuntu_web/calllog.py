"""Journal des appels exploitable : statut lisible, filtres, export CSV et statistiques.

Les appels viennent de pbx.parse_cdr() (lu par voipbuntu-pbx calls, en root) ;
ce module ne fait que des calculs sur ces lignes déjà contrôlées.
"""

import csv
import datetime
import io
import re

from . import directory

STATUSES = ("repondu", "manque", "occupe", "messagerie")
DIRECTIONS = ("entrant", "sortant", "interne")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
STATUS_LABELS = {"repondu": "répondu", "manque": "manqué", "occupe": "occupé", "messagerie": "messagerie"}
DIRECTION_LABELS = {"entrant": "entrant", "sortant": "sortant", "interne": "interne"}


def status_of(call):
    if call.get("voicemail"):
        return "messagerie"
    if call.get("disposition") == "ANSWERED":
        return "repondu"
    if call.get("disposition") == "BUSY":
        return "occupe"
    return "manque"


def enrich(calls, state):
    """Ajoute le statut, les postes qui ont sonné (numéros) et le nom du contact de l'annuaire."""
    users = {e["sip_user"].lower(): e["number"] for e in state["extensions"]}
    book = directory.by_number(state.get("directory"))
    out = []
    for c in calls:
        if not isinstance(c, dict):
            continue
        c = dict(c)
        c["status"] = status_of(c)
        rang = c.get("rang") if isinstance(c.get("rang"), list) else []
        c["rang"] = [users[str(u).lower()] for u in rang if str(u).lower() in users]
        party = c.get("src") if c.get("direction") == "entrant" else c.get("dst") if c.get("direction") == "sortant" else ""
        contact = book.get(directory.normalize_number(party) or "") if party else None
        c["contact"] = directory.callerid_name(contact) if contact else ""
        out.append(c)
    return out


def involves(call, ext):
    return ext in (call.get("src"), call.get("dst")) or ext in call.get("rang", [])


def missed_by(call, ext):
    """Appel manqué pour ce poste : il a sonné (ou était appelé) et personne n'a répondu."""
    return call["status"] != "repondu" and (call.get("dst") == ext or ext in call.get("rang", []))


def parse_filters(query):
    """Filtres de l'URL (parse_qs) ; refuse les valeurs inconnues plutôt que de les ignorer."""
    def one(name):
        return (query.get(name) or [""])[0].strip()
    f = {"ext": one("ext"), "direction": one("direction"), "status": one("status"),
         "from": one("from"), "to": one("to")}
    if f["ext"] and not re.match(r"^[1-9][0-9]{1,5}$", f["ext"]):
        raise ValueError("poste")
    if f["direction"] and f["direction"] not in DIRECTIONS:
        raise ValueError("sens")
    if f["status"] and f["status"] not in STATUSES:
        raise ValueError("statut")
    for k in ("from", "to"):
        if f[k] and not DATE_RE.match(f[k]):
            raise ValueError("date")
    return f


def apply_filters(calls, f):
    out = []
    for c in calls:
        day = c.get("start", "")[:10]
        if f.get("ext") and not involves(c, f["ext"]):
            continue
        if f.get("direction") and c.get("direction") != f["direction"]:
            continue
        if f.get("status") and c["status"] != f["status"]:
            continue
        if f.get("from") and day < f["from"]:
            continue
        if f.get("to") and day > f["to"]:
            continue
        out.append(c)
    return out


def stats(calls, state, today=None, days=30):
    """Appels par jour sur 30 jours, durée moyenne des appels répondus, part des appels manqués à l'accueil,
    appels manqués par poste aujourd'hui et sur 7 jours."""
    today = today or datetime.date.today()
    first = today - datetime.timedelta(days=days - 1)
    week = (today - datetime.timedelta(days=6)).isoformat()
    per_day = {(first + datetime.timedelta(days=i)).isoformat(): {"total": 0, "entrant": 0, "manque": 0}
               for i in range(days)}
    answered = []
    inbound = inbound_missed = 0
    exts = [e["number"] for e in state["extensions"]]
    missed = {n: {"today": 0, "week": 0} for n in exts}
    for c in calls:
        day = c.get("start", "")[:10]
        if day not in per_day:
            continue
        p = per_day[day]
        p["total"] += 1
        if c.get("direction") == "entrant":
            p["entrant"] += 1
            inbound += 1
            if c["status"] != "repondu":
                inbound_missed += 1
        if c["status"] != "repondu":
            p["manque"] += 1
        if c["status"] == "repondu" and isinstance(c.get("billsec"), int):
            answered.append(c["billsec"])
        for n in exts:
            if missed_by(c, n):
                if day >= week:
                    missed[n]["week"] += 1
                if day == today.isoformat():
                    missed[n]["today"] += 1
    names = {e["number"]: e["name"] for e in state["extensions"]}
    return {"days": [dict(day=d, **v) for d, v in sorted(per_day.items())],
            "total": sum(v["total"] for v in per_day.values()),
            "answered": len(answered),
            "average_seconds": round(sum(answered) / len(answered)) if answered else 0,
            "inbound": inbound, "inbound_missed": inbound_missed,
            "inbound_missed_ratio": round(inbound_missed / inbound, 3) if inbound else 0,
            "missed": [{"number": n, "name": names[n], "today": v["today"], "week": v["week"]}
                       for n, v in missed.items()]}


def export_csv(calls, lang="fr"):
    """CSV pour Excel : UTF-8 avec BOM, séparateur « ; »."""
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";", lineterminator="\r\n")
    if lang == "en":
        w.writerow(["Date", "Direction", "Caller", "Caller name", "Called", "Contact", "Extensions rung",
                    "Duration (s)", "Status"])
    else:
        w.writerow(["Date", "Sens", "Appelant", "Nom de l'appelant", "Appelé", "Contact", "Postes sonnés",
                    "Durée (s)", "Statut"])
    for c in calls:
        status = c["status"] if lang == "en" else STATUS_LABELS[c["status"]]
        direction = c.get("direction", "") if lang == "en" else DIRECTION_LABELS.get(c.get("direction"), "")
        w.writerow([c.get("start", ""), direction, c.get("src", ""), directory.csv_cell(c.get("src_name", "")),
                    c.get("dst", ""), directory.csv_cell(c.get("contact", "")), " ".join(c.get("rang", [])),
                    c.get("billsec", 0) if c["status"] == "repondu" else 0, status])
    return ("﻿" + buf.getvalue()).encode("utf-8")
