# Identité VOIPbuntu pour les écrans texte (menu console, assistant) : sourcé par les scripts.
# Couleurs newt (whiptail). Avec la palette chargée par voipbuntu-boot (share/vtrgb),
# black = encre, cyan = menthe, blue = sarcelle, red = corail ; sans elle, les teintes VGA restent lisibles.
export NEWT_COLORS='
root=white,black
roottext=cyan,black
border=cyan,black
window=lightgray,black
shadow=black,black
title=brightcyan,black
textbox=lightgray,black
acttextbox=black,cyan
label=lightgray,black
entry=white,blue
disentry=gray,black
checkbox=lightgray,black
actcheckbox=black,cyan
listbox=lightgray,black
actlistbox=black,cyan
sellistbox=white,blue
actsellistbox=black,cyan
button=black,lightgray
actbutton=white,red
compactbutton=lightgray,black
helpline=black,cyan
emptyscale=,blue
fullscale=,cyan
'
