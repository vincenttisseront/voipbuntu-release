# Composants libres utilisés par VOIPbuntu

Versions : celles du dépôt Ubuntu 24.04 au moment de la construction, listées
dans `voipbuntu-<version>-packages.lock` publié avec chaque ISO.

| Composant | Rôle | Licence | Lien |
| --- | --- | --- | --- |
| Ubuntu Server 24.04 LTS | Système de base | Diverses (principalement GPL) | https://ubuntu.com/legal/intellectual-property-policy |
| Subiquity / curtin | Installation automatique | AGPL-3.0 / AGPL-3.0 | https://github.com/canonical/subiquity |
| GRUB 2 | Chargeur de démarrage de l'ISO | GPL-3.0-or-later | https://www.gnu.org/software/grub/ |
| xorriso | Construction de l'ISO hybride | GPL-3.0-or-later | https://www.gnu.org/software/xorriso/ |
| nginx | HTTPS de la console, HTTP de démarrage | BSD-2-Clause | https://nginx.org/ |
| nftables | Pare-feu | GPL-2.0 | https://netfilter.org/projects/nftables/ |
| Python 3.12 | Console web et worker | PSF-2.0 | https://www.python.org/ |
| SQLite | Base de la console | Domaine public | https://sqlite.org/ |
| OpenSSL | Certificat TLS | Apache-2.0 | https://www.openssl.org/ |
| Manrope | Police de la console et du menu de démarrage | SIL OFL 1.1 (`branding/fonts/OFL.txt`) | https://github.com/sharanda/manrope |
| newt (whiptail) | Menu console et assistant | LGPL-2.0 | https://pagure.io/newt |
| unattended-upgrades | Correctifs de sécurité automatiques | GPL-2.0 | https://github.com/mvo5/unattended-upgrades |

Prévu aux étapes suivantes : FreePBX (GPL-2.0+ / AGPL-3.0 selon les modules), Asterisk (GPL-2.0).
