"""Modèle de la téléphonie VOIPbuntu et génération de la configuration Asterisk.

La console (sans privilège) tient l'état voulu dans /var/lib/voipbuntu/pbx.json ;
voipbuntu-pbx (root, via la file d'attente) le valide de nouveau, écrit les
fichiers d'Asterisk et recharge le service. Aucune valeur n'est recopiée dans
la configuration d'Asterisk sans être passée par validate().
"""

import json
import os
import re
import secrets
import string

from . import directory

DEFAULT_STATE = "/var/lib/voipbuntu/pbx.json"
MAX_EXTENSIONS = 200
NUMBER_RE = re.compile(r"^[1-9][0-9]{1,5}$")
SECRET_RE = re.compile(r"^[A-Za-z0-9]{16,64}$")
PIN_RE = re.compile(r"^[0-9]{4,8}$")
NAME_RE = re.compile(r"^[^\x00-\x1f\x7f\"<>;\[\]\\=,|]{1,40}$")
RESERVED = {"97", "43"}  # préfixes des codes de service *97 et *43 (sans l'étoile, jamais en conflit)
LANGUAGES = ("fr", "en")
# Identifiant SIP d'un poste (nom d'utilisateur saisi dans le téléphone) : par défaut son numéro
SIP_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,31}$")
RESERVED_IDS = {"global", "transport-udp", "transport-tcp", "operateur", "operateur-auth", "anonymous"}
# Numéros d'urgence et d'aide joignables par la ligne de l'opérateur : jamais des postes
EMERGENCY = ("15", "17", "18", "112", "114", "115", "119", "191", "196", "197", "116000", "116006", "116111", "116117")
HOST_RE = re.compile(r"^(?=.{1,253}$)[A-Za-z0-9](?:[A-Za-z0-9-]{0,62}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,62}[A-Za-z0-9])?)*$")
SIP_USER_RE = re.compile(r"^[A-Za-z0-9._+-]{1,64}$")
TRUNK_SECRET_RE = re.compile(r"^[!-~]{1,128}$")
TRUNK_SECRET_FORBIDDEN = set(";\\\"[]#")
PHONE_RE = re.compile(r"^\+?[0-9]{2,20}$")
TIME_RE = re.compile(r"^([01][0-9]|2[0-3]):[0-5][0-9]$")
DAYS = ("mon", "tue", "wed", "thu", "fri", "sat", "sun")
MAX_GROUPS = 20
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9](?:[A-Za-z0-9-]{0,62}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,62}[A-Za-z0-9])?)+$")
MAIL_SECURITY = ("starttls", "tls", "none")
MSMTP = "/usr/bin/msmtp"
FORWARD_MODES = ("off", "always", "noanswer")
NATIONAL_RE = re.compile(r"^0[1-9][0-9]{8}$")
INTERNATIONAL_RE = re.compile(r"^00[1-9][0-9]{3,16}$")
# Accueil vocal : annonces envoyées depuis la console, converties par voipbuntu-sounds (8 kHz mono)
SOUNDS = ("accueil", "menu", "fermeture", "attente")
SOUNDS = SOUNDS + ("file", "enregistrement")  # files d'attente : annonce d'attente, information sur l'enregistrement
SOUNDS_DIR = "/var/lib/asterisk/sounds/voipbuntu"
DEFAULT_MOH = "/usr/share/asterisk/moh"
MENU_DIGITS = ("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
# Numéros abrégés : *1 suivi de deux chiffres, vers un numéro extérieur par la ligne de l'opérateur
SPEED_PREFIX = "*1"
SPEED_CODE_RE = re.compile(r"^[0-9]{2}$")
MAX_SPEED_DIALS = 100
# Files d'attente (app_queue) et enregistrement des appels (MixMonitor)
MAX_QUEUES = 10
QUEUE_STRATEGIES = ("ringall", "rrmemory")
MONITOR_DIR = "/var/spool/asterisk/monitor"
RECORDING_RE = re.compile(r"^[0-9]{8}-[0-9]{6}-[0-9]{0,24}-[0-9]{2,6}-[0-9]{9,12}\.[0-9]{1,9}\.wav$")


class PbxError(ValueError):
    pass


def new_secret(length=24):
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def new_pin():
    return "".join(secrets.choice(string.digits) for _ in range(6))


def empty():
    return {"language": "fr", "extensions": []}


def load(path=DEFAULT_STATE):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
    except FileNotFoundError:
        return validate(empty())
    except (OSError, ValueError) as exc:
        raise PbxError("configuration téléphonique illisible : %s" % exc.__class__.__name__) from None
    return validate(data)


def save(state, path=DEFAULT_STATE):
    state = validate(state)
    tmp = path + ".tmp"
    old = os.umask(0o077)
    try:
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(state, handle, indent=1, sort_keys=True)
        os.replace(tmp, path)
    finally:
        os.umask(old)
    return state


def validate(data):
    if not isinstance(data, dict):
        raise PbxError("format invalide")
    language = data.get("language", "fr")
    if language not in LANGUAGES:
        raise PbxError("langue invalide")
    exts = data.get("extensions", [])
    if not isinstance(exts, list) or len(exts) > MAX_EXTENSIONS:
        raise PbxError("liste de postes invalide")
    clean, seen, users = [], set(), set()
    for ext in exts:
        if not isinstance(ext, dict):
            raise PbxError("poste invalide")
        number, name = str(ext.get("number", "")), str(ext.get("name", "")).strip()
        sip_user = str(ext.get("sip_user") or number)
        secret, pin = str(ext.get("secret", "")), str(ext.get("pin", ""))
        if not NUMBER_RE.match(number):
            raise PbxError("numéro invalide : %s" % number[:8])
        if number in seen:
            raise PbxError("numéro en double : %s" % number)
        if not NAME_RE.match(name):
            raise PbxError("nom invalide pour le poste %s" % number)
        if not SECRET_RE.match(secret):
            raise PbxError("mot de passe SIP invalide pour le poste %s" % number)
        if not PIN_RE.match(pin):
            raise PbxError("code de messagerie invalide pour le poste %s" % number)
        if not SIP_ID_RE.match(sip_user) or sip_user.lower() in RESERVED_IDS:
            raise PbxError("identifiant SIP invalide pour le poste %s" % number)
        if sip_user.lower() in users:
            raise PbxError("identifiant SIP en double : %s" % sip_user)
        seen.add(number)
        users.add(sip_user.lower())
        email = str(ext.get("email") or "").strip()
        if email and (len(email) > 254 or not EMAIL_RE.match(email)):
            raise PbxError("adresse e-mail invalide pour le poste %s" % number)
        clean.append({"number": number, "name": name, "sip_user": sip_user, "secret": secret, "pin": pin,
                      "voicemail": bool(ext.get("voicemail", True)), "forward": ext.get("forward"), "email": email,
                      "record": bool(ext.get("record", False))})
    clean.sort(key=lambda e: (len(e["number"]), e["number"]))
    trunk = validate_trunk(data.get("trunk"))
    if trunk["enabled"]:
        clash = sorted(seen & set(EMERGENCY))
        if clash:
            raise PbxError("le poste %s porte un numéro d'urgence : renumérotez-le avant d'activer la ligne" % clash[0])
    by_number = {e["number"]: e for e in clean}
    reception = validate_reception(data.get("reception"), by_number)
    groups = validate_groups(data.get("groups"), by_number)
    group_numbers = {g["number"] for g in groups}
    for e in clean:
        e["forward"] = validate_forward(e["forward"], e["number"], by_number, group_numbers, trunk)
    check_forward_loops(clean)
    mail = validate_mail(data.get("mail"))
    queues = validate_queues(data.get("queues"), by_number, group_numbers)
    queue_numbers = {q["number"] for q in queues}
    ivr = validate_ivr(data.get("ivr"), by_number, group_numbers | queue_numbers)
    try:
        book = directory.validate(data.get("directory"))
    except directory.DirectoryError as exc:
        raise PbxError(str(exc)) from None
    speed = validate_speed_dials(data.get("speed_dials"))
    return {"language": language, "extensions": clean, "trunk": trunk, "reception": reception, "groups": groups,
            "mail": mail, "ivr": ivr, "directory": book, "speed_dials": speed, "queues": queues,
            "recording": validate_recording(data.get("recording"))}


# ------------------------------------------------------- files d'attente et enregistrement
def default_recording():
    return {"keep_days": 30}


def validate_recording(data):
    """Enregistrement des appels : durée de conservation des fichiers (purge par voipbuntu-recordings.timer)."""
    if data is None:
        return default_recording()
    if not isinstance(data, dict):
        raise PbxError("enregistrement : réglages invalides")
    try:
        keep = int(data.get("keep_days", 30))
    except (TypeError, ValueError):
        raise PbxError("enregistrement : durée de conservation invalide") from None
    if not 1 <= keep <= 365:
        raise PbxError("enregistrement : durée de conservation entre 1 et 365 jours")
    return {"keep_days": keep}


def validate_queue_target(target, exts, groups, number):
    """Débordement d'une file : poste, groupe, « vm:poste » ou rien (raccrocher)."""
    target = str(target or "").strip()
    if not target:
        return ""
    if target.startswith("vm:"):
        box = target[3:]
        if box not in exts or not exts[box]["voicemail"]:
            raise PbxError("files : débordement de la file %s : la messagerie doit être celle d'un poste qui en a une" % number)
        return target
    if target in exts or target in groups:
        return target
    raise PbxError("files : débordement de la file %s : destination inconnue" % number)


def validate_queues(data, exts, groups):
    """Files d'attente : l'appelant patiente (musique, annonce) jusqu'à ce qu'un poste libre réponde."""
    if data is None:
        return []
    if not isinstance(data, list) or len(data) > MAX_QUEUES:
        raise PbxError("files : liste invalide")
    out, seen = [], set()
    for q in data:
        if not isinstance(q, dict):
            raise PbxError("files : file invalide")
        number, name = str(q.get("number", "")), str(q.get("name", "")).strip()
        if not NUMBER_RE.match(number) or number in EMERGENCY:
            raise PbxError("files : numéro invalide %s" % number[:8])
        if number in exts or number in groups or number in seen:
            raise PbxError("files : le numéro %s est déjà utilisé" % number)
        if not NAME_RE.match(name):
            raise PbxError("files : nom invalide pour %s" % number)
        members = q.get("members", [])
        if not isinstance(members, list) or len(members) > 20:
            raise PbxError("files : liste de postes invalide pour %s" % number)
        clean = []
        for m in members:
            m = str(m)
            if m not in exts:
                raise PbxError("files : poste %s inconnu" % m[:8])
            if m not in clean:
                clean.append(m)
        if not clean:
            raise PbxError("files : la file %s n'a aucun poste" % number)
        strategy = str(q.get("strategy", "ringall"))
        if strategy not in QUEUE_STRATEGIES:
            raise PbxError("files : stratégie invalide pour %s" % number)
        try:
            ring, wait = int(q.get("ring_seconds", 15)), int(q.get("max_wait", 120))
        except (TypeError, ValueError):
            raise PbxError("files : durées invalides pour %s" % number) from None
        if not 5 <= ring <= 60:
            raise PbxError("files : sonnerie de chaque poste entre 5 et 60 secondes")
        if not 10 <= wait <= 1800:
            raise PbxError("files : attente maximale entre 10 secondes et 30 minutes")
        seen.add(number)
        out.append({"number": number, "name": name, "members": clean, "strategy": strategy, "ring_seconds": ring,
                    "max_wait": wait, "overflow": validate_queue_target(q.get("overflow"), exts, groups, number),
                    "announce": bool(q.get("announce", True)), "record": bool(q.get("record", False))})
    out.sort(key=lambda q: (len(q["number"]), q["number"]))
    return out


def validate_speed_dials(data):
    """Numéros abrégés : *1XX compose un numéro extérieur (national ou international) par la ligne."""
    if data is None:
        return []
    if not isinstance(data, list) or len(data) > MAX_SPEED_DIALS:
        raise PbxError("numéros abrégés : liste invalide")
    out, seen = [], set()
    for d in data:
        if not isinstance(d, dict):
            raise PbxError("numéros abrégés : entrée invalide")
        code = str(d.get("code", "")).strip()
        if code.startswith(SPEED_PREFIX) and len(code) == 4:
            code = code[2:]
        if not SPEED_CODE_RE.match(code):
            raise PbxError("numéros abrégés : code invalide (deux chiffres)")
        if code in seen:
            raise PbxError("numéros abrégés : code %s en double" % code)
        number = directory.normalize_number(d.get("number"))
        if not number or not is_external(number):
            raise PbxError("numéros abrégés : numéro extérieur invalide pour *1%s" % code)
        name = directory.clean_text(d.get("name"), 40)
        seen.add(code)
        out.append({"code": code, "number": number, "name": name})
    out.sort(key=lambda d: d["code"])
    return out


def default_ivr():
    return {"enabled": False, "options": [], "timeout": 5, "default": "", "hold_music": False}


def validate_ivr_target(target, exts, groups, what):
    """Destination d'une touche du menu : poste, groupe, « vm:poste » (messagerie) ou « accueil »."""
    target = str(target or "").strip()
    if target in ("", "accueil"):
        return target
    if target.startswith("vm:"):
        box = target[3:]
        if box not in exts or not exts[box]["voicemail"]:
            raise PbxError("menu vocal : %s : la messagerie doit être celle d'un poste qui en a une" % what)
        return target
    if target in exts or target in groups:
        return target
    raise PbxError("menu vocal : %s : destination inconnue" % what)


def validate_ivr(data, exts, groups):
    """Menu vocal de l'accueil : « tapez 1 pour…, 2 pour… », destination par défaut sans choix."""
    if data is None:
        return default_ivr()
    if not isinstance(data, dict):
        raise PbxError("menu vocal : réglages invalides")
    m = default_ivr()
    m["enabled"] = bool(data.get("enabled", False))
    m["hold_music"] = bool(data.get("hold_music", False))
    try:
        m["timeout"] = int(data.get("timeout", 5))
    except (TypeError, ValueError):
        raise PbxError("menu vocal : délai invalide") from None
    if not 2 <= m["timeout"] <= 30:
        raise PbxError("menu vocal : délai de choix entre 2 et 30 secondes")
    options = data.get("options", [])
    if not isinstance(options, list) or len(options) > len(MENU_DIGITS):
        raise PbxError("menu vocal : liste de choix invalide")
    seen = set()
    for o in options:
        if not isinstance(o, dict):
            raise PbxError("menu vocal : choix invalide")
        digit = str(o.get("digit", ""))
        if digit not in MENU_DIGITS:
            raise PbxError("menu vocal : touche invalide")
        if digit in seen:
            raise PbxError("menu vocal : touche %s en double" % digit)
        target = validate_ivr_target(o.get("target"), exts, groups, "touche %s" % digit)
        if not target:
            raise PbxError("menu vocal : touche %s : destination inconnue" % digit)
        seen.add(digit)
        m["options"].append({"digit": digit, "target": target})
    m["options"].sort(key=lambda o: MENU_DIGITS.index(o["digit"]))
    m["default"] = validate_ivr_target(data.get("default", ""), exts, groups, "sans choix")
    if m["enabled"] and not m["options"]:
        raise PbxError("menu vocal : ajoutez au moins une touche pour l'activer")
    return m


def default_mail():
    return {"enabled": False, "host": "", "port": 587, "security": "starttls", "username": "", "password": "",
            "from_address": ""}


def validate_mail(data):
    """Serveur d'envoi (SMTP) pour la messagerie vocale par e-mail."""
    if data is None:
        return default_mail()
    if not isinstance(data, dict):
        raise PbxError("e-mail : réglages invalides")
    m = default_mail()
    m["enabled"] = bool(data.get("enabled", False))
    for key in ("host", "username", "password", "from_address", "security"):
        value = data.get(key, m[key])
        if not isinstance(value, str):
            raise PbxError("e-mail : champ %s invalide" % key)
        m[key] = value.strip() if key != "password" else value
    try:
        m["port"] = int(data.get("port", 587))
    except (TypeError, ValueError):
        raise PbxError("e-mail : port invalide") from None
    if not 1 <= m["port"] <= 65535:
        raise PbxError("e-mail : port invalide")
    if m["security"] not in MAIL_SECURITY:
        raise PbxError("e-mail : sécurité invalide")
    if m["host"] and not HOST_RE.match(m["host"]):
        raise PbxError("e-mail : serveur invalide")
    if m["username"] and (len(m["username"]) > 128 or not re.match(r"^[!-~]+$", m["username"]) or set(m["username"]) & TRUNK_SECRET_FORBIDDEN):
        raise PbxError("e-mail : identifiant invalide")
    if m["password"] and (not TRUNK_SECRET_RE.match(m["password"]) or set(m["password"]) & TRUNK_SECRET_FORBIDDEN):
        raise PbxError("e-mail : mot de passe invalide")
    if m["from_address"] and not EMAIL_RE.match(m["from_address"]):
        raise PbxError("e-mail : adresse d'expédition invalide")
    if m["enabled"] and not (m["host"] and m["from_address"]):
        raise PbxError("e-mail : serveur et adresse d'expédition sont requis")
    if m["username"] and m["security"] == "none":
        raise PbxError("e-mail : identifiant sans chiffrement")
    if m["enabled"] and m["username"] and not m["password"]:
        raise PbxError("e-mail : mot de passe requis avec un identifiant")
    return m


def render_msmtprc(m):
    """Configuration de msmtp, lue par Asterisk pour envoyer les messages vocaux."""
    lines = ["# Généré par voipbuntu-pbx, ne pas modifier.", "defaults",
             "syslog LOG_MAIL", "timeout 30",
             "tls %s" % ("off" if m["security"] == "none" else "on"),
             "tls_starttls %s" % ("on" if m["security"] == "starttls" else "off"),
             "tls_trust_file /etc/ssl/certs/ca-certificates.crt", "",
             "account default", "host %s" % m["host"], "port %d" % m["port"], "from %s" % m["from_address"]]
    if m["username"]:
        lines += ["auth on", "user %s" % m["username"], "password %s" % m["password"]]
    else:
        lines.append("auth off")
    return "\n".join(lines) + "\n"


# Pas de « ; » dans ces textes : voicemail.conf le lit comme un début de commentaire.
MAIL_TEXT = {
    "fr": ("Messagerie VOIPbuntu",
           "Nouveau message de ${VM_CALLERID} pour le poste ${VM_MAILBOX}",
           "Bonjour ${VM_NAME},\\n\\nVous avez reçu un message vocal de ${VM_CALLERID} le ${VM_DATE}, "
           "d'une durée de ${VM_DUR}.\\nLe message est joint à cet e-mail. Il reste aussi sur la messagerie (*97).\\n\\nVOIPbuntu\\n"),
    "en": ("VOIPbuntu voicemail",
           "New message from ${VM_CALLERID} for extension ${VM_MAILBOX}",
           "Hello ${VM_NAME},\\n\\nYou received a voice message from ${VM_CALLERID} on ${VM_DATE}, "
           "lasting ${VM_DUR}.\\nThe message is attached. It also stays in your voicemail (*97).\\n\\nVOIPbuntu\\n"),
}


def validate_groups(data, exts):
    """Groupes d'appel : un numéro court qui fait sonner plusieurs postes ensemble."""
    if data is None:
        return []
    if not isinstance(data, list) or len(data) > MAX_GROUPS:
        raise PbxError("groupes : liste invalide")
    out, seen = [], set()
    for g in data:
        if not isinstance(g, dict):
            raise PbxError("groupes : groupe invalide")
        number, name = str(g.get("number", "")), str(g.get("name", "")).strip()
        if not NUMBER_RE.match(number) or number in EMERGENCY:
            raise PbxError("groupes : numéro invalide %s" % number[:8])
        if number in exts or number in seen:
            raise PbxError("groupes : le numéro %s est déjà utilisé" % number)
        if not NAME_RE.match(name):
            raise PbxError("groupes : nom invalide pour %s" % number)
        rec = validate_reception({"members": g.get("members", []), "ring_seconds": g.get("ring_seconds", 25),
                                  "voicemail_box": g.get("voicemail_box", "")}, exts, "groupes")
        if not rec["members"]:
            raise PbxError("groupes : le groupe %s n'a aucun poste" % number)
        seen.add(number)
        out.append({"number": number, "name": name, "members": rec["members"],
                    "ring_seconds": rec["ring_seconds"], "voicemail_box": rec["voicemail_box"]})
    out.sort(key=lambda g: (len(g["number"]), g["number"]))
    return out


def default_forward():
    return {"mode": "off", "target": "", "ring_seconds": 20}


def is_external(target):
    return bool(NATIONAL_RE.match(target) or INTERNATIONAL_RE.match(target))


def validate_forward(data, number, exts, groups, trunk):
    """Renvoi d'un poste : toujours, ou sans réponse/occupé, vers un poste, un groupe ou un numéro extérieur."""
    if data is None:
        return default_forward()
    if not isinstance(data, dict):
        raise PbxError("renvoi invalide pour le poste %s" % number)
    f = default_forward()
    f["mode"] = str(data.get("mode", "off"))
    if f["mode"] not in FORWARD_MODES:
        raise PbxError("renvoi : mode invalide pour le poste %s" % number)
    try:
        f["ring_seconds"] = int(data.get("ring_seconds", 20))
    except (TypeError, ValueError):
        raise PbxError("renvoi : durée de sonnerie invalide") from None
    if not 5 <= f["ring_seconds"] <= 120:
        raise PbxError("renvoi : durée de sonnerie entre 5 et 120 secondes")
    target = str(data.get("target", "")).strip().replace(" ", "")
    if f["mode"] == "off":
        f["target"] = target if (target in exts or target in groups or is_external(target)) else ""
        return f
    if target == number:
        raise PbxError("renvoi : le poste %s ne peut pas se renvoyer vers lui-même" % number)
    if target in exts or target in groups:
        f["target"] = target
        return f
    if target in EMERGENCY:
        raise PbxError("renvoi : destination invalide pour le poste %s" % number)
    if is_external(target):
        if not trunk["enabled"]:
            raise PbxError("renvoi : un numéro extérieur demande la ligne de l'opérateur (poste %s)" % number)
        if INTERNATIONAL_RE.match(target) and not trunk["international"]:
            raise PbxError("renvoi : international non autorisé sur la ligne (poste %s)" % number)
        f["target"] = target
        return f
    raise PbxError("renvoi : destination invalide pour le poste %s" % number)


def check_forward_loops(exts):
    """Les renvois permanents ne doivent pas former de boucle (101 -> 102 -> 101)."""
    always = {e["number"]: e["forward"]["target"] for e in exts if e["forward"]["mode"] == "always"}
    for start in always:
        seen, cur = {start}, always[start]
        while cur in always:
            if cur in seen:
                raise PbxError("renvoi : boucle de renvois permanents entre les postes %s" % " et ".join(sorted(seen)))
            seen.add(cur)
            cur = always[cur]


def rename_number(state, old, new):
    """Un poste change de numéro court : accueil, groupes et renvois suivent."""
    for rec in [state["reception"]] + state.get("groups", []):
        rec["members"] = [new if m == old else m for m in rec["members"]]
        if rec["voicemail_box"] == old:
            rec["voicemail_box"] = new
    for e in state["extensions"]:
        if e.get("forward") and e["forward"].get("target") == old:
            e["forward"]["target"] = new
    for q in state.get("queues", []):
        q["members"] = [new if m == old else m for m in q["members"]]
        q["overflow"] = {old: new, "vm:" + old: "vm:" + new}.get(q.get("overflow", ""), q.get("overflow", ""))
    ivr = state.get("ivr")
    if ivr:
        swap = {old: new, "vm:" + old: "vm:" + new}
        for o in ivr["options"]:
            o["target"] = swap.get(o["target"], o["target"])
        ivr["default"] = swap.get(ivr["default"], ivr["default"])


def drop_number(state, number):
    """Un poste ou un groupe disparaît : il est retiré de l'accueil, des groupes et des renvois."""
    for rec in [state["reception"]] + state.get("groups", []):
        rec["members"] = [m for m in rec["members"] if m != number]
        if rec["voicemail_box"] == number:
            rec["voicemail_box"] = ""
    gone = {number} | {g["number"] for g in state.get("groups", []) if not g["members"]}
    state["groups"] = [g for g in state.get("groups", []) if g["members"]]
    # Files d'attente : le poste en sort ; une file sans poste disparaît
    for q in state.get("queues", []):
        q["members"] = [m for m in q["members"] if m != number]
    gone |= {q["number"] for q in state.get("queues", []) if not q["members"]}
    state["queues"] = [q for q in state.get("queues", []) if q["members"]]
    for q in state["queues"]:
        if q.get("overflow") in gone | {"vm:" + number}:
            q["overflow"] = ""
    for e in state["extensions"]:
        if e.get("forward") and e["forward"].get("target") in gone:
            e["forward"] = default_forward()
    drop_ivr_targets(state, gone | {"vm:" + number})


def drop_ivr_targets(state, gone):
    """Touches du menu vocal qui menaient à une destination disparue : retirées (menu coupé s'il est vide)."""
    ivr = state.get("ivr")
    if not ivr:
        return
    ivr["options"] = [o for o in ivr["options"] if o["target"] not in gone]
    if ivr["default"] in gone:
        ivr["default"] = ""
    if not ivr["options"]:
        ivr["enabled"] = False


def drop_voicemail(state, number):
    """Un poste perd sa messagerie : il n'est plus messagerie de secours."""
    for rec in [state["reception"]] + state.get("groups", []):
        if rec["voicemail_box"] == number:
            rec["voicemail_box"] = ""
    for q in state.get("queues", []):
        if q.get("overflow") == "vm:" + number:
            q["overflow"] = ""
    drop_ivr_targets(state, {"vm:" + number})


def default_trunk():
    return {"enabled": False, "host": "", "port": 5060, "username": "", "auth_username": "", "password": "",
            "register": True, "caller_id": "", "public_address": "", "international": False}


def validate_trunk(data):
    """Ligne de l'opérateur (compte SIP). Absente ou désactivée : aucun appel extérieur possible."""
    if data is None:
        return default_trunk()
    if not isinstance(data, dict):
        raise PbxError("ligne opérateur invalide")
    t = default_trunk()
    t["enabled"] = bool(data.get("enabled", False))
    t["register"] = bool(data.get("register", True))
    t["international"] = bool(data.get("international", False))
    for key in ("host", "username", "auth_username", "password", "caller_id", "public_address"):
        value = data.get(key, "")
        if not isinstance(value, str):
            raise PbxError("ligne opérateur : champ %s invalide" % key)
        t[key] = value.strip() if key != "password" else value
    try:
        t["port"] = int(data.get("port", 5060))
    except (TypeError, ValueError):
        raise PbxError("ligne opérateur : port invalide") from None
    if not 1 <= t["port"] <= 65535:
        raise PbxError("ligne opérateur : port invalide")
    if t["host"] and not HOST_RE.match(t["host"]):
        raise PbxError("ligne opérateur : serveur invalide")
    for key in ("username", "auth_username"):
        if t[key] and not SIP_USER_RE.match(t[key]):
            raise PbxError("ligne opérateur : identifiant invalide")
    if t["password"] and (not TRUNK_SECRET_RE.match(t["password"]) or set(t["password"]) & TRUNK_SECRET_FORBIDDEN):
        raise PbxError("ligne opérateur : mot de passe invalide (caractères ; \\ \" [ ] # et espaces refusés)")
    if t["caller_id"] and not PHONE_RE.match(t["caller_id"]):
        raise PbxError("ligne opérateur : numéro présenté invalide")
    if t["public_address"]:
        import ipaddress
        try:
            if ipaddress.ip_address(t["public_address"]).version != 4:
                raise ValueError
        except ValueError:
            raise PbxError("ligne opérateur : adresse publique IPv4 invalide") from None
    if t["enabled"] and not (t["host"] and t["username"] and t["password"]):
        raise PbxError("ligne opérateur : serveur, identifiant et mot de passe sont requis pour l'activer")
    return t


def default_reception():
    return {"members": [], "ring_seconds": 25, "hours": None, "voicemail_box": ""}


def validate_reception(data, exts, what="accueil"):
    """Accueil : postes qui sonnent ensemble pour un appel entrant, horaires, messagerie de secours."""
    if data is None:
        return default_reception()
    if not isinstance(data, dict):
        raise PbxError("%s invalide" % what)
    r = default_reception()
    members = data.get("members", [])
    if not isinstance(members, list) or len(members) > 20:
        raise PbxError("%s : liste de postes invalide" % what)
    for m in members:
        m = str(m)
        if m not in exts:
            raise PbxError("%s : poste %s inconnu" % (what, m[:8]))
        if m not in r["members"]:
            r["members"].append(m)
    try:
        r["ring_seconds"] = int(data.get("ring_seconds", 25))
    except (TypeError, ValueError):
        raise PbxError("%s : durée de sonnerie invalide" % what) from None
    if not 5 <= r["ring_seconds"] <= 120:
        raise PbxError("%s : durée de sonnerie entre 5 et 120 secondes" % what)
    box = str(data.get("voicemail_box") or "")
    if box and (box not in exts or not exts[box]["voicemail"]):
        raise PbxError("%s : la messagerie de secours doit être celle d'un poste qui en a une" % what)
    r["voicemail_box"] = box
    hours = data.get("hours")
    if hours is not None:
        if not isinstance(hours, dict):
            raise PbxError("%s : horaires invalides" % what)
        days = hours.get("days", [])
        start, end = str(hours.get("start", "")), str(hours.get("end", ""))
        if not isinstance(days, list) or not days or any(d not in DAYS for d in days):
            raise PbxError("%s : jours d'ouverture invalides" % what)
        if not TIME_RE.match(start) or not TIME_RE.match(end) or start >= end:
            raise PbxError("%s : horaires invalides (HH:MM, ouverture avant fermeture)" % what)
        r["hours"] = {"days": [d for d in DAYS if d in days], "start": start, "end": end}
    return r


def public(state):
    """Vue de la console : jamais le mot de passe SIP ni le code de messagerie."""
    trunk = dict(state["trunk"])
    trunk["password_set"] = bool(trunk.pop("password"))
    mail = dict(state["mail"])
    mail["password_set"] = bool(mail.pop("password"))
    return {"language": state["language"],
            "extensions": [{"number": e["number"], "name": e["name"], "sip_user": e["sip_user"], "voicemail": e["voicemail"],
                            "forward": e["forward"], "email": e["email"], "record": e["record"]}
                           for e in state["extensions"]],
            "trunk": trunk, "reception": state["reception"], "groups": state["groups"], "mail": mail,
            "ivr": state["ivr"], "speed_dials": state["speed_dials"],
            "queues": state["queues"], "recording": state["recording"],
            "directory_count": len(state["directory"]["contacts"])}


# ------------------------------------------------------------------ Asterisk
HEADER = "; Généré par voipbuntu-pbx, ne pas modifier : la console VOIPbuntu remplace ce fichier.\n"

MODULES = [
    "res_pjsip.so", "res_pjsip_session.so", "res_pjsip_authenticator_digest.so",
    "res_pjsip_endpoint_identifier_user.so", "res_pjsip_endpoint_identifier_ip.so",
    "res_pjsip_outbound_authenticator_digest.so", "res_pjsip_registrar.so", "res_pjsip_outbound_registration.so",
    "res_pjsip_sdp_rtp.so", "res_pjsip_caller_id.so", "res_pjsip_dtmf_info.so", "res_pjsip_rfc3326.so",
    "res_pjsip_mwi.so", "res_pjsip_mwi_body_generator.so", "res_pjsip_pubsub.so", "res_pjsip_nat.so",
    "res_pjsip_logger.so", "res_pjproject.so", "res_sorcery_config.so", "res_sorcery_memory.so",
    "res_sorcery_astdb.so", "res_rtp_asterisk.so", "res_timing_timerfd.so",
    "chan_pjsip.so", "chan_bridge_media.so",
    "app_dial.so", "app_stack.so", "app_exec.so", "app_voicemail.so", "app_echo.so", "app_playback.so", "app_verbose.so",
    "res_musiconhold.so",
    "bridge_simple.so", "bridge_native_rtp.so", "bridge_softmix.so", "bridge_holding.so",
    "codec_alaw.so", "codec_ulaw.so", "codec_g722.so", "codec_gsm.so", "codec_a_mu.so",
    "format_gsm.so", "format_wav.so", "format_wav_gsm.so", "format_pcm.so",
    "func_callerid.so", "func_logic.so", "func_strings.so", "func_channel.so", "func_dialplan.so",
    "pbx_config.so", "cdr_csv.so",
]
MODULES += ["app_queue.so", "app_mixmonitor.so"]  # files d'attente et enregistrement des appels
CDR_FIELDS = ("accountcode", "src", "dst", "dcontext", "clid", "channel", "dstchannel", "lastapp", "lastdata",
              "start", "answer", "end", "duration", "billsec", "disposition", "amaflags")
DISPOSITIONS = ("ANSWERED", "NO ANSWER", "BUSY", "FAILED", "CONGESTION")


def render(state, phone_nets="", asterisk_dir="/etc/asterisk", sounds=None, moh_dir=None):
    """Renvoie {nom de fichier: contenu} pour /etc/asterisk.

    sounds : {nom d'annonce: chemin sans extension} des annonces présentes sur le disque ;
    moh_dir : dossier de la musique d'attente (aucune classe de musique si None).
    """
    state = validate(state)
    state["_sounds"] = dict(sounds or {})
    state["_moh"] = bool(moh_dir)
    lang = state["language"]
    files = {}
    files["modules.conf"] = HEADER + "[modules]\nautoload=no\n" + "".join("load = %s\n" % m for m in MODULES)
    files["logger.conf"] = HEADER + ("[general]\ndateformat=%F %T\n\n[logfiles]\n"
                                     "console => notice,warning,error\nmessages.log => notice,warning,error,security\n")
    files["rtp.conf"] = HEADER + "[general]\nrtpstart=10000\nrtpend=20000\nstrictrtp=yes\nicesupport=no\n"
    files["manager.conf"] = HEADER + "[general]\nenabled=no\n"
    # cdr_csv lit sa section [csv] dans cdr.conf (il n'a pas de fichier à lui)
    files["cdr.conf"] = HEADER + ("[general]\nenable=yes\nunanswered=yes\ncongestion=yes\n\n"
                                  "[csv]\nusegmtime=no\nloguniqueid=no\nloguserfield=no\naccountlogs=no\n")
    for name, body in (("cel.conf", "[general]\nenable=no\n"),
                       ("features.conf", "[general]\n"), ("ccss.conf", "[general]\n"), ("acl.conf", ""),
                       ("pjproject.conf", "[startup]\nlog_level=default\n"), ("udptl.conf", "[general]\n")):
        files[name] = HEADER + body
    files["http.conf"] = HEADER + "[general]\nenabled=no\n"
    files["musiconhold.conf"] = HEADER + "[general]\n" + (
        "\n[default]\nmode=files\ndirectory=%s\nsort=alpha\n" % moh_dir if moh_dir else "")
    files["indications.conf"] = HEADER + "[general]\ncountry=fr\n\n[fr]\ndescription = France\nringcadence = 1500,3500\ndial = 440\nbusy = 440/500,0/500\nring = 440/1500,0/3500\ncongestion = 440/250,0/250\ncallwaiting = 440/300,0/10000\ndialrecall = !350+440/100,!0/100,!350+440/100,!0/100,!350+440/100,!0/100,350+440\nrecord = 1400/500,0/15000\ninfo = !950/330,!1400/330,!1800/330\nstutter = !440/100,!0/100,!440/100,!0/100,!440/100,!0/100,!440/100,!0/100,!440/100,!0/100,!440/100,!0/100,440\n"
    trunk = state["trunk"]
    nat = ""
    if trunk["enabled"] and trunk["public_address"]:
        nat = "external_media_address=%s\nexternal_signaling_address=%s\n%s" % (
            trunk["public_address"], trunk["public_address"],
            "".join("local_net=%s\n" % n for n in local_nets(phone_nets)))
    pjsip = [HEADER,
             "[global]\ntype=global\nuser_agent=VOIPbuntu\nendpoint_identifier_order=username,ip\n\n",
             "[transport-udp]\ntype=transport\nprotocol=udp\nbind=0.0.0.0:5060\n%s\n" % nat,
             "[transport-tcp]\ntype=transport\nprotocol=tcp\nbind=0.0.0.0:5060\n%s\n" % nat]
    for e in state["extensions"]:
        n, u = e["number"], e["sip_user"]
        pjsip.append(
            "[%s]\ntype=endpoint\ncontext=voipbuntu-internes\ndisallow=all\nallow=g722,alaw,ulaw\n"
            "auth=%s\naors=%s\ncallerid=\"%s\" <%s>\nlanguage=%s\ndirect_media=no\nrtp_symmetric=yes\n"
            "force_rport=yes\nrewrite_contact=yes\ndtmf_mode=rfc4733\n%s%s\n" % (
                u, u, u, e["name"], n, lang, ("mailboxes=%s@default\n" % n) if e["voicemail"] else "",
                "set_var=VB_RECORD=1\n" if e["record"] and recording_on(state) else ""))
        pjsip.append("[%s]\ntype=auth\nauth_type=userpass\nusername=%s\npassword=%s\n\n" % (u, u, e["secret"]))
        pjsip.append("[%s]\ntype=aor\nmax_contacts=2\nremove_existing=yes\nqualify_frequency=60\n\n" % u)
    if trunk["enabled"]:
        pjsip.append(render_trunk(trunk, lang))
    files["pjsip.conf"] = "".join(pjsip)
    ext = [HEADER, "[general]\nstatic=yes\nwriteprotect=yes\nclearglobalvars=yes\n\n[globals]\n\n",
           "[voipbuntu-internes]\n",
           "exten => *43,1,NoOp(Test d'écho)\n same => n,Answer()\n same => n,Playback(demo-echotest)\n"
           " same => n,Echo()\n same => n,Hangup()\n",
           "exten => *97,1,NoOp(Messagerie vocale)\n same => n,Answer()\n"
           " same => n,VoiceMailMain(${CALLERID(num)}@default)\n same => n,Hangup()\n"]
    for e in state["extensions"]:
        ext.append(render_extension(state, e))
    for g in state["groups"]:
        ext.append(render_group(state, g))
    for q in state["queues"]:
        ext.append("exten => %s,1,NoOp(File d'attente %s)\n" % (q["number"], q["number"]))
        ext.append(render_queue(state, q))
    if trunk["enabled"]:
        ext.append(render_outbound(trunk, state))
        ext.append(render_speed_dials(state))
    ext.append("exten => i,1,Playback(invalid)\n same => n,Hangup()\n"
               "exten => _X.,1,Playback(ss-noservice)\n same => n,Hangup()\n")
    if trunk["enabled"]:
        ext.append(render_inbound(state))
        ext.append(render_directory(state))
    if trunk["enabled"] and trunk["caller_id"]:
        # Renvois vers l'extérieur : la ligne présente toujours son propre numéro
        ext.append("\n[voipbuntu-renvoi]\nexten => s,1,ExecIf($[\"${CHANNEL(endpoint)}\" = \"%s\"]?"
                   "Set(CONNECTEDLINE(num,i)=%s))\n same => n,Return()\n" % (TRUNK, trunk["caller_id"]))
    if recording_on(state):
        ext.append(render_recording(state))
    files["extensions.conf"] = "".join(ext)
    files["queues.conf"] = render_queues_conf(state)
    files["queuerules.conf"] = HEADER + "[general]\n"
    mail = state["mail"]
    general = "[general]\nformat=wav49|gsm|wav\nattach=no\nmaxmsg=100\nmaxsecs=180\nminsecs=2\nmaxlogins=3\nskipms=3000\n"
    if mail["enabled"]:
        fromstring, subject, body = MAIL_TEXT[lang]
        rc = os.path.join(asterisk_dir, "msmtprc")
        general += ("serveremail=%s\nfromstring=%s\ncharset=UTF-8\nemaildateformat=%%d/%%m/%%Y %%H:%%M\n"
                    "emailsubject=%s\nemailbody=%s\nmailcmd=%s -C %s -t\n" % (
                        mail["from_address"], fromstring, subject, body, MSMTP, rc))
        files["msmtprc"] = render_msmtprc(mail)
    else:
        general += "serveremail=voipbuntu\n"
    vm = [HEADER, general, "\n[zonemessages]\neurope=Europe/Paris|'vm-received' Q 'digits/at' HM\n\n[default]\n"]
    for e in state["extensions"]:
        if e["voicemail"]:
            email = e["email"] if mail["enabled"] else ""
            vm.append("%s => %s,%s,%s,,tz=europe|saycid=no|envelope=no%s\n" % (
                e["number"], e["pin"], e["name"], email, "|attach=yes" if email else ""))
    files["voicemail.conf"] = "".join(vm)
    return files


TRUNK = "operateur"


def predial(state):
    """Option de Dial qui fixe le numéro présenté sur les branches qui sortent par la ligne."""
    t = state["trunk"]
    return ",b(voipbuntu-renvoi^s^1)" if t["enabled"] and t["caller_id"] else ""


def dial_targets(state, numbers):
    """Chaînes Dial des postes à faire sonner, renvois permanents et groupes résolus (sans boucle)."""
    exts = {e["number"]: e for e in state["extensions"]}
    groups = {g["number"]: g for g in state["groups"]}
    out, visited = [], set()

    def resolve(n):
        if n in visited:
            return
        visited.add(n)
        if n in groups:
            for m in groups[n]["members"]:
                resolve(m)
        elif is_external(n):
            target = "PJSIP/%s@%s" % (n, TRUNK)
            if state["trunk"]["enabled"] and target not in out:
                out.append(target)
        elif n in exts:
            f = exts[n]["forward"]
            if f["mode"] == "always":
                resolve(f["target"])
            elif "PJSIP/" + exts[n]["sip_user"] not in out:
                out.append("PJSIP/" + exts[n]["sip_user"])

    for n in numbers:
        resolve(n)
    return out


def ring_dial(state, numbers, seconds, media=""):
    """media : « r » (sonnerie jouée à l'appelant déjà décroché) ou « m(default) » (musique d'attente)."""
    targets = dial_targets(state, numbers)
    if not targets:
        return ""
    opts = predial(state) if any("@" in t for t in targets) else ""
    if media:
        opts = (opts or ",") + media
    # Les postes non enregistrés sont écartés à l'appel (un Dial vers eux échouerait en erreur)
    out = [" same => n,Set(VB_DIAL=)\n"]
    for t in targets:
        if "@" in t:
            out.append(" same => n,Set(VB_DIAL=${VB_DIAL}&%s)\n" % t)
        else:
            out.append(" same => n,ExecIf($[\"${PJSIP_DIAL_CONTACTS(%s)}\" != \"\"]?Set(VB_DIAL=${VB_DIAL}&%s))\n" % (t[6:], t))
    out.append(" same => n,GotoIf($[\"${VB_DIAL}\" = \"\"]?personne)\n"
               " same => n,Dial(${VB_DIAL:1},%d%s)\n same => n(personne),NoOp(Suite)\n" % (seconds, opts))
    return "".join(out)


def render_fallback(box):
    if box:
        return (" same => n,GotoIf($[\"${DIALSTATUS}\" = \"BUSY\"]?busy)\n"
                " same => n,VoiceMail(%s@default,u)\n same => n,Hangup()\n"
                " same => n(busy),VoiceMail(%s@default,b)\n same => n,Hangup()\n" % (box, box))
    return " same => n,Hangup()\n"


def render_extension(state, e):
    """Appel direct d'un poste : renvoi permanent, ou sonnerie puis renvoi / messagerie."""
    n, f = e["number"], e["forward"]
    box = n if e["voicemail"] else ""
    out = ["exten => %s,1,NoOp(Appel vers %s)\n" % (n, n)]
    if f["mode"] == "always":
        if is_external(f["target"]):
            out.append(" same => n,Dial(PJSIP/%s@%s,120%s)\n same => n,Hangup()\n" % (f["target"], TRUNK, predial(state)))
        else:
            out.append(" same => n,Goto(voipbuntu-internes,%s,1)\n" % f["target"])
        return "".join(out)
    # Appel enregistré : annonce d'information à l'appelant, puis sonnerie jouée par Asterisk
    rec = ",r" if e["record"] and recording_on(state) else ""
    if rec:
        out.append(" same => n,Gosub(voipbuntu-enreg,in,1(%s))\n" % n)
    # Poste non enregistré : pas de Dial (qui échouerait en erreur), directement la suite
    absent = " same => n,GotoIf($[\"${PJSIP_DIAL_CONTACTS(%s)}\" = \"\"]?%s)\n" % (
        e["sip_user"], "renvoi" if f["mode"] == "noanswer" else "absent")
    if f["mode"] != "noanswer":
        out.append(absent)
        out.append(" same => n,Dial(PJSIP/%s,25%s)\n" % (e["sip_user"], rec))
        out.append(" same => n(absent),NoOp(Suite)\n")
        out.append(render_fallback(box))
        return "".join(out)
    # Sans réponse, occupé ou injoignable : renvoi (trois rebonds au plus entre postes)
    out.append(absent)
    out.append(" same => n,Dial(PJSIP/%s,%d%s)\n" % (e["sip_user"], f["ring_seconds"], rec))
    out.append(" same => n,GotoIf($[\"${DIALSTATUS}\" = \"ANSWER\"]?fin)\n"
               " same => n(renvoi),Set(VB_HOPS=$[0${VB_HOPS} + 1])\n"
               " same => n,GotoIf($[${VB_HOPS} > 3]?secours)\n")
    if is_external(f["target"]):
        out.append(" same => n,Dial(PJSIP/%s@%s,60%s)\n" % (f["target"], TRUNK, predial(state)))
        out.append(" same => n,GotoIf($[\"${DIALSTATUS}\" = \"ANSWER\"]?fin)\n")
    else:
        out.append(" same => n,Goto(voipbuntu-internes,%s,1)\n" % f["target"])
    out.append(" same => n(secours),NoOp(Secours)\n")
    out.append(render_fallback(box))
    out.append(" same => n(fin),Hangup()\n")
    return "".join(out)


def render_group(state, g):
    out = ["exten => %s,1,NoOp(Groupe %s)\n" % (g["number"], g["number"])]
    out.append(ring_dial(state, [g["number"]], g["ring_seconds"]))
    out.append(render_fallback(g["voicemail_box"]))
    return "".join(out)


def local_nets(phone_nets):
    """Réseaux locaux pour le NAT : réseaux des téléphones et plages privées IPv4."""
    import ipaddress
    out = []
    for item in (phone_nets or "").replace(",", " ").split():
        try:
            net = ipaddress.ip_network(item, strict=False)
        except ValueError:
            continue
        if net.version == 4 and str(net) not in out:
            out.append(str(net))
    for net in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"):
        if net not in out:
            out.append(net)
    return out


def render_trunk(t, lang):
    host = "%s:%d" % (t["host"], t["port"])
    auth_user = t["auth_username"] or t["username"]
    out = []
    if t["register"]:
        out.append("[%s]\ntype=registration\noutbound_auth=%s-auth\nserver_uri=sip:%s\nclient_uri=sip:%s@%s\n"
                   "contact_user=%s\nretry_interval=60\nforbidden_retry_interval=600\nmax_retries=10000\n"
                   "expiration=600\nline=yes\nendpoint=%s\n\n" % (
                       TRUNK, TRUNK, host, t["username"], host, t["username"], TRUNK))
    out.append("[%s-auth]\ntype=auth\nauth_type=userpass\nusername=%s\npassword=%s\n\n" % (TRUNK, auth_user, t["password"]))
    out.append("[%s]\ntype=aor\ncontact=sip:%s\nqualify_frequency=60\n\n" % (TRUNK, host))
    out.append("[%s]\ntype=endpoint\ncontext=voipbuntu-entrant\ndisallow=all\nallow=alaw,ulaw,g722\n"
               "outbound_auth=%s-auth\naors=%s\nfrom_user=%s\nfrom_domain=%s\nlanguage=%s\ndirect_media=no\n"
               "rtp_symmetric=yes\nforce_rport=yes\nrewrite_contact=yes\ndtmf_mode=rfc4733\n"
               "send_pai=%s\ntrust_id_inbound=no\ntrust_id_outbound=yes\n\n" % (TRUNK, TRUNK, TRUNK, t["username"], t["host"], lang, "yes" if t["caller_id"] else "no"))
    out.append("[%s]\ntype=identify\nendpoint=%s\nmatch=%s\n\n" % (TRUNK, TRUNK, t["host"]))
    return "".join(out)


def render_outbound(t, state=None):
    """Appels sortants des postes : numéros français à 10 chiffres, urgences, international en option."""
    cid = " same => n,Set(CALLERID(num)=%s)\n" % t["caller_id"] if t["caller_id"] else ""
    rule = (" same => n,NoOp(Appel sortant)\n%s same => n,Dial(PJSIP/${EXTEN}@%s,120)\n"
            " same => n,Hangup()\n" % (cid, TRUNK))
    # Poste enregistré (set_var VB_RECORD) : enregistrement, annonce d'information jouée au correspondant
    # au décroché (option A de Dial). Jamais sur les numéros d'urgence.
    recorded = rule
    if state is not None and recording_on(state):
        recorded = (" same => n,NoOp(Appel sortant)\n%s same => n,Set(VB_DOPT=)\n"
                    " same => n,ExecIf($[\"${VB_RECORD}\" = \"1\"]?Gosub(voipbuntu-enreg,out,1(${EXTEN})))\n"
                    " same => n,ExecIf($[\"${VB_RECORD}\" = \"1\"]?Set(VB_DOPT=A(%s)))\n"
                    " same => n,Dial(PJSIP/${EXTEN}@%s,120,${VB_DOPT})\n same => n,Hangup()\n"
                    % (cid, state["_sounds"]["enregistrement"], TRUNK))
    out = ["exten => _0[1-9]XXXXXXXX,1,NoOp(Numéro national)\n" + recorded]
    if t["international"]:
        out.append("exten => _00[1-9].,1,NoOp(Numéro international)\n" + recorded)
    for n in EMERGENCY:
        out.append("exten => %s,1,NoOp(Urgence)\n%s" % (n, rule))
    return "".join(out)


def caller_media(state, answered):
    """Ce qu'entend l'appelant pendant que les postes sonnent."""
    if state["ivr"]["hold_music"] and state.get("_moh"):
        return "m(default)"
    return "r" if answered else ""


def render_inbound(state):
    """Appels entrants de l'opérateur : uniquement vers l'accueil, jamais vers la ligne sortante."""
    r, ivr, sounds = state["reception"], state["ivr"], state.get("_sounds", {})
    menu = ivr["enabled"] and ivr["options"]
    answered = bool(menu or "accueil" in sounds)
    out = ["\n[voipbuntu-entrant]\n",
           "exten => _X.,1,Goto(voipbuntu-accueil,s,1)\nexten => _+X.,1,Goto(voipbuntu-accueil,s,1)\n"
           "exten => s,1,Goto(voipbuntu-accueil,s,1)\n",
           "\n[voipbuntu-accueil]\nexten => s,1,NoOp(Appel entrant)\n", render_lookup()]
    if r["hours"]:
        out.append(" same => n,GotoIfTime(%s-%s,%s,*,*,Europe/Paris?ouvert)\n same => n,Goto(ferme)\n"
                   % (r["hours"]["start"], r["hours"]["end"], "&".join(r["hours"]["days"])))
    out.append(" same => n(ouvert),NoOp(Ouvert)\n")
    if answered:
        out.append(" same => n,Answer()\n same => n,Wait(1)\n")
    if "accueil" in sounds:
        out.append(" same => n,Playback(%s)\n" % sounds["accueil"])
    if menu:
        out.append(" same => n,Goto(voipbuntu-menu,s,1)\n")
    out.append(" same => n(sonner),NoOp(Sonnerie de l'accueil)\n")
    out.append(ring_dial(state, r["members"], r["ring_seconds"], caller_media(state, answered)))
    out.append(" same => n,Goto(secours)\n")
    # Fermé : annonce de fermeture, puis messagerie de secours
    out.append(" same => n(ferme),Answer()\n same => n,Wait(1)\n")
    if "fermeture" in sounds:
        out.append(" same => n,Playback(%s)\n" % sounds["fermeture"])
    if r["voicemail_box"]:
        out.append(" same => n,VoiceMail(%s@default,%s)\n same => n,Hangup()\n"
                   % (r["voicemail_box"], "s" if "fermeture" in sounds else "u"))
    else:
        out.append(" same => n,Playback(vm-goodbye)\n same => n,Hangup()\n")
    out.append(" same => n(secours),Answer()\n same => n,Wait(1)\n")
    if r["voicemail_box"]:
        out.append(" same => n,VoiceMail(%s@default,u)\n" % r["voicemail_box"])
    else:
        out.append(" same => n,Playback(vm-goodbye)\n")
    out.append(" same => n,Hangup()\n")
    if menu:
        out.append(render_menu(state))
    return "".join(out)


def render_speed_dials(state):
    """*1XX : le numéro abrégé suit la règle des appels sortants (numéro présenté, international autorisé ou non)."""
    out = []
    for d in state["speed_dials"]:
        if INTERNATIONAL_RE.match(d["number"]) and not state["trunk"]["international"]:
            continue  # international non autorisé sur la ligne : le code n'existe pas
        out.append("exten => %s%s,1,NoOp(Numéro abrégé %s)\n same => n,Goto(voipbuntu-internes,%s,1)\n"
                   % (SPEED_PREFIX, d["code"], d["code"], d["number"]))
    return "".join(out)


def render_lookup():
    """Appel entrant : le numéro de l'appelant (filtré : chiffres et +) est cherché dans l'annuaire."""
    return (" same => n,Set(VB_NUM=${FILTER(0-9+,${CALLERID(num)})})\n"
            " same => n,ExecIf($[\"${VB_NUM:0:3}\" = \"+33\"]?Set(VB_NUM=0${VB_NUM:3}))\n"
            " same => n,ExecIf($[\"${VB_NUM:0:1}\" = \"+\"]?Set(VB_NUM=00${VB_NUM:1}))\n"
            " same => n,ExecIf($[\"${VB_NUM:0:4}\" = \"0033\"]?Set(VB_NUM=0${VB_NUM:4}))\n"
            " same => n,ExecIf($[\"${VB_NUM:0:2}\" = \"33\" & ${LEN(${VB_NUM})} = 11]?Set(VB_NUM=0${VB_NUM:2}))\n"
            " same => n,GotoIf($[\"${VB_NUM}\" = \"\"]?inconnu)\n"
            " same => n,ExecIf(${DIALPLAN_EXISTS(voipbuntu-annuaire,${VB_NUM},1)}?Gosub(voipbuntu-annuaire,${VB_NUM},1))\n"
            " same => n(inconnu),NoOp(Annuaire)\n")


def render_directory(state):
    """Annuaire : un numéro connu donne son nom à l'appel (CALLERID(name)) avant que les postes sonnent."""
    out = ["\n[voipbuntu-annuaire]\n"]
    for number, contact in sorted(directory.by_number(state["directory"]).items()):
        out.append("exten => %s,1,Set(CALLERID(name)=%s)\n same => n,Return()\n"
                   % (number, directory.callerid_name(contact)))
    return "".join(out)


def render_menu(state):
    """Menu vocal : annonce du menu, choix d'une touche (DTMF), destination ; sans choix, la destination par défaut."""
    ivr, sounds = state["ivr"], state.get("_sounds", {})
    out = ["\n[voipbuntu-menu]\nexten => s,1,NoOp(Menu vocal)\n same => n,Set(VB_ESSAIS=0)\n"]
    out.append(" same => n(menu),%s\n" % ("Background(%s)" % sounds["menu"] if "menu" in sounds else "NoOp(Sans annonce de menu)"))
    out.append(" same => n,WaitExten(%d)\n" % ivr["timeout"])
    for o in ivr["options"]:
        out.append("exten => %s,1,NoOp(Menu : touche %s)\n" % (o["digit"], o["digit"]))
        out.append(render_ivr_destination(state, o["target"]))
    # Touche sans destination : « choix invalide », menu rejoué deux fois, puis la destination par défaut
    out.append("exten => i,1,Set(VB_ESSAIS=$[${VB_ESSAIS} + 1])\n same => n,GotoIf($[${VB_ESSAIS} > 2]?t,1)\n"
               " same => n,Playback(invalid)\n same => n,Goto(s,menu)\n")
    out.append("exten => t,1,NoOp(Menu : sans choix)\n")
    out.append(render_ivr_destination(state, ivr["default"]))
    return "".join(out)


def render_ivr_destination(state, target):
    if target in ("", "accueil"):
        return " same => n,Goto(voipbuntu-accueil,s,sonner)\n"
    if target.startswith("vm:"):
        return " same => n,VoiceMail(%s@default,u)\n same => n,Hangup()\n" % target[3:]
    exts = {e["number"]: e for e in state["extensions"]}
    groups = {g["number"]: g for g in state["groups"]}
    queues = {q["number"]: q for q in state.get("queues", [])}
    if target in queues:
        return render_queue(state, queues[target])
    if target in groups:
        seconds, box = groups[target]["ring_seconds"], groups[target]["voicemail_box"]
    else:
        seconds = state["reception"]["ring_seconds"]
        box = target if exts[target]["voicemail"] else state["reception"]["voicemail_box"]
    return ring_dial(state, [target], seconds, caller_media(state, True)) + render_fallback(box)


def recording_on(state):
    """L'enregistrement n'est actif qu'avec l'annonce d'information de l'appelant (obligation légale)."""
    return "enregistrement" in state.get("_sounds", {})


def recording_name(number):
    """Nom du fichier : date-heure, appelant (chiffres seuls, filtrés par FILTER), poste ou file, identifiant."""
    return ("${STRFTIME(${EPOCH},,%%Y%%m%%d-%%H%%M%%S)}-${FILTER(0-9,${CALLERID(num)}):0:24}-%s-${UNIQUEID}" % number)


def render_recording(state):
    """Sous-programme commun : annonce d'information (appel entrant) puis MixMonitor, une seule fois par appel."""
    announce = state["_sounds"]["enregistrement"]
    return ("\n[voipbuntu-enreg]\n"
            "exten => in,1,GotoIf($[\"${VB_ENREG}\" = \"1\"]?fin)\n same => n,Set(VB_ENREG=1)\n"
            " same => n,Answer()\n same => n,Playback(%s)\n"
            " same => n,MixMonitor(%s.wav,b)\n same => n(fin),Return()\n"
            "exten => out,1,GotoIf($[\"${VB_ENREG}\" = \"1\"]?fin)\n same => n,Set(VB_ENREG=1)\n"
            " same => n,MixMonitor(%s.wav,b)\n same => n(fin),Return()\n"
            % (announce, recording_name("${ARG1}"), recording_name("${ARG1}")))


def queue_name(q):
    return "voipbuntu-file-%s" % q["number"]


def render_queues_conf(state):
    """Une section par file : membres (postes), stratégie, sonnerie de chaque poste, musique et annonce."""
    exts = {e["number"]: e for e in state["extensions"]}
    sounds, moh = state.get("_sounds", {}), state.get("_moh")
    out = [HEADER, "[general]\npersistentmembers=no\nautofill=yes\nshared_lastcall=no\nlog_membername_as_agent=yes\n"]
    for q in state["queues"]:
        out.append("\n[%s]\nstrategy=%s\ntimeout=%d\nretry=2\nwrapuptime=0\nringinuse=no\nautopause=no\n"
                   "joinempty=unavailable,invalid,unknown\nleavewhenempty=unavailable,invalid,unknown\n"
                   "announce-frequency=0\nannounce-holdtime=no\nannounce-position=no\nreportholdtime=no\n"
                   "timeoutpriority=conf\n%s" % (queue_name(q), q["strategy"], q["ring_seconds"],
                                                    "musicclass=default\n" if moh else ""))
        if q["announce"] and "file" in sounds:
            out.append("periodic-announce=%s\nperiodic-announce-frequency=60\n" % sounds["file"])
        for m in q["members"]:
            u = exts[m]["sip_user"]
            out.append("member => PJSIP/%s,0,%s,PJSIP/%s\n" % (u, exts[m]["name"].replace(",", " "), u))
    return "".join(out)


def render_queue(state, q):
    """Corps d'une file : décroché, enregistrement facultatif, annonce, attente, puis débordement."""
    sounds = state.get("_sounds", {})
    out = [" same => n,Answer()\n same => n,Wait(1)\n"]
    if q["record"] and recording_on(state):
        out.append(" same => n,Gosub(voipbuntu-enreg,in,1(%s))\n" % q["number"])
    if q["announce"] and "file" in sounds:
        out.append(" same => n,Playback(%s)\n" % sounds["file"])
    # Sans musique d'attente sur l'appliance, l'appelant entend la sonnerie (option r)
    out.append(" same => n,Queue(%s,%s,,,%d)\n" % (queue_name(q), "" if state.get("_moh") else "r", q["max_wait"]))
    out.append(" same => n,NoOp(File %s : ${QUEUESTATUS})\n" % q["number"])
    target = q["overflow"]
    if not target:
        out.append(" same => n,Playback(vm-goodbye)\n same => n,Hangup()\n")
    else:
        out.append(render_ivr_destination(state, target))
    return "".join(out)


def parse_recordings(entries, keep_days, now):
    """Fichiers d'enregistrement [(nom, taille, date)] : seuls les noms générés par render_recording sortent."""
    out = []
    for name, size, mtime in entries:
        if not RECORDING_RE.match(name):
            continue
        parts = name[:-4].split("-")
        out.append({"name": name, "size": int(size), "mtime": int(mtime), "caller": parts[2], "target": parts[3],
                    "start": "%s-%s-%s %s:%s:%s" % (parts[0][:4], parts[0][4:6], parts[0][6:8],
                                                     parts[1][:2], parts[1][2:4], parts[1][4:6]),
                    "expires": int(mtime) + keep_days * 86400})
    out.sort(key=lambda r: r["name"], reverse=True)
    return out


def sip_servers(addresses, phone_nets):
    """Adresses IPv4 de l'appliance à saisir dans les postes : d'abord celles des réseaux des téléphones."""
    import ipaddress
    nets = []
    for item in (phone_nets or "").replace(",", " ").split():
        try:
            nets.append(ipaddress.ip_network(item, strict=False))
        except ValueError:
            continue
    inside, other = [], []
    for a in addresses:
        try:
            iface = ipaddress.ip_interface(a["address"])
        except (KeyError, ValueError):
            continue
        if iface.version != 4:
            continue
        ip = str(iface.ip)
        (inside if any(iface.ip in n for n in nets) else other).append(ip)
    return inside + [ip for ip in other if ip not in inside]


def read_phone_nets(path="/etc/voipbuntu/appliance.conf"):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            for line in handle:
                m = re.match(r'^\s*PHONE_NETS\s*=\s*"?([^"\n]*)"?\s*$', line)
                if m:
                    return m.group(1)
    except OSError:
        pass
    return ""


def parse_contacts(text):
    """Analyse « pjsip show contacts » : {identifiant SIP: {"status", "rtt", "address"}}."""
    out = {}
    for line in text.splitlines():
        m = re.match(r"^\s*Contact:\s+(\S+?)/(\S+)\s+\S+\s+(Avail|NonQual|Unavail|Unknown|Created|Removed)\s*([0-9.]+|nan)?", line)
        if m and SIP_ID_RE.match(m.group(1)):
            uri = m.group(2)
            host = re.sub(r"^sips?:[^@]*@", "", uri).split(";")[0]
            out[m.group(1)] = {"status": m.group(3), "rtt": m.group(4) if m.group(4) not in (None, "nan") else None,
                               "address": host[:64]}
    return out


def parse_cdr(text, limit=100):
    """Analyse Master.csv de cdr_csv : les derniers appels, du plus récent au plus ancien.

    Seuls des champs contrôlés sortent : numéros (chiffres, * et #), dates, durées, issue, sens.
    """
    import csv
    import io
    rows = []
    for row in csv.reader(io.StringIO(text)):
        if len(row) < len(CDR_FIELDS):
            continue
        rec = dict(zip(CDR_FIELDS, row))
        if rec["dcontext"] not in ("voipbuntu-internes", "voipbuntu-entrant", "voipbuntu-accueil", "voipbuntu-menu"):
            continue
        src, dst = rec["src"], rec["dst"]
        if src.lower() in ("anonymous", "unknown"):
            src = "anonymous"
        elif not re.match(r"^\+?[0-9*#]{0,24}$", src):
            continue
        if not re.match(r"^\+?[0-9*#a-z]{1,24}$", dst):
            continue
        if rec["dcontext"] != "voipbuntu-internes":
            direction = "entrant"
        elif rec["dstchannel"].startswith("PJSIP/%s-" % TRUNK):
            direction = "sortant"
        else:
            direction = "interne"
        if not re.match(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$", rec["start"]):
            continue
        try:
            duration, billsec = int(rec["duration"]), int(rec["billsec"])
        except ValueError:
            continue
        disposition = rec["disposition"] if rec["disposition"] in DISPOSITIONS else "FAILED"
        name = re.match(r'^"([^"]{0,40})"', rec["clid"])
        # Poste qui a sonné (PJSIP/<identifiant SIP>-xxxx), pour compter les appels manqués par poste
        rang = re.match(r"^PJSIP/([A-Za-z0-9][A-Za-z0-9._-]{0,31})-[0-9a-f]+$", rec["dstchannel"])
        rang = [rang.group(1)] if rang and rang.group(1) != TRUNK else []
        rows.append(({"start": rec["start"], "src": src, "src_name": name.group(1) if name else "",
                      "dst": dst, "duration": duration, "billsec": billsec, "disposition": disposition,
                      "voicemail": rec["lastapp"] == "VoiceMail", "direction": direction, "rang": rang},
                     rec["channel"][:80]))
    # Appel entrant qui fait sonner plusieurs postes : une ligne par poste appelé, on n'en garde qu'une
    merged, index = [], {}
    for rec, channel in rows:
        key = channel if rec["direction"] == "entrant" and channel else None
        if key and key in index:
            kept = merged[index[key]]
            rang = kept["rang"] + [u for u in rec["rang"] if u not in kept["rang"]]
            if kept["disposition"] != "ANSWERED" and rec["disposition"] == "ANSWERED":
                kept = merged[index[key]] = rec
            kept["rang"] = rang
            continue
        if key:
            index[key] = len(merged)
        merged.append(rec)
    merged.reverse()
    return merged[:limit]


def parse_channels(text):
    """Nombre d'appels en cours d'après « core show channels count »."""
    m = re.search(r"^(\d+) active calls?", text, re.M)
    return int(m.group(1)) if m else 0


def parse_registrar(text):
    """Analyse « database show registrar » : appareil (User-Agent) et adresse de chaque poste enregistré."""
    out = {}
    for line in text.splitlines():
        m = re.match(r"^/registrar/contact/([^;/\s]+);@[0-9a-f]+\s*:\s*(\{.*\})\s*$", line)
        if not m or not SIP_ID_RE.match(m.group(1)):
            continue
        try:
            data = json.loads(m.group(2))
        except ValueError:
            continue
        agent = re.sub(r"[\x00-\x1f\x7f]", "", str(data.get("user_agent", "")))[:80]
        via = str(data.get("via_addr", ""))[:45]
        port = str(data.get("via_port", ""))
        try:
            expires = int(data.get("expiration_time", 0))
        except ValueError:
            expires = 0
        prev = out.get(m.group(1))
        if prev is None or expires > prev["expires"]:
            out[m.group(1)] = {"user_agent": agent, "via": via + (":" + port if port.isdigit() else ""),
                               "expires": expires}
    return out


ATTEMPT_RE = re.compile(r"^\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\] NOTICE\[\d+\] res_pjsip/pjsip_distributor\.c: "
                        r"Request 'REGISTER' from '[^']*?<?sips?:([^@>'\s]{1,64})@[^']*' failed for '([0-9a-fA-F.:\[\]]{3,60}?):(\d+)' "
                        r"\(callid: [^)]*\) - (No matching endpoint found|Failed to authenticate)")


def parse_attempts(text, limit=50):
    """Enregistrements refusés relevés dans messages.log : appareils à configurer ou mot de passe faux."""
    seen = {}
    for line in text.splitlines():
        m = ATTEMPT_RE.match(line)
        if not m:
            continue
        when, user, ip, _port, reason = m.groups()
        if not SIP_ID_RE.match(user):
            continue
        key = (user, ip.strip("[]"))
        rec = seen.get(key) or {"user": user, "address": ip.strip("[]"), "count": 0, "first": when,
                                "reason": "unknown"}
        rec["count"] += 1
        rec["last"] = when
        if reason == "No matching endpoint found":
            rec["unknown_seen"] = True
        rec["reason"] = "unknown" if rec.get("unknown_seen") else "auth"
        seen[key] = rec
    out = sorted(seen.values(), key=lambda r: r["last"], reverse=True)
    for r in out:
        r.pop("unknown_seen", None)
    return out[:limit]


def network_of(address, phone_nets):
    """Réseau des téléphones (CIDR) d'où vient une adresse « ip » ou « ip:port », ou None."""
    import ipaddress
    host = (address or "").strip()
    if host.startswith("["):
        host = host[1:].split("]")[0]
    elif host.count(":") == 1:
        host = host.split(":")[0]
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return None
    for item in (phone_nets or "").replace(",", " ").split():
        try:
            net = ipaddress.ip_network(item, strict=False)
        except ValueError:
            continue
        if ip.version == net.version and ip in net:
            return str(net)
    return None


def parse_registration(text):
    """État de l'enregistrement de la ligne d'après « pjsip show registrations »."""
    for line in text.splitlines():
        m = re.match(r"^\s*%s/\S+\s+%s-auth\s+(Registered|Unregistered|Rejected)\b" % (TRUNK, TRUNK), line)
        if m:
            return m.group(1).lower()
    return None
