"""Base SQLite de la console (comptes, sessions, mesures)."""

import os
import sqlite3
import threading

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
    username TEXT PRIMARY KEY,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'admin',
    created REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions(
    token_hash TEXT PRIMARY KEY,
    username TEXT NOT NULL,
    csrf TEXT NOT NULL,
    created REAL NOT NULL,
    last_seen REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS login_failures(
    key TEXT PRIMARY KEY,
    failures INTEGER NOT NULL,
    locked_until REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS metrics(
    ts INTEGER PRIMARY KEY,
    cpu REAL, mem REAL, disk REAL, rx REAL, tx REAL, load1 REAL
);
CREATE TABLE IF NOT EXISTS audit(
    ts REAL NOT NULL,
    username TEXT,
    remote TEXT,
    event TEXT NOT NULL
);
"""


class Database:
    def __init__(self, path):
        self.path = path
        directory = os.path.dirname(path)
        if directory:
            os.makedirs(directory, mode=0o700, exist_ok=True)
        old_umask = os.umask(0o077)
        try:
            self.conn = sqlite3.connect(path, check_same_thread=False)
        finally:
            os.umask(old_umask)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.executescript(SCHEMA)
        self.conn.commit()
        self.lock = threading.RLock()

    def audit(self, event, username=None, remote=None, now=None):
        import time
        with self.lock:
            self.conn.execute(
                "INSERT INTO audit(ts, username, remote, event) VALUES (?,?,?,?)",
                (now or time.time(), username, remote, event),
            )
            self.conn.execute("DELETE FROM audit WHERE rowid NOT IN (SELECT rowid FROM audit ORDER BY ts DESC LIMIT 5000)")
            self.conn.commit()

    def get_user(self, username):
        with self.lock:
            return self.conn.execute(
                "SELECT username, password_hash, role FROM users WHERE username=?", (username,)
            ).fetchone()

    def set_password(self, username, password_hash, role="admin"):
        import time
        with self.lock:
            self.conn.execute(
                "INSERT INTO users(username, password_hash, role, created) VALUES (?,?,?,?) "
                "ON CONFLICT(username) DO UPDATE SET password_hash=excluded.password_hash",
                (username, password_hash, role, time.time()),
            )
            self.conn.commit()

    def has_users(self):
        with self.lock:
            return self.conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] > 0
