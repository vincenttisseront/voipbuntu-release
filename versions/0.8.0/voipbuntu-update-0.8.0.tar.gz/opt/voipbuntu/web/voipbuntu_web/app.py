"""Serveur HTTP de la console VOIPbuntu (bibliothèque standard uniquement).

Il écoute en local (127.0.0.1:8080) ; nginx assure le TLS devant lui et lui
transmet l'adresse du client dans X-Real-IP.
"""

import argparse
import hmac
import json
import logging
import mimetypes
import os
import re
import sys
import time
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs

from . import alerts, backup, networks, pbx, security, sysinfo
from . import netconf
from .db import Database
from .i18n import Translator, LANGUAGES
from .jobs import WorkerClient, WorkerUnavailable, ACTIONS

LOG = logging.getLogger("voipbuntu-web")
COOKIE = "pxb_session"
MAX_BODY = 1024 * 1024  # restauration d'une sauvegarde (200 postes, groupes, renvois)
LOG_SOURCES = ("asterisk", "system")
USERNAME_RE = re.compile(r"^[a-z_][a-z0-9_.-]{0,31}$")
CSP = ("default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
       "connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")


class ApiError(Exception):
    def __init__(self, status, message, extra=None):
        super().__init__(message)
        self.status = status
        self.message = message
        self.extra = extra or {}


class Context:
    def __init__(self, db, static_dir, version, worker, data_path, trust_proxy, secure_cookie,
                 update_state="/var/lib/voipbuntu/update.json", pbx_state=pbx.DEFAULT_STATE,
                 networks_state=networks.DEFAULT_STATE):
        self.db = db
        self.networks_state = networks_state
        self.pbx_state = pbx_state
        self.appliance_conf = "/etc/voipbuntu/appliance.conf"
        self.backup_dir = backup.DEFAULT_DIR
        self.backup_settings = backup.DEFAULT_SETTINGS
        self.backup_status = "/var/lib/voipbuntu/backup-status.json"
        self.alerts_settings = alerts.DEFAULT_SETTINGS
        self.alerts_state = alerts.DEFAULT_STATE
        self.update_state = update_state
        self.static_dir = os.path.realpath(static_dir)
        self.version = version
        self.worker = worker
        self.data_path = data_path
        self.trust_proxy = trust_proxy
        self.secure_cookie = secure_cookie
        self.sessions = security.SessionStore(db)
        self.throttle = security.LoginThrottle(db)
        self.translator = Translator(static_dir)
        # Empreinte factice : un identifiant inconnu coûte autant qu'un vrai.
        self.dummy_hash = security.hash_password(security.new_token())


class Handler(BaseHTTPRequestHandler):
    server_version = "VOIPbuntu"
    sys_version = ""
    protocol_version = "HTTP/1.1"
    ctx = None  # renseigné par make_server

    # ------------------------------------------------------------ utilitaires
    def log_message(self, fmt, *args):  # journal sans corps ni cookie
        LOG.info("%s %s", self.remote, fmt % args)

    @property
    def remote(self):
        if self.ctx.trust_proxy:
            real = self.headers.get("X-Real-IP", "")
            if real and len(real) < 64:
                return real
        return self.client_address[0]

    @property
    def lang(self):
        cookie = self.cookies.get("pxb_lang")
        if cookie and cookie.value in LANGUAGES:
            return cookie.value
        accept = self.headers.get("Accept-Language", "")
        return "en" if accept[:2].lower() == "en" else "fr"

    @property
    def cookies(self):
        jar = SimpleCookie()
        try:
            jar.load(self.headers.get("Cookie", ""))
        except Exception:
            pass
        return jar

    def t(self, text):
        return self.ctx.translator.translate(text, self.lang)

    def security_headers(self):
        self.send_header("Content-Security-Policy", CSP)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")

    def send_json(self, status, payload, cookies=()):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for cookie in cookies:
            self.send_header("Set-Cookie", cookie)
        self.security_headers()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def session_cookie(self, token, max_age=None):
        parts = ["%s=%s" % (COOKIE, token), "Path=/", "HttpOnly", "SameSite=Strict"]
        if self.ctx.secure_cookie:
            parts.append("Secure")
        if max_age is not None:
            parts.append("Max-Age=%d" % max_age)
        return "; ".join(parts)

    def read_json(self):
        ctype = self.headers.get("Content-Type", "").split(";")[0].strip().lower()
        if ctype != "application/json":
            raise ApiError(HTTPStatus.UNSUPPORTED_MEDIA_TYPE, "Requête invalide.")
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.") from None
        if length < 0 or length > MAX_BODY:
            raise ApiError(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "Requête trop volumineuse.")
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode("utf-8")) if raw else {}
        except (ValueError, UnicodeDecodeError):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.") from None
        if not isinstance(data, dict):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.")
        return data

    def check_origin(self):
        origin = self.headers.get("Origin")
        if origin is None:
            return
        host = self.headers.get("Host", "")
        if urlsplit(origin).netloc != host:
            raise ApiError(HTTPStatus.FORBIDDEN, "Origine refusée.")

    def current_session(self):
        morsel = self.cookies.get(COOKIE)
        return self.ctx.sessions.get(morsel.value if morsel else None)

    def require_session(self, write=False):
        session = self.current_session()
        if session is None:
            raise ApiError(HTTPStatus.UNAUTHORIZED, "Session expirée, reconnectez-vous.")
        if write:
            self.check_origin()
            token = self.headers.get("X-CSRF-Token", "")
            if not token or not hmac.compare_digest(token, session["csrf"]):
                raise ApiError(HTTPStatus.FORBIDDEN, "Jeton de sécurité invalide, rechargez la page.")
        return session

    # ---------------------------------------------------------------- routage
    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        self.dispatch("GET")

    def do_POST(self):
        self.dispatch("POST")

    def do_PUT(self):
        self.dispatch("PUT")

    def do_DELETE(self):
        self.dispatch("DELETE")

    def dispatch(self, method):
        path = urlsplit(self.path).path
        try:
            if path.startswith("/api/"):
                route = ROUTES.get((method if method != "HEAD" else "GET", path))
                if route is None:
                    raise ApiError(HTTPStatus.NOT_FOUND, "Ressource introuvable.")
                route(self)
            elif method in ("GET", "HEAD"):
                self.serve_static(path)
            else:
                raise ApiError(HTTPStatus.METHOD_NOT_ALLOWED, "Méthode non autorisée.")
        except ApiError as exc:
            payload = {"error": self.t(exc.message)}
            payload.update(exc.extra)
            self.send_json(exc.status, payload)
        except Exception:
            LOG.exception("erreur interne sur %s %s", method, path)
            self.send_json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": self.t("Erreur interne.")})

    def serve_static(self, path):
        if path in ("/", ""):
            path = "/index.html"
        relative = os.path.normpath(path.lstrip("/"))
        full = os.path.realpath(os.path.join(self.ctx.static_dir, relative))
        if not full.startswith(self.ctx.static_dir + os.sep) or not os.path.isfile(full):
            raise ApiError(HTTPStatus.NOT_FOUND, "Ressource introuvable.")
        ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript", "application/json"):
            ctype += "; charset=utf-8"
        with open(full, "rb") as handle:
            body = handle.read()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.security_headers()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    # ------------------------------------------------------------------- API
    def api_login(self):
        self.check_origin()
        data = self.read_json()
        username = data.get("username")
        password = data.get("password")
        if not isinstance(username, str) or not isinstance(password, str) or not USERNAME_RE.match(username) \
                or len(password) > 256:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Identifiant ou mot de passe incorrect.")
        keys = ["ip:" + self.remote, "user:" + username]
        wait = self.ctx.throttle.locked_for(keys)
        if wait:
            raise ApiError(HTTPStatus.TOO_MANY_REQUESTS, "Trop de tentatives, réessayez plus tard.", {"retry": wait})
        user = self.ctx.db.get_user(username)
        stored = user[1] if user else self.ctx.dummy_hash
        if not security.verify_password(password, stored) or user is None:
            self.ctx.throttle.failure(keys)
            self.ctx.db.audit("login-failed", username, self.remote)
            raise ApiError(HTTPStatus.UNAUTHORIZED, "Identifiant ou mot de passe incorrect.")
        self.ctx.throttle.success(keys)
        token, csrf = self.ctx.sessions.create(username)
        self.ctx.db.audit("login", username, self.remote)
        self.send_json(HTTPStatus.OK, {"user": username, "csrf": csrf}, [self.session_cookie(token)])

    def api_logout(self):
        session = self.require_session(write=True)
        morsel = self.cookies.get(COOKIE)
        self.ctx.sessions.delete(morsel.value if morsel else "")
        self.ctx.db.audit("logout", session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True}, [self.session_cookie("", max_age=0)])

    def api_session(self):
        session = self.current_session()
        payload = {"version": self.ctx.version, "lang": self.lang, "configured": self.ctx.db.has_users()}
        if session:
            payload.update({"user": session["username"], "csrf": session["csrf"]})
        self.send_json(HTTPStatus.OK, payload)

    def api_status(self):
        self.require_session()
        payload = sysinfo.status(self.ctx.version, self.ctx.data_path)
        payload["services"] = sysinfo.service_states()
        self.send_json(HTTPStatus.OK, payload)

    def api_metrics(self):
        self.require_session()
        query = parse_qs(urlsplit(self.path).query)
        range_name = (query.get("range") or ["1h"])[0]
        if range_name not in sysinfo.RANGES:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Période inconnue.")
        self.send_json(HTTPStatus.OK, sysinfo.series(self.ctx.db, range_name))

    def api_password(self):
        session = self.require_session(write=True)
        data = self.read_json()
        current, new = data.get("current"), data.get("new")
        if not isinstance(current, str) or not isinstance(new, str):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.")
        user = self.ctx.db.get_user(session["username"])
        if user is None or not security.verify_password(current, user[1]):
            self.ctx.db.audit("password-change-failed", session["username"], self.remote)
            raise ApiError(HTTPStatus.FORBIDDEN, "Mot de passe actuel incorrect.")
        problem = security.password_problem(new)
        if problem:
            raise ApiError(HTTPStatus.BAD_REQUEST, problem)
        self.ctx.db.set_password(session["username"], security.hash_password(new))
        self.ctx.sessions.delete_user(session["username"])
        token, csrf = self.ctx.sessions.create(session["username"])
        self.ctx.db.audit("password-changed", session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "csrf": csrf}, [self.session_cookie(token)])

    def api_update(self):
        self.require_session()
        state = {}
        try:
            with open(self.ctx.update_state, "r", encoding="utf-8") as handle:
                state = json.load(handle)
        except (OSError, ValueError):
            state = {}
        if not isinstance(state, dict):
            state = {}
        version_re = re.compile(r"^\d+\.\d+\.\d+$")
        latest = state.get("latest") if isinstance(state.get("latest"), str) and version_re.match(state["latest"]) else None
        checked = state.get("checked") if isinstance(state.get("checked"), (int, float)) else None
        error = state.get("error") if isinstance(state.get("error"), str) else None
        notes = state.get("notes") if isinstance(state.get("notes"), str) else ""
        self.send_json(HTTPStatus.OK, {
            "current": self.ctx.version, "latest": latest, "checked": checked,
            "available": bool(latest) and _vtuple(latest) > _vtuple(self.ctx.version),
            "notes": notes[:4000], "error": error[:300] if error else None})

    # ------------------------------------------------------------ téléphonie
    def pbx_load(self):
        try:
            return pbx.load(self.ctx.pbx_state)
        except pbx.PbxError:
            raise ApiError(HTTPStatus.INTERNAL_SERVER_ERROR, "Configuration téléphonique illisible.") from None

    def pbx_commit(self, state, username, event):
        try:
            pbx.save(state, self.ctx.pbx_state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        self.ctx.db.audit(event, username, self.remote)
        try:
            self.ctx.worker.submit("pbx-apply", username)
            return True
        except WorkerUnavailable:
            return False

    def api_pbx(self):
        self.require_session()
        state = self.pbx_load()
        try:
            live = self.ctx.worker.pbx_status()
        except WorkerUnavailable:
            live = {"running": None, "contacts": {}}
        contacts = live.get("contacts") if isinstance(live.get("contacts"), dict) else {}
        view = pbx.public(state)
        phone_nets = pbx.read_phone_nets(self.ctx.appliance_conf)
        labels = self.networks_load()
        registered_users = set()
        for ext in view["extensions"]:
            c = contacts.get(ext["sip_user"]) or {}
            ext["registered"] = c.get("status") in ("Avail", "NonQual", "Created")
            ext["address"] = c.get("address")
            ext["rtt"] = c.get("rtt")
            ext["user_agent"] = str(c.get("user_agent") or "")[:80]
            ext["network"] = pbx.network_of(c.get("address"), phone_nets) if c else None
            ext["network_label"] = networks.label_for(ext["network"], labels) if ext["network"] else ""
            if ext["registered"]:
                registered_users.add(ext["sip_user"].lower())
        known = {e["sip_user"].lower(): e["number"] for e in view["extensions"]}
        attempts = []
        for a in live.get("attempts") if isinstance(live.get("attempts"), list) else []:
            if not isinstance(a, dict) or not pbx.SIP_ID_RE.match(str(a.get("user", ""))):
                continue
            user = str(a["user"])
            if user.lower() in registered_users:
                continue  # appareil configuré depuis : plus rien à faire
            net = pbx.network_of(str(a.get("address", "")), phone_nets)
            attempts.append({"user": user, "address": str(a.get("address", ""))[:45],
                             "count": int(a.get("count", 0)) if str(a.get("count", "")).isdigit() else 0,
                             "last": str(a.get("last", ""))[:19], "extension": known.get(user.lower()),
                             "reason": "auth" if user.lower() in known else "unknown",
                             "network": net, "network_label": networks.label_for(net, labels) if net else ""})
        view["attempts"] = attempts[:50]
        view["trunk"]["state"] = live.get("trunk") if live.get("trunk") in ("registered", "unregistered", "rejected") else None
        view["running"] = live.get("running")
        view["calls"] = live.get("calls") if isinstance(live.get("calls"), int) else None
        self.send_json(HTTPStatus.OK, view)

    def api_pbx_calls(self):
        self.require_session()
        try:
            data = self.ctx.worker.pbx_calls()
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None
        calls = data.get("calls") if isinstance(data.get("calls"), list) else []
        self.send_json(HTTPStatus.OK, {"calls": calls[:200], "error": bool(data.get("error"))})

    def api_logs(self):
        self.require_session()
        source = (parse_qs(urlsplit(self.path).query).get("source") or ["asterisk"])[0]
        if source not in LOG_SOURCES:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Journal inconnu.")
        try:
            data = self.ctx.worker.logs(source)
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None
        lines = data.get("lines") if isinstance(data.get("lines"), list) else []
        self.send_json(HTTPStatus.OK, {"source": source, "lines": [str(x)[:500] for x in lines[-200:]],
                                       "error": bool(data.get("error"))})

    # ------------------------------------------------------------ sauvegarde
    def api_backup(self):
        session = self.require_session()
        state = self.pbx_load()
        payload = backup.payload(state, self.networks_load(), self.ctx.version)
        self.send_backup(payload, "voipbuntu-sauvegarde-%s.json" % time.strftime("%Y%m%d-%H%M"))
        self.ctx.db.audit("backup:export", session["username"], self.remote)

    def send_backup(self, payload, filename):
        body = json.dumps(payload, ensure_ascii=False, indent=1).encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Disposition", 'attachment; filename="%s"' % filename)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.security_headers()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def api_restore(self):
        session = self.require_session(write=True)
        self.restore(self.read_json(), session, "backup:restore")

    def restore(self, data, session, event):
        try:
            state, nets = backup.read_payload(data)
        except backup.BackupError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, str(exc)) from None
        if nets is not None:
            networks.save(nets, self.ctx.networks_state)
        applied = self.pbx_commit(state, session["username"], event)
        if nets is not None and applied:
            try:
                self.ctx.worker.submit("networks-apply", session["username"])
            except WorkerUnavailable:
                applied = False
        self.send_json(HTTPStatus.OK, {"ok": True, "extensions": len(state["extensions"]), "applied": applied,
                                       "networks": None if nets is None else len(nets["networks"])})

    def api_backups(self):
        self.require_session()
        try:
            with open(self.ctx.backup_status, encoding="utf-8") as h:
                status = json.load(h)
            status = {k: status.get(k) for k in ("last_run", "ok", "message", "file", "mail_failed")} if isinstance(status, dict) else None
        except (OSError, ValueError):
            status = None
        self.send_json(HTTPStatus.OK, {"settings": backup.load_settings(self.ctx.backup_settings), "status": status,
                                       "backups": backup.listing(self.ctx.backup_dir)})

    def api_backups_settings(self):
        session = self.require_session(write=True)
        try:
            settings = backup.save_settings(self.read_json(), self.ctx.backup_settings)
        except backup.BackupError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, str(exc)) from None
        self.ctx.db.audit("backup:settings:%s" % ("on" if settings["enabled"] else "off"), session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "settings": settings})

    def api_backups_file(self):
        session = self.require_session()
        name = (parse_qs(urlsplit(self.path).query).get("name") or [""])[0]
        try:
            data = backup.read_file(name, self.ctx.backup_dir)
        except backup.BackupError as exc:
            raise ApiError(HTTPStatus.NOT_FOUND, str(exc)) from None
        self.send_backup(data, name)
        self.ctx.db.audit("backup:download:" + name, session["username"], self.remote)

    def api_backups_restore(self):
        session = self.require_session(write=True)
        name = str(self.read_json().get("name", ""))
        try:
            data = backup.read_file(name, self.ctx.backup_dir)
        except backup.BackupError as exc:
            raise ApiError(HTTPStatus.NOT_FOUND, str(exc)) from None
        self.restore(data, session, "backup:restore:" + name)

    def api_pbx_create(self):
        session = self.require_session(write=True)
        data = self.read_json()
        number, name = str(data.get("number", "")).strip(), str(data.get("name", "")).strip()
        if not pbx.NUMBER_RE.match(number):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Numéro invalide : de 2 à 6 chiffres, sans 0 en tête.")
        if not pbx.NAME_RE.match(name):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Nom invalide : 1 à 40 caractères, sans guillemets ni crochets.")
        state = self.pbx_load()
        if any(e["number"] == number for e in state["extensions"] + state["groups"]):
            raise ApiError(HTTPStatus.CONFLICT, "Ce numéro existe déjà.")
        if len(state["extensions"]) >= pbx.MAX_EXTENSIONS:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Nombre maximal de postes atteint.")
        if number in pbx.EMERGENCY:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Ce numéro est réservé aux urgences.")
        sip_user = str(data.get("sip_user") or "").strip() or number
        self.check_sip_user(state, sip_user)
        email = self.check_email(data.get("email"))
        ext = {"number": number, "name": name, "sip_user": sip_user, "secret": pbx.new_secret(),
               "pin": pbx.new_pin(), "voicemail": bool(data.get("voicemail", True)), "email": email}
        state["extensions"].append(ext)
        applied = self.pbx_commit(state, session["username"], "pbx:create:" + number)
        self.send_json(HTTPStatus.CREATED, dict(self.sheet(ext), applied=applied))

    def check_email(self, value):
        email = str(value or "").strip()
        if email and (len(email) > 254 or not pbx.EMAIL_RE.match(email)):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Adresse e-mail invalide.")
        return email

    def check_sip_user(self, state, sip_user, keep=None):
        if not pbx.SIP_ID_RE.match(sip_user) or sip_user.lower() in pbx.RESERVED_IDS:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Identifiant SIP invalide : lettres, chiffres, point, tiret, 32 caractères au plus.")
        if any(e["sip_user"].lower() == sip_user.lower() and e["number"] != keep for e in state["extensions"]):
            raise ApiError(HTTPStatus.CONFLICT, "Cet identifiant SIP est déjà utilisé par un autre poste.")

    def api_pbx_update(self):
        """Modifie un poste : numéro court, nom, messagerie. Identifiant et mot de passe SIP inchangés."""
        session = self.require_session(write=True)
        data = self.read_json()
        current = str(data.get("number", ""))
        state = self.pbx_load()
        ext = next((e for e in state["extensions"] if e["number"] == current), None)
        if ext is None:
            raise ApiError(HTTPStatus.NOT_FOUND, "Poste introuvable.")
        new_number = str(data.get("new_number", current)).strip()
        name = str(data.get("name", ext["name"])).strip()
        if not pbx.NUMBER_RE.match(new_number):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Numéro invalide : de 2 à 6 chiffres, sans 0 en tête.")
        if new_number in pbx.EMERGENCY:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Ce numéro est réservé aux urgences.")
        if not pbx.NAME_RE.match(name):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Nom invalide : 1 à 40 caractères, sans guillemets ni crochets.")
        if new_number != current and any(e["number"] == new_number for e in state["extensions"] + state["groups"]):
            raise ApiError(HTTPStatus.CONFLICT, "Ce numéro existe déjà.")
        ext["number"], ext["name"] = new_number, name
        if "voicemail" in data:
            ext["voicemail"] = bool(data["voicemail"])
        if "email" in data:
            ext["email"] = self.check_email(data["email"])
        pbx.rename_number(state, current, new_number)
        if not ext["voicemail"]:
            pbx.drop_voicemail(state, new_number)
        event = "pbx:update:%s" % current + ("->%s" % new_number if new_number != current else "")
        applied = self.pbx_commit(state, session["username"], event)
        self.send_json(HTTPStatus.OK, {"ok": True, "number": new_number, "sip_user": ext["sip_user"], "applied": applied})

    def api_pbx_trunk(self):
        """Ligne de l'opérateur. Un mot de passe vide conserve celui déjà enregistré."""
        session = self.require_session(write=True)
        data = self.read_json()
        state = self.pbx_load()
        fields = ("enabled", "host", "port", "username", "auth_username", "password", "register",
                  "caller_id", "public_address", "international")
        trunk = {k: data[k] for k in fields if k in data}
        if not trunk.get("password"):
            trunk["password"] = state["trunk"]["password"]
        state["trunk"] = trunk
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        applied = self.pbx_commit(state, session["username"],
                                  "pbx:trunk:%s" % ("on" if state["trunk"]["enabled"] else "off"))
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "trunk": pbx.public(state)["trunk"]})

    def api_pbx_reception(self):
        session = self.require_session(write=True)
        data = self.read_json()
        state = self.pbx_load()
        state["reception"] = {k: data.get(k) for k in ("members", "ring_seconds", "hours", "voicemail_box")}
        if state["reception"]["ring_seconds"] is None:
            state["reception"]["ring_seconds"] = 25
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        applied = self.pbx_commit(state, session["username"], "pbx:reception")
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "reception": state["reception"]})

    def api_pbx_mail(self):
        """Serveur d'envoi des messages vocaux. Un mot de passe vide conserve celui déjà enregistré."""
        session = self.require_session(write=True)
        data = self.read_json()
        state = self.pbx_load()
        mail = {k: data[k] for k in ("enabled", "host", "port", "security", "username", "password", "from_address") if k in data}
        if not mail.get("password") and mail.get("username") and mail.get("username") == state["mail"]["username"]:
            mail["password"] = state["mail"]["password"]
        state["mail"] = mail
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        applied = self.pbx_commit(state, session["username"], "pbx:mail:%s" % ("on" if state["mail"]["enabled"] else "off"))
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "mail": pbx.public(state)["mail"]})

    def api_pbx_groups(self):
        """Groupes d'appel : la liste complète est remplacée. Les renvois vers un groupe retiré sont coupés."""
        session = self.require_session(write=True)
        data = self.read_json()
        groups = data.get("groups")
        if not isinstance(groups, list):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Liste de groupes invalide.")
        state = self.pbx_load()
        kept = {str(g.get("number", "")) for g in groups if isinstance(g, dict)}
        for g in state["groups"]:
            if g["number"] not in kept:
                pbx.drop_number(state, g["number"])
        state["groups"] = groups
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        applied = self.pbx_commit(state, session["username"], "pbx:groups:%d" % len(state["groups"]))
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "groups": state["groups"]})

    def api_pbx_forward(self):
        session = self.require_session(write=True)
        data = self.read_json()
        number = str(data.get("number", ""))
        state = self.pbx_load()
        ext = next((e for e in state["extensions"] if e["number"] == number), None)
        if ext is None:
            raise ApiError(HTTPStatus.NOT_FOUND, "Poste introuvable.")
        ext["forward"] = {k: data.get(k) for k in ("mode", "target", "ring_seconds")}
        if ext["forward"]["ring_seconds"] is None:
            ext["forward"]["ring_seconds"] = 20
        if ext["forward"]["target"] is None:
            ext["forward"]["target"] = ""
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        fwd = next(e for e in state["extensions"] if e["number"] == number)["forward"]
        applied = self.pbx_commit(state, session["username"], "pbx:forward:%s:%s" % (number, fwd["mode"]))
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "forward": fwd})

    PBX_MESSAGES = (
        ("ligne opérateur : serveur invalide", "Serveur SIP invalide : nom de domaine ou adresse IP."),
        ("ligne opérateur : port invalide", "Port invalide (1 à 65535)."),
        ("ligne opérateur : identifiant invalide", "Identifiant de la ligne invalide."),
        ("ligne opérateur : mot de passe invalide", "Mot de passe de la ligne invalide : espaces, guillemets, points-virgules, crochets, dièses et barres obliques inverses refusés."),
        ("ligne opérateur : numéro présenté invalide", "Numéro présenté invalide (chiffres, + en tête possible)."),
        ("ligne opérateur : adresse publique", "Adresse IP publique invalide (IPv4)."),
        ("ligne opérateur : serveur, identifiant et mot de passe", "Serveur, identifiant et mot de passe sont requis pour activer la ligne."),
        ("porte un numéro d'urgence", "Un poste porte un numéro d'urgence : renumérotez-le avant d'activer la ligne."),
        ("accueil : durée de sonnerie", "Durée de sonnerie entre 5 et 120 secondes."),
        ("accueil : la messagerie de secours", "La messagerie de secours doit être celle d'un poste qui en a une."),
        ("accueil : jours", "Choisissez au moins un jour d'ouverture."),
        ("accueil : horaires", "Horaires invalides : HH:MM, ouverture avant fermeture."),
        ("accueil : poste", "Poste inconnu dans l'accueil."),
        ("groupes : numéro invalide", "Numéro de groupe invalide : de 2 à 6 chiffres, sans 0 en tête, hors numéros d'urgence."),
        ("groupes : le numéro", "Ce numéro de groupe est déjà pris par un poste ou un autre groupe."),
        ("groupes : nom", "Nom de groupe invalide : 1 à 40 caractères, sans guillemets ni crochets."),
        ("aucun poste", "Un groupe doit contenir au moins un poste."),
        ("groupes : durée de sonnerie", "Durée de sonnerie entre 5 et 120 secondes."),
        ("groupes : la messagerie de secours", "La messagerie de secours doit être celle d'un poste qui en a une."),
        ("groupes : poste", "Poste inconnu dans le groupe."),
        ("groupes : liste", "Vingt groupes au plus."),
        ("renvoi : boucle", "Ces renvois permanents forment une boucle : un poste renvoie vers un autre qui renvoie vers le premier."),
        ("vers lui-même", "Un poste ne peut pas se renvoyer vers lui-même."),
        ("demande la ligne", "Un renvoi vers un numéro extérieur demande la ligne de l'opérateur : désactivez d'abord ce renvoi, ou activez la ligne."),
        ("international non autorisé", "Renvoi vers l'international : autorisez d'abord l'international sur la ligne."),
        ("renvoi : durée", "Durée de sonnerie avant renvoi entre 5 et 120 secondes."),
        ("renvoi : destination", "Destination invalide : un poste, un groupe ou un numéro à 10 chiffres commençant par 0."),
        ("renvoi : mode", "Type de renvoi invalide."),
        ("e-mail : serveur et adresse", "Serveur SMTP et adresse d'expédition sont requis pour activer l'envoi."),
        ("e-mail : identifiant sans chiffrement", "Avec un identifiant, choisissez STARTTLS ou TLS : le mot de passe ne doit pas circuler en clair."),
        ("e-mail : mot de passe requis", "Mot de passe requis avec un identifiant SMTP."),
        ("e-mail : serveur", "Serveur SMTP invalide : nom de domaine ou adresse IP."),
        ("e-mail : port", "Port invalide (1 à 65535)."),
        ("e-mail : sécurité", "Sécurité de la connexion invalide."),
        ("e-mail : identifiant", "Identifiant SMTP invalide : espaces, guillemets, points-virgules, crochets, dièses et barres obliques inverses refusés."),
        ("e-mail : mot de passe", "Mot de passe SMTP invalide : espaces, guillemets, points-virgules, crochets, dièses et barres obliques inverses refusés."),
        ("e-mail : adresse d'expédition", "Adresse d'expédition invalide."),
        ("adresse e-mail invalide", "Adresse e-mail invalide."),
        ("menu vocal : délai", "Délai de choix entre 2 et 30 secondes."),
        ("menu vocal : touche invalide", "Touche invalide : de 0 à 9."),
        ("en double", "Chaque touche ne peut servir qu'une fois."),
        ("menu vocal : ajoutez", "Ajoutez au moins une touche pour activer le menu vocal."),
        ("menu vocal : touche", "Destination inconnue pour une touche du menu."),
        ("menu vocal : sans choix", "Destination par défaut inconnue."),
        ("menu vocal", "Menu vocal invalide."),
    )

    def pbx_message(self, exc):
        text = str(exc)
        for prefix, message in self.PBX_MESSAGES:
            if prefix in text:
                return message
        return "Configuration téléphonique invalide."

    # ------------------------------------------------------------ accueil vocal
    MAX_SOUND = 20 * 1024 * 1024

    def api_pbx_ivr(self):
        """Menu vocal de l'accueil : touches, délai, destination par défaut, musique d'attente."""
        session = self.require_session(write=True)
        data = self.read_json()
        state = self.pbx_load()
        state["ivr"] = {k: data.get(k) for k in ("enabled", "options", "timeout", "default", "hold_music")}
        if state["ivr"]["timeout"] is None:
            state["ivr"]["timeout"] = 5
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        applied = self.pbx_commit(state, session["username"], "pbx:ivr:%s" % ("on" if state["ivr"]["enabled"] else "off"))
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "ivr": state["ivr"]})

    def sound_name(self, value):
        if value not in pbx.SOUNDS:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Annonce inconnue.")
        return value

    def api_sounds(self):
        self.require_session()
        try:
            with open(self.ctx.sounds_status, "r", encoding="utf-8") as handle:
                status = json.load(handle)
        except (OSError, ValueError):
            status = {}
        known = status.get("sounds") if isinstance(status.get("sounds"), dict) else {}
        out = {}
        for name in pbx.SOUNDS:
            rec = known.get(name) if isinstance(known.get(name), dict) else {}
            seconds = rec.get("seconds")
            out[name] = {"present": rec.get("present") is True,
                         "seconds": seconds if isinstance(seconds, (int, float)) else None,
                         "updated": rec.get("updated") if isinstance(rec.get("updated"), int) else None,
                         "error": str(rec["error"])[:200] if rec.get("error") else None,
                         "pending": any(os.path.lexists(os.path.join(self.ctx.sounds_upload, name + ext))
                                        for ext in (".upload", ".delete"))}
        converter = status.get("converter") if status.get("converter") in ("sox", "ffmpeg") else None
        self.send_json(HTTPStatus.OK, {"sounds": out, "converter": converter, "checked": "converter" in status})

    def sound_drop(self, name, ext, data=None):
        """Dépôt pour voipbuntu-sounds : <nom>.upload (fichier envoyé) ou <nom>.delete (suppression)."""
        os.makedirs(self.ctx.sounds_upload, mode=0o700, exist_ok=True)
        for other in (".upload", ".delete"):
            try:
                os.unlink(os.path.join(self.ctx.sounds_upload, name + other))
            except FileNotFoundError:
                pass
        path = os.path.join(self.ctx.sounds_upload, name + ext)
        tmp = path + ".tmp"
        old = os.umask(0o077)
        try:
            with open(tmp, "wb") as handle:
                handle.write(data or b"")
            os.replace(tmp, path)
        finally:
            os.umask(old)

    def api_sounds_upload(self):
        """Envoi d'une annonce : le fichier brut (WAV ou MP3) dans le corps, le nom dans ?name=."""
        session = self.require_session(write=True)
        name = self.sound_name((parse_qs(urlsplit(self.path).query).get("name") or [""])[0])
        ctype = self.headers.get("Content-Type", "").split(";")[0].strip().lower()
        if ctype not in ("application/octet-stream", "audio/wav", "audio/x-wav", "audio/wave", "audio/mpeg", "audio/mp3"):
            raise ApiError(HTTPStatus.UNSUPPORTED_MEDIA_TYPE, "Envoyez un fichier WAV ou MP3.")
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.") from None
        if length > self.MAX_SOUND:
            self.close_connection = True  # corps non lu : la connexion ne peut pas resservir
            raise ApiError(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "Fichier trop volumineux (20 Mo au plus).")
        if length <= 0:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Fichier vide.")
        data = self.rfile.read(length)
        is_wav = data[:4] == b"RIFF" and data[8:12] == b"WAVE"
        is_mp3 = data[:3] == b"ID3" or (len(data) > 1 and data[0] == 0xFF and data[1] & 0xE0 == 0xE0)
        if len(data) != length or not (is_wav or is_mp3):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Envoyez un fichier WAV ou MP3.")
        self.sound_drop(name, ".upload", data)
        self.ctx.db.audit("sounds:upload:%s" % name, session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": self.sound_submit(session)})

    def api_sounds_delete(self):
        session = self.require_session(write=True)
        name = self.sound_name(str(self.read_json().get("name", "")))
        self.sound_drop(name, ".delete")
        self.ctx.db.audit("sounds:delete:%s" % name, session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": self.sound_submit(session)})

    def sound_submit(self, session):
        try:
            self.ctx.worker.submit("sounds-apply", session["username"])
            return True
        except WorkerUnavailable:
            return False

    # ------------------------------------------------------------ réseaux
    def networks_load(self):
        try:
            return networks.load(self.ctx.networks_state)
        except networks.NetworkError:
            return {"networks": []}

    def api_networks(self):
        self.require_session()
        conf = networks.read_conf_nets(self.ctx.appliance_conf)
        self.send_json(HTTPStatus.OK, networks.view(self.networks_load(), conf))

    def api_networks_save(self):
        session = self.require_session(write=True)
        data = self.read_json()
        try:
            state = networks.save({"networks": data.get("networks")}, self.ctx.networks_state)
        except networks.NetworkError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Liste de réseaux invalide : format (192.168.20.0/24), doublons, 16 réseaux au plus, noms sans caractères spéciaux.", {"detail": str(exc)[:120]}) from None
        self.ctx.db.audit("networks:%s" % ",".join(n["cidr"] for n in state["networks"])[:180],
                          session["username"], self.remote)
        try:
            self.ctx.worker.submit("networks-apply", session["username"])
            applied = True
        except WorkerUnavailable:
            applied = False
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "networks": state["networks"]})

    # ------------------------------------------------ réseau de l'appliance
    def netconf_files(self):
        return netconf.paths(os.path.dirname(os.path.abspath(self.ctx.networks_state)))

    def netconf_stored(self, files):
        try:
            return netconf.load(files["state"])
        except netconf.NetconfError:
            return None

    @staticmethod
    def netconf_pending(status):
        return bool(status and status["state"] == "pending" and "nonce" in status
                    and (status["deadline"] or 0) > time.time())

    def api_system_network(self):
        self.require_session()
        files = self.netconf_files()
        current = netconf.live()
        stored = self.netconf_stored(files)
        settings = netconf.defaults(current)
        if stored:
            settings["ntp"] = stored["ntp"]
            for key in ("hostname", "timezone", "network"):
                if stored[key]:
                    settings[key] = stored[key]
        status = netconf.read_status(files["status"])
        if status:
            status["pending"] = self.netconf_pending(status)
            status.pop("nonce", None)
        self.send_json(HTTPStatus.OK, {"settings": settings, "managed": bool(stored and stored["network"]),
                                       "live": current, "status": status, "check": netconf.read_check(files["check"]),
                                       "timezones": netconf.timezones(), "confirm_seconds": netconf.CONFIRM_SECONDS})

    def api_system_network_save(self):
        """Réseau, nom de machine, NTP, fuseau : seules les parties envoyées changent."""
        session = self.require_session(write=True)
        data = self.read_json()
        changes = {k: data[k] for k in ("network", "hostname", "ntp", "timezone") if k in data}
        if not changes:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.")
        files = self.netconf_files()
        if self.netconf_pending(netconf.read_status(files["status"])):
            raise ApiError(HTTPStatus.CONFLICT, "Une configuration réseau attend déjà sa confirmation.")
        current = netconf.live()
        if isinstance(changes.get("network"), dict):
            names = [i["name"] for i in current["interfaces"]]
            if str(changes["network"].get("interface", "")) not in names:
                raise ApiError(HTTPStatus.BAD_REQUEST, "Interface réseau inconnue.")
        try:
            state = netconf.save(netconf.merge(self.netconf_stored(files), changes), files["state"])
        except netconf.NetconfError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, str(exc)) from None
        net = state["network"]
        parts = []
        if "network" in changes and net:
            parts.append("%s:%s" % (net["interface"], net["mode"] if net["mode"] == "dhcp"
                                    else "%s/%s" % (net["address"], net["prefix"])))
        parts += ["%s=%s" % (k, ",".join(state[k]) if isinstance(state[k], list) else state[k])
                  for k in ("hostname", "ntp", "timezone") if k in changes]
        self.ctx.db.audit(("system:network:" + ";".join(parts))[:200], session["username"], self.remote)
        try:
            self.ctx.worker.submit("network-apply", session["username"])
            applied = True
        except WorkerUnavailable:
            applied = False
        new_address = None
        if "network" in changes and net and net["mode"] == "static":
            iface = next((i for i in current["interfaces"] if i["name"] == net["interface"]), {"addresses": []})
            if not any(a.split("/")[0] == net["address"] for a in iface["addresses"]):
                new_address = net["address"]
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "settings": state, "new_address": new_address,
                                       "confirm_seconds": netconf.CONFIRM_SECONDS})

    def api_system_network_confirm(self):
        """La console est joignable après le changement de réseau : voipbuntu-netconf le garde."""
        session = self.require_session(write=True)
        self.read_json()  # corps vide attendu, lu pour garder la connexion propre
        files = self.netconf_files()
        status = netconf.read_status(files["status"])
        if not self.netconf_pending(status):
            raise ApiError(HTTPStatus.CONFLICT, "Aucune configuration réseau en attente de confirmation.")
        host = self.headers.get("Host", "")
        host = host[1:].split("]", 1)[0] if host.startswith("[") else (host.rsplit(":", 1)[0] if host.count(":") == 1 else host)
        if status["address"] and netconf.is_ip(host) and host != status["address"]:
            raise ApiError(HTTPStatus.CONFLICT, "Confirmez depuis la nouvelle adresse de l'appliance.")
        netconf.write_json(files["confirm"], {"nonce": status["nonce"]})
        self.ctx.db.audit("system:network:confirm", session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True})

    def api_pbx_delete(self):
        session = self.require_session(write=True)
        number = str(self.read_json().get("number", ""))
        state = self.pbx_load()
        kept = [e for e in state["extensions"] if e["number"] != number]
        if len(kept) == len(state["extensions"]):
            raise ApiError(HTTPStatus.NOT_FOUND, "Poste introuvable.")
        state["extensions"] = kept
        pbx.drop_number(state, number)
        applied = self.pbx_commit(state, session["username"], "pbx:delete:" + number)
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied})

    def api_pbx_secret(self):
        session = self.require_session(write=True)
        data = self.read_json()
        number, renew = str(data.get("number", "")), bool(data.get("renew", False))
        state = self.pbx_load()
        ext = next((e for e in state["extensions"] if e["number"] == number), None)
        if ext is None:
            raise ApiError(HTTPStatus.NOT_FOUND, "Poste introuvable.")
        applied = None
        if renew:
            ext["secret"] = pbx.new_secret()
            applied = self.pbx_commit(state, session["username"], "pbx:renew:" + number)
        else:
            self.ctx.db.audit("pbx:reveal:" + number, session["username"], self.remote)
        self.send_json(HTTPStatus.OK, dict(self.sheet(ext), applied=applied))

    def sheet(self, ext):
        """Fiche de configuration d'un poste (base DECT ou téléphone SIP)."""
        servers = pbx.sip_servers(sysinfo.ip_addresses(), pbx.read_phone_nets(self.ctx.appliance_conf))
        return {"number": ext["number"], "name": ext["name"], "sip_user": ext["sip_user"],
                "secret": ext["secret"], "pin": ext["pin"],
                "servers": servers, "port": 5060, "transport": "UDP", "voicemail_code": "*97",
                "voicemail": ext["voicemail"]}

    def api_jobs_list(self):
        self.require_session()
        try:
            self.send_json(HTTPStatus.OK, self.ctx.worker.list())
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None

    def api_jobs_submit(self):
        session = self.require_session(write=True)
        data = self.read_json()
        action = data.get("action")
        if action not in ACTIONS:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Action inconnue.")
        try:
            result = self.ctx.worker.submit(action, session["username"])
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None
        self.ctx.db.audit("job:" + action, session["username"], self.remote)
        self.send_json(HTTPStatus.ACCEPTED, result)

    # ---------------------------------------------------------------- alertes
    def api_alerts(self):
        self.require_session()
        try:
            mail = pbx.load(self.ctx.pbx_state)["mail"]["enabled"]
        except pbx.PbxError:
            mail = False
        payload = alerts.public(alerts.load_state(self.ctx.alerts_state))
        payload.update({"settings": alerts.load_settings(self.ctx.alerts_settings), "mail_enabled": mail,
                        "causes": [{"cause": k, "label": label} for k, label, _ in alerts.CAUSES]})
        self.send_json(HTTPStatus.OK, payload)

    def api_alerts_settings(self):
        session = self.require_session(write=True)
        try:
            settings = alerts.save_settings(self.read_json(), self.ctx.alerts_settings)
        except alerts.AlertError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, str(exc)) from None
        on = ",".join(k for k, v in settings["causes"].items() if v) or "aucune"
        self.ctx.db.audit(("alerts:settings:%d-destinataires:%s" % (len(settings["recipients"]), on))[:180],
                          session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "settings": settings})

    def api_audit(self):
        self.require_session()
        with self.ctx.db.lock:
            rows = self.ctx.db.conn.execute(
                "SELECT ts, username, remote, event FROM audit ORDER BY ts DESC LIMIT 200").fetchall()
        self.send_json(HTTPStatus.OK, {"events": [
            {"ts": r[0], "user": r[1], "remote": r[2], "event": r[3]} for r in rows]})


ROUTES = {
    ("POST", "/api/login"): Handler.api_login,
    ("POST", "/api/logout"): Handler.api_logout,
    ("GET", "/api/session"): Handler.api_session,
    ("GET", "/api/status"): Handler.api_status,
    ("GET", "/api/metrics"): Handler.api_metrics,
    ("POST", "/api/password"): Handler.api_password,
    ("GET", "/api/jobs"): Handler.api_jobs_list,
    ("GET", "/api/update"): Handler.api_update,
    ("GET", "/api/pbx"): Handler.api_pbx,
    ("POST", "/api/pbx/extensions"): Handler.api_pbx_create,
    ("POST", "/api/pbx/delete"): Handler.api_pbx_delete,
    ("POST", "/api/pbx/update"): Handler.api_pbx_update,
    ("POST", "/api/pbx/trunk"): Handler.api_pbx_trunk,
    ("POST", "/api/pbx/reception"): Handler.api_pbx_reception,
    ("POST", "/api/pbx/groups"): Handler.api_pbx_groups,
    ("POST", "/api/pbx/forward"): Handler.api_pbx_forward,
    ("POST", "/api/pbx/mail"): Handler.api_pbx_mail,
    ("GET", "/api/backups"): Handler.api_backups,
    ("GET", "/api/backups/file"): Handler.api_backups_file,
    ("POST", "/api/backups/settings"): Handler.api_backups_settings,
    ("POST", "/api/backups/restore"): Handler.api_backups_restore,
    ("GET", "/api/networks"): Handler.api_networks,
    ("POST", "/api/networks"): Handler.api_networks_save,
    ("GET", "/api/system/network"): Handler.api_system_network,
    ("POST", "/api/system/network"): Handler.api_system_network_save,
    ("POST", "/api/system/network/confirm"): Handler.api_system_network_confirm,
    ("POST", "/api/pbx/secret"): Handler.api_pbx_secret,
    ("GET", "/api/pbx/calls"): Handler.api_pbx_calls,
    ("GET", "/api/logs"): Handler.api_logs,
    ("GET", "/api/backup"): Handler.api_backup,
    ("POST", "/api/restore"): Handler.api_restore,
    ("POST", "/api/jobs"): Handler.api_jobs_submit,
    ("GET", "/api/audit"): Handler.api_audit,
    ("GET", "/api/alerts"): Handler.api_alerts,
    ("POST", "/api/alerts"): Handler.api_alerts_settings,
}
# Accueil vocal : menu « tapez 1 », annonces et musique d'attente
ROUTES.update({
    ("POST", "/api/pbx/ivr"): Handler.api_pbx_ivr,
    ("GET", "/api/sounds"): Handler.api_sounds,
    ("POST", "/api/sounds/upload"): Handler.api_sounds_upload,
    ("POST", "/api/sounds/delete"): Handler.api_sounds_delete,
})


def _vtuple(value):
    m = re.match(r"^(\d+)\.(\d+)\.(\d+)", value or "")
    return tuple(int(x) for x in m.groups()) if m else (0, 0, 0)


def read_version(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            value = handle.read().strip()
    except OSError:
        return "0.0.0"
    return value if re.match(r"^\d+\.\d+\.\d+([.-][0-9A-Za-z.-]+)?$", value) else "0.0.0"


def make_server(args):
    db = Database(args.db)
    ctx = Context(db, args.static, read_version(args.version_file), WorkerClient(args.worker_socket),
                  args.data, trust_proxy=args.trust_proxy, secure_cookie=not args.insecure_cookie,
                  update_state=args.update_state, pbx_state=args.pbx_state,
                  networks_state=args.networks_state)
    ctx.appliance_conf = args.appliance_conf
    ctx.backup_dir, ctx.backup_settings = args.backup_dir, args.backup_settings
    ctx.backup_status = os.path.join(os.path.dirname(args.backup_settings), "backup-status.json")
    ctx.sounds_upload = os.path.join(os.path.dirname(args.pbx_state), "sounds-upload")
    ctx.sounds_status = os.path.join(os.path.dirname(args.pbx_state), "sounds.json")
    # Alertes : à côté des réglages de sauvegarde (/var/lib/voipbuntu)
    ctx.alerts_settings = os.path.join(os.path.dirname(args.backup_settings), "alerts-settings.json")
    ctx.alerts_state = os.path.join(os.path.dirname(args.backup_settings), "alerts.json")
    handler = type("BoundHandler", (Handler,), {"ctx": ctx})
    server = ThreadingHTTPServer((args.listen, args.port), handler)
    server.daemon_threads = True
    return server, ctx


def parse_args(argv=None):
    base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    parser = argparse.ArgumentParser(description="Console web VOIPbuntu")
    parser.add_argument("--listen", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--db", default="/var/lib/voipbuntu/web.db")
    parser.add_argument("--static", default=os.path.join(base, "static"))
    parser.add_argument("--version-file", default="/opt/voipbuntu/VERSION")
    parser.add_argument("--worker-socket", default="/run/voipbuntu/worker.sock")
    parser.add_argument("--data", default="/srv/voipbuntu")
    parser.add_argument("--update-state", default="/var/lib/voipbuntu/update.json")
    parser.add_argument("--pbx-state", default=pbx.DEFAULT_STATE)
    parser.add_argument("--networks-state", default=networks.DEFAULT_STATE)
    parser.add_argument("--appliance-conf", default="/etc/voipbuntu/appliance.conf")
    parser.add_argument("--backup-dir", default=backup.DEFAULT_DIR)
    parser.add_argument("--backup-settings", default=backup.DEFAULT_SETTINGS)
    parser.add_argument("--trust-proxy", action="store_true")
    parser.add_argument("--insecure-cookie", action="store_true", help="tests uniquement")
    parser.add_argument("--no-sampler", action="store_true")
    return parser.parse_args(argv)


def main(argv=None):
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s", stream=sys.stderr)
    args = parse_args(argv)
    server, ctx = make_server(args)
    if not args.no_sampler:
        sysinfo.Sampler(ctx.db, args.data).start()
    LOG.info("console VOIPbuntu %s à l'écoute sur %s:%d", ctx.version, args.listen, args.port)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
