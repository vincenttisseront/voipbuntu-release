"""Active Directory : connexion à la console par groupe AD, import des contacts et postes proposés.

Bibliothèque standard uniquement (socket, ssl) : client LDAP v3 minimal, sur le modèle
du serveur ldapd.py (mêmes fonctions BER).

- Connexion à la console : la console se connecte au contrôleur avec l'identifiant et le
  mot de passe saisis (bind simple sous TLS), lit les groupes du compte et en déduit le rôle
  (groupe admin d'abord, puis groupe lecture). Aucun compte de service n'est utilisé ici.
- Import des contacts : voipbuntu-adsync (root, par la file d'attente) déchiffre le mot de
  passe du compte de service avec /etc/voipbuntu/secrets.key, lit l'OU choisie et range les
  contacts marqués « ad » dans l'annuaire partagé (pbx.json) ; les contacts locaux ne sont
  jamais touchés.
- TLS toujours vérifié : LDAPS (636) ou LDAP + StartTLS (389), nom du contrôleur contrôlé,
  autorités de confiance = magasin du système + chaîne du certificat de l'entreprise
  importé en 0.9.0 + certificat d'autorité collé dans les réglages.

Réglages : /var/lib/voipbuntu/ad.json (écrit par la console, sans mot de passe en clair).
État : /var/lib/voipbuntu-ad/status.json (écrit par root, lisible par la console).
"""

import hashlib
import json
import os
import re
import socket
import ssl
import tempfile

from . import directory, ldapd

SETTINGS = "/var/lib/voipbuntu/ad.json"
STATE_DIR = "/var/lib/voipbuntu-ad"
COMPANY_CHAIN = "/etc/voipbuntu/tls/cert.pem"
MODES = ("ldaps", "starttls")
DEFAULT_PORTS = {"ldaps": 636, "starttls": 389}
TIMEOUT = 6
MAX_HOSTS = 3
MAX_MESSAGE = 4 * 1024 * 1024
MAX_PROPOSALS = 200
PAGE_SIZE = 500

HOST_RE = re.compile(r"^(?=.{1,253}$)[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$")
# DN sans caractère échappé : « OU=Contacts,DC=corp,DC=local »
DN_RE = re.compile(r"^[A-Za-z][A-Za-z0-9-]{0,30}=[^,=+<>#;\\\"\x00-\x1f]{1,64}(?:,\s*[A-Za-z][A-Za-z0-9-]{0,30}=[^,=+<>#;\\\"\x00-\x1f]{1,64}){0,15}$")
GROUP_NAME_RE = re.compile(r"^[\w][\w .'()&-]{0,63}$", re.UNICODE)
# Compte de service : UPN (svc-voip@corp.local), DOMAINE\nom ou DN
BIND_USER_RE = re.compile(r"^(?:[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}@[A-Za-z0-9.-]{1,253}|[A-Za-z0-9][A-Za-z0-9-]{0,14}\\[A-Za-z0-9_][A-Za-z0-9_.-]{0,63})$")
SECRET_RE = re.compile(r"^v1:[A-Za-z0-9+/]{40,400}={0,2}$")
PEM_RE = re.compile(r"-----BEGIN CERTIFICATE-----[A-Za-z0-9+/=\s]+?-----END CERTIFICATE-----")
SAM_RE = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_.-]{0,31}$")
CA_MAX = 32 * 1024

# Règles de correspondance propres à AD
IN_CHAIN = "1.2.840.113556.1.4.1941"   # appartenance aux groupes imbriqués
BIT_AND = "1.2.840.113556.1.4.803"     # userAccountControl & 2 : compte désactivé
PAGED = "1.2.840.113556.1.4.319"       # résultats par pages (AD limite à 1000 par réponse)
STARTTLS = "1.3.6.1.4.1.1466.20037"

USER_ATTRS = ["sAMAccountName", "displayName", "memberOf", "userAccountControl"]
CONTACT_ATTRS = ["objectClass", "objectGUID", "displayName", "cn", "givenName", "sn", "company",
                 "telephoneNumber", "mobile", "homePhone", "ipPhone", "mail", "sAMAccountName"]


class AdError(Exception):
    """Réglage ou échange refusé ; le message est en français, sans secret."""


class Unreachable(AdError):
    """Aucun contrôleur joignable, ou certificat refusé."""


class BadCredentials(AdError):
    pass


# ------------------------------------------------------------------ réglages
def empty():
    return {"enabled": False, "hosts": [], "mode": "ldaps", "port": 636, "domain": "", "base_dn": "",
            "admin_group": "", "read_group": "", "bind_user": "", "bind_secret": "", "ca_pem": "",
            "import_enabled": False, "contacts_ou": "", "propose_extensions": False}


def domain_dn(domain):
    return ",".join("DC=" + part for part in domain.split(".") if part)


def is_dn(text):
    return bool(DN_RE.match(text or ""))


def validate(data):
    """Réglages complets ; refus plutôt que correction silencieuse."""
    if data is None:
        return empty()
    if not isinstance(data, dict):
        raise AdError("Réglages Active Directory invalides.")
    out = empty()
    for key in ("enabled", "import_enabled", "propose_extensions"):
        value = data.get(key, False)
        if not isinstance(value, bool):
            raise AdError("Réglages Active Directory invalides.")
        out[key] = value
    hosts = data.get("hosts", [])
    if isinstance(hosts, str):
        hosts = hosts.replace(",", " ").split()
    if not isinstance(hosts, list) or len(hosts) > MAX_HOSTS:
        raise AdError("Trois contrôleurs de domaine au plus.")
    for h in hosts:
        if not isinstance(h, str) or not HOST_RE.match(h):
            raise AdError("Nom de contrôleur de domaine invalide.")
    out["hosts"] = [h.lower() for h in hosts]
    mode = data.get("mode", "ldaps")
    if mode not in MODES:
        raise AdError("Mode de connexion invalide : LDAPS ou StartTLS.")
    out["mode"] = mode
    port = data.get("port") or DEFAULT_PORTS[mode]
    if not isinstance(port, int) or isinstance(port, bool) or not 1 <= port <= 65535:
        raise AdError("Port invalide.")
    out["port"] = port
    domain = str(data.get("domain") or "").strip().lower()
    if domain and (not HOST_RE.match(domain) or "." not in domain):
        raise AdError("Nom de domaine invalide (par exemple corp.local).")
    out["domain"] = domain
    base = str(data.get("base_dn") or "").strip()
    if not base and domain:
        base = domain_dn(domain)
    if base and not is_dn(base):
        raise AdError("Base DN invalide (par exemple DC=corp,DC=local).")
    out["base_dn"] = base
    for key in ("admin_group", "read_group"):
        value = str(data.get(key) or "").strip()
        if value and not (is_dn(value) or GROUP_NAME_RE.match(value)):
            raise AdError("Groupe invalide : nom du groupe ou DN complet.")
        out[key] = value
    user = str(data.get("bind_user") or "").strip()
    if user and not (BIND_USER_RE.match(user) or is_dn(user)):
        raise AdError("Compte de service invalide : nom@domaine ou DN complet.")
    out["bind_user"] = user
    secret = str(data.get("bind_secret") or "")
    if secret and not SECRET_RE.match(secret):
        raise AdError("Mot de passe chiffré du compte de service invalide.")
    out["bind_secret"] = secret
    ca = str(data.get("ca_pem") or "").strip()
    if ca:
        blocks = PEM_RE.findall(ca)
        if len(ca) > CA_MAX or not blocks or len(PEM_RE.sub("", ca).strip()) > 0:
            raise AdError("Certificat d'autorité invalide : collez un ou plusieurs certificats PEM.")
        ca = "\n".join(b.strip() for b in blocks) + "\n"
    out["ca_pem"] = ca
    ou = str(data.get("contacts_ou") or "").strip()
    if ou and not is_dn(ou):
        raise AdError("OU des contacts invalide (par exemple OU=Utilisateurs,DC=corp,DC=local).")
    out["contacts_ou"] = ou
    if out["enabled"] or out["import_enabled"] or out["propose_extensions"]:
        if not out["hosts"] or not out["domain"] or not out["base_dn"]:
            raise AdError("Renseignez le contrôleur de domaine, le domaine et la base DN.")
    if out["enabled"] and not (out["admin_group"] or out["read_group"]):
        raise AdError("Choisissez au moins un groupe autorisé (administrateurs ou lecture seule).")
    if (out["import_enabled"] or out["propose_extensions"]) and not (out["bind_user"] and out["bind_secret"] and out["contacts_ou"]):
        raise AdError("L'import demande le compte de service, son mot de passe et l'OU à lire.")
    return out


def read_nofollow(path, limit=256 * 1024):
    """Lecture sans suivre de lien (fichier d'un dossier de la console lu par root)."""
    import stat
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as handle:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise OSError("pas un fichier")
        data = handle.read(limit + 1)
    if len(data) > limit:
        raise OSError("fichier trop gros")
    return data


def load(path=SETTINGS):
    try:
        raw = read_nofollow(path)
    except FileNotFoundError:
        return empty()
    except OSError:
        raise AdError("Réglages Active Directory illisibles.") from None
    try:
        return validate(json.loads(raw.decode("utf-8")))
    except (ValueError, UnicodeDecodeError):
        raise AdError("Réglages Active Directory illisibles.") from None


def write_json(path, data, mode=0o600, owner=None):
    """Écriture atomique : fichier temporaire créé en O_EXCL, droits réglés sur le descripteur, renommage."""
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path) or ".", prefix=".voipbuntu-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            os.fchmod(handle.fileno(), mode)
            if owner:
                os.fchown(handle.fileno(), owner[0], owner[1])
            json.dump(data, handle, ensure_ascii=False, indent=1, sort_keys=True)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def save(settings, path=SETTINGS):
    settings = validate(settings)
    write_json(path, settings)
    return settings


def public_view(settings):
    """Réglages renvoyés à la console : jamais le mot de passe, même chiffré."""
    view = {k: v for k, v in settings.items() if k != "bind_secret"}
    view["has_password"] = bool(settings.get("bind_secret"))
    return view


def load_status(folder=STATE_DIR):
    try:
        with open(os.path.join(folder, "status.json"), "r", encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


# ------------------------------------------------------------------ TLS
CA_EXPORT = STATE_DIR + "/company-ca.pem"   # copie lisible par la console (voipbuntu-adsync)
CA_MARK = "# VOIPbuntu : autorités de la chaîne du certificat HTTPS de l'entreprise\n"


def company_chain(path=COMPANY_CHAIN):
    """Certificats d'autorité de la chaîne importée en 0.9.0 (tout sauf le certificat de l'appliance).

    /etc/voipbuntu/tls n'est lisible que par root : la console lit la copie CA_EXPORT, qui ne
    contient que les autorités (repérée par CA_MARK).
    """
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            text = handle.read(256 * 1024)
    except OSError:
        return []
    blocks = [b.strip() for b in PEM_RE.findall(text)]
    return blocks if text.startswith(CA_MARK) else blocks[1:]


def export_chain(source=COMPANY_CHAIN, target=CA_EXPORT, owner=None):
    """Root : recopie les autorités de la chaîne (certificats publics) pour la console."""
    blocks = company_chain(source)
    text = CA_MARK + "".join(b + "\n" for b in blocks)
    try:
        with open(target, "r", encoding="utf-8") as handle:
            if handle.read() == text:
                return len(blocks)
    except (OSError, UnicodeDecodeError):
        pass
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(target), prefix=".voipbuntu-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            os.fchmod(handle.fileno(), 0o640)
            if owner:
                os.fchown(handle.fileno(), owner[0], owner[1])
            handle.write(text)
        os.replace(tmp, target)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return len(blocks)


def tls_context(settings, chain_path=COMPANY_CHAIN):
    ctx = ssl.create_default_context()
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    anchors = company_chain(chain_path) + PEM_RE.findall(settings.get("ca_pem") or "")
    if anchors:
        try:
            ctx.load_verify_locations(cadata="\n".join(anchors) + "\n")
        except ssl.SSLError:
            raise AdError("Certificat d'autorité illisible.") from None
    # Une autorité intermédiaire de l'entreprise suffit comme point de confiance
    if hasattr(ssl, "VERIFY_X509_PARTIAL_CHAIN"):
        ctx.verify_flags |= ssl.VERIFY_X509_PARTIAL_CHAIN
    # Même tolérance qu'OpenSSL sous Python 3.12 (Ubuntu 24.04) pour les autorités internes
    if hasattr(ssl, "VERIFY_X509_STRICT"):
        ctx.verify_flags &= ~ssl.VERIFY_X509_STRICT
    return ctx


# ------------------------------------------------------------------ BER (côté client)
tlv, seq, ber_int, ber_str = ldapd.tlv, ldapd.seq, ldapd.ber_int, ldapd.ber_str


def f_eq(attr, value):
    return tlv(0xa3, ber_str(attr) + ber_str(value))


def f_and(*items):
    return tlv(0xa0, b"".join(items))


def f_or(*items):
    return tlv(0xa1, b"".join(items))


def f_not(item):
    return tlv(0xa2, item)


def f_present(attr):
    return tlv(0x87, attr.encode("ascii"))


def f_ext(rule, attr, value):
    return tlv(0xa9, tlv(0x81, rule.encode("ascii")) + tlv(0x82, attr.encode("ascii")) + tlv(0x83, value.encode("utf-8")))


def read_message(sock):
    """Un LDAPMessage complet lu sur le socket (TLS ou non)."""
    def take(n):
        data = b""
        while len(data) < n:
            chunk = sock.recv(n - len(data))
            if not chunk:
                raise AdError("Connexion fermée par le contrôleur de domaine.")
            data += chunk
        return data
    head = take(2)
    if head[0] != 0x30:
        raise AdError("Réponse LDAP invalide.")
    length, extra = head[1], b""
    if length & 0x80:
        count = length & 0x7f
        if count == 0 or count > 4:
            raise AdError("Réponse LDAP invalide.")
        extra = take(count)
        length = int.from_bytes(extra, "big")
    if length > MAX_MESSAGE:
        raise AdError("Réponse LDAP trop longue.")
    return head + extra + take(length)


def norm_dn(dn):
    return ldapd.normalize_dn(dn) or ""


class Client:
    """Connexion LDAP v3 vers un contrôleur, toujours chiffrée et vérifiée."""

    def __init__(self, host, port, mode, context, timeout=TIMEOUT):
        self.host, self.port, self.mode, self.context, self.timeout = host, port, mode, context, timeout
        self.sock = None
        self.msgid = 0

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def connect(self):
        try:
            raw = socket.create_connection((self.host, self.port), timeout=self.timeout)
        except OSError as exc:
            raise Unreachable("Contrôleur %s injoignable (%s)." % (self.host, exc.strerror or exc.__class__.__name__)) from None
        try:
            if self.mode == "starttls":
                self.sock = raw
                code, text, _ = self.extended(STARTTLS)
                if code != 0:
                    raise Unreachable("StartTLS refusé par %s (code %d)." % (self.host, code))
                raw = self.sock
            self.sock = self.context.wrap_socket(raw, server_hostname=self.host)
        except ssl.SSLCertVerificationError as exc:
            raw.close()
            raise Unreachable("Certificat de %s refusé : %s. Importez le certificat de l'autorité de l'entreprise." % (
                self.host, exc.verify_message or "vérification impossible")) from None
        except (ssl.SSLError, OSError) as exc:
            raw.close()
            raise Unreachable("Échange TLS impossible avec %s (%s)." % (self.host, exc.__class__.__name__)) from None
        return self

    def close(self):
        if self.sock is not None:
            try:
                self.send(tlv(0x42, b""))
            except (OSError, AdError):
                pass
            try:
                self.sock.close()
            except OSError:
                pass
            self.sock = None

    def send(self, op, controls=b""):
        self.msgid += 1
        try:
            self.sock.sendall(seq(ber_int(self.msgid), op, controls))
        except OSError:
            raise Unreachable("Connexion interrompue avec %s." % self.host) from None
        return self.msgid

    def receive(self):
        try:
            raw = read_message(self.sock)
        except (OSError, socket.timeout):
            raise Unreachable("Pas de réponse de %s." % self.host) from None
        try:
            _, body, _ = ldapd.read_tlv(raw, 0)
            parts = ldapd.children(body)
            msgid = ldapd.to_int(parts[0][1])
            return msgid, parts[1][0], parts[1][1], parts[2:]
        except (ldapd.ProtocolError, IndexError):
            raise AdError("Réponse LDAP invalide.") from None

    @staticmethod
    def result(op):
        parts = ldapd.children(op)
        return ldapd.to_int(parts[0][1]), ldapd.to_str(parts[2][1]) if len(parts) > 2 else ""

    def extended(self, oid):
        msgid = self.send(tlv(0x77, tlv(0x80, oid.encode("ascii"))))
        while True:
            rid, tag, op, _ = self.receive()
            if rid == msgid and tag == 0x78:
                code, text = self.result(op)
                return code, text, op
            if rid == 0:  # notice of disconnection
                raise Unreachable("Connexion fermée par %s." % self.host)

    def bind(self, name, password):
        if not password:
            raise BadCredentials("Mot de passe vide.")  # bind « non authentifié » : jamais accepté
        msgid = self.send(tlv(0x60, ber_int(3) + ber_str(name) + tlv(0x80, password.encode("utf-8"))))
        rid, tag, op, _ = self.receive()
        if rid != msgid or tag != 0x61:
            raise AdError("Réponse LDAP invalide.")
        code, text = self.result(op)
        if code == 49:
            raise BadCredentials("Identifiant ou mot de passe incorrect.")
        if code != 0:
            raise AdError("Connexion refusée par le contrôleur (code %d)." % code)

    def search(self, base, scope, flt, attrs, size=0, paged=True):
        """[(dn, {attribut en minuscules: [valeurs]})] ; références (referrals) ignorées."""
        out, cookie = [], b""
        while True:
            controls = b""
            if paged:
                value = seq(ber_int(PAGE_SIZE), ber_str(cookie))
                controls = tlv(0xa0, seq(ber_str(PAGED), tlv(0x01, b"\x00"), ber_str(value)))
            op = tlv(0x63, ber_str(base) + ber_int(scope, 0x0a) + ber_int(0, 0x0a) + ber_int(size) + ber_int(30)
                     + tlv(0x01, b"\x00") + flt + seq(*[ber_str(a) for a in attrs]))
            msgid = self.send(op, controls)
            cookie = b""
            while True:
                rid, tag, body, extra = self.receive()
                if rid != msgid:
                    continue
                if tag == 0x64:
                    out.append(self.entry(body))
                    if len(out) > 20000:
                        raise AdError("Trop d'entrées dans l'Active Directory.")
                elif tag == 0x73:
                    continue
                elif tag == 0x65:
                    code, text = self.result(body)
                    if code == 32:
                        raise AdError("Base introuvable dans l'Active Directory : %s." % base[:120])
                    if code not in (0, 4):
                        raise AdError("Recherche refusée par le contrôleur (code %d)." % code)
                    cookie = self.page_cookie(extra) if paged else b""
                    break
            if not cookie:
                return out

    @staticmethod
    def page_cookie(extra):
        try:
            for tag, value in extra:
                if tag != 0xa0:
                    continue
                for _, control in ldapd.children(value):
                    fields = ldapd.children(control)
                    if ldapd.to_str(fields[0][1]) == PAGED:
                        inner = ldapd.children(ldapd.children(fields[-1][1])[0][1])
                        return inner[1][1]
        except (ldapd.ProtocolError, IndexError):
            return b""
        return b""

    @staticmethod
    def entry(body):
        parts = ldapd.children(body)
        dn = ldapd.to_str(parts[0][1])
        attrs = {}
        for _, attr in ldapd.children(parts[1][1]):
            fields = ldapd.children(attr)
            name = ldapd.to_str(fields[0][1]).lower()
            values = [v for _, v in ldapd.children(fields[1][1])] if len(fields) > 1 else []
            if name == "objectguid":
                attrs[name] = [v.hex() for v in values]
            else:
                attrs[name] = [v.decode("utf-8", "replace") for v in values]
        return dn, attrs


def connect(settings, context=None, chain_path=COMPANY_CHAIN, timeout=TIMEOUT):
    """Premier contrôleur joignable de la liste ; Unreachable si aucun ne répond."""
    context = context or tls_context(settings, chain_path)
    errors = []
    for host in settings["hosts"]:
        try:
            return Client(host, settings["port"], settings["mode"], context, timeout).connect()
        except Unreachable as exc:
            errors.append(str(exc))
    raise Unreachable(" ".join(errors) or "Aucun contrôleur de domaine configuré.")


def first(attrs, name, default=""):
    values = attrs.get(name.lower()) or []
    return values[0] if values else default


# ------------------------------------------------------------------ connexion à la console
def login_name(settings, username):
    """« DOMAINE\\nom » ou « nom@domaine » → (nom de compte, nom de bind)."""
    text = username.strip()
    if "\\" in text:
        text = text.split("\\", 1)[1]
    elif "@" in text:
        text = text.split("@", 1)[0]
    if not SAM_RE.match(text):
        return None, None
    return text.lower(), "%s@%s" % (text, settings["domain"])


def group_dn(client, settings, group):
    if is_dn(group):
        return group
    found = client.search(settings["base_dn"], 2, f_and(f_eq("objectClass", "group"),
                                                        f_or(f_eq("cn", group), f_eq("sAMAccountName", group))),
                          ["cn"], size=2, paged=False)
    return found[0][0] if found else None


def is_member(client, settings, user_dn, attrs, group):
    dn = group_dn(client, settings, group)
    if not dn:
        return False
    wanted = norm_dn(dn)
    if any(norm_dn(g) == wanted for g in attrs.get("memberof", [])):
        return True
    # Groupes imbriqués : règle LDAP_MATCHING_RULE_IN_CHAIN d'AD
    nested = client.search(user_dn, 0, f_ext(IN_CHAIN, "memberOf", dn), ["1.1"], paged=False)
    return bool(nested)


def authenticate(settings, username, password, context=None, chain_path=COMPANY_CHAIN):
    """{"username", "role", "name"} ; role None si le compte n'est dans aucun groupe autorisé.

    BadCredentials si l'AD refuse le mot de passe, Unreachable si aucun contrôleur ne répond.
    """
    sam, upn = login_name(settings, username)
    if not sam or not password:
        raise BadCredentials("Identifiant ou mot de passe incorrect.")
    with connect(settings, context, chain_path) as client:
        client.bind(upn, password)
        found = client.search(settings["base_dn"], 2, f_and(f_eq("objectClass", "user"), f_eq("sAMAccountName", sam)),
                              USER_ATTRS, size=2, paged=False)
        if not found:
            return {"username": sam, "role": None, "name": ""}
        user_dn, attrs = found[0]
        account = first(attrs, "sAMAccountName", sam).lower()
        role = None
        for wanted, group in (("admin", settings["admin_group"]), ("lecture", settings["read_group"])):
            if group and is_member(client, settings, user_dn, attrs, group):
                role = wanted
                break
        return {"username": account, "role": role, "name": first(attrs, "displayName")[:80]}


# ------------------------------------------------------------------ import des contacts
def contact_filter():
    """Utilisateurs actifs et contacts de l'OU."""
    active_user = f_and(f_eq("objectCategory", "person"), f_eq("objectClass", "user"),
                        f_not(f_ext(BIT_AND, "userAccountControl", "2")))
    return f_or(active_user, f_eq("objectClass", "contact"))


def fetch(settings, password, context=None, chain_path=COMPANY_CHAIN):
    with connect(settings, context, chain_path) as client:
        client.bind(settings["bind_user"], password)
        return client.search(settings["contacts_ou"], 2, contact_filter(), CONTACT_ATTRS)


def contact_id(dn, attrs):
    key = first(attrs, "objectGUID") or norm_dn(dn)
    return hashlib.sha256(("ad:" + key).encode("utf-8")).hexdigest()[:12]


def to_contacts(entries):
    """(contacts marqués « ad », ignorés) ; une entrée sans numéro valable est ignorée."""
    contacts, skipped, ids = [], 0, set()
    for dn, attrs in entries:
        name = first(attrs, "displayName") or " ".join(
            x for x in (first(attrs, "givenName"), first(attrs, "sn")) if x) or first(attrs, "cn")
        numbers = []
        for attr, kind in (("telephoneNumber", "bureau"), ("mobile", "mobile"), ("homePhone", "domicile")):
            for value in attrs.get(attr.lower(), []):
                n = directory.normalize_number(value)
                if n and n not in [x["number"] for x in numbers] and len(numbers) < directory.MAX_NUMBERS:
                    numbers.append({"kind": kind, "number": n})
        cid = contact_id(dn, attrs)
        try:
            c = directory.validate_contact({"id": cid, "name": name, "company": first(attrs, "company"), "numbers": numbers})
        except directory.DirectoryError:
            skipped += 1
            continue
        if c["id"] in ids:
            continue
        ids.add(c["id"])
        c["source"] = "ad"
        contacts.append(c)
    contacts.sort(key=directory.sort_key)
    return contacts, skipped


def merge(state, contacts):
    """Contacts AD remplacés en bloc, contacts locaux intacts ; (état, changé, tronqués)."""
    book = state.get("directory") or directory.empty()
    local = [c for c in book["contacts"] if c.get("source") != "ad"]
    before = [c for c in book["contacts"] if c.get("source") == "ad"]
    room = max(0, directory.MAX_CONTACTS - len(local))
    kept = contacts[:room]
    taken = {c["id"] for c in local}
    kept = [c for c in kept if c["id"] not in taken]
    state["directory"] = {"contacts": local + kept}

    def canon(items):
        return json.dumps(sorted(items, key=lambda c: c["id"]), sort_keys=True)
    return state, canon(before) != canon(kept), len(contacts) - len(kept)


PROPOSAL_NUMBER_RE = re.compile(r"^[1-9][0-9]{1,5}$")
NAME_UNSAFE = re.compile(r"[\"<>\[\]\\;\x00-\x1f]")
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9.-]{1,253}\.[A-Za-z]{2,}$")


def proposals(entries, extensions=()):
    """Postes à créer : ipPhone, sinon telephoneNumber court (2 à 6 chiffres) des utilisateurs."""
    used = {str(e.get("number")) for e in extensions}
    out, seen = [], set()
    for dn, attrs in entries:
        if "user" not in [c.lower() for c in attrs.get("objectclass", ["user"])]:
            continue
        number = ""
        for attr in ("ipPhone", "telephoneNumber"):
            value = re.sub(r"[\s.-]", "", first(attrs, attr))
            if PROPOSAL_NUMBER_RE.match(value):
                number = value
                break
        if not number or number in used or number in seen:
            continue
        name = NAME_UNSAFE.sub(" ", first(attrs, "displayName") or first(attrs, "cn") or number)
        name = re.sub(r"\s+", " ", name).strip()[:40] or number
        mail = first(attrs, "mail")
        seen.add(number)
        out.append({"number": number, "name": name, "email": mail if EMAIL_RE.match(mail) else "",
                    "account": first(attrs, "sAMAccountName")[:64]})
        if len(out) >= MAX_PROPOSALS:
            break
    out.sort(key=lambda p: (len(p["number"]), p["number"]))
    return out
