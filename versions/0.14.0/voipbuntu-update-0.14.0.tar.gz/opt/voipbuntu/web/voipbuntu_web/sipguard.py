"""Protection contre les attaques SIP (lot O) : bannissement automatique des adresses qui
échouent à s'authentifier ou balaient des identifiants.

Ce module ne touche ni au réseau ni au pare-feu : il lit le journal d'Asterisk, décide, et
valide les réglages. voipbuntu-sipguard (root) applique les décisions dans une table nftables
à part (inet voipbuntu-guard), que voipbuntu-firewall ne réécrit jamais.

Règles :
- une adresse hors des réseaux des téléphones est bannie après max_failures échecs
  (identifiant inconnu ou mauvais mot de passe) en WINDOW secondes ;
- une adresse des réseaux des téléphones n'est bannie que si elle balaie des identifiants
  (plus de SCAN_USERS identifiants différents) : un téléphone mal configuré qui réessaie son
  mot de passe n'est jamais banni, et l'auto-découverte continue de le proposer ;
- jamais : 127.0.0.0/8 et ::1, les serveurs de l'opérateur, les bases DECT déclarées, les
  adresses et réseaux de la liste blanche.
"""
import ipaddress
import re
import time

DEFAULT_SETTINGS = "/var/lib/voipbuntu/sipguard.json"
WINDOW = 600            # secondes pendant lesquelles les échecs d'une adresse sont comptés
SCAN_USERS = 3          # identifiants différents au-delà desquels une adresse balaie (comme l'auto-découverte)
BASE_HANDSETS = 30      # une base DECT déclarée présente un compte par combiné
MAX_WHITELIST = 20
MAX_BANS = 1000         # au-delà, les plus anciens bannissements sont oubliés
HISTORY = 50
NEVER = ("127.0.0.0/8", "::1/128")

# L'adresse est celle qu'Asterisk a vue : la dernière « failed for '...' » de la ligne, suivie d'un
# Call-ID sans espace. Le champ From, fourni par l'attaquant, peut contenir n'importe quel texte :
# le motif glouton « .* » le traverse, et une fausse adresse glissée dedans n'est jamais retenue.
FAIL_RE = re.compile(r"^\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\] NOTICE\[\d+\] res_pjsip/pjsip_distributor\.c: "
                     r"Request '([A-Z]{3,10})' from '(.*)' failed for '([0-9a-fA-F.:\[\]]{3,60}?):(\d{1,5})' "
                     r"\(callid: [^\s)]*\) - (No matching endpoint found|Failed to authenticate)$")
USER_RE = re.compile(r"sips?:([^@>'\s]{1,64})@")


class GuardError(ValueError):
    pass


def default_settings():
    return {"enabled": True, "max_failures": 5, "ban_minutes": 60, "whitelist": []}


def _int(data, key, low, high, label):
    try:
        value = int(data.get(key, default_settings()[key]))
    except (TypeError, ValueError):
        raise GuardError("%s invalide." % label) from None
    if not low <= value <= high:
        raise GuardError("%s : entre %d et %d." % (label, low, high))
    return value


def validate_settings(data):
    if data is None:
        return default_settings()
    if not isinstance(data, dict):
        raise GuardError("Réglages de la protection SIP invalides.")
    out = default_settings()
    out["enabled"] = bool(data.get("enabled", True))
    out["max_failures"] = _int(data, "max_failures", 3, 50, "Nombre d'échecs")
    out["ban_minutes"] = _int(data, "ban_minutes", 5, 10080, "Durée du bannissement (minutes)")
    items = data.get("whitelist", [])
    if isinstance(items, str):
        items = items.replace(",", " ").split()
    if not isinstance(items, list) or len(items) > MAX_WHITELIST:
        raise GuardError("Liste blanche : %d adresses ou réseaux au plus." % MAX_WHITELIST)
    seen = []
    for item in items:
        try:
            net = str(ipaddress.ip_network(str(item).strip(), strict=False))
        except ValueError:
            raise GuardError("Liste blanche : adresse ou réseau invalide (%s)." % str(item)[:40]) from None
        if net not in seen:
            seen.append(net)
    out["whitelist"] = seen
    return out


def networks(items):
    out = []
    for item in items or ():
        try:
            out.append(ipaddress.ip_network(str(item).strip(), strict=False))
        except ValueError:
            continue
    return out


def address(text):
    """Adresse IP normalisée, ou None."""
    try:
        return str(ipaddress.ip_address(str(text).strip("[]")))
    except ValueError:
        return None


def inside(addr, nets):
    ip = ipaddress.ip_address(addr)
    return any(ip.version == n.version and ip in n for n in nets)


def parse_failures(text, now, window=WINDOW, after=None):
    """Échecs récents par adresse : {adresse: {"count", "users", "last", "reasons"}}.

    after : {adresse: instant} ; les échecs d'avant la fin du dernier bannissement de l'adresse ne
    comptent plus (sinon elle serait rebannie aussitôt libérée)."""
    after = after or {}
    out = {}
    for line in text.splitlines():
        m = FAIL_RE.match(line)
        if not m:
            continue
        when, _method, sender, ip, _port, reason = m.groups()
        try:
            ts = time.mktime(time.strptime(when, "%Y-%m-%d %H:%M:%S"))
        except (ValueError, OverflowError):
            continue
        if ts < now - window or ts > now + 60:
            continue
        addr = address(ip)
        if addr is None or ts <= after.get(addr, 0):
            continue
        rec = out.setdefault(addr, {"count": 0, "users": set(), "last": ts, "reasons": set()})
        rec["count"] += 1
        rec["last"] = max(rec["last"], ts)
        rec["reasons"].add("auth" if reason == "Failed to authenticate" else "unknown")
        u = USER_RE.search(sender)
        if u:
            rec["users"].add(u.group(1).lower()[:64])
    return out


def decide(failures, settings, phone_nets=(), protected=(), bases=(), banned=()):
    """Adresses à bannir maintenant : [(adresse, motif, nombre d'échecs)].

    phone_nets : réseaux des téléphones ; protected : adresses ou réseaux jamais bannis (opérateur) ;
    bases : adresses des bases DECT déclarées ; banned : adresses déjà bannies."""
    if not settings["enabled"]:
        return []
    phones = networks(phone_nets)
    never = networks(NEVER) + networks(settings["whitelist"]) + networks(protected)
    bases = {address(b) for b in bases if address(b)}
    out = []
    for addr, rec in sorted(failures.items()):
        if addr in banned or addr in bases or inside(addr, never):
            continue
        scan = len(rec["users"]) > SCAN_USERS
        if inside(addr, phones):
            if scan:
                out.append((addr, "scan", rec["count"]))
        elif rec["count"] >= settings["max_failures"]:
            out.append((addr, "scan" if scan else ("auth" if rec["reasons"] == {"auth"} else "unknown"), rec["count"]))
    return out


def empty_state():
    return {"bans": [], "history": [], "last_run": None, "released": {}}


def clean_state(state, now):
    """État relu depuis le disque (root) : bannissements valides et non expirés seulement."""
    if not isinstance(state, dict):
        state = {}
    bans = []
    for b in state.get("bans") or []:
        if not isinstance(b, dict):
            continue
        addr = address(b.get("address", ""))
        until = b.get("until")
        if addr is None or not isinstance(until, (int, float)) or until <= now:
            continue
        bans.append({"address": addr, "since": b.get("since") if isinstance(b.get("since"), (int, float)) else now,
                     "until": until, "reason": b.get("reason") if b.get("reason") in ("auth", "unknown", "scan") else "auth",
                     "count": b.get("count") if isinstance(b.get("count"), int) else 0})
    history = [h for h in (state.get("history") or []) if isinstance(h, dict)][-HISTORY:]
    last = state.get("last_run") if isinstance(state.get("last_run"), (int, float)) else None
    released = {}
    raw = state.get("released") if isinstance(state.get("released"), dict) else {}
    for b in state.get("bans") or []:  # bannissements arrivés à leur terme : libérés à leur échéance
        if isinstance(b, dict) and address(b.get("address", "")) and isinstance(b.get("until"), (int, float)) \
                and b["until"] <= now:
            raw = dict(raw, **{address(b["address"]): b["until"]})
    for addr, ts in raw.items():
        if address(addr) and isinstance(ts, (int, float)) and ts > now - WINDOW and len(released) < MAX_BANS:
            released[address(addr)] = ts
    return {"bans": bans[-MAX_BANS:], "history": history, "last_run": last, "released": released}


def add_bans(state, decisions, settings, now):
    for addr, reason, count in decisions:
        state["bans"].append({"address": addr, "since": now, "until": now + settings["ban_minutes"] * 60,
                              "reason": reason, "count": count})
        state["history"].append({"ts": now, "event": "ban", "address": addr, "reason": reason, "count": count})
    state["bans"] = state["bans"][-MAX_BANS:]
    state["history"] = state["history"][-HISTORY:]


def remove_ban(state, addr, now, who="admin"):
    before = len(state["bans"])
    state["bans"] = [b for b in state["bans"] if b["address"] != addr]
    if len(state["bans"]) != before:
        state.setdefault("released", {})[addr] = now
        state["history"].append({"ts": now, "event": "unban", "address": addr, "reason": who})
        state["history"] = state["history"][-HISTORY:]
        return True
    return False


def nft_script(state, table, now):
    """Script nft : table dédiée recréée, ensembles remplis avec le temps restant de chaque bannissement."""
    v4, v6 = [], []
    for b in state["bans"]:
        left = int(b["until"] - now)
        if left <= 0:
            continue
        (v4 if ipaddress.ip_address(b["address"]).version == 4 else v6).append("%s timeout %ds" % (b["address"], left))
    lines = ["table inet %s" % table, "delete table inet %s" % table, "table inet %s {" % table,
             "    set ban4 {", "        type ipv4_addr", "        flags timeout"]
    if v4:
        lines.append("        elements = { %s }" % ", ".join(v4))
    lines += ["    }", "    set ban6 {", "        type ipv6_addr", "        flags timeout"]
    if v6:
        lines.append("        elements = { %s }" % ", ".join(v6))
    lines += ["    }",
              "    chain input {",
              # Avant la table principale : un paquet jeté ici l'est pour de bon, quelle que soit la suite
              "        type filter hook input priority filter - 10; policy accept;",
              "        ip saddr @ban4 drop",
              "        ip6 saddr @ban6 drop",
              "    }", "}"]
    return "\n".join(lines) + "\n"


def public(state, settings, now):
    """Vue de la console."""
    return {"settings": settings,
            "bans": [{"address": b["address"], "since": int(b["since"]), "until": int(b["until"]),
                      "left": max(0, int(b["until"] - now)), "reason": b["reason"], "count": b["count"]}
                     for b in sorted(state["bans"], key=lambda b: b["since"], reverse=True)],
            "history": list(reversed(state["history"]))[:20], "last_run": state["last_run"]}
