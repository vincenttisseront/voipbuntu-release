"""Fenêtre de maintenance, mises à jour de sécurité et archive de support de VOIPbuntu.

Réglages (écrits par la console) : /var/lib/voipbuntu/maintenance.json
    {"auto_update": false, "security": true, "reboot": false, "notify": true,
     "days": [0, ..., 6], "start": "03:00", "hours": 2, "reboot_at": null}
(jours : 0 = lundi). voipbuntu-maintenance (root, voipbuntu-maintenance.timer, toutes
les 5 minutes) les relit sans suivre de lien et les revalide avec validate_settings().

État (écrit par root, lisible par la console) : /var/lib/voipbuntu/maintenance-state.json.

Archive de support : redact_json() et redact_conf() retirent les secrets par le nom
de leur clé, puis scrub() remplace toute valeur secrète connue qui resterait (journaux) ;
voipbuntu-maintenance refuse l'archive si un secret connu y figure encore.
"""

import json
import os
import re
import stat
import time

DEFAULT_SETTINGS = "/var/lib/voipbuntu/maintenance.json"
DEFAULT_STATE = "/var/lib/voipbuntu/maintenance-state.json"
REBOOT_REQUIRED = "/run/reboot-required"
TIME_RE = re.compile(r"^([01][0-9]|2[0-3]):([0-5][0-9])$")
MAX_HOURS = 8
REBOOT_HORIZON = 30 * 86400  # redémarrage planifiable dans les 30 jours
HISTORY = 30

# Clés dont la valeur est un secret (JSON de la console, fichiers .conf d'Asterisk, msmtp...)
SECRET_KEY_RE = re.compile(r"(pass|secret|pin|key|token|hash|totp|recovery|credential|auth|cookie|csrf|private)",
                           re.I)
# Clés sans secret malgré leur nom
NOT_SECRET = frozenset(("keep", "keep_days", "authentication", "pinned_fingerprint_algo"))
REDACTED = "***"
# Ligne « clé = valeur » ou « clé: valeur » dont la clé ressemble à un secret
CONF_SECRET_RE = re.compile(r"^(\s*[;#]?\s*[A-Za-z0-9_.\-]*(?:pass|secret|pin|key|token|auth|cred|private)"
                            r"[A-Za-z0-9_.\-]*\s*(?:=>|=|:|\s)\s*)(\S.*)$", re.I)
# voicemail.conf : « 1001 => 1234,Nom,e-mail » (le code PIN vient en premier)
VOICEMAIL_RE = re.compile(r"^(\s*[0-9]+\s*=>\s*)([^,\s]*)(.*)$")
# En-têtes de clés privées, quel que soit le fichier
PRIVATE_BLOCK_RE = re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----", re.S)


class MaintenanceError(ValueError):
    pass


# ------------------------------------------------------------------- réglages
def default_settings():
    return {"auto_update": False, "security": True, "reboot": False, "notify": True,
            "days": list(range(7)), "start": "03:00", "hours": 2, "reboot_at": None}


def validate_settings(data, now=None):
    if not isinstance(data, dict):
        raise MaintenanceError("Réglages de maintenance invalides.")
    s = default_settings()
    for key in ("auto_update", "security", "reboot", "notify"):
        if key in data:
            if not isinstance(data[key], bool):
                raise MaintenanceError("Réglages de maintenance invalides.")
            s[key] = data[key]
    if "days" in data:
        days = data["days"]
        if not isinstance(days, list) or any(not isinstance(d, int) or isinstance(d, bool) or not 0 <= d <= 6
                                             for d in days):
            raise MaintenanceError("Jours de maintenance invalides.")
        s["days"] = sorted(set(days))
    if "start" in data:
        if not isinstance(data["start"], str) or not TIME_RE.match(data["start"]):
            raise MaintenanceError("Heure de début invalide (HH:MM).")
        s["start"] = data["start"]
    if "hours" in data:
        h = data["hours"]
        if not isinstance(h, int) or isinstance(h, bool) or not 1 <= h <= MAX_HOURS:
            raise MaintenanceError("Durée de la fenêtre invalide : de 1 à 8 heures.")
        s["hours"] = h
    if data.get("reboot_at") is not None:
        at = data["reboot_at"]
        t = time.time() if now is None else now
        if not isinstance(at, int) or isinstance(at, bool):
            raise MaintenanceError("Date de redémarrage invalide.")
        # Une date passée reste lisible (redémarrage déjà fait) : seule la console vérifie l'avenir.
        if at > t + REBOOT_HORIZON:
            raise MaintenanceError("Redémarrage planifiable dans les 30 prochains jours.")
        s["reboot_at"] = at
    if (s["auto_update"] or s["security"]) and not s["days"]:
        raise MaintenanceError("Choisissez au moins un jour pour la fenêtre de maintenance.")
    return s


def read_json(path, limit=256 * 1024):
    """Lecture sans suivre de lien (dossier de la console) : None si absent ou illisible."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except OSError:
        return None
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            return None
        with os.fdopen(fd, "rb") as handle:
            fd = None
            raw = handle.read(limit + 1)
    finally:
        if fd is not None:
            os.close(fd)
    if len(raw) > limit:
        return None
    try:
        data = json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return None
    return data if isinstance(data, dict) else None


def load_settings(path=DEFAULT_SETTINGS):
    data = read_json(path)
    if data is None:
        return default_settings()
    try:
        return validate_settings(data)
    except MaintenanceError:
        return default_settings()


def load_state(path=DEFAULT_STATE):
    data = read_json(path, limit=1024 * 1024)
    return data if isinstance(data, dict) else {}


# ------------------------------------------------------------------ fenêtre
def window_at(settings, t):
    """Fenêtre ouverte à l'instant t : (identifiant, début, fin) en heure locale, ou None."""
    if not settings["days"]:
        return None
    hh, mm = (int(x) for x in settings["start"].split(":"))
    lt = time.localtime(t)
    for back in (0, 1):  # une fenêtre de la veille peut déborder après minuit
        day = time.localtime(time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday - back, 12, 0, 0, 0, 0, -1)))
        if day.tm_wday not in settings["days"]:
            continue
        start = time.mktime((day.tm_year, day.tm_mon, day.tm_mday, hh, mm, 0, 0, 0, -1))
        end = start + settings["hours"] * 3600
        if start <= t < end:
            return time.strftime("%Y-%m-%dT%H:%M", time.localtime(start)), int(start), int(end)
    return None


def next_window(settings, t):
    """Début de la prochaine fenêtre (ou de celle en cours), None sans jour choisi."""
    if not settings["days"] or not (settings["auto_update"] or settings["security"]):
        return None
    current = window_at(settings, t)
    if current:
        return current[1]
    hh, mm = (int(x) for x in settings["start"].split(":"))
    lt = time.localtime(t)
    for ahead in range(0, 8):
        day = time.localtime(time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday + ahead, 12, 0, 0, 0, 0, -1)))
        if day.tm_wday not in settings["days"]:
            continue
        start = time.mktime((day.tm_year, day.tm_mon, day.tm_mday, hh, mm, 0, 0, 0, -1))
        if start > t:
            return int(start)
    return None


# --------------------------------------------------- archive de support : secrets
def secret_key(name):
    return isinstance(name, str) and name not in NOT_SECRET and bool(SECRET_KEY_RE.search(name))


def collect_secrets(value, found=None, key=None):
    """Valeurs des clés secrètes d'un document JSON (pour la vérification finale)."""
    found = set() if found is None else found
    if isinstance(value, dict):
        for k, v in value.items():
            collect_secrets(v, found, k)
    elif isinstance(value, list):
        for v in value:
            collect_secrets(v, found, key)
    elif isinstance(value, (str, int)) and not isinstance(value, bool) and secret_key(key):
        text = str(value)
        if text:
            found.add(text)
    return found


def redact_json(value, key=None):
    if isinstance(value, dict):
        return {k: redact_json(v, k) for k, v in value.items()}
    if isinstance(value, list):
        return [redact_json(v, key) for v in value]
    if secret_key(key) and value not in (None, "", False, True):
        return REDACTED
    return value


def conf_secrets(text, voicemail=False):
    found = set()
    for line in text.splitlines():
        m = CONF_SECRET_RE.match(line)
        if m:
            found.add(m.group(2).strip().strip('"\''))
        if voicemail:
            m = VOICEMAIL_RE.match(line)
            if m and m.group(2):
                found.add(m.group(2))
    for block in PRIVATE_BLOCK_RE.findall(text):
        found.add(block)
    return {s for s in found if s}


def redact_conf(text, voicemail=False):
    text = PRIVATE_BLOCK_RE.sub("-----PRIVATE KEY " + REDACTED + "-----", text)
    out = []
    for line in text.splitlines():
        m = CONF_SECRET_RE.match(line)
        if m:
            line = m.group(1) + REDACTED
        elif voicemail:
            m = VOICEMAIL_RE.match(line)
            if m and m.group(2):
                line = m.group(1) + REDACTED + m.group(3)
        out.append(line)
    return "\n".join(out) + ("\n" if text.endswith("\n") else "")


def strong_secrets(values, minimum=6):
    """Secrets assez longs pour être cherchés partout sans faux positif (les codes courts
    sont retirés par leur clé seulement)."""
    return sorted({v for v in values if isinstance(v, str) and len(v) >= minimum and v != REDACTED},
                  key=len, reverse=True)


def scrub(data, secrets):
    """Remplace dans des octets toute occurrence d'un secret connu."""
    for s in secrets:
        data = data.replace(s.encode("utf-8"), REDACTED.encode())
    return data


def leaks(data, secrets):
    return [s for s in secrets if s.encode("utf-8") in data]
