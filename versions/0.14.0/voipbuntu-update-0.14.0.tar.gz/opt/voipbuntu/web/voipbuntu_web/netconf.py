"""Réseau et système de l'appliance : adresse IP, DNS, nom de machine, NTP, fuseau.

La console tient les réglages voulus dans /var/lib/voipbuntu/netconf.json ;
voipbuntu-netconf (root, via la file d'attente) les valide de nouveau et les
applique : netplan (/etc/netplan/60-voipbuntu.yaml) avec retour arrière si la
console ne confirme pas, hostnamectl, timesyncd, timedatectl.

Fichiers d'échange dans le dossier d'état (/var/lib/voipbuntu) :
  netconf.json          réglages voulus (console)
  netconf-status.json   état de la dernière application (root)
  netconf-confirm.json  confirmation de la console pour la nouvelle adresse (console)
  netcheck.json         résultat du dernier test de joignabilité (root)
"""

import ipaddress
import json
import os
import re
import socket
import subprocess

try:
    import zoneinfo
except ImportError:  # pragma: no cover - Python < 3.9
    zoneinfo = None

DEFAULT_DIR = "/var/lib/voipbuntu"
STATE_NAME = "netconf.json"
STATUS_NAME = "netconf-status.json"
CONFIRM_NAME = "netconf-confirm.json"
CHECK_NAME = "netcheck.json"
CONFIRM_SECONDS = 180
NETPLAN_FILE = "60-voipbuntu.yaml"
MAX_DNS = 3
MAX_SEARCH = 6
MAX_NTP = 4
IFNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{1,15}$")
LABEL = r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?"
HOSTNAME_RE = re.compile(r"^%s$" % LABEL)
DOMAIN_RE = re.compile(r"^%s(?:\.%s)*$" % (LABEL, LABEL))
TZ_RE = re.compile(r"^[A-Za-z0-9_+-]+(?:/[A-Za-z0-9_+-]+){0,2}$")
NONCE_RE = re.compile(r"^[0-9a-f]{32}$")
CHECK_HOSTS = ("api.github.com", "archive.ubuntu.com")


class NetconfError(ValueError):
    pass


def paths(state_dir=DEFAULT_DIR):
    return {k: os.path.join(state_dir, v) for k, v in
            (("state", STATE_NAME), ("status", STATUS_NAME), ("confirm", CONFIRM_NAME), ("check", CHECK_NAME))}


# ------------------------------------------------------------------ validation
def split_list(value):
    if value is None:
        return []
    if isinstance(value, str):
        return [v for v in re.split(r"[\s,;]+", value.strip()) if v]
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    raise NetconfError("Format des réglages invalide.")


def prefix_of(mask):
    """Masque en longueur de préfixe : « 24 », « /24 » ou « 255.255.255.0 »."""
    text = str(mask if mask is not None else "").strip().lstrip("/")
    if text.isdigit():
        value = int(text)
    else:
        try:
            value = ipaddress.IPv4Network("0.0.0.0/" + text).prefixlen
        except ValueError:
            raise NetconfError("Masque invalide : 24 ou 255.255.255.0 par exemple.") from None
    if not 8 <= value <= 30:
        raise NetconfError("Masque invalide : 24 ou 255.255.255.0 par exemple.")
    return value


def ip_or_error(value, message):
    try:
        return ipaddress.ip_address(str(value).strip())
    except ValueError:
        raise NetconfError(message) from None


def is_ip(value):
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False


def usable(ip):
    return not (ip.is_loopback or ip.is_multicast or ip.is_unspecified or ip.is_link_local or ip.is_reserved)


def validate_network(net):
    if not isinstance(net, dict):
        raise NetconfError("Format des réglages invalide.")
    interface = str(net.get("interface", "")).strip()
    if not IFNAME_RE.match(interface):
        raise NetconfError("Interface réseau inconnue.")
    mode = net.get("mode")
    if mode not in ("dhcp", "static"):
        raise NetconfError("Mode d'adressage invalide.")
    dns = []
    for item in split_list(net.get("dns")):
        ip = ip_or_error(item, "Serveur DNS invalide : adresse IP attendue.")
        if not usable(ip):
            raise NetconfError("Serveur DNS invalide : adresse IP attendue.")
        if str(ip) not in dns:
            dns.append(str(ip))
    if len(dns) > MAX_DNS:
        raise NetconfError("Trois serveurs DNS au plus.")
    search = []
    for item in split_list(net.get("search")):
        item = item.lower().rstrip(".")
        if len(item) > 253 or not DOMAIN_RE.match(item):
            raise NetconfError("Domaine de recherche invalide.")
        if item not in search:
            search.append(item)
    if len(search) > MAX_SEARCH:
        raise NetconfError("Six domaines de recherche au plus.")
    out = {"interface": interface, "mode": mode, "address": "", "prefix": None, "gateway": "",
           "dns": dns, "search": search}
    if mode == "static":
        ip = ip_or_error(net.get("address", ""), "Adresse IP invalide (IPv4, par exemple 192.168.1.10).")
        if ip.version != 4 or not usable(ip):
            raise NetconfError("Adresse IP invalide (IPv4, par exemple 192.168.1.10).")
        prefix = prefix_of(net.get("prefix", net.get("mask")))
        subnet = ipaddress.IPv4Network("%s/%d" % (ip, prefix), strict=False)
        if ip in (subnet.network_address, subnet.broadcast_address):
            raise NetconfError("Cette adresse est celle du réseau ou de diffusion : choisissez-en une autre.")
        gw = ip_or_error(net.get("gateway", ""), "Passerelle invalide : une adresse du même réseau que l'appliance.")
        if gw.version != 4 or gw not in subnet or gw == ip or gw in (subnet.network_address, subnet.broadcast_address):
            raise NetconfError("Passerelle invalide : une adresse du même réseau que l'appliance.")
        if not dns:
            raise NetconfError("En adresse fixe, indiquez au moins un serveur DNS.")
        out.update(address=str(ip), prefix=prefix, gateway=str(gw))
    return out


def timezones():
    if zoneinfo is None:
        return []
    try:
        return sorted(z for z in zoneinfo.available_timezones() if "/" in z or z == "UTC")
    except Exception:  # base tzdata absente
        return []


def validate_timezone(value, known=None):
    tz = str(value or "").strip()
    known = timezones() if known is None else known
    if not TZ_RE.match(tz) or ".." in tz or (known and tz not in known):
        raise NetconfError("Fuseau horaire inconnu.")
    return tz


def validate(data, known_timezones=None):
    if not isinstance(data, dict):
        raise NetconfError("Format des réglages invalide.")
    out = {"network": None, "hostname": "", "ntp": [], "timezone": ""}
    if data.get("network") is not None:
        out["network"] = validate_network(data["network"])
    hostname = str(data.get("hostname") or "").strip().lower()
    if hostname and (not HOSTNAME_RE.match(hostname) or hostname.isdigit()):
        raise NetconfError("Nom de machine invalide : lettres, chiffres et tirets, 63 caractères au plus.")
    out["hostname"] = hostname
    ntp = []
    for item in split_list(data.get("ntp")):
        item = item.lower().rstrip(".")
        try:
            ok = usable(ipaddress.ip_address(item))
        except ValueError:
            ok = len(item) <= 253 and bool(DOMAIN_RE.match(item))
        if not ok:
            raise NetconfError("Serveur NTP invalide : nom ou adresse IP.")
        if item not in ntp:
            ntp.append(item)
    if len(ntp) > MAX_NTP:
        raise NetconfError("Quatre serveurs NTP au plus.")
    out["ntp"] = ntp
    if data.get("timezone"):
        out["timezone"] = validate_timezone(data["timezone"], known_timezones)
    return out


def read_json(path, limit=65536):
    """Lecture sans suivre de lien symbolique (le dossier appartient à la console)."""
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    with os.fdopen(fd, "rb") as handle:
        raw = handle.read(limit + 1)
    if len(raw) > limit:
        raise ValueError("trop long")
    return json.loads(raw.decode("utf-8"))


def load(path):
    try:
        return validate(read_json(path))
    except FileNotFoundError:
        return None
    except (OSError, ValueError):
        raise NetconfError("Réglages réseau illisibles.") from None


def save(state, path, known_timezones=None):
    state = validate(state, known_timezones)
    write_json(path, state)
    return state


def write_json(path, data, owner=None, mode=0o600):
    """Écriture atomique par un fichier temporaire exclusif, puis renommage."""
    import tempfile
    directory = os.path.dirname(path) or "."
    fd, tmp = tempfile.mkstemp(prefix="." + os.path.basename(path) + ".", dir=directory)
    try:
        # Droits posés sur le descripteur, jamais par le chemin : le dossier appartient à la console.
        os.fchmod(fd, mode)
        if owner:
            os.fchown(fd, *owner)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=1)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def merge(current, changes):
    """Réglages modifiés par la console : seules les clés envoyées sont remplacées."""
    base = dict(current or {"network": None, "hostname": "", "ntp": [], "timezone": ""})
    for key in ("network", "hostname", "ntp", "timezone"):
        if key in changes:
            base[key] = changes[key]
    return base


# ------------------------------------------------------------------ netplan
def q(value):
    return json.dumps(str(value))  # chaîne YAML entre guillemets (JSON est du YAML)


def render_netplan(net):
    lines = ["# Généré par la console VOIPbuntu (Système > Réseau) : ne pas modifier à la main.",
             "network:", "  version: 2", "  renderer: networkd", "  ethernets:",
             "    %s:" % q(net["interface"])]
    if net["mode"] == "dhcp":
        lines += ["      dhcp4: true", "      dhcp6: false"]
        if net["dns"] or net["search"]:
            lines += ["      dhcp4-overrides:"]
            if net["dns"]:
                lines += ["        use-dns: false"]
            if net["search"]:
                lines += ["        use-domains: false"]
    else:
        lines += ["      dhcp4: false", "      dhcp6: false",
                  "      addresses: [%s]" % q("%s/%d" % (net["address"], net["prefix"])),
                  "      routes:", "        - to: default", "          via: %s" % q(net["gateway"])]
    if net["dns"] or net["search"]:
        lines += ["      nameservers:"]
        if net["dns"]:
            lines += ["        addresses: [%s]" % ", ".join(q(d) for d in net["dns"])]
        if net["search"]:
            lines += ["        search: [%s]" % ", ".join(q(s) for s in net["search"])]
    return "\n".join(lines) + "\n"


def render_timesyncd(ntp):
    if not ntp:
        return None
    return "# Généré par la console VOIPbuntu (Système > Réseau)\n[Time]\nNTP=%s\n" % " ".join(ntp)


# ------------------------------------------------------------------ état réel (lecture seule)
def run(argv, timeout=5):
    try:
        return subprocess.run(argv, capture_output=True, text=True, timeout=timeout,
                              env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LANG": "C.UTF-8"}).stdout
    except (OSError, subprocess.SubprocessError):
        return ""


def read_text(path):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            return handle.read(65536)
    except OSError:
        return ""


def interfaces():
    try:
        data = json.loads(run(["ip", "-j", "addr", "show"]) or "[]")
    except ValueError:
        return []
    out = []
    for link in data if isinstance(data, list) else []:
        name = str(link.get("ifname", ""))
        if link.get("link_type") != "ether" or not IFNAME_RE.match(name) or link.get("master"):
            continue
        if name.startswith(("veth", "docker", "br-", "virbr")):
            continue
        addrs, dhcp = [], False
        for a in link.get("addr_info") or []:
            if a.get("family") == "inet" and a.get("scope") == "global":
                addrs.append("%s/%s" % (a.get("local"), a.get("prefixlen")))
                dhcp = dhcp or bool(a.get("dynamic"))
        out.append({"name": name, "mac": str(link.get("address", ""))[:17], "addresses": addrs,
                    "dhcp": dhcp, "up": "UP" in (link.get("flags") or [])})
    return out


def default_route():
    try:
        data = json.loads(run(["ip", "-j", "-4", "route", "show", "default"]) or "[]")
    except ValueError:
        return {"gateway": "", "interface": ""}
    for r in data if isinstance(data, list) else []:
        return {"gateway": str(r.get("gateway", "")), "interface": str(r.get("dev", ""))}
    return {"gateway": "", "interface": ""}


def resolvers(text=None):
    """Serveurs DNS réellement utilisés (systemd-resolved, sinon /etc/resolv.conf)."""
    if text is None:
        text = read_text("/run/systemd/resolve/resolv.conf") or read_text("/etc/resolv.conf")
    servers, search = [], []
    for line in text.splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[0] == "nameserver" and parts[1] not in servers:
            servers.append(parts[1])
        elif parts and parts[0] == "search":
            search = parts[1:]
    return servers[:6], search[:6]


def current_timezone():
    try:
        target = os.readlink("/etc/localtime")
        if "zoneinfo/" in target:
            return target.split("zoneinfo/", 1)[1]
    except OSError:
        pass
    return read_text("/etc/timezone").strip() or "UTC"


def current_ntp():
    for path in ("/etc/systemd/timesyncd.conf.d/60-voipbuntu.conf", "/etc/systemd/timesyncd.conf"):
        for line in read_text(path).splitlines():
            if line.strip().startswith("NTP=") and line.split("=", 1)[1].strip():
                return line.split("=", 1)[1].split()
    return []


def live():
    route = default_route()
    dns, search = resolvers()
    synced = run(["timedatectl", "show", "-p", "NTPSynchronized", "--value"]).strip()
    return {"interfaces": interfaces(), "gateway": route["gateway"], "route_interface": route["interface"],
            "dns": dns, "search": search, "hostname": socket.gethostname(), "timezone": current_timezone(),
            "ntp": current_ntp(), "ntp_synced": {"yes": True, "no": False}.get(synced)}


def defaults(current):
    """Réglages proposés quand la console n'en a encore aucun : ceux en service."""
    ifaces = current.get("interfaces") or []
    name = current.get("route_interface") or (ifaces[0]["name"] if ifaces else "")
    iface = next((i for i in ifaces if i["name"] == name), None)
    address, prefix = "", None
    if iface and iface["addresses"]:
        address, prefix = iface["addresses"][0].split("/")
        prefix = int(prefix)
    return {"network": {"interface": name, "mode": "dhcp" if (iface is None or iface["dhcp"]) else "static",
                        "address": address, "prefix": prefix, "gateway": current.get("gateway", ""),
                        "dns": current.get("dns", [])[:MAX_DNS], "search": current.get("search", [])[:MAX_SEARCH]},
            "hostname": current.get("hostname", ""), "ntp": current.get("ntp", [])[:MAX_NTP],
            "timezone": current.get("timezone", "")}


def read_status(path):
    try:
        data = read_json(path)
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict) or data.get("state") not in ("pending", "applied", "rolled-back", "failed"):
        return None
    out = {"state": data["state"], "ts": data.get("ts") if isinstance(data.get("ts"), (int, float)) else None,
           "message": str(data.get("message", ""))[:300], "address": str(data.get("address", ""))[:45],
           "deadline": data.get("deadline") if isinstance(data.get("deadline"), (int, float)) else None,
           "network_changed": bool(data.get("network_changed"))}
    if data["state"] == "pending" and NONCE_RE.match(str(data.get("nonce", ""))):
        out["nonce"] = data["nonce"]
    return out


def read_check(path):
    try:
        data = read_json(path)
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict) or not isinstance(data.get("steps"), list):
        return None
    steps = []
    for s in data["steps"][:8]:
        if isinstance(s, dict):
            steps.append({"id": str(s.get("id", ""))[:40], "ok": bool(s.get("ok")),
                          "detail": str(s.get("detail", ""))[:200], "error": str(s.get("error", ""))[:20]})
    return {"ts": data.get("ts") if isinstance(data.get("ts"), (int, float)) else None,
            "ok": bool(data.get("ok")), "steps": steps}
