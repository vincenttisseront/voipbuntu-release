"""Modèle de la téléphonie VOIPbuntu et génération de la configuration Asterisk.

La console (sans privilège) tient l'état voulu dans /var/lib/voipbuntu/pbx.json ;
voipbuntu-pbx (root, via la file d'attente) le valide de nouveau, écrit les
fichiers d'Asterisk et recharge le service. Aucune valeur n'est recopiée dans
la configuration d'Asterisk sans être passée par validate().
"""

import json
import os
import re
import secrets
import string

DEFAULT_STATE = "/var/lib/voipbuntu/pbx.json"
MAX_EXTENSIONS = 200
NUMBER_RE = re.compile(r"^[1-9][0-9]{1,5}$")
SECRET_RE = re.compile(r"^[A-Za-z0-9]{16,64}$")
PIN_RE = re.compile(r"^[0-9]{4,8}$")
NAME_RE = re.compile(r"^[^\x00-\x1f\x7f\"<>;\[\]\\=,|]{1,40}$")
RESERVED = {"97", "43"}  # préfixes des codes de service *97 et *43 (sans l'étoile, jamais en conflit)
LANGUAGES = ("fr", "en")


class PbxError(ValueError):
    pass


def new_secret(length=24):
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def new_pin():
    return "".join(secrets.choice(string.digits) for _ in range(6))


def empty():
    return {"language": "fr", "extensions": []}


def load(path=DEFAULT_STATE):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
    except FileNotFoundError:
        return empty()
    except (OSError, ValueError) as exc:
        raise PbxError("configuration téléphonique illisible : %s" % exc.__class__.__name__) from None
    return validate(data)


def save(state, path=DEFAULT_STATE):
    state = validate(state)
    tmp = path + ".tmp"
    old = os.umask(0o077)
    try:
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(state, handle, indent=1, sort_keys=True)
        os.replace(tmp, path)
    finally:
        os.umask(old)
    return state


def validate(data):
    if not isinstance(data, dict):
        raise PbxError("format invalide")
    language = data.get("language", "fr")
    if language not in LANGUAGES:
        raise PbxError("langue invalide")
    exts = data.get("extensions", [])
    if not isinstance(exts, list) or len(exts) > MAX_EXTENSIONS:
        raise PbxError("liste de postes invalide")
    clean, seen = [], set()
    for ext in exts:
        if not isinstance(ext, dict):
            raise PbxError("poste invalide")
        number, name = str(ext.get("number", "")), str(ext.get("name", "")).strip()
        secret, pin = str(ext.get("secret", "")), str(ext.get("pin", ""))
        if not NUMBER_RE.match(number):
            raise PbxError("numéro invalide : %s" % number[:8])
        if number in seen:
            raise PbxError("numéro en double : %s" % number)
        if not NAME_RE.match(name):
            raise PbxError("nom invalide pour le poste %s" % number)
        if not SECRET_RE.match(secret):
            raise PbxError("mot de passe SIP invalide pour le poste %s" % number)
        if not PIN_RE.match(pin):
            raise PbxError("code de messagerie invalide pour le poste %s" % number)
        seen.add(number)
        clean.append({"number": number, "name": name, "secret": secret, "pin": pin,
                      "voicemail": bool(ext.get("voicemail", True))})
    clean.sort(key=lambda e: (len(e["number"]), e["number"]))
    return {"language": language, "extensions": clean}


def public(state):
    """Vue de la console : jamais le mot de passe SIP ni le code de messagerie."""
    return {"language": state["language"],
            "extensions": [{"number": e["number"], "name": e["name"], "voicemail": e["voicemail"]}
                           for e in state["extensions"]]}


# ------------------------------------------------------------------ Asterisk
HEADER = "; Généré par voipbuntu-pbx, ne pas modifier : la console VOIPbuntu remplace ce fichier.\n"

MODULES = [
    "res_pjsip.so", "res_pjsip_session.so", "res_pjsip_authenticator_digest.so",
    "res_pjsip_endpoint_identifier_user.so", "res_pjsip_registrar.so", "res_pjsip_outbound_registration.so",
    "res_pjsip_sdp_rtp.so", "res_pjsip_caller_id.so", "res_pjsip_dtmf_info.so", "res_pjsip_rfc3326.so",
    "res_pjsip_mwi.so", "res_pjsip_mwi_body_generator.so", "res_pjsip_pubsub.so", "res_pjsip_nat.so",
    "res_pjsip_logger.so", "res_pjproject.so", "res_sorcery_config.so", "res_sorcery_memory.so",
    "res_sorcery_astdb.so", "res_rtp_asterisk.so", "res_timing_timerfd.so",
    "chan_pjsip.so", "chan_bridge_media.so",
    "app_dial.so", "app_voicemail.so", "app_echo.so", "app_playback.so", "app_verbose.so",
    "bridge_simple.so", "bridge_native_rtp.so", "bridge_softmix.so", "bridge_holding.so",
    "codec_alaw.so", "codec_ulaw.so", "codec_g722.so", "codec_gsm.so", "codec_a_mu.so",
    "format_gsm.so", "format_wav.so", "format_wav_gsm.so", "format_pcm.so",
    "func_callerid.so", "func_logic.so", "func_strings.so", "func_channel.so",
    "pbx_config.so", "cdr_csv.so",
]
CDR_FIELDS = ("accountcode", "src", "dst", "dcontext", "clid", "channel", "dstchannel", "lastapp", "lastdata",
              "start", "answer", "end", "duration", "billsec", "disposition", "amaflags")
DISPOSITIONS = ("ANSWERED", "NO ANSWER", "BUSY", "FAILED", "CONGESTION")


def render(state):
    """Renvoie {nom de fichier: contenu} pour /etc/asterisk."""
    state = validate(state)
    lang = state["language"]
    files = {}
    files["modules.conf"] = HEADER + "[modules]\nautoload=no\n" + "".join("load = %s\n" % m for m in MODULES)
    files["logger.conf"] = HEADER + ("[general]\ndateformat=%F %T\n\n[logfiles]\n"
                                     "console => notice,warning,error\nmessages.log => notice,warning,error,security\n")
    files["rtp.conf"] = HEADER + "[general]\nrtpstart=10000\nrtpend=20000\nstrictrtp=yes\nicesupport=no\n"
    files["manager.conf"] = HEADER + "[general]\nenabled=no\n"
    # cdr_csv lit sa section [csv] dans cdr.conf (il n'a pas de fichier à lui)
    files["cdr.conf"] = HEADER + ("[general]\nenable=yes\nunanswered=yes\ncongestion=yes\n\n"
                                  "[csv]\nusegmtime=no\nloguniqueid=no\nloguserfield=no\naccountlogs=no\n")
    for name, body in (("cel.conf", "[general]\nenable=no\n"),
                       ("features.conf", "[general]\n"), ("ccss.conf", "[general]\n"), ("acl.conf", ""),
                       ("pjproject.conf", "[startup]\nlog_level=default\n"), ("udptl.conf", "[general]\n")):
        files[name] = HEADER + body
    files["http.conf"] = HEADER + "[general]\nenabled=no\n"
    files["indications.conf"] = HEADER + "[general]\ncountry=fr\n\n[fr]\ndescription = France\nringcadence = 1500,3500\ndial = 440\nbusy = 440/500,0/500\nring = 440/1500,0/3500\ncongestion = 440/250,0/250\ncallwaiting = 440/300,0/10000\ndialrecall = !350+440/100,!0/100,!350+440/100,!0/100,!350+440/100,!0/100,350+440\nrecord = 1400/500,0/15000\ninfo = !950/330,!1400/330,!1800/330\nstutter = !440/100,!0/100,!440/100,!0/100,!440/100,!0/100,!440/100,!0/100,!440/100,!0/100,!440/100,!0/100,440\n"
    pjsip = [HEADER,
             "[global]\ntype=global\nuser_agent=VOIPbuntu\nendpoint_identifier_order=username\n\n",
             "[transport-udp]\ntype=transport\nprotocol=udp\nbind=0.0.0.0:5060\n\n",
             "[transport-tcp]\ntype=transport\nprotocol=tcp\nbind=0.0.0.0:5060\n\n"]
    for e in state["extensions"]:
        n = e["number"]
        pjsip.append(
            "[%s]\ntype=endpoint\ncontext=voipbuntu-internes\ndisallow=all\nallow=g722,alaw,ulaw\n"
            "auth=%s\naors=%s\ncallerid=\"%s\" <%s>\nlanguage=%s\ndirect_media=no\nrtp_symmetric=yes\n"
            "force_rport=yes\nrewrite_contact=yes\ndtmf_mode=rfc4733\n%s\n" % (
                n, n, n, e["name"], n, lang, ("mailboxes=%s@default\n" % n) if e["voicemail"] else ""))
        pjsip.append("[%s]\ntype=auth\nauth_type=userpass\nusername=%s\npassword=%s\n\n" % (n, n, e["secret"]))
        pjsip.append("[%s]\ntype=aor\nmax_contacts=2\nremove_existing=yes\nqualify_frequency=60\n\n" % n)
    files["pjsip.conf"] = "".join(pjsip)
    ext = [HEADER, "[general]\nstatic=yes\nwriteprotect=yes\nclearglobalvars=yes\n\n[globals]\n\n",
           "[voipbuntu-internes]\n",
           "exten => *43,1,NoOp(Test d'écho)\n same => n,Answer()\n same => n,Playback(demo-echotest)\n"
           " same => n,Echo()\n same => n,Hangup()\n",
           "exten => *97,1,NoOp(Messagerie vocale)\n same => n,Answer()\n"
           " same => n,VoiceMailMain(${CALLERID(num)}@default)\n same => n,Hangup()\n"]
    for e in state["extensions"]:
        n = e["number"]
        ext.append("exten => %s,1,NoOp(Appel vers %s)\n same => n,Dial(PJSIP/%s,25)\n" % (n, n, n))
        if e["voicemail"]:
            ext.append(" same => n,GotoIf($[\"${DIALSTATUS}\" = \"BUSY\"]?busy)\n"
                       " same => n,VoiceMail(%s@default,u)\n same => n,Hangup()\n"
                       " same => n(busy),VoiceMail(%s@default,b)\n same => n,Hangup()\n" % (n, n))
        else:
            ext.append(" same => n,Hangup()\n")
    ext.append("exten => i,1,Playback(invalid)\n same => n,Hangup()\n"
               "exten => _X.,1,Playback(ss-noservice)\n same => n,Hangup()\n")
    files["extensions.conf"] = "".join(ext)
    vm = [HEADER, "[general]\nformat=wav49|gsm|wav\nserveremail=voipbuntu\nattach=no\nmaxmsg=100\n"
                  "maxsecs=180\nminsecs=2\nmaxlogins=3\nskipms=3000\n\n"
                  "[zonemessages]\neurope=Europe/Paris|'vm-received' Q 'digits/at' HM\n\n[default]\n"]
    for e in state["extensions"]:
        if e["voicemail"]:
            vm.append("%s => %s,%s,,,tz=europe|saycid=no|envelope=no\n" % (e["number"], e["pin"], e["name"]))
    files["voicemail.conf"] = "".join(vm)
    return files


def sip_servers(addresses, phone_nets):
    """Adresses IPv4 de l'appliance à saisir dans les postes : d'abord celles des réseaux des téléphones."""
    import ipaddress
    nets = []
    for item in (phone_nets or "").replace(",", " ").split():
        try:
            nets.append(ipaddress.ip_network(item, strict=False))
        except ValueError:
            continue
    inside, other = [], []
    for a in addresses:
        try:
            iface = ipaddress.ip_interface(a["address"])
        except (KeyError, ValueError):
            continue
        if iface.version != 4:
            continue
        ip = str(iface.ip)
        (inside if any(iface.ip in n for n in nets) else other).append(ip)
    return inside + [ip for ip in other if ip not in inside]


def read_phone_nets(path="/etc/voipbuntu/appliance.conf"):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            for line in handle:
                m = re.match(r'^\s*PHONE_NETS\s*=\s*"?([^"\n]*)"?\s*$', line)
                if m:
                    return m.group(1)
    except OSError:
        pass
    return ""


def parse_contacts(text):
    """Analyse « pjsip show contacts » : {numéro: {"status", "rtt", "uri"}}."""
    out = {}
    for line in text.splitlines():
        m = re.match(r"^\s*Contact:\s+(\S+?)/(\S+)\s+\S+\s+(Avail|NonQual|Unavail|Unknown|Created|Removed)\s*([0-9.]+|nan)?", line)
        if m and NUMBER_RE.match(m.group(1)):
            uri = m.group(2)
            host = re.sub(r"^sips?:[^@]*@", "", uri).split(";")[0]
            out[m.group(1)] = {"status": m.group(3), "rtt": m.group(4) if m.group(4) not in (None, "nan") else None,
                               "address": host[:64]}
    return out


def parse_cdr(text, limit=100):
    """Analyse Master.csv de cdr_csv : les derniers appels, du plus récent au plus ancien.

    Seuls des champs contrôlés sortent : numéros (chiffres, * et #), dates, durées, issue.
    """
    import csv
    import io
    out = []
    for row in csv.reader(io.StringIO(text)):
        if len(row) < len(CDR_FIELDS):
            continue
        rec = dict(zip(CDR_FIELDS, row))
        if rec["dcontext"] != "voipbuntu-internes":
            continue
        src, dst = rec["src"], rec["dst"]
        if not re.match(r"^[0-9*#]{1,16}$", src) or not re.match(r"^[0-9*#a-z]{1,16}$", dst):
            continue
        if not re.match(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$", rec["start"]):
            continue
        try:
            duration, billsec = int(rec["duration"]), int(rec["billsec"])
        except ValueError:
            continue
        disposition = rec["disposition"] if rec["disposition"] in DISPOSITIONS else "FAILED"
        name = re.match(r'^"([^"]{0,40})"', rec["clid"])
        out.append({"start": rec["start"], "src": src, "src_name": name.group(1) if name else "",
                    "dst": dst, "duration": duration, "billsec": billsec, "disposition": disposition,
                    "voicemail": rec["lastapp"] == "VoiceMail"})
    out.reverse()
    return out[:limit]


def parse_channels(text):
    """Nombre d'appels en cours d'après « core show channels count »."""
    m = re.search(r"^(\d+) active calls?", text, re.M)
    return int(m.group(1)) if m else 0
