"""Sauvegardes de la configuration de VOIPbuntu.

Une sauvegarde est un fichier JSON « voipbuntu-backup » : configuration
téléphonique (pbx.json, mots de passe SIP compris) et noms des réseaux des
téléphones. Les sauvegardes automatiques sont écrites par voipbuntu-backup
(root, minuteur systemd) dans /var/lib/voipbuntu/backups, lisibles par la
seule console ; les réglages sont dans /var/lib/voipbuntu/backup.json.
"""

import json
import os
import re
import time

from . import networks, pbx

FORMAT = "voipbuntu-backup"
DEFAULT_DIR = "/var/lib/voipbuntu/backups"
DEFAULT_SETTINGS = "/var/lib/voipbuntu/backup.json"
NAME_RE = re.compile(r"^voipbuntu-sauvegarde-(\d{8})-(\d{4})(?:-auto)?\.json$")
MAX_FILE = 4 * 1024 * 1024


class BackupError(ValueError):
    pass


def payload(state, nets, version, created=None):
    return {"format": FORMAT, "format_version": 1, "version": version,
            "created": int(created if created is not None else time.time()), "pbx": state, "networks": nets}


def read_payload(data):
    """Valide une sauvegarde ; renvoie (état pbx, réseaux ou None pour les sauvegardes 0.2 sans réseaux)."""
    if not isinstance(data, dict) or data.get("format") != FORMAT or data.get("format_version") != 1:
        raise BackupError("Ce fichier n'est pas une sauvegarde VOIPbuntu.")
    try:
        state = pbx.validate(data.get("pbx"))
    except pbx.PbxError:
        raise BackupError("Sauvegarde invalide : configuration téléphonique incohérente.") from None
    nets = None
    if data.get("networks") is not None:
        try:
            nets = networks.validate(data["networks"])
        except networks.NetworkError:
            raise BackupError("Sauvegarde invalide : réseaux des téléphones incohérents.") from None
    return state, nets


def default_settings():
    return {"enabled": True, "hour": 2, "keep": 14, "email": ""}


def validate_settings(data):
    if not isinstance(data, dict):
        raise BackupError("Réglages de sauvegarde invalides.")
    s = default_settings()
    s["enabled"] = bool(data.get("enabled", True))
    try:
        s["hour"], s["keep"] = int(data.get("hour", 2)), int(data.get("keep", 14))
    except (TypeError, ValueError):
        raise BackupError("Réglages de sauvegarde invalides.") from None
    if not 0 <= s["hour"] <= 23:
        raise BackupError("Heure de sauvegarde invalide (0 à 23).")
    if not 1 <= s["keep"] <= 90:
        raise BackupError("Nombre de sauvegardes conservées entre 1 et 90.")
    email = str(data.get("email") or "").strip()
    if email and (len(email) > 254 or not pbx.EMAIL_RE.match(email)):
        raise BackupError("Adresse e-mail invalide.")
    s["email"] = email
    return s


def load_settings(path=DEFAULT_SETTINGS):
    try:
        with open(path, encoding="utf-8") as h:
            return validate_settings(json.load(h))
    except FileNotFoundError:
        return default_settings()
    except (OSError, ValueError):
        return default_settings()


def save_settings(settings, path=DEFAULT_SETTINGS):
    settings = validate_settings(settings)
    tmp = path + ".tmp"
    old = os.umask(0o077)
    try:
        with open(tmp, "w", encoding="utf-8") as h:
            json.dump(settings, h, indent=1, sort_keys=True)
        os.replace(tmp, path)
    finally:
        os.umask(old)
    return settings


def listing(directory=DEFAULT_DIR):
    """Sauvegardes présentes, de la plus récente à la plus ancienne."""
    out = []
    try:
        names = os.listdir(directory)
    except OSError:
        return out
    for name in names:
        m = NAME_RE.match(name)
        if not m:
            continue
        try:
            st = os.stat(os.path.join(directory, name))
        except OSError:
            continue
        try:  # date du nom (heure locale de l'appliance), plus sûre que la date de modification
            created = int(time.mktime(time.strptime(m.group(1) + m.group(2), "%Y%m%d%H%M")))
        except ValueError:
            created = int(st.st_mtime)
        out.append({"name": name, "size": st.st_size, "created": created, "auto": name.endswith("-auto.json")})
    out.sort(key=lambda b: (b["created"], b["name"]), reverse=True)
    return out


def path_of(name, directory=DEFAULT_DIR):
    """Chemin d'une sauvegarde à partir de son nom (jamais de chemin fourni par l'utilisateur)."""
    if not isinstance(name, str) or not NAME_RE.match(name):
        raise BackupError("Sauvegarde introuvable.")
    path = os.path.join(directory, name)
    if not os.path.isfile(path):
        raise BackupError("Sauvegarde introuvable.")
    return path


def read_file(name, directory=DEFAULT_DIR):
    path = path_of(name, directory)
    if os.path.getsize(path) > MAX_FILE:
        raise BackupError("Sauvegarde trop volumineuse.")
    with open(path, encoding="utf-8") as h:
        try:
            return json.load(h)
        except ValueError:
            raise BackupError("Ce fichier n'est pas une sauvegarde VOIPbuntu.") from None


def write(data, directory=DEFAULT_DIR, keep=14, now=None, owner=None):
    """Écrit une sauvegarde automatique puis ne garde que les keep plus récentes ; renvoie son chemin."""
    os.makedirs(directory, mode=0o700, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M", time.localtime(now if now is not None else time.time()))
    name = "voipbuntu-sauvegarde-%s-auto.json" % stamp
    path = os.path.join(directory, name)
    tmp = path + ".tmp"
    old = os.umask(0o077)
    try:
        with open(tmp, "w", encoding="utf-8") as h:
            json.dump(data, h, ensure_ascii=False, indent=1)
        if owner:
            os.chown(tmp, owner[0], owner[1])
        os.replace(tmp, path)
    finally:
        os.umask(old)
    autos = [b for b in listing(directory) if b["auto"]]
    for b in autos[keep:]:
        try:
            os.unlink(os.path.join(directory, b["name"]))
        except OSError:
            pass
    return path
