"""Modèle de la téléphonie VOIPbuntu et génération de la configuration Asterisk.

La console (sans privilège) tient l'état voulu dans /var/lib/voipbuntu/pbx.json ;
voipbuntu-pbx (root, via la file d'attente) le valide de nouveau, écrit les
fichiers d'Asterisk et recharge le service. Aucune valeur n'est recopiée dans
la configuration d'Asterisk sans être passée par validate().
"""

import json
import os
import re
import secrets
import string

from . import directory

DEFAULT_STATE = "/var/lib/voipbuntu/pbx.json"
MAX_EXTENSIONS = 200
NUMBER_RE = re.compile(r"^[1-9][0-9]{1,5}$")
SECRET_RE = re.compile(r"^[A-Za-z0-9]{16,64}$")
PIN_RE = re.compile(r"^[0-9]{4,8}$")
NAME_RE = re.compile(r"^[^\x00-\x1f\x7f\"<>;\[\]\\=,|]{1,40}$")
RESERVED = {"97", "43"}  # préfixes des codes de service *97 et *43 (sans l'étoile, jamais en conflit)
LANGUAGES = ("fr", "en")
# Identifiant SIP d'un poste (nom d'utilisateur saisi dans le téléphone) : par défaut son numéro
SIP_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,31}$")
RESERVED_IDS = {"global", "transport-udp", "transport-tcp", "operateur", "operateur-auth", "anonymous"}
# Numéros d'urgence et d'aide joignables par la ligne de l'opérateur : jamais des postes
EMERGENCY = ("15", "17", "18", "112", "114", "115", "119", "191", "196", "197", "116000", "116006", "116111", "116117")
HOST_RE = re.compile(r"^(?=.{1,253}$)[A-Za-z0-9](?:[A-Za-z0-9-]{0,62}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,62}[A-Za-z0-9])?)*$")
SIP_USER_RE = re.compile(r"^[A-Za-z0-9._+-]{1,64}$")
TRUNK_SECRET_RE = re.compile(r"^[!-~]{1,128}$")
TRUNK_SECRET_FORBIDDEN = set(";\\\"[]#")
PHONE_RE = re.compile(r"^\+?[0-9]{2,20}$")
TIME_RE = re.compile(r"^([01][0-9]|2[0-3]):[0-5][0-9]$")
DAYS = ("mon", "tue", "wed", "thu", "fri", "sat", "sun")
MAX_GROUPS = 20
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9](?:[A-Za-z0-9-]{0,62}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,62}[A-Za-z0-9])?)+$")
MAIL_SECURITY = ("starttls", "tls", "none")
MSMTP = "/usr/bin/msmtp"
FORWARD_MODES = ("off", "always", "noanswer")
NATIONAL_RE = re.compile(r"^0[1-9][0-9]{8}$")
INTERNATIONAL_RE = re.compile(r"^00[1-9][0-9]{3,16}$")
# Accueil vocal : annonces envoyées depuis la console, converties par voipbuntu-sounds (8 kHz mono)
SOUNDS = ("accueil", "menu", "fermeture", "attente")
SOUNDS = SOUNDS + ("file", "enregistrement")  # files d'attente : annonce d'attente, information sur l'enregistrement
SOUNDS_DIR = "/var/lib/asterisk/sounds/voipbuntu"
DEFAULT_MOH = "/usr/share/asterisk/moh"
MENU_DIGITS = ("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
# Numéros abrégés : *1 suivi de deux chiffres, vers un numéro extérieur par la ligne de l'opérateur
SPEED_PREFIX = "*1"
SPEED_CODE_RE = re.compile(r"^[0-9]{2}$")
MAX_SPEED_DIALS = 100
# Files d'attente (app_queue) et enregistrement des appels (MixMonitor)
MAX_QUEUES = 10
QUEUE_STRATEGIES = ("ringall", "rrmemory")
MONITOR_DIR = "/var/spool/asterisk/monitor"
RECORDING_RE = re.compile(r"^[0-9]{8}-[0-9]{6}-[0-9]{0,24}-[0-9]{2,6}-[0-9]{9,12}\.[0-9]{1,9}\.wav$")
# Numéros directs (SDA), fermetures exceptionnelles et codes de service
MAX_DIDS = 50
MAX_PERIODS = 30
DATE_RE = re.compile(r"^(19|20)[0-9]{2}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$")
# Jours fériés français : (clé, libellé, coché par défaut). Pâques et Pentecôte tombent un dimanche.
HOLIDAYS = (("jour-an", "Jour de l'an", True), ("vendredi-saint", "Vendredi saint (Alsace-Moselle)", False),
            ("paques", "Pâques", True), ("lundi-paques", "Lundi de Pâques", True),
            ("fete-travail", "Fête du travail", True), ("victoire-1945", "Victoire 1945", True),
            ("ascension", "Ascension", True), ("pentecote", "Pentecôte", True),
            ("lundi-pentecote", "Lundi de Pentecôte", True), ("fete-nationale", "Fête nationale", True),
            ("assomption", "Assomption", True), ("toussaint", "Toussaint", True),
            ("armistice", "Armistice 1918", True), ("noel", "Noël", True),
            ("saint-etienne", "Saint-Étienne (Alsace-Moselle)", False))
HOLIDAY_YEARS = 6  # année en cours et les cinq suivantes (la configuration est réécrite à chaque application)
# Codes de service : *8 interception du groupe, **<poste> interception d'un poste, *70 parcage
# (places 71 à 79), *76 ne pas déranger ; pendant un appel, ## transfert aveugle et *2 accompagné.
PICKUP_CODE, DIRECT_PICKUP, PARK_CODE, DND_CODE = "*8", "**", "*70", "*76"
BLIND_XFER, ATTENDED_XFER = "##", "*2"
PARK_SLOTS = tuple(str(n) for n in range(71, 80))
# Types de poste : téléphone SIP (filaire), combiné DECT (compte porté par une base), logiciel (softphone)
KINDS = ("sip", "dect", "softphone")
MAX_DECT_BASES = 10
BASE_ID_RE = re.compile(r"^b[0-9]{1,3}$")
BASE_HANDSETS = 30  # comptes SIP qu'une base DECT peut présenter depuis une même adresse (N670 : 20)
MAC_RE = re.compile(r"^([0-9a-f]{2}:){5}[0-9a-f]{2}$")
DND_FAMILY = "DND"  # même famille AstDB que la supervision (lot K : DB(DND/<poste>))
# Droits d'appel par poste (lot N) : tout ce que la ligne permet, France (fixes et mobiles), internes seulement.
# Les numéros d'urgence restent toujours joignables.
RIGHTS = ("all", "national", "internal")
# Renvoi immédiat depuis le combiné (lot N) : *72 + numéro l'active, *73 l'annule ; AstDB CF/<poste> = destination
CF_CODE, CF_CANCEL_CODE, CF_FAMILY = "*72", "*73", "CF"
CF_HOPS = 3  # renvois enchaînés au plus (101 -> 102 -> 103 -> ...), puis le poste sonne normalement
# Salles de conférence et appel général (lot P)
MAX_CONFERENCES = 10
MAX_PAGINGS = 10
PAGING_MEMBERS = 30


class PbxError(ValueError):
    pass


def new_secret(length=24):
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def new_pin():
    return "".join(secrets.choice(string.digits) for _ in range(6))


def empty():
    return {"language": "fr", "extensions": []}


def load(path=DEFAULT_STATE):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
    except FileNotFoundError:
        return validate(empty())
    except (OSError, ValueError) as exc:
        raise PbxError("configuration téléphonique illisible : %s" % exc.__class__.__name__) from None
    return validate(data)


def save(state, path=DEFAULT_STATE):
    state = validate(state)
    tmp = path + ".tmp"
    old = os.umask(0o077)
    try:
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(state, handle, indent=1, sort_keys=True)
        os.replace(tmp, path)
    finally:
        os.umask(old)
    return state


def validate(data):
    if not isinstance(data, dict):
        raise PbxError("format invalide")
    language = data.get("language", "fr")
    if language not in LANGUAGES:
        raise PbxError("langue invalide")
    exts = data.get("extensions", [])
    if not isinstance(exts, list) or len(exts) > MAX_EXTENSIONS:
        raise PbxError("liste de postes invalide")
    bases = validate_dect_bases(data.get("dect_bases"))
    base_ids = {b["id"] for b in bases}
    clean, seen, users = [], set(), set()
    for ext in exts:
        if not isinstance(ext, dict):
            raise PbxError("poste invalide")
        number, name = str(ext.get("number", "")), str(ext.get("name", "")).strip()
        sip_user = str(ext.get("sip_user") or number)
        secret, pin = str(ext.get("secret", "")), str(ext.get("pin", ""))
        if not NUMBER_RE.match(number):
            raise PbxError("numéro invalide : %s" % number[:8])
        if number in seen:
            raise PbxError("numéro en double : %s" % number)
        if not NAME_RE.match(name):
            raise PbxError("nom invalide pour le poste %s" % number)
        if not SECRET_RE.match(secret):
            raise PbxError("mot de passe SIP invalide pour le poste %s" % number)
        if not PIN_RE.match(pin):
            raise PbxError("code de messagerie invalide pour le poste %s" % number)
        if not SIP_ID_RE.match(sip_user) or sip_user.lower() in RESERVED_IDS:
            raise PbxError("identifiant SIP invalide pour le poste %s" % number)
        if sip_user.lower() in users:
            raise PbxError("identifiant SIP en double : %s" % sip_user)
        seen.add(number)
        users.add(sip_user.lower())
        email = str(ext.get("email") or "").strip()
        if email and (len(email) > 254 or not EMAIL_RE.match(email)):
            raise PbxError("adresse e-mail invalide pour le poste %s" % number)
        kind = str(ext.get("kind") or "sip")
        if kind not in KINDS:
            raise PbxError("type de poste invalide pour le poste %s" % number)
        base = str(ext.get("base") or "") if kind == "dect" else ""
        if base and base not in base_ids:
            raise PbxError("base DECT inconnue pour le poste %s" % number)
        clean.append({"number": number, "name": name, "sip_user": sip_user, "secret": secret, "pin": pin,
                      "kind": kind, "base": base,
                      "voicemail": bool(ext.get("voicemail", True)), "forward": ext.get("forward"), "email": email,
                      "record": bool(ext.get("record", False)),
                      "caller_id": str(ext.get("caller_id") or "").strip(),
                      "rights": validate_rights(ext.get("rights"), number)})
    clean.sort(key=lambda e: (len(e["number"]), e["number"]))
    trunk = validate_trunk(data.get("trunk"))
    if trunk["enabled"]:
        clash = sorted(seen & set(EMERGENCY))
        if clash:
            raise PbxError("le poste %s porte un numéro d'urgence : renumérotez-le avant d'activer la ligne" % clash[0])
    by_number = {e["number"]: e for e in clean}
    reception = validate_reception(data.get("reception"), by_number)
    groups = validate_groups(data.get("groups"), by_number)
    group_numbers = {g["number"] for g in groups}
    for e in clean:
        e["forward"] = validate_forward(e["forward"], e["number"], by_number, group_numbers, trunk)
    check_forward_loops(clean)
    mail = validate_mail(data.get("mail"))
    queues = validate_queues(data.get("queues"), by_number, group_numbers)
    queue_numbers = {q["number"] for q in queues}
    conferences = validate_conferences(data.get("conferences"), seen | group_numbers | queue_numbers)
    conf_numbers = {c["number"] for c in conferences}
    pagings = validate_pagings(data.get("pagings"), by_number, seen | group_numbers | queue_numbers | conf_numbers)
    paging_numbers = {g["number"] for g in pagings}
    # Une salle de conférence peut servir de destination à l'accueil vocal et aux numéros directs
    ivr = validate_ivr(data.get("ivr"), by_number, group_numbers | queue_numbers | conf_numbers)
    try:
        book = directory.validate(data.get("directory"))
    except directory.DirectoryError as exc:
        raise PbxError(str(exc)) from None
    speed = validate_speed_dials(data.get("speed_dials"))
    dids = validate_dids(data.get("dids"), by_number, group_numbers, queue_numbers | conf_numbers)
    check_caller_ids(clean, dids)
    services = validate_services(data.get("services"), seen | group_numbers | queue_numbers | conf_numbers | paging_numbers)
    return {"language": language, "extensions": clean, "trunk": trunk, "reception": reception, "groups": groups,
            "mail": mail, "ivr": ivr, "directory": book, "speed_dials": speed, "queues": queues,
            "recording": validate_recording(data.get("recording")),
            "dids": dids, "closures": validate_closures(data.get("closures")), "services": services,
            "dect_bases": bases, "conferences": conferences, "pagings": pagings}


def validate_conferences(data, taken):
    """Salles de conférence : numéro court, nom, code facultatif, nombre de participants."""
    if data is None:
        return []
    if not isinstance(data, list) or len(data) > MAX_CONFERENCES:
        raise PbxError("conférences : liste invalide (%d salles au plus)" % MAX_CONFERENCES)
    out, seen = [], set()
    for c in data:
        if not isinstance(c, dict):
            raise PbxError("conférences : salle invalide")
        number, name = str(c.get("number", "")), str(c.get("name", "")).strip()
        if not NUMBER_RE.match(number) or number in EMERGENCY or number in RESERVED:
            raise PbxError("conférences : numéro invalide %s" % number[:8])
        if number in taken or number in seen:
            raise PbxError("conférences : le numéro %s est déjà utilisé" % number)
        if not NAME_RE.match(name):
            raise PbxError("conférences : nom invalide pour %s" % number)
        pin = str(c.get("pin") or "")
        if pin and not PIN_RE.match(pin):
            raise PbxError("conférences : code invalide pour %s (4 à 8 chiffres)" % number)
        try:
            size = int(c.get("max_members", 10))
        except (TypeError, ValueError):
            raise PbxError("conférences : nombre de participants invalide pour %s" % number) from None
        if not 2 <= size <= 30:
            raise PbxError("conférences : de 2 à 30 participants (salle %s)" % number)
        seen.add(number)
        out.append({"number": number, "name": name, "pin": pin, "max_members": size,
                    "moh": bool(c.get("moh", True))})
    out.sort(key=lambda c: (len(c["number"]), c["number"]))
    return out


def validate_pagings(data, exts, taken):
    """Appel général (interphone) : un numéro qui fait parler sur le haut-parleur de plusieurs postes."""
    if data is None:
        return []
    if not isinstance(data, list) or len(data) > MAX_PAGINGS:
        raise PbxError("appel général : liste invalide (%d au plus)" % MAX_PAGINGS)
    out, seen = [], set()
    for g in data:
        if not isinstance(g, dict):
            raise PbxError("appel général : entrée invalide")
        number, name = str(g.get("number", "")), str(g.get("name", "")).strip()
        if not NUMBER_RE.match(number) or number in EMERGENCY or number in RESERVED:
            raise PbxError("appel général : numéro invalide %s" % number[:8])
        if number in taken or number in seen:
            raise PbxError("appel général : le numéro %s est déjà utilisé" % number)
        if not NAME_RE.match(name):
            raise PbxError("appel général : nom invalide pour %s" % number)
        members = g.get("members", [])
        if not isinstance(members, list) or len(members) > PAGING_MEMBERS:
            raise PbxError("appel général : liste de postes invalide pour %s" % number)
        clean = []
        for m in members:
            m = str(m)
            if m not in exts:
                raise PbxError("appel général : poste %s inconnu" % m[:8])
            if m not in clean:
                clean.append(m)
        if not clean:
            raise PbxError("appel général : %s n'a aucun poste" % number)
        seen.add(number)
        out.append({"number": number, "name": name, "members": clean, "duplex": bool(g.get("duplex", False))})
    out.sort(key=lambda g: (len(g["number"]), g["number"]))
    return out


def validate_rights(value, number):
    """Droits d'appel d'un poste ; absent (ancienne configuration) : tout ce que la ligne permet."""
    value = str(value or "all")
    if value not in RIGHTS:
        raise PbxError("droits d'appel invalides pour le poste %s" % number)
    return value


def forward_allowed(state, number, target):
    """Renvoi du combiné (*72) admis : destination interne existante, ou extérieure si la ligne et les droits le permettent."""
    exts = {e["number"]: e for e in state["extensions"]}
    if number not in exts or not target or target == number:
        return False
    internal = {e["number"] for e in state["extensions"]} | {g["number"] for g in state["groups"]} | \
        {q["number"] for q in state["queues"]}
    if target in internal:
        return True
    trunk, rights = state["trunk"], exts[number]["rights"]
    if not trunk["enabled"] or target in EMERGENCY:
        return False
    if NATIONAL_RE.match(target):
        return rights != "internal"
    if INTERNATIONAL_RE.match(target):
        return rights == "all" and trunk["international"]
    return False


def parse_forwards(text):
    """Renvois du combiné d'après « database show CF » : {poste: destination}."""
    out = {}
    for line in text.splitlines():
        m = re.match(r"^/%s/([1-9][0-9]{1,5})\s*:\s*([0-9]{2,20})\s*$" % CF_FAMILY, line)
        if m:
            out[m.group(1)] = m.group(2)
    return out


def validate_dect_bases(data):
    """Bases DECT (Gigaset N670...) : une adresse, plusieurs comptes SIP (un par combiné)."""
    if data is None:
        return []
    if not isinstance(data, list) or len(data) > MAX_DECT_BASES:
        raise PbxError("bases DECT : liste invalide")
    out, ids, addresses = [], set(), set()
    for b in data:
        if not isinstance(b, dict):
            raise PbxError("bases DECT : base invalide")
        bid, name = str(b.get("id", "")), str(b.get("name", "")).strip()
        model = str(b.get("model") or "").strip()
        address = str(b.get("address") or "").strip()
        mac = str(b.get("mac") or "").strip().lower()
        if not BASE_ID_RE.match(bid) or bid in ids:
            raise PbxError("bases DECT : identifiant invalide")
        if not NAME_RE.match(name):
            raise PbxError("bases DECT : nom invalide")
        if model and not NAME_RE.match(model):
            raise PbxError("bases DECT : modèle invalide")
        if address:
            if not is_ip(address):
                raise PbxError("bases DECT : adresse IP invalide")
            if address in addresses:
                raise PbxError("bases DECT : adresse en double")
            addresses.add(address)
        if mac and not MAC_RE.match(mac):
            raise PbxError("bases DECT : adresse MAC invalide")
        ids.add(bid)
        out.append({"id": bid, "name": name, "model": model, "address": address, "mac": mac})
    return out


def new_base_id(state):
    used = {b["id"] for b in state.get("dect_bases", [])}
    return next("b%d" % i for i in range(1, 1000) if "b%d" % i not in used)


def host_of(address):
    """Adresse IP seule d'une adresse « ip », « ip:port » ou « [ipv6]:port »."""
    host = (address or "").strip()
    if host.startswith("["):
        host = host[1:].split("]")[0]
    elif host.count(":") == 1:
        host = host.split(":")[0]
    return host


def base_at(state, address):
    """Base DECT déclarée à cette adresse (« ip » ou « ip:port »), ou None."""
    host = host_of(address)
    return next((b for b in state.get("dect_bases", []) if b["address"] and b["address"] == host), None)


# ------------------------------------------- numéros directs, fermetures et codes de service
def validate_did_target(target, exts, groups, queues, did):
    """Destination d'un numéro direct : poste, groupe, file, « accueil » (accueil vocal) ou « vm:poste »."""
    target = str(target or "accueil").strip()
    if target == "accueil" or target in exts or target in groups or target in queues:
        return target
    if target.startswith("vm:") and target[3:] in exts and exts[target[3:]]["voicemail"]:
        return target
    raise PbxError("numéros directs : destination inconnue pour %s" % did)


def validate_dids(data, exts, groups, queues):
    """Numéros directs (SDA) reçus sur la ligne : chacun vers sa destination. Format national ou E.164."""
    if data is None:
        return []
    if not isinstance(data, list) or len(data) > MAX_DIDS:
        raise PbxError("numéros directs : liste invalide (%d au plus)" % MAX_DIDS)
    out, seen = [], set()
    for d in data:
        if not isinstance(d, dict):
            raise PbxError("numéros directs : entrée invalide")
        number = directory.normalize_number(d.get("number"))
        if not number or not is_external(number):
            raise PbxError("numéros directs : numéro invalide %s" % str(d.get("number", ""))[:24])
        if number in seen:
            raise PbxError("numéros directs : %s en double" % number)
        seen.add(number)
        out.append({"number": number, "name": directory.clean_text(d.get("name"), 40),
                    "target": validate_did_target(d.get("target"), exts, groups, queues, number),
                    "hours": bool(d.get("hours", False))})
    out.sort(key=lambda d: d["number"])
    return out


def check_caller_ids(exts, dids):
    """Numéro présenté par un poste : un des numéros directs de la ligne (vide : celui de la ligne)."""
    known = {d["number"] for d in dids}
    for e in exts:
        if e["caller_id"]:
            e["caller_id"] = directory.normalize_number(e["caller_id"]) or e["caller_id"]
        if e["caller_id"] and e["caller_id"] not in known:
            raise PbxError("numéro présenté : %s n'est pas un numéro direct de la ligne (poste %s)"
                           % (e["caller_id"], e["number"]))


def default_closures():
    return {"holidays_enabled": False, "holidays": [k for k, _, on in HOLIDAYS if on], "periods": []}


def validate_closures(data):
    """Fermetures exceptionnelles : jours fériés cochés un par un et périodes saisies (congés)."""
    import datetime
    if data is None:
        return default_closures()
    if not isinstance(data, dict):
        raise PbxError("fermetures : réglages invalides")
    keys = [k for k, _, _ in HOLIDAYS]
    days = data.get("holidays", default_closures()["holidays"])
    if not isinstance(days, list) or any(str(k) not in keys for k in days):
        raise PbxError("fermetures : jour férié inconnu")
    periods = data.get("periods", [])
    if not isinstance(periods, list) or len(periods) > MAX_PERIODS:
        raise PbxError("fermetures : %d périodes au plus" % MAX_PERIODS)
    out = []
    for p in periods:
        if not isinstance(p, dict):
            raise PbxError("fermetures : période invalide")
        start, end = str(p.get("start", "")), str(p.get("end", "") or p.get("start", ""))
        try:
            if not DATE_RE.match(start) or not DATE_RE.match(end):
                raise ValueError
            first, last = datetime.date.fromisoformat(start), datetime.date.fromisoformat(end)
        except ValueError:
            raise PbxError("fermetures : dates invalides (AAAA-MM-JJ)") from None
        if last < first:
            raise PbxError("fermetures : la fin d'une période est avant son début")
        if (last - first).days > 366:
            raise PbxError("fermetures : une période dure un an au plus")
        out.append({"name": directory.clean_text(p.get("name"), 40), "start": start, "end": end})
    out.sort(key=lambda p: (p["start"], p["end"]))
    return {"holidays_enabled": bool(data.get("holidays_enabled", False)),
            "holidays": [k for k in keys if k in days], "periods": out}


def easter(year):
    """Dimanche de Pâques (calendrier grégorien, algorithme de Meeus/Jones/Butcher)."""
    import datetime
    a, b, c = year % 19, year // 100, year % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7  # noqa: E741
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = (h + l - 7 * m + 114) % 31 + 1
    return datetime.date(year, month, day)


def holidays(year):
    """Jours fériés français d'une année : [(clé, date)], dans l'ordre du calendrier."""
    import datetime
    p = easter(year)
    day = datetime.timedelta(days=1)
    dates = {"jour-an": datetime.date(year, 1, 1), "vendredi-saint": p - 2 * day, "paques": p,
             "lundi-paques": p + day, "fete-travail": datetime.date(year, 5, 1),
             "victoire-1945": datetime.date(year, 5, 8), "ascension": p + 39 * day, "pentecote": p + 49 * day,
             "lundi-pentecote": p + 50 * day, "fete-nationale": datetime.date(year, 7, 14),
             "assomption": datetime.date(year, 8, 15), "toussaint": datetime.date(year, 11, 1),
             "armistice": datetime.date(year, 11, 11), "noel": datetime.date(year, 12, 25),
             "saint-etienne": datetime.date(year, 12, 26)}
    return sorted(((k, dates[k]) for k, _, _ in HOLIDAYS), key=lambda x: x[1])


def closure_ranges(closures, today=None):
    """Plages fermées [(AAAAMMJJ début, AAAAMMJJ fin)] : jours fériés cochés sur six ans, périodes non passées."""
    import datetime
    today = today or datetime.date.today()
    out = []
    if closures["holidays_enabled"]:
        for year in range(today.year, today.year + HOLIDAY_YEARS):
            for key, date in holidays(year):
                if key in closures["holidays"] and date >= today:
                    out.append((date.strftime("%Y%m%d"), date.strftime("%Y%m%d")))
    for p in closures["periods"]:
        if p["end"] >= today.isoformat():
            out.append((p["start"].replace("-", ""), p["end"].replace("-", "")))
    return sorted(set(out))


def validate_services(data, numbers):
    """Codes de service. Le parcage occupe les numéros 71 à 79 : coupé d'office s'ils sont déjà pris."""
    if data is None:
        data = {}
    if not isinstance(data, dict):
        raise PbxError("codes de service : réglages invalides")
    clash = sorted(set(PARK_SLOTS) & set(numbers))
    parking = data.get("parking")
    if parking is None:
        parking = not clash
    if parking and clash:
        raise PbxError("parcage : le numéro %s est réservé aux places de parcage (71 à 79)" % clash[0])
    return {"parking": bool(parking)}


def did_variants(number):
    """Formes sous lesquelles l'opérateur peut transmettre un numéro direct (national, 33…, +33…, 0033…)."""
    if NATIONAL_RE.match(number):
        rest = number[1:]
        return [number, "33" + rest, "+33" + rest, "0033" + rest]
    return [number, "+" + number[2:], number[2:]]  # international : 00…, +…, sans préfixe


def present_as(number, trunk_cid):
    """Numéro direct présenté en sortie, dans la même forme que le numéro présenté de la ligne."""
    if NATIONAL_RE.match(number):
        if trunk_cid.startswith("+33"):
            return "+33" + number[1:]
        if trunk_cid.startswith("0033"):
            return "0033" + number[1:]
        if trunk_cid.startswith("33") and len(trunk_cid) == 11:
            return "33" + number[1:]
        return number
    return ("+" + number[2:]) if trunk_cid.startswith("+") else number


def parse_dnd(text):
    """Postes en « ne pas déranger » d'après « database show DND »."""
    out = set()
    for line in text.splitlines():
        m = re.match(r"^/%s/([1-9][0-9]{1,5})\s*:\s*1\s*$" % DND_FAMILY, line)
        if m:
            out.add(m.group(1))
    return sorted(out, key=lambda n: (len(n), n))


# ------------------------------------------------------- files d'attente et enregistrement
def default_recording():
    return {"keep_days": 30}


def validate_recording(data):
    """Enregistrement des appels : durée de conservation des fichiers (purge par voipbuntu-recordings.timer)."""
    if data is None:
        return default_recording()
    if not isinstance(data, dict):
        raise PbxError("enregistrement : réglages invalides")
    try:
        keep = int(data.get("keep_days", 30))
    except (TypeError, ValueError):
        raise PbxError("enregistrement : durée de conservation invalide") from None
    if not 1 <= keep <= 365:
        raise PbxError("enregistrement : durée de conservation entre 1 et 365 jours")
    return {"keep_days": keep}


def validate_queue_target(target, exts, groups, number):
    """Débordement d'une file : poste, groupe, « vm:poste » ou rien (raccrocher)."""
    target = str(target or "").strip()
    if not target:
        return ""
    if target.startswith("vm:"):
        box = target[3:]
        if box not in exts or not exts[box]["voicemail"]:
            raise PbxError("files : débordement de la file %s : la messagerie doit être celle d'un poste qui en a une" % number)
        return target
    if target in exts or target in groups:
        return target
    raise PbxError("files : débordement de la file %s : destination inconnue" % number)


def validate_queues(data, exts, groups):
    """Files d'attente : l'appelant patiente (musique, annonce) jusqu'à ce qu'un poste libre réponde."""
    if data is None:
        return []
    if not isinstance(data, list) or len(data) > MAX_QUEUES:
        raise PbxError("files : liste invalide")
    out, seen = [], set()
    for q in data:
        if not isinstance(q, dict):
            raise PbxError("files : file invalide")
        number, name = str(q.get("number", "")), str(q.get("name", "")).strip()
        if not NUMBER_RE.match(number) or number in EMERGENCY:
            raise PbxError("files : numéro invalide %s" % number[:8])
        if number in exts or number in groups or number in seen:
            raise PbxError("files : le numéro %s est déjà utilisé" % number)
        if not NAME_RE.match(name):
            raise PbxError("files : nom invalide pour %s" % number)
        members = q.get("members", [])
        if not isinstance(members, list) or len(members) > 20:
            raise PbxError("files : liste de postes invalide pour %s" % number)
        clean = []
        for m in members:
            m = str(m)
            if m not in exts:
                raise PbxError("files : poste %s inconnu" % m[:8])
            if m not in clean:
                clean.append(m)
        if not clean:
            raise PbxError("files : la file %s n'a aucun poste" % number)
        strategy = str(q.get("strategy", "ringall"))
        if strategy not in QUEUE_STRATEGIES:
            raise PbxError("files : stratégie invalide pour %s" % number)
        try:
            ring, wait = int(q.get("ring_seconds", 15)), int(q.get("max_wait", 120))
        except (TypeError, ValueError):
            raise PbxError("files : durées invalides pour %s" % number) from None
        if not 5 <= ring <= 60:
            raise PbxError("files : sonnerie de chaque poste entre 5 et 60 secondes")
        if not 10 <= wait <= 1800:
            raise PbxError("files : attente maximale entre 10 secondes et 30 minutes")
        seen.add(number)
        out.append({"number": number, "name": name, "members": clean, "strategy": strategy, "ring_seconds": ring,
                    "max_wait": wait, "overflow": validate_queue_target(q.get("overflow"), exts, groups, number),
                    "announce": bool(q.get("announce", True)), "record": bool(q.get("record", False))})
    out.sort(key=lambda q: (len(q["number"]), q["number"]))
    return out


def validate_speed_dials(data):
    """Numéros abrégés : *1XX compose un numéro extérieur (national ou international) par la ligne."""
    if data is None:
        return []
    if not isinstance(data, list) or len(data) > MAX_SPEED_DIALS:
        raise PbxError("numéros abrégés : liste invalide")
    out, seen = [], set()
    for d in data:
        if not isinstance(d, dict):
            raise PbxError("numéros abrégés : entrée invalide")
        code = str(d.get("code", "")).strip()
        if code.startswith(SPEED_PREFIX) and len(code) == 4:
            code = code[2:]
        if not SPEED_CODE_RE.match(code):
            raise PbxError("numéros abrégés : code invalide (deux chiffres)")
        if code in seen:
            raise PbxError("numéros abrégés : code %s en double" % code)
        number = directory.normalize_number(d.get("number"))
        if not number or not is_external(number):
            raise PbxError("numéros abrégés : numéro extérieur invalide pour *1%s" % code)
        name = directory.clean_text(d.get("name"), 40)
        seen.add(code)
        out.append({"code": code, "number": number, "name": name})
    out.sort(key=lambda d: d["code"])
    return out


def default_ivr():
    return {"enabled": False, "options": [], "timeout": 5, "default": "", "hold_music": False}


def validate_ivr_target(target, exts, groups, what):
    """Destination d'une touche du menu : poste, groupe, « vm:poste » (messagerie) ou « accueil »."""
    target = str(target or "").strip()
    if target in ("", "accueil"):
        return target
    if target.startswith("vm:"):
        box = target[3:]
        if box not in exts or not exts[box]["voicemail"]:
            raise PbxError("menu vocal : %s : la messagerie doit être celle d'un poste qui en a une" % what)
        return target
    if target in exts or target in groups:
        return target
    raise PbxError("menu vocal : %s : destination inconnue" % what)


def validate_ivr(data, exts, groups):
    """Menu vocal de l'accueil : « tapez 1 pour…, 2 pour… », destination par défaut sans choix."""
    if data is None:
        return default_ivr()
    if not isinstance(data, dict):
        raise PbxError("menu vocal : réglages invalides")
    m = default_ivr()
    m["enabled"] = bool(data.get("enabled", False))
    m["hold_music"] = bool(data.get("hold_music", False))
    try:
        m["timeout"] = int(data.get("timeout", 5))
    except (TypeError, ValueError):
        raise PbxError("menu vocal : délai invalide") from None
    if not 2 <= m["timeout"] <= 30:
        raise PbxError("menu vocal : délai de choix entre 2 et 30 secondes")
    options = data.get("options", [])
    if not isinstance(options, list) or len(options) > len(MENU_DIGITS):
        raise PbxError("menu vocal : liste de choix invalide")
    seen = set()
    for o in options:
        if not isinstance(o, dict):
            raise PbxError("menu vocal : choix invalide")
        digit = str(o.get("digit", ""))
        if digit not in MENU_DIGITS:
            raise PbxError("menu vocal : touche invalide")
        if digit in seen:
            raise PbxError("menu vocal : touche %s en double" % digit)
        target = validate_ivr_target(o.get("target"), exts, groups, "touche %s" % digit)
        if not target:
            raise PbxError("menu vocal : touche %s : destination inconnue" % digit)
        seen.add(digit)
        m["options"].append({"digit": digit, "target": target})
    m["options"].sort(key=lambda o: MENU_DIGITS.index(o["digit"]))
    m["default"] = validate_ivr_target(data.get("default", ""), exts, groups, "sans choix")
    if m["enabled"] and not m["options"]:
        raise PbxError("menu vocal : ajoutez au moins une touche pour l'activer")
    return m


def default_mail():
    return {"enabled": False, "host": "", "port": 587, "security": "starttls", "username": "", "password": "",
            "from_address": ""}


def validate_mail(data):
    """Serveur d'envoi (SMTP) pour la messagerie vocale par e-mail."""
    if data is None:
        return default_mail()
    if not isinstance(data, dict):
        raise PbxError("e-mail : réglages invalides")
    m = default_mail()
    m["enabled"] = bool(data.get("enabled", False))
    for key in ("host", "username", "password", "from_address", "security"):
        value = data.get(key, m[key])
        if not isinstance(value, str):
            raise PbxError("e-mail : champ %s invalide" % key)
        m[key] = value.strip() if key != "password" else value
    try:
        m["port"] = int(data.get("port", 587))
    except (TypeError, ValueError):
        raise PbxError("e-mail : port invalide") from None
    if not 1 <= m["port"] <= 65535:
        raise PbxError("e-mail : port invalide")
    if m["security"] not in MAIL_SECURITY:
        raise PbxError("e-mail : sécurité invalide")
    if m["host"] and not HOST_RE.match(m["host"]):
        raise PbxError("e-mail : serveur invalide")
    if m["username"] and (len(m["username"]) > 128 or not re.match(r"^[!-~]+$", m["username"]) or set(m["username"]) & TRUNK_SECRET_FORBIDDEN):
        raise PbxError("e-mail : identifiant invalide")
    if m["password"] and (not TRUNK_SECRET_RE.match(m["password"]) or set(m["password"]) & TRUNK_SECRET_FORBIDDEN):
        raise PbxError("e-mail : mot de passe invalide")
    if m["from_address"] and not EMAIL_RE.match(m["from_address"]):
        raise PbxError("e-mail : adresse d'expédition invalide")
    if m["enabled"] and not (m["host"] and m["from_address"]):
        raise PbxError("e-mail : serveur et adresse d'expédition sont requis")
    if m["username"] and m["security"] == "none":
        raise PbxError("e-mail : identifiant sans chiffrement")
    if m["enabled"] and m["username"] and not m["password"]:
        raise PbxError("e-mail : mot de passe requis avec un identifiant")
    return m


def render_msmtprc(m):
    """Configuration de msmtp, lue par Asterisk pour envoyer les messages vocaux."""
    lines = ["# Généré par voipbuntu-pbx, ne pas modifier.", "defaults",
             "syslog LOG_MAIL", "timeout 30",
             "tls %s" % ("off" if m["security"] == "none" else "on"),
             "tls_starttls %s" % ("on" if m["security"] == "starttls" else "off"),
             "tls_trust_file /etc/ssl/certs/ca-certificates.crt", "",
             "account default", "host %s" % m["host"], "port %d" % m["port"], "from %s" % m["from_address"]]
    if m["username"]:
        lines += ["auth on", "user %s" % m["username"], "password %s" % m["password"]]
    else:
        lines.append("auth off")
    return "\n".join(lines) + "\n"


# Pas de « ; » dans ces textes : voicemail.conf le lit comme un début de commentaire.
MAIL_TEXT = {
    "fr": ("Messagerie VOIPbuntu",
           "Nouveau message de ${VM_CALLERID} pour le poste ${VM_MAILBOX}",
           "Bonjour ${VM_NAME},\\n\\nVous avez reçu un message vocal de ${VM_CALLERID} le ${VM_DATE}, "
           "d'une durée de ${VM_DUR}.\\nLe message est joint à cet e-mail. Il reste aussi sur la messagerie (*97).\\n\\nVOIPbuntu\\n"),
    "en": ("VOIPbuntu voicemail",
           "New message from ${VM_CALLERID} for extension ${VM_MAILBOX}",
           "Hello ${VM_NAME},\\n\\nYou received a voice message from ${VM_CALLERID} on ${VM_DATE}, "
           "lasting ${VM_DUR}.\\nThe message is attached. It also stays in your voicemail (*97).\\n\\nVOIPbuntu\\n"),
}


def validate_groups(data, exts):
    """Groupes d'appel : un numéro court qui fait sonner plusieurs postes ensemble."""
    if data is None:
        return []
    if not isinstance(data, list) or len(data) > MAX_GROUPS:
        raise PbxError("groupes : liste invalide")
    out, seen = [], set()
    for g in data:
        if not isinstance(g, dict):
            raise PbxError("groupes : groupe invalide")
        number, name = str(g.get("number", "")), str(g.get("name", "")).strip()
        if not NUMBER_RE.match(number) or number in EMERGENCY:
            raise PbxError("groupes : numéro invalide %s" % number[:8])
        if number in exts or number in seen:
            raise PbxError("groupes : le numéro %s est déjà utilisé" % number)
        if not NAME_RE.match(name):
            raise PbxError("groupes : nom invalide pour %s" % number)
        rec = validate_reception({"members": g.get("members", []), "ring_seconds": g.get("ring_seconds", 25),
                                  "voicemail_box": g.get("voicemail_box", "")}, exts, "groupes")
        if not rec["members"]:
            raise PbxError("groupes : le groupe %s n'a aucun poste" % number)
        seen.add(number)
        out.append({"number": number, "name": name, "members": rec["members"],
                    "ring_seconds": rec["ring_seconds"], "voicemail_box": rec["voicemail_box"]})
    out.sort(key=lambda g: (len(g["number"]), g["number"]))
    return out


def default_forward():
    return {"mode": "off", "target": "", "ring_seconds": 20}


def is_external(target):
    return bool(NATIONAL_RE.match(target) or INTERNATIONAL_RE.match(target))


def validate_forward(data, number, exts, groups, trunk):
    """Renvoi d'un poste : toujours, ou sans réponse/occupé, vers un poste, un groupe ou un numéro extérieur."""
    if data is None:
        return default_forward()
    if not isinstance(data, dict):
        raise PbxError("renvoi invalide pour le poste %s" % number)
    f = default_forward()
    f["mode"] = str(data.get("mode", "off"))
    if f["mode"] not in FORWARD_MODES:
        raise PbxError("renvoi : mode invalide pour le poste %s" % number)
    try:
        f["ring_seconds"] = int(data.get("ring_seconds", 20))
    except (TypeError, ValueError):
        raise PbxError("renvoi : durée de sonnerie invalide") from None
    if not 5 <= f["ring_seconds"] <= 120:
        raise PbxError("renvoi : durée de sonnerie entre 5 et 120 secondes")
    target = str(data.get("target", "")).strip().replace(" ", "")
    if f["mode"] == "off":
        f["target"] = target if (target in exts or target in groups or is_external(target)) else ""
        return f
    if target == number:
        raise PbxError("renvoi : le poste %s ne peut pas se renvoyer vers lui-même" % number)
    if target in exts or target in groups:
        f["target"] = target
        return f
    if target in EMERGENCY:
        raise PbxError("renvoi : destination invalide pour le poste %s" % number)
    if is_external(target):
        if not trunk["enabled"]:
            raise PbxError("renvoi : un numéro extérieur demande la ligne de l'opérateur (poste %s)" % number)
        if INTERNATIONAL_RE.match(target) and not trunk["international"]:
            raise PbxError("renvoi : international non autorisé sur la ligne (poste %s)" % number)
        f["target"] = target
        return f
    raise PbxError("renvoi : destination invalide pour le poste %s" % number)


def check_forward_loops(exts):
    """Les renvois permanents ne doivent pas former de boucle (101 -> 102 -> 101)."""
    always = {e["number"]: e["forward"]["target"] for e in exts if e["forward"]["mode"] == "always"}
    for start in always:
        seen, cur = {start}, always[start]
        while cur in always:
            if cur in seen:
                raise PbxError("renvoi : boucle de renvois permanents entre les postes %s" % " et ".join(sorted(seen)))
            seen.add(cur)
            cur = always[cur]


def rename_number(state, old, new):
    """Un poste change de numéro court : accueil, groupes et renvois suivent."""
    for rec in [state["reception"]] + state.get("groups", []):
        rec["members"] = [new if m == old else m for m in rec["members"]]
        if rec["voicemail_box"] == old:
            rec["voicemail_box"] = new
    for e in state["extensions"]:
        if e.get("forward") and e["forward"].get("target") == old:
            e["forward"]["target"] = new
    for q in state.get("queues", []):
        q["members"] = [new if m == old else m for m in q["members"]]
        q["overflow"] = {old: new, "vm:" + old: "vm:" + new}.get(q.get("overflow", ""), q.get("overflow", ""))
    for d in state.get("dids", []):  # numéros directs
        d["target"] = {old: new, "vm:" + old: "vm:" + new}.get(d.get("target"), d.get("target"))
    for g in state.get("pagings", []):  # appel général
        g["members"] = [new if m == old else m for m in g["members"]]
    ivr = state.get("ivr")
    if ivr:
        swap = {old: new, "vm:" + old: "vm:" + new}
        for o in ivr["options"]:
            o["target"] = swap.get(o["target"], o["target"])
        ivr["default"] = swap.get(ivr["default"], ivr["default"])


def drop_number(state, number):
    """Un poste ou un groupe disparaît : il est retiré de l'accueil, des groupes et des renvois."""
    for rec in [state["reception"]] + state.get("groups", []):
        rec["members"] = [m for m in rec["members"] if m != number]
        if rec["voicemail_box"] == number:
            rec["voicemail_box"] = ""
    gone = {number} | {g["number"] for g in state.get("groups", []) if not g["members"]}
    state["groups"] = [g for g in state.get("groups", []) if g["members"]]
    # Files d'attente : le poste en sort ; une file sans poste disparaît
    for q in state.get("queues", []):
        q["members"] = [m for m in q["members"] if m != number]
    gone |= {q["number"] for q in state.get("queues", []) if not q["members"]}
    state["queues"] = [q for q in state.get("queues", []) if q["members"]]
    for q in state["queues"]:
        if q.get("overflow") in gone | {"vm:" + number}:
            q["overflow"] = ""
    # Appel général : le poste en sort ; un appel général sans poste disparaît
    for g in state.get("pagings", []):
        g["members"] = [m for m in g["members"] if m != number]
    state["pagings"] = [g for g in state.get("pagings", []) if g["members"]]
    for e in state["extensions"]:
        if e.get("forward") and e["forward"].get("target") in gone:
            e["forward"] = default_forward()
    drop_ivr_targets(state, gone | {"vm:" + number})


def drop_ivr_targets(state, gone):
    """Touches du menu vocal qui menaient à une destination disparue : retirées (menu coupé s'il est vide).

    Les numéros directs qui y menaient reviennent à l'accueil.
    """
    for d in state.get("dids", []):
        if d.get("target") in gone:
            d["target"] = "accueil"
    ivr = state.get("ivr")
    if not ivr:
        return
    ivr["options"] = [o for o in ivr["options"] if o["target"] not in gone]
    if ivr["default"] in gone:
        ivr["default"] = ""
    if not ivr["options"]:
        ivr["enabled"] = False


def drop_voicemail(state, number):
    """Un poste perd sa messagerie : il n'est plus messagerie de secours."""
    for rec in [state["reception"]] + state.get("groups", []):
        if rec["voicemail_box"] == number:
            rec["voicemail_box"] = ""
    for q in state.get("queues", []):
        if q.get("overflow") == "vm:" + number:
            q["overflow"] = ""
    drop_ivr_targets(state, {"vm:" + number})


def default_trunk():
    return {"enabled": False, "host": "", "port": 5060, "username": "", "auth_username": "", "password": "",
            "register": True, "caller_id": "", "public_address": "", "international": False}


def validate_trunk(data):
    """Ligne de l'opérateur (compte SIP). Absente ou désactivée : aucun appel extérieur possible."""
    if data is None:
        return default_trunk()
    if not isinstance(data, dict):
        raise PbxError("ligne opérateur invalide")
    t = default_trunk()
    t["enabled"] = bool(data.get("enabled", False))
    t["register"] = bool(data.get("register", True))
    t["international"] = bool(data.get("international", False))
    for key in ("host", "username", "auth_username", "password", "caller_id", "public_address"):
        value = data.get(key, "")
        if not isinstance(value, str):
            raise PbxError("ligne opérateur : champ %s invalide" % key)
        t[key] = value.strip() if key != "password" else value
    try:
        t["port"] = int(data.get("port", 5060))
    except (TypeError, ValueError):
        raise PbxError("ligne opérateur : port invalide") from None
    if not 1 <= t["port"] <= 65535:
        raise PbxError("ligne opérateur : port invalide")
    if t["host"] and not HOST_RE.match(t["host"]):
        raise PbxError("ligne opérateur : serveur invalide")
    for key in ("username", "auth_username"):
        if t[key] and not SIP_USER_RE.match(t[key]):
            raise PbxError("ligne opérateur : identifiant invalide")
    if t["password"] and (not TRUNK_SECRET_RE.match(t["password"]) or set(t["password"]) & TRUNK_SECRET_FORBIDDEN):
        raise PbxError("ligne opérateur : mot de passe invalide (caractères ; \\ \" [ ] # et espaces refusés)")
    if t["caller_id"] and not PHONE_RE.match(t["caller_id"]):
        raise PbxError("ligne opérateur : numéro présenté invalide")
    if t["public_address"]:
        import ipaddress
        try:
            if ipaddress.ip_address(t["public_address"]).version != 4:
                raise ValueError
        except ValueError:
            raise PbxError("ligne opérateur : adresse publique IPv4 invalide") from None
    if t["enabled"] and not (t["host"] and t["username"] and t["password"]):
        raise PbxError("ligne opérateur : serveur, identifiant et mot de passe sont requis pour l'activer")
    return t


def default_reception():
    return {"members": [], "ring_seconds": 25, "hours": None, "voicemail_box": ""}


def validate_reception(data, exts, what="accueil"):
    """Accueil : postes qui sonnent ensemble pour un appel entrant, horaires, messagerie de secours."""
    if data is None:
        return default_reception()
    if not isinstance(data, dict):
        raise PbxError("%s invalide" % what)
    r = default_reception()
    members = data.get("members", [])
    if not isinstance(members, list) or len(members) > 20:
        raise PbxError("%s : liste de postes invalide" % what)
    for m in members:
        m = str(m)
        if m not in exts:
            raise PbxError("%s : poste %s inconnu" % (what, m[:8]))
        if m not in r["members"]:
            r["members"].append(m)
    try:
        r["ring_seconds"] = int(data.get("ring_seconds", 25))
    except (TypeError, ValueError):
        raise PbxError("%s : durée de sonnerie invalide" % what) from None
    if not 5 <= r["ring_seconds"] <= 120:
        raise PbxError("%s : durée de sonnerie entre 5 et 120 secondes" % what)
    box = str(data.get("voicemail_box") or "")
    if box and (box not in exts or not exts[box]["voicemail"]):
        raise PbxError("%s : la messagerie de secours doit être celle d'un poste qui en a une" % what)
    r["voicemail_box"] = box
    hours = data.get("hours")
    if hours is not None:
        if not isinstance(hours, dict):
            raise PbxError("%s : horaires invalides" % what)
        days = hours.get("days", [])
        start, end = str(hours.get("start", "")), str(hours.get("end", ""))
        if not isinstance(days, list) or not days or any(d not in DAYS for d in days):
            raise PbxError("%s : jours d'ouverture invalides" % what)
        if not TIME_RE.match(start) or not TIME_RE.match(end) or start >= end:
            raise PbxError("%s : horaires invalides (HH:MM, ouverture avant fermeture)" % what)
        r["hours"] = {"days": [d for d in DAYS if d in days], "start": start, "end": end}
    return r


def public(state):
    """Vue de la console : jamais le mot de passe SIP ni le code de messagerie."""
    trunk = dict(state["trunk"])
    trunk["password_set"] = bool(trunk.pop("password"))
    mail = dict(state["mail"])
    mail["password_set"] = bool(mail.pop("password"))
    return {"language": state["language"],
            "extensions": [{"number": e["number"], "name": e["name"], "sip_user": e["sip_user"], "voicemail": e["voicemail"],
                            "kind": e["kind"], "base": e["base"],
                            "forward": e["forward"], "email": e["email"], "record": e["record"],
                            "caller_id": e["caller_id"], "rights": e["rights"]}
                           for e in state["extensions"]],
            "trunk": trunk, "reception": state["reception"], "groups": state["groups"], "mail": mail,
            "ivr": state["ivr"], "speed_dials": state["speed_dials"],
            "queues": state["queues"], "recording": state["recording"],
            "directory_count": len(state["directory"]["contacts"]),
            "dids": state["dids"], "closures": state["closures"], "services": state["services"],
            "holidays": public_holidays(state["closures"]), "dect_bases": state["dect_bases"],
            # Le code d'une salle n'est jamais renvoyé à la console (comme le code de messagerie)
            "conferences": [{"number": c["number"], "name": c["name"], "pin_set": bool(c["pin"]),
                             "max_members": c["max_members"], "moh": c["moh"]} for c in state["conferences"]],
            "pagings": state["pagings"]}


def public_holidays(closures, today=None):
    """Jours fériés de l'année en cours et de la suivante, pour la console (libellé, date, coché)."""
    import datetime
    today = today or datetime.date.today()
    labels = {k: label for k, label, _ in HOLIDAYS}
    out = []
    for year in (today.year, today.year + 1):
        for key, date in holidays(year):
            out.append({"key": key, "label": labels[key], "date": date.isoformat(),
                        "checked": key in closures["holidays"]})
    return out


# ------------------------------------------------------------------ Asterisk
HEADER = "; Généré par voipbuntu-pbx, ne pas modifier : la console VOIPbuntu remplace ce fichier.\n"

MODULES = [
    "res_pjsip.so", "res_pjsip_session.so", "res_pjsip_authenticator_digest.so",
    "res_pjsip_endpoint_identifier_user.so", "res_pjsip_endpoint_identifier_ip.so",
    "res_pjsip_outbound_authenticator_digest.so", "res_pjsip_registrar.so", "res_pjsip_outbound_registration.so",
    "res_pjsip_sdp_rtp.so", "res_pjsip_caller_id.so", "res_pjsip_dtmf_info.so", "res_pjsip_rfc3326.so",
    "res_pjsip_mwi.so", "res_pjsip_mwi_body_generator.so", "res_pjsip_pubsub.so", "res_pjsip_nat.so",
    "res_pjsip_logger.so", "res_pjproject.so", "res_sorcery_config.so", "res_sorcery_memory.so",
    "res_sorcery_astdb.so", "res_rtp_asterisk.so", "res_timing_timerfd.so",
    "chan_pjsip.so", "chan_bridge_media.so",
    "app_dial.so", "app_stack.so", "app_exec.so", "app_voicemail.so", "app_echo.so", "app_playback.so", "app_verbose.so",
    "res_musiconhold.so",
    "bridge_simple.so", "bridge_native_rtp.so", "bridge_softmix.so", "bridge_holding.so",
    "codec_alaw.so", "codec_ulaw.so", "codec_g722.so", "codec_gsm.so", "codec_a_mu.so",
    "format_gsm.so", "format_wav.so", "format_wav_gsm.so", "format_pcm.so",
    "func_callerid.so", "func_logic.so", "func_strings.so", "func_channel.so", "func_dialplan.so",
    "pbx_config.so", "cdr_csv.so",
]
MODULES += ["app_queue.so", "app_mixmonitor.so"]  # files d'attente et enregistrement des appels
MODULES += ["res_manager_devicestate.so"]  # supervision en direct : état des postes par l'AMI locale (lot K)
# Numéros directs, interception, parcage, ne pas déranger et transferts (REFER des téléphones, ## et *2)
MODULES += ["res_pjsip_refer.so", "res_pjsip_header_funcs.so", "res_parking.so", "app_directed_pickup.so",
            "bridge_builtin_features.so", "func_db.so", "func_cut.so"]
MODULES += ["app_read.so"]  # renvoi depuis le combiné : *72 seul demande le numéro (lot N)
MODULES += ["app_confbridge.so", "app_page.so"]  # salles de conférence et appel général (lot P)
CDR_FIELDS = ("accountcode", "src", "dst", "dcontext", "clid", "channel", "dstchannel", "lastapp", "lastdata",
              "start", "answer", "end", "duration", "billsec", "disposition", "amaflags")
DISPOSITIONS = ("ANSWERED", "NO ANSWER", "BUSY", "FAILED", "CONGESTION")


def render(state, phone_nets="", asterisk_dir="/etc/asterisk", sounds=None, moh_dir=None, today=None):
    """Renvoie {nom de fichier: contenu} pour /etc/asterisk.

    sounds : {nom d'annonce: chemin sans extension} des annonces présentes sur le disque ;
    moh_dir : dossier de la musique d'attente (aucune classe de musique si None) ;
    today : date du jour (jours fériés calculés à partir d'elle), aujourd'hui par défaut.
    """
    state = validate(state)
    state["_sounds"] = dict(sounds or {})
    state["_moh"] = bool(moh_dir)
    state["_closed"] = closure_ranges(state["closures"], today)
    lang = state["language"]
    files = {}
    files["modules.conf"] = HEADER + "[modules]\nautoload=no\n" + "".join("load = %s\n" % m for m in MODULES)
    files["logger.conf"] = HEADER + ("[general]\ndateformat=%F %T\n\n[logfiles]\n"
                                     "console => notice,warning,error\nmessages.log => notice,warning,error,security\n")
    files["rtp.conf"] = HEADER + "[general]\nrtpstart=10000\nrtpend=20000\nstrictrtp=yes\nicesupport=no\n"
    # AMI : désactivée ici ; voipbuntu-live écrit le fichier inclus (127.0.0.1, compte de supervision)
    files["manager.conf"] = HEADER + "#tryinclude voipbuntu-live-manager.conf\n"
    # cdr_csv lit sa section [csv] dans cdr.conf (il n'a pas de fichier à lui)
    files["cdr.conf"] = HEADER + ("[general]\nenable=yes\nunanswered=yes\ncongestion=yes\n\n"
                                  "[csv]\nusegmtime=no\nloguniqueid=no\nloguserfield=no\naccountlogs=no\n")
    for name, body in (("cel.conf", "[general]\nenable=no\n"),
                       ("ccss.conf", "[general]\n"), ("acl.conf", ""),
                       ("pjproject.conf", "[startup]\nlog_level=default\n"), ("udptl.conf", "[general]\n")):
        files[name] = HEADER + body
    files["http.conf"] = HEADER + "[general]\nenabled=no\n"
    files["features.conf"] = render_features()
    files["confbridge.conf"] = render_confbridge(state)
    files["res_parking.conf"] = render_parking(state)
    files["musiconhold.conf"] = HEADER + "[general]\n" + (
        "\n[default]\nmode=files\ndirectory=%s\nsort=alpha\n" % moh_dir if moh_dir else "")
    files["indications.conf"] = HEADER + "[general]\ncountry=fr\n\n[fr]\ndescription = France\nringcadence = 1500,3500\ndial = 440\nbusy = 440/500,0/500\nring = 440/1500,0/3500\ncongestion = 440/250,0/250\ncallwaiting = 440/300,0/10000\ndialrecall = !350+440/100,!0/100,!350+440/100,!0/100,!350+440/100,!0/100,350+440\nrecord = 1400/500,0/15000\ninfo = !950/330,!1400/330,!1800/330\nstutter = !440/100,!0/100,!440/100,!0/100,!440/100,!0/100,!440/100,!0/100,!440/100,!0/100,!440/100,!0/100,440\n"
    trunk = state["trunk"]
    nat = ""
    if trunk["enabled"] and trunk["public_address"]:
        nat = "external_media_address=%s\nexternal_signaling_address=%s\n%s" % (
            trunk["public_address"], trunk["public_address"],
            "".join("local_net=%s\n" % n for n in local_nets(phone_nets)))
    pjsip = [HEADER,
             "[global]\ntype=global\nuser_agent=VOIPbuntu\nendpoint_identifier_order=username,ip\n\n",
             "[transport-udp]\ntype=transport\nprotocol=udp\nbind=0.0.0.0:5060\n%s\n" % nat,
             "[transport-tcp]\ntype=transport\nprotocol=tcp\nbind=0.0.0.0:5060\n%s\n" % nat]
    bases = {b["id"]: b for b in state["dect_bases"]}
    for e in state["extensions"]:
        n, u = e["number"], e["sip_user"]
        if e["kind"] == "dect":
            base = bases.get(e["base"])
            pjsip.append("; Combiné DECT%s\n" % (" de la base " + base["name"] if base else ""))
        elif e["kind"] == "softphone":
            pjsip.append("; Téléphone logiciel\n")
        pjsip.append(
            "[%s]\ntype=endpoint\ncontext=voipbuntu-internes\ndisallow=all\nallow=g722,alaw,ulaw\n"
            "auth=%s\naors=%s\ncallerid=\"%s\" <%s>\nlanguage=%s\ndirect_media=no\nrtp_symmetric=yes\n"
            "force_rport=yes\nrewrite_contact=yes\ndtmf_mode=rfc4733\n%s%s%s\n" % (
                u, u, u, e["name"], n, lang, ("mailboxes=%s@default\n" % n) if e["voicemail"] else "",
                "set_var=VB_RECORD=1\n" if e["record"] and recording_on(state) else "",
                render_endpoint_services(state, e)))
        pjsip.append("[%s]\ntype=auth\nauth_type=userpass\nusername=%s\npassword=%s\n\n" % (u, u, e["secret"]))
        # Un combiné DECT n'existe qu'une fois, derrière sa base : un seul contact, le dernier gagne
        pjsip.append("[%s]\ntype=aor\nmax_contacts=%d\nremove_existing=yes\nqualify_frequency=60\n\n" % (
            u, 1 if e["kind"] == "dect" else 2))
    if trunk["enabled"]:
        pjsip.append(render_trunk(trunk, lang, any(e["caller_id"] for e in state["extensions"])))
    files["pjsip.conf"] = "".join(pjsip)
    ext = [HEADER, "[general]\nstatic=yes\nwriteprotect=yes\nclearglobalvars=yes\n\n[globals]\n\n",
           "[voipbuntu-internes]\n",
           "exten => *43,1,NoOp(Test d'écho)\n same => n,Answer()\n same => n,Playback(demo-echotest)\n"
           " same => n,Echo()\n same => n,Hangup()\n",
           "exten => *97,1,NoOp(Messagerie vocale)\n same => n,Answer()\n"
           " same => n,VoiceMailMain(${CALLERID(num)}@default)\n same => n,Hangup()\n",
           render_service_codes(state)]
    for e in state["extensions"]:
        ext.append(render_extension(state, e))
    for g in state["groups"]:
        ext.append(render_group(state, g))
    for q in state["queues"]:
        ext.append("exten => %s,1,NoOp(File d'attente %s)\n" % (q["number"], q["number"]))
        ext.append(render_queue(state, q))
    for c in state["conferences"]:
        ext.append(render_conference(c))
    for g in state["pagings"]:
        ext.append(render_paging(state, g))
    if trunk["enabled"]:
        ext.append(render_outbound(trunk, state))  # state : enregistrement et numéro présenté par poste
        ext.append(render_speed_dials(state))
    ext.append("exten => i,1,Playback(invalid)\n same => n,Hangup()\n"
               "exten => _X.,1,Playback(ss-noservice)\n same => n,Hangup()\n")
    if trunk["enabled"]:
        ext.append(render_inbound(state))
        ext.append(render_directory(state))
        ext.append(render_dids(state))
    if state["_closed"]:
        ext.append(render_closures(state))
    if trunk["enabled"] and trunk["caller_id"]:
        # Renvois vers l'extérieur : la ligne présente toujours son propre numéro
        ext.append("\n[voipbuntu-renvoi]\nexten => s,1,ExecIf($[\"${CHANNEL(endpoint)}\" = \"%s\"]?"
                   "Set(CONNECTEDLINE(num,i)=%s))\n same => n,Return()\n" % (TRUNK, trunk["caller_id"]))
    if recording_on(state):
        ext.append(render_recording(state))
    ext.append(render_rights(state))  # droits d'appel par poste (lot N)
    ext.append(render_forward_targets(state))  # renvoi du combiné (*72)
    if state["pagings"]:
        ext.append(render_intercom())
    files["extensions.conf"] = "".join(ext)
    files["queues.conf"] = render_queues_conf(state)
    files["queuerules.conf"] = HEADER + "[general]\n"
    mail = state["mail"]
    general = "[general]\nformat=wav49|gsm|wav\nattach=no\nmaxmsg=100\nmaxsecs=180\nminsecs=2\nmaxlogins=3\nskipms=3000\n"
    if mail["enabled"]:
        fromstring, subject, body = MAIL_TEXT[lang]
        rc = os.path.join(asterisk_dir, "msmtprc")
        general += ("serveremail=%s\nfromstring=%s\ncharset=UTF-8\nemaildateformat=%%d/%%m/%%Y %%H:%%M\n"
                    "emailsubject=%s\nemailbody=%s\nmailcmd=%s -C %s -t\n" % (
                        mail["from_address"], fromstring, subject, body, MSMTP, rc))
        files["msmtprc"] = render_msmtprc(mail)
    else:
        general += "serveremail=voipbuntu\n"
    vm = [HEADER, general, "\n[zonemessages]\neurope=Europe/Paris|'vm-received' Q 'digits/at' HM\n\n[default]\n"]
    for e in state["extensions"]:
        if e["voicemail"]:
            email = e["email"] if mail["enabled"] else ""
            vm.append("%s => %s,%s,%s,,tz=europe|saycid=no|envelope=no%s\n" % (
                e["number"], e["pin"], e["name"], email, "|attach=yes" if email else ""))
    files["voicemail.conf"] = "".join(vm)
    return files


TRUNK = "operateur"


def predial(state):
    """Option de Dial qui fixe le numéro présenté sur les branches qui sortent par la ligne."""
    t = state["trunk"]
    return ",b(voipbuntu-renvoi^s^1)" if t["enabled"] and t["caller_id"] else ""


def dial_targets(state, numbers):
    """Chaînes Dial des postes à faire sonner, renvois permanents et groupes résolus (sans boucle)."""
    exts = {e["number"]: e for e in state["extensions"]}
    groups = {g["number"]: g for g in state["groups"]}
    out, visited = [], set()

    def resolve(n):
        if n in visited:
            return
        visited.add(n)
        if n in groups:
            for m in groups[n]["members"]:
                resolve(m)
        elif is_external(n):
            target = "PJSIP/%s@%s" % (n, TRUNK)
            if state["trunk"]["enabled"] and target not in out:
                out.append(target)
        elif n in exts:
            f = exts[n]["forward"]
            if f["mode"] == "always":
                resolve(f["target"])
            elif "PJSIP/" + exts[n]["sip_user"] not in out:
                out.append("PJSIP/" + exts[n]["sip_user"])

    for n in numbers:
        resolve(n)
    return out


def ring_dial(state, numbers, seconds, media=""):
    """media : « r » (sonnerie jouée à l'appelant déjà décroché) ou « m(default) » (musique d'attente)."""
    targets = dial_targets(state, numbers)
    if not targets:
        return ""
    by_user = {e["sip_user"]: e["number"] for e in state["extensions"]}
    opts = predial(state) if any("@" in t for t in targets) else ""
    if media:
        opts = (opts or ",") + media
    # Les postes non enregistrés sont écartés à l'appel (un Dial vers eux échouerait en erreur)
    out = [" same => n,Set(VB_DIAL=)\n"]
    for t in targets:
        if "@" in t:
            out.append(" same => n,Set(VB_DIAL=${VB_DIAL}&%s)\n" % t)
        else:
            # … ainsi que les postes en « ne pas déranger » (*76) ou renvoyés depuis le combiné (*72)
            out.append(" same => n,ExecIf($[\"${PJSIP_DIAL_CONTACTS(%s)}\" != \"\" & ${DB_EXISTS(%s/%s)} = 0"
                       " & ${DB_EXISTS(%s/%s)} = 0]?Set(VB_DIAL=${VB_DIAL}&%s))\n"
                       % (t[6:], DND_FAMILY, by_user[t[6:]], CF_FAMILY, by_user[t[6:]], t))
    out.append(" same => n,GotoIf($[\"${VB_DIAL}\" = \"\"]?personne)\n"
               " same => n,Dial(${VB_DIAL:1},%d%s)\n same => n(personne),NoOp(Suite)\n" % (seconds, opts))
    return "".join(out)


def render_fallback(box):
    if box:
        return (" same => n,GotoIf($[\"${DIALSTATUS}\" = \"BUSY\"]?busy)\n"
                " same => n,VoiceMail(%s@default,u)\n same => n,Hangup()\n"
                " same => n(busy),VoiceMail(%s@default,b)\n same => n,Hangup()\n" % (box, box))
    return " same => n,Hangup()\n"


def render_extension(state, e):
    """Appel direct d'un poste : renvoi permanent, ou sonnerie puis renvoi / messagerie."""
    n, f = e["number"], e["forward"]
    box = n if e["voicemail"] else ""
    out = ["exten => %s,1,NoOp(Appel vers %s)\n" % (n, n)]
    # Renvoi depuis le combiné (*72) : prioritaire sur le renvoi réglé dans la console
    out.append(" same => n,GotoIf(${DB_EXISTS(%s/%s)}?cf)\n same => n(normal),NoOp(Suite)\n" % (CF_FAMILY, n))
    cf = render_handset_forward(state, e)
    if f["mode"] == "always":
        if is_external(f["target"]):
            out.append(" same => n,Dial(PJSIP/%s@%s,120%s)\n same => n,Hangup()\n" % (f["target"], TRUNK, predial(state)))
        else:
            out.append(" same => n,Goto(voipbuntu-internes,%s,1)\n" % f["target"])
        out.append(cf)
        return "".join(out)
    # Ne pas déranger (*76) : occupé, ou messagerie (message « occupé ») si le poste en a une
    out.append(" same => n,GotoIf(${DB_EXISTS(%s/%s)}?npd)\n" % (DND_FAMILY, n))
    dnd = (" same => n(npd),NoOp(Ne pas déranger)\n" +
           (" same => n,VoiceMail(%s@default,b)\n same => n,Hangup()\n" % n if box else " same => n,Busy(5)\n same => n,Hangup()\n"))
    # Appel enregistré : annonce d'information à l'appelant, puis sonnerie jouée par Asterisk
    rec = ",r" if e["record"] and recording_on(state) else ""
    if rec:
        out.append(" same => n,Gosub(voipbuntu-enreg,in,1(%s))\n" % n)
    # Poste non enregistré : pas de Dial (qui échouerait en erreur), directement la suite
    absent = " same => n,GotoIf($[\"${PJSIP_DIAL_CONTACTS(%s)}\" = \"\"]?%s)\n" % (
        e["sip_user"], "renvoi" if f["mode"] == "noanswer" else "absent")
    if f["mode"] != "noanswer":
        out.append(absent)
        out.append(" same => n,Dial(PJSIP/%s,25%s)\n" % (e["sip_user"], rec))
        out.append(" same => n(absent),NoOp(Suite)\n")
        out.append(render_fallback(box))
        out.append(dnd)
        out.append(cf)
        return "".join(out)
    # Sans réponse, occupé ou injoignable : renvoi (trois rebonds au plus entre postes)
    out.append(absent)
    out.append(" same => n,Dial(PJSIP/%s,%d%s)\n" % (e["sip_user"], f["ring_seconds"], rec))
    out.append(" same => n,GotoIf($[\"${DIALSTATUS}\" = \"ANSWER\"]?fin)\n"
               " same => n(renvoi),Set(VB_HOPS=$[0${VB_HOPS} + 1])\n"
               " same => n,GotoIf($[${VB_HOPS} > 3]?secours)\n")
    if is_external(f["target"]):
        out.append(" same => n,Dial(PJSIP/%s@%s,60%s)\n" % (f["target"], TRUNK, predial(state)))
        out.append(" same => n,GotoIf($[\"${DIALSTATUS}\" = \"ANSWER\"]?fin)\n")
    else:
        out.append(" same => n,Goto(voipbuntu-internes,%s,1)\n" % f["target"])
    out.append(" same => n(secours),NoOp(Secours)\n")
    out.append(render_fallback(box))
    out.append(" same => n(fin),Hangup()\n")
    out.append(dnd)
    out.append(cf)
    return "".join(out)


def render_handset_forward(state, e):
    """Branche « cf » d'un poste : destination relue dans AstDB et revérifiée avec les droits actuels du poste."""
    n, trunk = e["number"], state["trunk"]
    out = [" same => n(cf),Set(VB_CF=${DB(%s/%s)})\n" % (CF_FAMILY, n),
           " same => n,Set(VB_HOPS=$[0${VB_HOPS} + 1])\n",
           " same => n,GotoIf($[${VB_HOPS} > %d | \"${VB_CF}\" = \"%s\"]?normal)\n" % (CF_HOPS, n),
           " same => n,GotoIf(${DIALPLAN_EXISTS(voipbuntu-cf-internes,${VB_CF},1)}?voipbuntu-internes,${VB_CF},1)\n"]
    if trunk["enabled"] and e["rights"] != "internal":
        out.append(" same => n,GotoIf(${DIALPLAN_EXISTS(voipbuntu-cf-national,${VB_CF},1)}?cfext)\n")
        if trunk["international"] and e["rights"] == "all":
            out.append(" same => n,GotoIf(${DIALPLAN_EXISTS(voipbuntu-cf-international,${VB_CF},1)}?cfext)\n")
    out.append(" same => n,Goto(normal)\n")  # destination qui n'est plus admise : le poste sonne normalement
    if trunk["enabled"] and e["rights"] != "internal":
        out.append(" same => n(cfext),Dial(PJSIP/${VB_CF}@%s,120%s)\n same => n,Hangup()\n" % (TRUNK, predial(state)))
    return "".join(out)


def render_group(state, g):
    out = ["exten => %s,1,NoOp(Groupe %s)\n" % (g["number"], g["number"])]
    out.append(ring_dial(state, [g["number"]], g["ring_seconds"]))
    out.append(render_fallback(g["voicemail_box"]))
    return "".join(out)


def local_nets(phone_nets):
    """Réseaux locaux pour le NAT : réseaux des téléphones et plages privées IPv4."""
    import ipaddress
    out = []
    for item in (phone_nets or "").replace(",", " ").split():
        try:
            net = ipaddress.ip_network(item, strict=False)
        except ValueError:
            continue
        if net.version == 4 and str(net) not in out:
            out.append(str(net))
    for net in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"):
        if net not in out:
            out.append(net)
    return out


# Transferts et ligne : le correspondant extérieur ne transfère jamais (ni REFER, ni ##, ni *2) ; s'il le
# pouvait malgré tout, ce serait dans le contexte entrant, qui ne mène qu'à l'accueil et aux numéros directs.
# Le poste qui reçoit l'appel peut transférer au clavier (t : l'appelé).
TRUNK_TRANSFER = "allow_transfer=no\nset_var=TRANSFER_CONTEXT=voipbuntu-entrant\nset_var=BRIDGE_FEATURES=t\n"


def render_trunk(t, lang, extension_cids=False):
    host = "%s:%d" % (t["host"], t["port"])
    auth_user = t["auth_username"] or t["username"]
    out = []
    if t["register"]:
        out.append("[%s]\ntype=registration\noutbound_auth=%s-auth\nserver_uri=sip:%s\nclient_uri=sip:%s@%s\n"
                   "contact_user=%s\nretry_interval=60\nforbidden_retry_interval=600\nmax_retries=10000\n"
                   "expiration=600\nline=yes\nendpoint=%s\n\n" % (
                       TRUNK, TRUNK, host, t["username"], host, t["username"], TRUNK))
    out.append("[%s-auth]\ntype=auth\nauth_type=userpass\nusername=%s\npassword=%s\n\n" % (TRUNK, auth_user, t["password"]))
    out.append("[%s]\ntype=aor\ncontact=sip:%s\nqualify_frequency=60\n\n" % (TRUNK, host))
    out.append("[%s]\ntype=endpoint\ncontext=voipbuntu-entrant\ndisallow=all\nallow=alaw,ulaw,g722\n"
               "outbound_auth=%s-auth\naors=%s\nfrom_user=%s\nfrom_domain=%s\nlanguage=%s\ndirect_media=no\n"
               "rtp_symmetric=yes\nforce_rport=yes\nrewrite_contact=yes\ndtmf_mode=rfc4733\n"
               "send_pai=%s\ntrust_id_inbound=no\ntrust_id_outbound=yes\n%s\n" % (TRUNK, TRUNK, TRUNK, t["username"], t["host"], lang,
                                                               "yes" if t["caller_id"] or extension_cids else "no",
                                                               TRUNK_TRANSFER))
    out.append("[%s]\ntype=identify\nendpoint=%s\nmatch=%s\n\n" % (TRUNK, TRUNK, t["host"]))
    return "".join(out)


def render_outbound(t, state=None):
    """Appels sortants des postes : numéros français à 10 chiffres, urgences, international en option."""
    cid = " same => n,Set(CALLERID(num)=%s)\n" % t["caller_id"] if t["caller_id"] else ""
    cid += " same => n,Set(BRIDGE_FEATURES=T)\n"  # appel sortant : seul le poste transfère au clavier
    if state is not None and any(e["caller_id"] for e in state["extensions"]):
        # Poste qui présente un numéro direct (set_var VB_CID) ; sinon le numéro de la ligne
        cid += " same => n,ExecIf($[\"${VB_CID}\" != \"\"]?Set(CALLERID(num)=${VB_CID}))\n"
    rule = (" same => n,NoOp(Appel sortant)\n%s same => n,Dial(PJSIP/${EXTEN}@%s,120)\n"
            " same => n,Hangup()\n" % (cid, TRUNK))
    # Poste enregistré (set_var VB_RECORD) : enregistrement, annonce d'information jouée au correspondant
    # au décroché (option A de Dial). Jamais sur les numéros d'urgence.
    recorded = rule
    if state is not None and recording_on(state):
        recorded = (" same => n,NoOp(Appel sortant)\n%s same => n,Set(VB_DOPT=)\n"
                    " same => n,ExecIf($[\"${VB_RECORD}\" = \"1\"]?Gosub(voipbuntu-enreg,out,1(${EXTEN})))\n"
                    " same => n,ExecIf($[\"${VB_RECORD}\" = \"1\"]?Set(VB_DOPT=A(%s)))\n"
                    " same => n,Dial(PJSIP/${EXTEN}@%s,120,${VB_DOPT})\n same => n,Hangup()\n"
                    % (cid, state["_sounds"]["enregistrement"], TRUNK))
    # Droits du poste (set_var VB_DROITS) : « internal » n'appelle pas l'extérieur, « national » pas l'international
    national = " same => n,GotoIf($[\"${VB_DROITS}\" = \"internal\"]?voipbuntu-interdit,s,1)\n"
    international = " same => n,GotoIf($[\"${VB_DROITS}\" != \"\"]?voipbuntu-interdit,s,1)\n"
    out = ["exten => _0[1-9]XXXXXXXX,1,NoOp(Numéro national)\n" + national + recorded]
    if t["international"]:
        out.append("exten => _00[1-9].,1,NoOp(Numéro international)\n" + international + recorded)
    for n in EMERGENCY:
        out.append("exten => %s,1,NoOp(Urgence)\n%s" % (n, rule))
    return "".join(out)


def caller_media(state, answered):
    """Ce qu'entend l'appelant pendant que les postes sonnent."""
    if state["ivr"]["hold_music"] and state.get("_moh"):
        return "m(default)"
    return "r" if answered else ""


def render_inbound(state):
    """Appels entrants de l'opérateur : uniquement vers l'accueil, jamais vers la ligne sortante."""
    r, ivr, sounds = state["reception"], state["ivr"], state.get("_sounds", {})
    menu = ivr["enabled"] and ivr["options"]
    answered = bool(menu or "accueil" in sounds)
    out = ["\n[voipbuntu-entrant]\n",
           render_did_lookup(state) if state["dids"] else
           "exten => _X.,1,Goto(voipbuntu-accueil,s,1)\nexten => _+X.,1,Goto(voipbuntu-accueil,s,1)\n"
           "exten => s,1,Goto(voipbuntu-accueil,s,1)\n",
           "\n[voipbuntu-accueil]\nexten => s,1,NoOp(Appel entrant)\n", render_lookup()]
    if state.get("_closed"):
        # Fermeture exceptionnelle (jour férié, congés) : même chemin que hors des horaires
        out.append(" same => n,Gosub(voipbuntu-fermetures,s,1)\n same => n,GotoIf($[\"${VB_FERME}\" = \"1\"]?ferme)\n")
    if r["hours"]:
        out.append(" same => n,GotoIfTime(%s-%s,%s,*,*,Europe/Paris?ouvert)\n same => n,Goto(ferme)\n"
                   % (r["hours"]["start"], r["hours"]["end"], "&".join(r["hours"]["days"])))
    out.append(" same => n(ouvert),NoOp(Ouvert)\n")
    if answered:
        out.append(" same => n,Answer()\n same => n,Wait(1)\n")
    if "accueil" in sounds:
        out.append(" same => n,Playback(%s)\n" % sounds["accueil"])
    if menu:
        out.append(" same => n,Goto(voipbuntu-menu,s,1)\n")
    out.append(" same => n(sonner),NoOp(Sonnerie de l'accueil)\n")
    out.append(ring_dial(state, r["members"], r["ring_seconds"], caller_media(state, answered)))
    out.append(" same => n,Goto(secours)\n")
    # Fermé : annonce de fermeture, puis messagerie de secours
    out.append(" same => n(ferme),Answer()\n same => n,Wait(1)\n")
    if "fermeture" in sounds:
        out.append(" same => n,Playback(%s)\n" % sounds["fermeture"])
    if r["voicemail_box"]:
        out.append(" same => n,VoiceMail(%s@default,%s)\n same => n,Hangup()\n"
                   % (r["voicemail_box"], "s" if "fermeture" in sounds else "u"))
    else:
        out.append(" same => n,Playback(vm-goodbye)\n same => n,Hangup()\n")
    out.append(" same => n(secours),Answer()\n same => n,Wait(1)\n")
    if r["voicemail_box"]:
        out.append(" same => n,VoiceMail(%s@default,u)\n" % r["voicemail_box"])
    else:
        out.append(" same => n,Playback(vm-goodbye)\n")
    out.append(" same => n,Hangup()\n")
    if menu:
        out.append(render_menu(state))
    return "".join(out)


def render_features():
    """Transferts au clavier pendant un appel (## aveugle, *2 accompagné) et interception *8."""
    return HEADER + ("[general]\ntransferdigittimeout=3\natxfernoanswertimeout=20\natxferdropcall=no\n"
                     "pickupexten=%s\n\n[featuremap]\nblindxfer=%s\natxfer=%s\n" % (PICKUP_CODE, BLIND_XFER, ATTENDED_XFER))


def render_parking(state):
    """Parcage : *70 gare l'appel (par transfert ou directement), places 71 à 79 pour le reprendre."""
    if not state["services"]["parking"]:
        return HEADER + "[general]\n"
    return HEADER + ("[general]\nparkeddynamic=no\n\n[default]\ncontext=voipbuntu-parcage\nparkpos=%s-%s\n"
                     "parkingtime=120\ncomebacktoorigin=yes\nfindslot=next\nparkedcalltransfers=both\n"
                     "parkedcallreparking=both\n%s" % (PARK_SLOTS[0], PARK_SLOTS[-1],
                                                      "parkedmusicclass=default\n" if state.get("_moh") else ""))


def render_endpoint_services(state, e):
    """Réglages du poste pour les codes de service : groupe d'interception, numéro du poste, numéro présenté."""
    out = "call_group=1\npickup_group=1\nset_var=VB_POSTE=%s\n" % e["number"]
    if e["caller_id"]:
        out += "set_var=VB_CID=%s\n" % present_as(e["caller_id"], state["trunk"]["caller_id"])
    # Transferts au clavier (## et *2) permis aux deux correspondants des appels de ce poste
    out += "set_var=__BRIDGE_FEATURES=Tt\n"
    if e["rights"] != "all":
        # Droits restreints : vérifiés par les règles de sortie, et un transfert aveugle (## ou touche de transfert)
        # part d'un contexte qui refuse ce que le poste ne peut pas composer lui-même
        out += "set_var=VB_DROITS=%s\nset_var=TRANSFER_CONTEXT=voipbuntu-droits-%s\n" % (e["rights"], e["rights"])
    return out


def render_confbridge(state):
    """Profils des salles de conférence : taille de la salle, code d'entrée, musique quand on est seul."""
    out = [HEADER, "[general]\n"]
    for c in state["conferences"]:
        n = c["number"]
        out.append("\n[vb-salle-%s]\ntype=bridge\nmax_members=%d\nlanguage=%s\n" % (n, c["max_members"], state["language"]))
        out.append("\n[vb-participant-%s]\ntype=user\nannounce_user_count=yes\nannounce_join_leave=no\n"
                   "dsp_drop_silence=yes\n%s%s" % (n, "pin=%s\n" % c["pin"] if c["pin"] else "",
                                                   "music_on_hold_when_empty=yes\n" if c["moh"] and state.get("_moh") else ""))
    return "".join(out)


def render_conference(c):
    n = c["number"]
    return ("exten => %s,1,NoOp(Salle de conférence %s)\n same => n,Answer()\n same => n,Wait(0.5)\n"
            " same => n,ConfBridge(vb-%s,vb-salle-%s,vb-participant-%s)\n same => n,Hangup()\n" % (n, n, n, n, n))


def render_paging(state, g):
    """Appel général : chaque poste enregistré, ni en « ne pas déranger » ni renvoyé, ni l'appelant lui-même,
    décroche en haut-parleur s'il sait le faire (en-têtes Alert-Info et Call-Info), sinon il sonne."""
    exts = {e["number"]: e for e in state["extensions"]}
    out = ["exten => %s,1,NoOp(Appel général %s)\n same => n,Set(VB_PAGE=)\n" % (g["number"], g["number"])]
    for m in g["members"]:
        u = exts[m]["sip_user"]
        out.append(" same => n,ExecIf($[\"${PJSIP_DIAL_CONTACTS(%s)}\" != \"\" & ${DB_EXISTS(%s/%s)} = 0"
                   " & ${DB_EXISTS(%s/%s)} = 0 & \"${CHANNEL(endpoint)}\" != \"%s\"]?Set(VB_PAGE=${VB_PAGE}&PJSIP/%s))\n"
                   % (u, DND_FAMILY, m, CF_FAMILY, m, u, u))
    out.append(" same => n,GotoIf($[\"${VB_PAGE}\" = \"\"]?personne)\n"
               " same => n,Page(${VB_PAGE:1},%sib(voipbuntu-interphone^s^1),30)\n same => n,Hangup()\n"
               " same => n(personne),Answer()\n same => n,Playback(ss-noservice)\n same => n,Hangup()\n"
               % ("d" if g["duplex"] else ""))
    return "".join(out)


def render_intercom():
    """Avant chaque appel d'un appel général : demande de décroché automatique (Yealink, Snom, Grandstream, Fanvil)."""
    return ("\n[voipbuntu-interphone]\nexten => s,1,Set(PJSIP_HEADER(add,Alert-Info)=<http://localhost>\\;info=alert-autoanswer\\;delay=0)\n"
            " same => n,Set(PJSIP_HEADER(add,Call-Info)=<sip:localhost>\\;answer-after=0)\n same => n,Return()\n")


def render_rights(state):
    """Contextes des droits restreints : appel refusé, transferts aveugles des postes restreints."""
    out = ["\n[voipbuntu-interdit]\nexten => s,1,NoOp(Appel non autorisé pour ce poste)\n same => n,Answer()\n"
           " same => n,Wait(0.5)\n same => n,Playback(cannot-complete-as-dialed)\n same => n,Hangup()\n"]
    used = {e["rights"] for e in state["extensions"]}
    refuse = ",1,Goto(voipbuntu-interdit,s,1)\n"
    for rights in ("national", "internal"):
        if rights not in used:
            continue
        out.append("\n[voipbuntu-droits-%s]\n" % rights)
        out.append("exten => _00." + refuse)
        if rights == "internal":
            out.append("exten => _0[1-9]." + refuse)
        out.append("exten => _%s." % SPEED_PREFIX + refuse)  # numéros abrégés : jamais par transfert
        out.append("include => voipbuntu-internes\n")
    return "".join(out)


def render_forward_targets(state):
    """Destinations admises pour le renvoi du combiné : postes, groupes et files ; l'extérieur selon la ligne."""
    out = ["\n[voipbuntu-cf-internes]\n"]
    for n in sorted({e["number"] for e in state["extensions"]} | {g["number"] for g in state["groups"]} |
                    {q["number"] for q in state["queues"]}, key=lambda x: (len(x), x)):
        out.append("exten => %s,1,Return()\n" % n)
    if state["trunk"]["enabled"]:
        out.append("\n[voipbuntu-cf-national]\nexten => _0[1-9]XXXXXXXX,1,Return()\n")
        if state["trunk"]["international"]:
            out.append("\n[voipbuntu-cf-international]\nexten => _00[1-9].,1,Return()\n")
    return "".join(out)


def render_forward_codes(state):
    """*72<numéro> : renvoi immédiat du poste qui compose ; *72 seul demande le numéro ; *73 l'annule."""
    queued = any(q["members"] for q in state["queues"])
    trunk = state["trunk"]
    pause = " same => n,PauseQueueMember(,PJSIP/${CHANNEL(endpoint)})\n" if queued else ""
    unpause = (" same => n,ExecIf($[${DB_EXISTS(%s/${VB_POSTE})} = 0]?UnpauseQueueMember(,PJSIP/${CHANNEL(endpoint)}))\n"
               % DND_FAMILY) if queued else ""
    out = ["exten => %s,1,NoOp(Renvoi immédiat : numéro demandé)\n same => n,Answer()\n same => n,Wait(0.5)\n"
           " same => n,Read(VB_CIBLE,vm-enter-num-to-call,20,,1,10)\n"
           " same => n,GotoIf($[\"${VB_CIBLE}\" = \"\"]?voipbuntu-interdit,s,1)\n"
           " same => n,Goto(voipbuntu-internes,%s${FILTER(0-9,${VB_CIBLE})},1)\n" % (CF_CODE, CF_CODE)]
    out.append("exten => _%sX.,1,NoOp(Renvoi immédiat depuis le combiné)\n same => n,Answer()\n same => n,Wait(0.5)\n"
               " same => n,Set(VB_CIBLE=${EXTEN:%d})\n"
               " same => n,GotoIf($[\"${VB_POSTE}\" = \"\" | \"${VB_CIBLE}\" = \"${VB_POSTE}\"]?refus)\n"
               " same => n,GotoIf(${DIALPLAN_EXISTS(voipbuntu-cf-internes,${VB_CIBLE},1)}?ok)\n" % (CF_CODE, len(CF_CODE)))
    if trunk["enabled"]:
        out.append(" same => n,GotoIf($[${DIALPLAN_EXISTS(voipbuntu-cf-national,${VB_CIBLE},1)} & "
                   "\"${VB_DROITS}\" != \"internal\"]?ok)\n")
        if trunk["international"]:
            out.append(" same => n,GotoIf($[${DIALPLAN_EXISTS(voipbuntu-cf-international,${VB_CIBLE},1)} & "
                       "\"${VB_DROITS}\" = \"\"]?ok)\n")
    out.append(" same => n(refus),Goto(voipbuntu-interdit,s,1)\n"
               " same => n(ok),Set(DB(%s/${VB_POSTE})=${VB_CIBLE})\n%s"
               " same => n,Playback(call-fwd-unconditional&activated)\n same => n,SayDigits(${VB_CIBLE})\n"
               " same => n,Hangup()\n" % (CF_FAMILY, pause))
    out.append("exten => %s,1,NoOp(Renvoi immédiat annulé)\n same => n,Answer()\n same => n,Wait(0.5)\n"
               " same => n,GotoIf($[\"${VB_POSTE}\" = \"\"]?fin)\n"
               " same => n,Set(VB_X=${DB_DELETE(%s/${VB_POSTE})})\n%s"
               " same => n,Playback(call-fwd-unconditional&de-activated)\n same => n(fin),Hangup()\n"
               % (CF_CANCEL_CODE, CF_FAMILY, unpause))
    return "".join(out)


def render_service_codes(state):
    """*8, **<poste>, *70 et 71 à 79, *76."""
    out = ["exten => %s,1,NoOp(Interception du groupe)\n same => n,Pickup()\n same => n,Hangup()\n" % PICKUP_CODE]
    for e in state["extensions"]:
        out.append("exten => %s%s,1,NoOp(Interception du poste %s)\n same => n,PickupChan(PJSIP/%s)\n same => n,Hangup()\n"
                   % (DIRECT_PICKUP, e["number"], e["number"], e["sip_user"]))
    if state["services"]["parking"]:
        # Park() en première priorité : un transfert vers *70 est reconnu comme un parcage (place annoncée)
        out.append("exten => %s,1,Park(default)\n same => n,Hangup()\n" % PARK_CODE)
        for slot in PARK_SLOTS:
            out.append("exten => %s,1,ParkedCall(default,%s)\n same => n,Hangup()\n" % (slot, slot))
    queued = any(q["members"] for q in state["queues"])
    out.append("exten => %s,1,NoOp(Ne pas déranger)\n same => n,Answer()\n same => n,Wait(0.5)\n"
               " same => n,GotoIf($[\"${VB_POSTE}\" = \"\"]?fin)\n"
               " same => n,GotoIf(${DB_EXISTS(%s/${VB_POSTE})}?off)\n"
               " same => n,Set(DB(%s/${VB_POSTE})=1)\n%s"
               " same => n,Playback(do-not-disturb&activated)\n same => n,Hangup()\n"
               " same => n(off),Set(VB_X=${DB_DELETE(%s/${VB_POSTE})})\n%s"
               " same => n,Playback(do-not-disturb&de-activated)\n same => n(fin),Hangup()\n" % (
                   DND_CODE, DND_FAMILY, DND_FAMILY,
                   " same => n,PauseQueueMember(,PJSIP/${CHANNEL(endpoint)})\n" if queued else "", DND_FAMILY,
                   (" same => n,ExecIf($[${DB_EXISTS(%s/${VB_POSTE})} = 0]?UnpauseQueueMember(,PJSIP/${CHANNEL(endpoint)}))\n"
                    % CF_FAMILY) if queued else ""))
    out.append(render_forward_codes(state))
    return "".join(out)


def render_did_lookup(state):
    """Appel de la ligne : numéro direct cherché dans le numéro appelé, puis dans l'en-tête To ; sinon l'accueil."""
    out = []
    for pattern in ("_X.", "_+X.", "s"):
        out.append("exten => %s,1,Set(VB_SDA=${FILTER(0-9+,${EXTEN})})\n"
                   " same => n,GotoIf(${DIALPLAN_EXISTS(voipbuntu-sda,${VB_SDA},1)}?voipbuntu-sda,${VB_SDA},1)\n"
                   " same => n,Set(VB_SDA=${FILTER(0-9+,${CUT(CUT(PJSIP_HEADER(read,To),@,1),:,2)})})\n"
                   " same => n,GotoIf(${DIALPLAN_EXISTS(voipbuntu-sda,${VB_SDA},1)}?voipbuntu-sda,${VB_SDA},1)\n"
                   " same => n,Goto(voipbuntu-accueil,s,1)\n" % pattern)
    return "".join(out)


def render_dids(state):
    """Un numéro direct par destination ; ses autres formes (33…, +33…, 0033…) y renvoient."""
    if not state["dids"]:
        return ""
    out = ["\n[voipbuntu-appelant]\nexten => s,1,NoOp(Nom de l'appelant)\n", render_lookup(), " same => n,Return()\n",
           "\n[voipbuntu-sda]\n"]
    hours, closed = state["reception"]["hours"], state.get("_closed")
    for d in state["dids"]:
        n, target = d["number"], d["target"]
        out.append("exten => %s,1,NoOp(Numéro direct %s)\n same => n,Set(VB_SDA=%s)\n" % (n, n, n))
        if target == "accueil":
            out.append(" same => n,Goto(voipbuntu-accueil,s,1)\n")
        else:
            out.append(" same => n,Gosub(voipbuntu-appelant,s,1)\n")
            if d["hours"] and closed:
                out.append(" same => n,Gosub(voipbuntu-fermetures,s,1)\n"
                           " same => n,GotoIf($[\"${VB_FERME}\" = \"1\"]?voipbuntu-accueil,s,ferme)\n")
            if d["hours"] and hours:
                out.append(" same => n,GotoIfTime(%s-%s,%s,*,*,Europe/Paris?ouvert)\n same => n,Goto(voipbuntu-accueil,s,ferme)\n"
                           " same => n(ouvert),NoOp(Ouvert)\n" % (hours["start"], hours["end"], "&".join(hours["days"])))
            if target.startswith("vm:"):
                out.append(" same => n,Answer()\n same => n,Wait(1)\n same => n,VoiceMail(%s@default,u)\n same => n,Hangup()\n"
                           % target[3:])
            else:
                # Poste, groupe ou file : même traitement qu'un appel interne (renvois, ne pas déranger, messagerie)
                out.append(" same => n,Goto(voipbuntu-internes,%s,1)\n" % target)
        for v in did_variants(n)[1:]:
            out.append("exten => %s,1,Goto(voipbuntu-sda,%s,1)\n" % (v, n))
    return "".join(out)


def render_closures(state):
    """Gosub : VB_FERME=1 si aujourd'hui (heure de Paris) est un jour férié coché ou dans une période de fermeture."""
    out = ["\n[voipbuntu-fermetures]\nexten => s,1,Set(VB_FERME=0)\n"
           " same => n,Set(VB_JOUR=${STRFTIME(${EPOCH},Europe/Paris,%Y%m%d)})\n"]
    for first, last in state["_closed"]:
        cond = "${VB_JOUR} = %s" % first if first == last else "${VB_JOUR} >= %s & ${VB_JOUR} <= %s" % (first, last)
        out.append(" same => n,ExecIf($[%s]?Set(VB_FERME=1))\n" % cond)
    out.append(" same => n,Return()\n")
    return "".join(out)


def render_speed_dials(state):
    """*1XX : le numéro abrégé suit la règle des appels sortants (numéro présenté, international autorisé ou non)."""
    out = []
    for d in state["speed_dials"]:
        if INTERNATIONAL_RE.match(d["number"]) and not state["trunk"]["international"]:
            continue  # international non autorisé sur la ligne : le code n'existe pas
        out.append("exten => %s%s,1,NoOp(Numéro abrégé %s)\n same => n,Goto(voipbuntu-internes,%s,1)\n"
                   % (SPEED_PREFIX, d["code"], d["code"], d["number"]))
    return "".join(out)


def render_lookup():
    """Appel entrant : le numéro de l'appelant (filtré : chiffres et +) est cherché dans l'annuaire."""
    return (" same => n,Set(VB_NUM=${FILTER(0-9+,${CALLERID(num)})})\n"
            " same => n,ExecIf($[\"${VB_NUM:0:3}\" = \"+33\"]?Set(VB_NUM=0${VB_NUM:3}))\n"
            " same => n,ExecIf($[\"${VB_NUM:0:1}\" = \"+\"]?Set(VB_NUM=00${VB_NUM:1}))\n"
            " same => n,ExecIf($[\"${VB_NUM:0:4}\" = \"0033\"]?Set(VB_NUM=0${VB_NUM:4}))\n"
            " same => n,ExecIf($[\"${VB_NUM:0:2}\" = \"33\" & ${LEN(${VB_NUM})} = 11]?Set(VB_NUM=0${VB_NUM:2}))\n"
            " same => n,GotoIf($[\"${VB_NUM}\" = \"\"]?inconnu)\n"
            " same => n,ExecIf(${DIALPLAN_EXISTS(voipbuntu-annuaire,${VB_NUM},1)}?Gosub(voipbuntu-annuaire,${VB_NUM},1))\n"
            " same => n(inconnu),NoOp(Annuaire)\n")


def render_directory(state):
    """Annuaire : un numéro connu donne son nom à l'appel (CALLERID(name)) avant que les postes sonnent."""
    out = ["\n[voipbuntu-annuaire]\n"]
    for number, contact in sorted(directory.by_number(state["directory"]).items()):
        out.append("exten => %s,1,Set(CALLERID(name)=%s)\n same => n,Return()\n"
                   % (number, directory.callerid_name(contact)))
    return "".join(out)


def render_menu(state):
    """Menu vocal : annonce du menu, choix d'une touche (DTMF), destination ; sans choix, la destination par défaut."""
    ivr, sounds = state["ivr"], state.get("_sounds", {})
    out = ["\n[voipbuntu-menu]\nexten => s,1,NoOp(Menu vocal)\n same => n,Set(VB_ESSAIS=0)\n"]
    out.append(" same => n(menu),%s\n" % ("Background(%s)" % sounds["menu"] if "menu" in sounds else "NoOp(Sans annonce de menu)"))
    out.append(" same => n,WaitExten(%d)\n" % ivr["timeout"])
    for o in ivr["options"]:
        out.append("exten => %s,1,NoOp(Menu : touche %s)\n" % (o["digit"], o["digit"]))
        out.append(render_ivr_destination(state, o["target"]))
    # Touche sans destination : « choix invalide », menu rejoué deux fois, puis la destination par défaut
    out.append("exten => i,1,Set(VB_ESSAIS=$[${VB_ESSAIS} + 1])\n same => n,GotoIf($[${VB_ESSAIS} > 2]?t,1)\n"
               " same => n,Playback(invalid)\n same => n,Goto(s,menu)\n")
    out.append("exten => t,1,NoOp(Menu : sans choix)\n")
    out.append(render_ivr_destination(state, ivr["default"]))
    return "".join(out)


def render_ivr_destination(state, target):
    if target in ("", "accueil"):
        return " same => n,Goto(voipbuntu-accueil,s,sonner)\n"
    if target.startswith("vm:"):
        return " same => n,VoiceMail(%s@default,u)\n same => n,Hangup()\n" % target[3:]
    exts = {e["number"]: e for e in state["extensions"]}
    groups = {g["number"]: g for g in state["groups"]}
    queues = {q["number"]: q for q in state.get("queues", [])}
    if target in queues:
        return render_queue(state, queues[target])
    if target in {c["number"] for c in state.get("conferences", [])}:
        return " same => n,Goto(voipbuntu-internes,%s,1)\n" % target  # salle de conférence (lot P)
    if target in groups:
        seconds, box = groups[target]["ring_seconds"], groups[target]["voicemail_box"]
    else:
        seconds = state["reception"]["ring_seconds"]
        box = target if exts[target]["voicemail"] else state["reception"]["voicemail_box"]
    return ring_dial(state, [target], seconds, caller_media(state, True)) + render_fallback(box)


def recording_on(state):
    """L'enregistrement n'est actif qu'avec l'annonce d'information de l'appelant (obligation légale)."""
    return "enregistrement" in state.get("_sounds", {})


def recording_name(number):
    """Nom du fichier : date-heure, appelant (chiffres seuls, filtrés par FILTER), poste ou file, identifiant."""
    return ("${STRFTIME(${EPOCH},,%%Y%%m%%d-%%H%%M%%S)}-${FILTER(0-9,${CALLERID(num)}):0:24}-%s-${UNIQUEID}" % number)


def render_recording(state):
    """Sous-programme commun : annonce d'information (appel entrant) puis MixMonitor, une seule fois par appel."""
    announce = state["_sounds"]["enregistrement"]
    return ("\n[voipbuntu-enreg]\n"
            "exten => in,1,GotoIf($[\"${VB_ENREG}\" = \"1\"]?fin)\n same => n,Set(VB_ENREG=1)\n"
            " same => n,Answer()\n same => n,Playback(%s)\n"
            " same => n,MixMonitor(%s.wav,b)\n same => n(fin),Return()\n"
            "exten => out,1,GotoIf($[\"${VB_ENREG}\" = \"1\"]?fin)\n same => n,Set(VB_ENREG=1)\n"
            " same => n,MixMonitor(%s.wav,b)\n same => n(fin),Return()\n"
            % (announce, recording_name("${ARG1}"), recording_name("${ARG1}")))


def queue_name(q):
    return "voipbuntu-file-%s" % q["number"]


def render_queues_conf(state):
    """Une section par file : membres (postes), stratégie, sonnerie de chaque poste, musique et annonce."""
    exts = {e["number"]: e for e in state["extensions"]}
    sounds, moh = state.get("_sounds", {}), state.get("_moh")
    out = [HEADER, "[general]\npersistentmembers=no\nautofill=yes\nshared_lastcall=no\nlog_membername_as_agent=yes\n"]
    for q in state["queues"]:
        out.append("\n[%s]\nstrategy=%s\ntimeout=%d\nretry=2\nwrapuptime=0\nringinuse=no\nautopause=no\n"
                   "joinempty=unavailable,invalid,unknown\nleavewhenempty=unavailable,invalid,unknown\n"
                   "announce-frequency=0\nannounce-holdtime=no\nannounce-position=no\nreportholdtime=no\n"
                   "timeoutpriority=conf\n%s" % (queue_name(q), q["strategy"], q["ring_seconds"],
                                                    "musicclass=default\n" if moh else ""))
        if q["announce"] and "file" in sounds:
            out.append("periodic-announce=%s\nperiodic-announce-frequency=60\n" % sounds["file"])
        for m in q["members"]:
            u = exts[m]["sip_user"]
            out.append("member => PJSIP/%s,0,%s,PJSIP/%s\n" % (u, exts[m]["name"].replace(",", " "), u))
    return "".join(out)


def render_queue(state, q):
    """Corps d'une file : décroché, enregistrement facultatif, annonce, attente, puis débordement."""
    sounds = state.get("_sounds", {})
    out = [" same => n,Answer()\n same => n,Wait(1)\n"]
    if q["record"] and recording_on(state):
        out.append(" same => n,Gosub(voipbuntu-enreg,in,1(%s))\n" % q["number"])
    if q["announce"] and "file" in sounds:
        out.append(" same => n,Playback(%s)\n" % sounds["file"])
    # Sans musique d'attente sur l'appliance, l'appelant entend la sonnerie (option r)
    out.append(" same => n,Queue(%s,%s,,,%d)\n" % (queue_name(q), "" if state.get("_moh") else "r", q["max_wait"]))
    out.append(" same => n,NoOp(File %s : ${QUEUESTATUS})\n" % q["number"])
    target = q["overflow"]
    if not target:
        out.append(" same => n,Playback(vm-goodbye)\n same => n,Hangup()\n")
    else:
        out.append(render_ivr_destination(state, target))
    return "".join(out)


def parse_recordings(entries, keep_days, now):
    """Fichiers d'enregistrement [(nom, taille, date)] : seuls les noms générés par render_recording sortent."""
    out = []
    for name, size, mtime in entries:
        if not RECORDING_RE.match(name):
            continue
        parts = name[:-4].split("-")
        out.append({"name": name, "size": int(size), "mtime": int(mtime), "caller": parts[2], "target": parts[3],
                    "start": "%s-%s-%s %s:%s:%s" % (parts[0][:4], parts[0][4:6], parts[0][6:8],
                                                     parts[1][:2], parts[1][2:4], parts[1][4:6]),
                    "expires": int(mtime) + keep_days * 86400})
    out.sort(key=lambda r: r["name"], reverse=True)
    return out


def sip_servers(addresses, phone_nets):
    """Adresses IPv4 de l'appliance à saisir dans les postes : d'abord celles des réseaux des téléphones."""
    import ipaddress
    nets = []
    for item in (phone_nets or "").replace(",", " ").split():
        try:
            nets.append(ipaddress.ip_network(item, strict=False))
        except ValueError:
            continue
    inside, other = [], []
    for a in addresses:
        try:
            iface = ipaddress.ip_interface(a["address"])
        except (KeyError, ValueError):
            continue
        if iface.version != 4:
            continue
        ip = str(iface.ip)
        (inside if any(iface.ip in n for n in nets) else other).append(ip)
    return inside + [ip for ip in other if ip not in inside]


def read_phone_nets(path="/etc/voipbuntu/appliance.conf"):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            for line in handle:
                m = re.match(r'^\s*PHONE_NETS\s*=\s*"?([^"\n]*)"?\s*$', line)
                if m:
                    return m.group(1)
    except OSError:
        pass
    return ""


def parse_contacts(text):
    """Analyse « pjsip show contacts » : {identifiant SIP: {"status", "rtt", "address"}}."""
    out = {}
    for line in text.splitlines():
        m = re.match(r"^\s*Contact:\s+(\S+?)/(\S+)\s+\S+\s+(Avail|NonQual|Unavail|Unknown|Created|Removed)\s*([0-9.]+|nan)?", line)
        if m and SIP_ID_RE.match(m.group(1)):
            uri = m.group(2)
            host = re.sub(r"^sips?:[^@]*@", "", uri).split(";")[0]
            out[m.group(1)] = {"status": m.group(3), "rtt": m.group(4) if m.group(4) not in (None, "nan") else None,
                               "address": host[:64]}
    return out


def parse_cdr(text, limit=100):
    """Analyse Master.csv de cdr_csv : les derniers appels, du plus récent au plus ancien.

    Seuls des champs contrôlés sortent : numéros (chiffres, * et #), dates, durées, issue, sens.
    """
    import csv
    import io
    rows = []
    for row in csv.reader(io.StringIO(text)):
        if len(row) < len(CDR_FIELDS):
            continue
        rec = dict(zip(CDR_FIELDS, row))
        if rec["dcontext"] not in ("voipbuntu-internes", "voipbuntu-entrant", "voipbuntu-accueil", "voipbuntu-menu",
                                   "voipbuntu-sda"):
            continue
        src, dst = rec["src"], rec["dst"]
        if src.lower() in ("anonymous", "unknown"):
            src = "anonymous"
        elif not re.match(r"^\+?[0-9*#]{0,24}$", src):
            continue
        if not re.match(r"^\+?[0-9*#a-z]{1,24}$", dst):
            continue
        if rec["dcontext"] != "voipbuntu-internes" or rec["channel"].startswith("PJSIP/%s-" % TRUNK):
            direction = "entrant"  # numéro direct vers un poste : contexte des postes, mais appel de la ligne
        elif rec["dstchannel"].startswith("PJSIP/%s-" % TRUNK):
            direction = "sortant"
        else:
            direction = "interne"
        if not re.match(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$", rec["start"]):
            continue
        try:
            duration, billsec = int(rec["duration"]), int(rec["billsec"])
        except ValueError:
            continue
        disposition = rec["disposition"] if rec["disposition"] in DISPOSITIONS else "FAILED"
        name = re.match(r'^"([^"]{0,40})"', rec["clid"])
        # Poste qui a sonné (PJSIP/<identifiant SIP>-xxxx), pour compter les appels manqués par poste
        rang = re.match(r"^PJSIP/([A-Za-z0-9][A-Za-z0-9._-]{0,31})-[0-9a-f]+$", rec["dstchannel"])
        rang = [rang.group(1)] if rang and rang.group(1) != TRUNK else []
        rows.append(({"start": rec["start"], "src": src, "src_name": name.group(1) if name else "",
                      "dst": dst, "duration": duration, "billsec": billsec, "disposition": disposition,
                      "voicemail": rec["lastapp"] == "VoiceMail", "direction": direction, "rang": rang},
                     rec["channel"][:80]))
    # Appel entrant qui fait sonner plusieurs postes : une ligne par poste appelé, on n'en garde qu'une
    merged, index = [], {}
    for rec, channel in rows:
        key = channel if rec["direction"] == "entrant" and channel else None
        if key and key in index:
            kept = merged[index[key]]
            rang = kept["rang"] + [u for u in rec["rang"] if u not in kept["rang"]]
            if kept["disposition"] != "ANSWERED" and rec["disposition"] == "ANSWERED":
                kept = merged[index[key]] = rec
            kept["rang"] = rang
            continue
        if key:
            index[key] = len(merged)
        merged.append(rec)
    merged.reverse()
    return merged[:limit]


def parse_channels(text):
    """Nombre d'appels en cours d'après « core show channels count »."""
    m = re.search(r"^(\d+) active calls?", text, re.M)
    return int(m.group(1)) if m else 0


def parse_registrar(text):
    """Analyse « database show registrar » : appareil (User-Agent) et adresse de chaque poste enregistré."""
    out = {}
    for line in text.splitlines():
        m = re.match(r"^/registrar/contact/([^;/\s]+);@[0-9a-f]+\s*:\s*(\{.*\})\s*$", line)
        if not m or not SIP_ID_RE.match(m.group(1)):
            continue
        try:
            data = json.loads(m.group(2))
        except ValueError:
            continue
        agent = re.sub(r"[\x00-\x1f\x7f]", "", str(data.get("user_agent", "")))[:80]
        via = str(data.get("via_addr", ""))[:45]
        port = str(data.get("via_port", ""))
        try:
            expires = int(data.get("expiration_time", 0))
        except ValueError:
            expires = 0
        prev = out.get(m.group(1))
        if prev is None or expires > prev["expires"]:
            out[m.group(1)] = {"user_agent": agent, "via": via + (":" + port if port.isdigit() else ""),
                               "expires": expires}
    return out


# Requêtes refusées par Asterisk (messages.log) : un appareil inconnu envoie souvent des OPTIONS
# (maintien de connexion) ou des INVITE avant même de tenter un REGISTER.
ATTEMPT_RE = re.compile(r"^\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\] NOTICE\[\d+\] res_pjsip/pjsip_distributor\.c: "
                        r"Request '(REGISTER|OPTIONS|INVITE|SUBSCRIBE|NOTIFY|PUBLISH|MESSAGE|REFER|INFO)' "
                        r"from '[^']*?<?sips?:([^@>'\s]{1,64})@[^']*' failed for '([0-9a-fA-F.:\[\]]{3,60}?):(\d+)' "
                        r"\(callid: [^)]*\) - (No matching endpoint found|Failed to authenticate)")
SIP_METHODS = ("REGISTER", "OPTIONS", "INVITE", "SUBSCRIBE", "NOTIFY", "PUBLISH", "MESSAGE", "REFER", "INFO")
MAX_ATTEMPT_KEYS = 500  # anti-saturation : au-delà, les nouveaux couples identifiant/adresse sont ignorés
SCAN_USERS = 3  # plus d'identifiants différents depuis une même adresse : balayage, jamais proposé


def parse_attempts(text, limit=50, bases=()):
    """Requêtes refusées relevées dans messages.log : appareils à configurer ou mot de passe faux.

    Une adresse qui essaie plus de SCAN_USERS identifiants différents est marquée « suspect » :
    c'est un balayage (outil d'attaque, appareil mal réglé), pas un téléphone à ajouter.
    Exception : une base DECT déclarée (bases : ses adresses) présente un compte par combiné,
    jusqu'à BASE_HANDSETS identifiants."""
    seen = {}
    for line in text.splitlines():
        m = ATTEMPT_RE.match(line)
        if not m:
            continue
        when, method, user, ip, port, reason = m.groups()
        if not SIP_ID_RE.match(user):
            continue
        key = (user, ip.strip("[]"))
        rec = seen.get(key)
        if rec is None:
            if len(seen) >= MAX_ATTEMPT_KEYS:
                continue
            rec = seen[key] = {"user": user, "address": ip.strip("[]"), "count": 0, "first": when,
                               "reason": "unknown", "methods": []}
        rec["count"] += 1
        rec["last"] = when
        rec["port"] = int(port) if 0 < int(port) < 65536 else 0
        if method not in rec["methods"]:
            rec["methods"].append(method)
        if reason == "No matching endpoint found":
            rec["unknown_seen"] = True
        rec["reason"] = "unknown" if rec.get("unknown_seen") else "auth"
    users_by_address = {}
    for user, address in seen:
        users_by_address.setdefault(address, set()).add(user.lower())
    out = sorted(seen.values(), key=lambda r: r["last"], reverse=True)
    for r in out:
        r.pop("unknown_seen", None)
        r["methods"].sort()
        r["suspect"] = len(users_by_address[r["address"]]) > (BASE_HANDSETS if r["address"] in bases else SCAN_USERS)
    return out[:limit]


# Modèle d'un appareil d'après son User-Agent : marque du provisionnement et modèle proposé
DEVICE_PATTERNS = (
    ("yealink", re.compile(r"Yealink\s+(?:SIP[- ]?)?(?:VP-)?([A-Z]{0,2}[0-9]{2,3}[A-Z]{0,2})\b", re.I)),
    ("snom", re.compile(r"snom\s*-?\s*([A-Z]?[0-9]{3}[A-Z]?)\b", re.I)),
    ("grandstream", re.compile(r"Grandstream\s+([A-Z]{2,4}[0-9]{3,4}[A-Z]?)\b", re.I)),
    ("fanvil", re.compile(r"Fanvil\s+([A-Z][0-9]{1,3}[A-Z]{0,3})\b", re.I)),
    ("gigaset", re.compile(r"Gigaset\s+([A-Z0-9][A-Za-z0-9 ]{1,23}?)(?:/|\s+[0-9]|$)", re.I)),
)


# Bases DECT reconnues au modèle : Gigaset N510/N670/N870, Yealink W60B/W70B/W80, Snom M300/M700/M900
DECT_MODELS = {"gigaset": re.compile(r"^N[0-9]{3}"), "yealink": re.compile(r"^W[0-9]{2}"),
               "snom": re.compile(r"^M[0-9]{2,3}")}


def guess_device(user_agent):
    """{"vendor", "model", "dect"} reconnus dans le User-Agent, ou {} : Gigaset n'est pas provisionnable."""
    agent = str(user_agent or "")[:120]
    for vendor, pattern in DEVICE_PATTERNS:
        m = pattern.search(agent)
        if m:
            model = re.sub(r"[^A-Za-z0-9+ -]", "", m.group(1)).strip()[:24]
            if vendor != "gigaset":
                model = model.upper().replace(" ", "")
            dect = bool(DECT_MODELS.get(vendor) and DECT_MODELS[vendor].match(model.upper()))
            return {"vendor": vendor, "model": model, "dect": dect}
    return {}


def used_numbers(state):
    """Tous les numéros déjà pris (postes, groupes, files, accueil vocal...)."""
    used = set(RESERVED) | set(EMERGENCY)
    for key, value in state.items():
        if isinstance(value, list):
            for item in value:
                if isinstance(item, dict) and isinstance(item.get("number"), str):
                    used.add(item["number"])
        elif isinstance(value, dict) and isinstance(value.get("number"), str):
            used.add(value["number"])
    return used


def suggest_number(state, sip_user=""):
    """Numéro proposé pour un appareil découvert : son identifiant s'il est numérique et libre,
    sinon le premier numéro libre après le plus grand poste à 3 chiffres (à partir de 100)."""
    used = used_numbers(state)
    if NUMBER_RE.match(str(sip_user)) and sip_user not in used:
        return sip_user
    numbers = [int(e["number"]) for e in state.get("extensions", []) if re.match(r"^[1-9][0-9]{2}$", e.get("number", ""))]
    start = max(numbers) + 1 if numbers else 100
    for candidate in list(range(start, 1000)) + list(range(100, start)):
        if str(candidate) not in used:
            return str(candidate)
    return ""


def is_ip(value):
    import ipaddress
    try:
        ipaddress.ip_address(str(value))
        return True
    except ValueError:
        return False


def network_of(address, phone_nets):
    """Réseau des téléphones (CIDR) d'où vient une adresse « ip » ou « ip:port », ou None."""
    import ipaddress
    host = (address or "").strip()
    if host.startswith("["):
        host = host[1:].split("]")[0]
    elif host.count(":") == 1:
        host = host.split(":")[0]
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return None
    for item in (phone_nets or "").replace(",", " ").split():
        try:
            net = ipaddress.ip_network(item, strict=False)
        except ValueError:
            continue
        if ip.version == net.version and ip in net:
            return str(net)
    return None


def parse_registration(text):
    """État de l'enregistrement de la ligne d'après « pjsip show registrations »."""
    for line in text.splitlines():
        m = re.match(r"^\s*%s/\S+\s+%s-auth\s+(Registered|Unregistered|Rejected)\b" % (TRUNK, TRUNK), line)
        if m:
            return m.group(1).lower()
    return None
