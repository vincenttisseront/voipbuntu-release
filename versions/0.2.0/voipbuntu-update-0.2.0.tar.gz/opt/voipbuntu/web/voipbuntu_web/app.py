"""Serveur HTTP de la console VOIPbuntu (bibliothèque standard uniquement).

Il écoute en local (127.0.0.1:8080) ; nginx assure le TLS devant lui et lui
transmet l'adresse du client dans X-Real-IP.
"""

import argparse
import hmac
import json
import logging
import mimetypes
import os
import re
import sys
import time
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs

from . import pbx, security, sysinfo
from .db import Database
from .i18n import Translator, LANGUAGES
from .jobs import WorkerClient, WorkerUnavailable, ACTIONS

LOG = logging.getLogger("voipbuntu-web")
COOKIE = "pxb_session"
MAX_BODY = 64 * 1024
BACKUP_FORMAT = "voipbuntu-backup"
LOG_SOURCES = ("asterisk", "system")
USERNAME_RE = re.compile(r"^[a-z_][a-z0-9_.-]{0,31}$")
CSP = ("default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
       "connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")


class ApiError(Exception):
    def __init__(self, status, message, extra=None):
        super().__init__(message)
        self.status = status
        self.message = message
        self.extra = extra or {}


class Context:
    def __init__(self, db, static_dir, version, worker, data_path, trust_proxy, secure_cookie,
                 update_state="/var/lib/voipbuntu/update.json", pbx_state=pbx.DEFAULT_STATE):
        self.db = db
        self.pbx_state = pbx_state
        self.appliance_conf = "/etc/voipbuntu/appliance.conf"
        self.update_state = update_state
        self.static_dir = os.path.realpath(static_dir)
        self.version = version
        self.worker = worker
        self.data_path = data_path
        self.trust_proxy = trust_proxy
        self.secure_cookie = secure_cookie
        self.sessions = security.SessionStore(db)
        self.throttle = security.LoginThrottle(db)
        self.translator = Translator(static_dir)
        # Empreinte factice : un identifiant inconnu coûte autant qu'un vrai.
        self.dummy_hash = security.hash_password(security.new_token())


class Handler(BaseHTTPRequestHandler):
    server_version = "VOIPbuntu"
    sys_version = ""
    protocol_version = "HTTP/1.1"
    ctx = None  # renseigné par make_server

    # ------------------------------------------------------------ utilitaires
    def log_message(self, fmt, *args):  # journal sans corps ni cookie
        LOG.info("%s %s", self.remote, fmt % args)

    @property
    def remote(self):
        if self.ctx.trust_proxy:
            real = self.headers.get("X-Real-IP", "")
            if real and len(real) < 64:
                return real
        return self.client_address[0]

    @property
    def lang(self):
        cookie = self.cookies.get("pxb_lang")
        if cookie and cookie.value in LANGUAGES:
            return cookie.value
        accept = self.headers.get("Accept-Language", "")
        return "en" if accept[:2].lower() == "en" else "fr"

    @property
    def cookies(self):
        jar = SimpleCookie()
        try:
            jar.load(self.headers.get("Cookie", ""))
        except Exception:
            pass
        return jar

    def t(self, text):
        return self.ctx.translator.translate(text, self.lang)

    def security_headers(self):
        self.send_header("Content-Security-Policy", CSP)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")

    def send_json(self, status, payload, cookies=()):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for cookie in cookies:
            self.send_header("Set-Cookie", cookie)
        self.security_headers()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def session_cookie(self, token, max_age=None):
        parts = ["%s=%s" % (COOKIE, token), "Path=/", "HttpOnly", "SameSite=Strict"]
        if self.ctx.secure_cookie:
            parts.append("Secure")
        if max_age is not None:
            parts.append("Max-Age=%d" % max_age)
        return "; ".join(parts)

    def read_json(self):
        ctype = self.headers.get("Content-Type", "").split(";")[0].strip().lower()
        if ctype != "application/json":
            raise ApiError(HTTPStatus.UNSUPPORTED_MEDIA_TYPE, "Requête invalide.")
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.") from None
        if length < 0 or length > MAX_BODY:
            raise ApiError(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "Requête trop volumineuse.")
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode("utf-8")) if raw else {}
        except (ValueError, UnicodeDecodeError):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.") from None
        if not isinstance(data, dict):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.")
        return data

    def check_origin(self):
        origin = self.headers.get("Origin")
        if origin is None:
            return
        host = self.headers.get("Host", "")
        if urlsplit(origin).netloc != host:
            raise ApiError(HTTPStatus.FORBIDDEN, "Origine refusée.")

    def current_session(self):
        morsel = self.cookies.get(COOKIE)
        return self.ctx.sessions.get(morsel.value if morsel else None)

    def require_session(self, write=False):
        session = self.current_session()
        if session is None:
            raise ApiError(HTTPStatus.UNAUTHORIZED, "Session expirée, reconnectez-vous.")
        if write:
            self.check_origin()
            token = self.headers.get("X-CSRF-Token", "")
            if not token or not hmac.compare_digest(token, session["csrf"]):
                raise ApiError(HTTPStatus.FORBIDDEN, "Jeton de sécurité invalide, rechargez la page.")
        return session

    # ---------------------------------------------------------------- routage
    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        self.dispatch("GET")

    def do_POST(self):
        self.dispatch("POST")

    def do_PUT(self):
        self.dispatch("PUT")

    def do_DELETE(self):
        self.dispatch("DELETE")

    def dispatch(self, method):
        path = urlsplit(self.path).path
        try:
            if path.startswith("/api/"):
                route = ROUTES.get((method if method != "HEAD" else "GET", path))
                if route is None:
                    raise ApiError(HTTPStatus.NOT_FOUND, "Ressource introuvable.")
                route(self)
            elif method in ("GET", "HEAD"):
                self.serve_static(path)
            else:
                raise ApiError(HTTPStatus.METHOD_NOT_ALLOWED, "Méthode non autorisée.")
        except ApiError as exc:
            payload = {"error": self.t(exc.message)}
            payload.update(exc.extra)
            self.send_json(exc.status, payload)
        except Exception:
            LOG.exception("erreur interne sur %s %s", method, path)
            self.send_json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": self.t("Erreur interne.")})

    def serve_static(self, path):
        if path in ("/", ""):
            path = "/index.html"
        relative = os.path.normpath(path.lstrip("/"))
        full = os.path.realpath(os.path.join(self.ctx.static_dir, relative))
        if not full.startswith(self.ctx.static_dir + os.sep) or not os.path.isfile(full):
            raise ApiError(HTTPStatus.NOT_FOUND, "Ressource introuvable.")
        ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript", "application/json"):
            ctype += "; charset=utf-8"
        with open(full, "rb") as handle:
            body = handle.read()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.security_headers()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    # ------------------------------------------------------------------- API
    def api_login(self):
        self.check_origin()
        data = self.read_json()
        username = data.get("username")
        password = data.get("password")
        if not isinstance(username, str) or not isinstance(password, str) or not USERNAME_RE.match(username) \
                or len(password) > 256:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Identifiant ou mot de passe incorrect.")
        keys = ["ip:" + self.remote, "user:" + username]
        wait = self.ctx.throttle.locked_for(keys)
        if wait:
            raise ApiError(HTTPStatus.TOO_MANY_REQUESTS, "Trop de tentatives, réessayez plus tard.", {"retry": wait})
        user = self.ctx.db.get_user(username)
        stored = user[1] if user else self.ctx.dummy_hash
        if not security.verify_password(password, stored) or user is None:
            self.ctx.throttle.failure(keys)
            self.ctx.db.audit("login-failed", username, self.remote)
            raise ApiError(HTTPStatus.UNAUTHORIZED, "Identifiant ou mot de passe incorrect.")
        self.ctx.throttle.success(keys)
        token, csrf = self.ctx.sessions.create(username)
        self.ctx.db.audit("login", username, self.remote)
        self.send_json(HTTPStatus.OK, {"user": username, "csrf": csrf}, [self.session_cookie(token)])

    def api_logout(self):
        session = self.require_session(write=True)
        morsel = self.cookies.get(COOKIE)
        self.ctx.sessions.delete(morsel.value if morsel else "")
        self.ctx.db.audit("logout", session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True}, [self.session_cookie("", max_age=0)])

    def api_session(self):
        session = self.current_session()
        payload = {"version": self.ctx.version, "lang": self.lang, "configured": self.ctx.db.has_users()}
        if session:
            payload.update({"user": session["username"], "csrf": session["csrf"]})
        self.send_json(HTTPStatus.OK, payload)

    def api_status(self):
        self.require_session()
        payload = sysinfo.status(self.ctx.version, self.ctx.data_path)
        payload["services"] = sysinfo.service_states()
        self.send_json(HTTPStatus.OK, payload)

    def api_metrics(self):
        self.require_session()
        query = parse_qs(urlsplit(self.path).query)
        range_name = (query.get("range") or ["1h"])[0]
        if range_name not in sysinfo.RANGES:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Période inconnue.")
        self.send_json(HTTPStatus.OK, sysinfo.series(self.ctx.db, range_name))

    def api_password(self):
        session = self.require_session(write=True)
        data = self.read_json()
        current, new = data.get("current"), data.get("new")
        if not isinstance(current, str) or not isinstance(new, str):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.")
        user = self.ctx.db.get_user(session["username"])
        if user is None or not security.verify_password(current, user[1]):
            self.ctx.db.audit("password-change-failed", session["username"], self.remote)
            raise ApiError(HTTPStatus.FORBIDDEN, "Mot de passe actuel incorrect.")
        problem = security.password_problem(new)
        if problem:
            raise ApiError(HTTPStatus.BAD_REQUEST, problem)
        self.ctx.db.set_password(session["username"], security.hash_password(new))
        self.ctx.sessions.delete_user(session["username"])
        token, csrf = self.ctx.sessions.create(session["username"])
        self.ctx.db.audit("password-changed", session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "csrf": csrf}, [self.session_cookie(token)])

    def api_update(self):
        self.require_session()
        state = {}
        try:
            with open(self.ctx.update_state, "r", encoding="utf-8") as handle:
                state = json.load(handle)
        except (OSError, ValueError):
            state = {}
        if not isinstance(state, dict):
            state = {}
        version_re = re.compile(r"^\d+\.\d+\.\d+$")
        latest = state.get("latest") if isinstance(state.get("latest"), str) and version_re.match(state["latest"]) else None
        checked = state.get("checked") if isinstance(state.get("checked"), (int, float)) else None
        error = state.get("error") if isinstance(state.get("error"), str) else None
        notes = state.get("notes") if isinstance(state.get("notes"), str) else ""
        self.send_json(HTTPStatus.OK, {
            "current": self.ctx.version, "latest": latest, "checked": checked,
            "available": bool(latest) and _vtuple(latest) > _vtuple(self.ctx.version),
            "notes": notes[:4000], "error": error[:300] if error else None})

    # ------------------------------------------------------------ téléphonie
    def pbx_load(self):
        try:
            return pbx.load(self.ctx.pbx_state)
        except pbx.PbxError:
            raise ApiError(HTTPStatus.INTERNAL_SERVER_ERROR, "Configuration téléphonique illisible.") from None

    def pbx_commit(self, state, username, event):
        pbx.save(state, self.ctx.pbx_state)
        self.ctx.db.audit(event, username, self.remote)
        try:
            self.ctx.worker.submit("pbx-apply", username)
            return True
        except WorkerUnavailable:
            return False

    def api_pbx(self):
        self.require_session()
        state = self.pbx_load()
        try:
            live = self.ctx.worker.pbx_status()
        except WorkerUnavailable:
            live = {"running": None, "contacts": {}}
        contacts = live.get("contacts") if isinstance(live.get("contacts"), dict) else {}
        view = pbx.public(state)
        for ext in view["extensions"]:
            c = contacts.get(ext["number"])
            ext["registered"] = bool(c) and c.get("status") in ("Avail", "NonQual", "Created")
            ext["address"] = (c or {}).get("address")
            ext["rtt"] = (c or {}).get("rtt")
        view["running"] = live.get("running")
        view["calls"] = live.get("calls") if isinstance(live.get("calls"), int) else None
        self.send_json(HTTPStatus.OK, view)

    def api_pbx_calls(self):
        self.require_session()
        try:
            data = self.ctx.worker.pbx_calls()
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None
        calls = data.get("calls") if isinstance(data.get("calls"), list) else []
        self.send_json(HTTPStatus.OK, {"calls": calls[:200], "error": bool(data.get("error"))})

    def api_logs(self):
        self.require_session()
        source = (parse_qs(urlsplit(self.path).query).get("source") or ["asterisk"])[0]
        if source not in LOG_SOURCES:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Journal inconnu.")
        try:
            data = self.ctx.worker.logs(source)
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None
        lines = data.get("lines") if isinstance(data.get("lines"), list) else []
        self.send_json(HTTPStatus.OK, {"source": source, "lines": [str(x)[:500] for x in lines[-200:]],
                                       "error": bool(data.get("error"))})

    # ------------------------------------------------------------ sauvegarde
    def api_backup(self):
        session = self.require_session()
        state = self.pbx_load()
        payload = {"format": BACKUP_FORMAT, "format_version": 1, "version": self.ctx.version,
                   "created": int(time.time()), "pbx": state}
        body = json.dumps(payload, ensure_ascii=False, indent=1).encode("utf-8")
        self.ctx.db.audit("backup:export", session["username"], self.remote)
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Disposition", 'attachment; filename="voipbuntu-sauvegarde-%s.json"'
                         % time.strftime("%Y%m%d-%H%M"))
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.security_headers()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def api_restore(self):
        session = self.require_session(write=True)
        data = self.read_json()
        if data.get("format") != BACKUP_FORMAT or data.get("format_version") != 1:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Ce fichier n'est pas une sauvegarde VOIPbuntu.")
        try:
            state = pbx.validate(data.get("pbx"))
        except pbx.PbxError:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Sauvegarde invalide : configuration téléphonique incohérente.") from None
        applied = self.pbx_commit(state, session["username"], "backup:restore")
        self.send_json(HTTPStatus.OK, {"ok": True, "extensions": len(state["extensions"]), "applied": applied})

    def api_pbx_create(self):
        session = self.require_session(write=True)
        data = self.read_json()
        number, name = str(data.get("number", "")).strip(), str(data.get("name", "")).strip()
        if not pbx.NUMBER_RE.match(number):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Numéro invalide : de 2 à 6 chiffres, sans 0 en tête.")
        if not pbx.NAME_RE.match(name):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Nom invalide : 1 à 40 caractères, sans guillemets ni crochets.")
        state = self.pbx_load()
        if any(e["number"] == number for e in state["extensions"]):
            raise ApiError(HTTPStatus.CONFLICT, "Ce numéro existe déjà.")
        if len(state["extensions"]) >= pbx.MAX_EXTENSIONS:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Nombre maximal de postes atteint.")
        ext = {"number": number, "name": name, "secret": pbx.new_secret(), "pin": pbx.new_pin(),
               "voicemail": bool(data.get("voicemail", True))}
        state["extensions"].append(ext)
        applied = self.pbx_commit(state, session["username"], "pbx:create:" + number)
        self.send_json(HTTPStatus.CREATED, dict(self.sheet(ext), applied=applied))

    def api_pbx_delete(self):
        session = self.require_session(write=True)
        number = str(self.read_json().get("number", ""))
        state = self.pbx_load()
        kept = [e for e in state["extensions"] if e["number"] != number]
        if len(kept) == len(state["extensions"]):
            raise ApiError(HTTPStatus.NOT_FOUND, "Poste introuvable.")
        state["extensions"] = kept
        applied = self.pbx_commit(state, session["username"], "pbx:delete:" + number)
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied})

    def api_pbx_secret(self):
        session = self.require_session(write=True)
        data = self.read_json()
        number, renew = str(data.get("number", "")), bool(data.get("renew", False))
        state = self.pbx_load()
        ext = next((e for e in state["extensions"] if e["number"] == number), None)
        if ext is None:
            raise ApiError(HTTPStatus.NOT_FOUND, "Poste introuvable.")
        applied = None
        if renew:
            ext["secret"] = pbx.new_secret()
            applied = self.pbx_commit(state, session["username"], "pbx:renew:" + number)
        else:
            self.ctx.db.audit("pbx:reveal:" + number, session["username"], self.remote)
        self.send_json(HTTPStatus.OK, dict(self.sheet(ext), applied=applied))

    def sheet(self, ext):
        """Fiche de configuration d'un poste (base DECT ou téléphone SIP)."""
        servers = pbx.sip_servers(sysinfo.ip_addresses(), pbx.read_phone_nets(self.ctx.appliance_conf))
        return {"number": ext["number"], "name": ext["name"], "secret": ext["secret"], "pin": ext["pin"],
                "servers": servers, "port": 5060, "transport": "UDP", "voicemail_code": "*97",
                "voicemail": ext["voicemail"]}

    def api_jobs_list(self):
        self.require_session()
        try:
            self.send_json(HTTPStatus.OK, self.ctx.worker.list())
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None

    def api_jobs_submit(self):
        session = self.require_session(write=True)
        data = self.read_json()
        action = data.get("action")
        if action not in ACTIONS:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Action inconnue.")
        try:
            result = self.ctx.worker.submit(action, session["username"])
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None
        self.ctx.db.audit("job:" + action, session["username"], self.remote)
        self.send_json(HTTPStatus.ACCEPTED, result)

    def api_audit(self):
        self.require_session()
        with self.ctx.db.lock:
            rows = self.ctx.db.conn.execute(
                "SELECT ts, username, remote, event FROM audit ORDER BY ts DESC LIMIT 200").fetchall()
        self.send_json(HTTPStatus.OK, {"events": [
            {"ts": r[0], "user": r[1], "remote": r[2], "event": r[3]} for r in rows]})


ROUTES = {
    ("POST", "/api/login"): Handler.api_login,
    ("POST", "/api/logout"): Handler.api_logout,
    ("GET", "/api/session"): Handler.api_session,
    ("GET", "/api/status"): Handler.api_status,
    ("GET", "/api/metrics"): Handler.api_metrics,
    ("POST", "/api/password"): Handler.api_password,
    ("GET", "/api/jobs"): Handler.api_jobs_list,
    ("GET", "/api/update"): Handler.api_update,
    ("GET", "/api/pbx"): Handler.api_pbx,
    ("POST", "/api/pbx/extensions"): Handler.api_pbx_create,
    ("POST", "/api/pbx/delete"): Handler.api_pbx_delete,
    ("POST", "/api/pbx/secret"): Handler.api_pbx_secret,
    ("GET", "/api/pbx/calls"): Handler.api_pbx_calls,
    ("GET", "/api/logs"): Handler.api_logs,
    ("GET", "/api/backup"): Handler.api_backup,
    ("POST", "/api/restore"): Handler.api_restore,
    ("POST", "/api/jobs"): Handler.api_jobs_submit,
    ("GET", "/api/audit"): Handler.api_audit,
}


def _vtuple(value):
    m = re.match(r"^(\d+)\.(\d+)\.(\d+)", value or "")
    return tuple(int(x) for x in m.groups()) if m else (0, 0, 0)


def read_version(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            value = handle.read().strip()
    except OSError:
        return "0.0.0"
    return value if re.match(r"^\d+\.\d+\.\d+([.-][0-9A-Za-z.-]+)?$", value) else "0.0.0"


def make_server(args):
    db = Database(args.db)
    ctx = Context(db, args.static, read_version(args.version_file), WorkerClient(args.worker_socket),
                  args.data, trust_proxy=args.trust_proxy, secure_cookie=not args.insecure_cookie,
                  update_state=args.update_state, pbx_state=args.pbx_state)
    handler = type("BoundHandler", (Handler,), {"ctx": ctx})
    server = ThreadingHTTPServer((args.listen, args.port), handler)
    server.daemon_threads = True
    return server, ctx


def parse_args(argv=None):
    base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    parser = argparse.ArgumentParser(description="Console web VOIPbuntu")
    parser.add_argument("--listen", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--db", default="/var/lib/voipbuntu/web.db")
    parser.add_argument("--static", default=os.path.join(base, "static"))
    parser.add_argument("--version-file", default="/opt/voipbuntu/VERSION")
    parser.add_argument("--worker-socket", default="/run/voipbuntu/worker.sock")
    parser.add_argument("--data", default="/srv/voipbuntu")
    parser.add_argument("--update-state", default="/var/lib/voipbuntu/update.json")
    parser.add_argument("--pbx-state", default=pbx.DEFAULT_STATE)
    parser.add_argument("--trust-proxy", action="store_true")
    parser.add_argument("--insecure-cookie", action="store_true", help="tests uniquement")
    parser.add_argument("--no-sampler", action="store_true")
    return parser.parse_args(argv)


def main(argv=None):
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s", stream=sys.stderr)
    args = parse_args(argv)
    server, ctx = make_server(args)
    if not args.no_sampler:
        sysinfo.Sampler(ctx.db, args.data).start()
    LOG.info("console VOIPbuntu %s à l'écoute sur %s:%d", ctx.version, args.listen, args.port)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
