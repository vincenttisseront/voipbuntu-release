"""Copie automatique des sauvegardes hors de l'appliance : partage Windows (SMB) ou SFTP.

Réglages dans /var/lib/voipbuntu/backup-copy.json (tenus par la console). Le mot
de passe du partage y est chiffré avec la clé de l'appliance
(/etc/voipbuntu/secrets.key, root:voipweb 0640, absente des sauvegardes) et n'est
jamais renvoyé à la console. La copie elle-même tourne en root (voipbuntu-backup,
par la file d'attente) : smbclient pour SMB, sftp avec une clé propre à
l'appliance et l'empreinte du serveur épinglée pour SFTP.
"""

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import subprocess
import tempfile

from . import backup

DEFAULT_SETTINGS = "/var/lib/voipbuntu/backup-copy.json"
DEFAULT_STATUS = "/var/lib/voipbuntu/backup-copy-status.json"
DEFAULT_KEY = "/etc/voipbuntu/secrets.key"
SFTP_DIR = "/etc/voipbuntu/backup-sftp"           # clé privée SFTP (root seul)
SFTP_PUBLIC = "/var/lib/voipbuntu/backup-sftp.pub"  # clé publique, affichée par la console
MODES = ("none", "smb", "sftp")
HOST_RE = re.compile(r"^(?=.{1,253}$)[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$")
SHARE_RE = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9 _.$-]{0,79}$")
SEGMENT_RE = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9 _.-]{0,63}$")
USER_RE = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_.@-]{0,63}$")
DOMAIN_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9.-]{0,62}$")
FINGERPRINT_RE = re.compile(r"^SHA256:[A-Za-z0-9+/]{43}$")
PASSWORD_MAX = 128
TEST_NAME = "voipbuntu-essai-copie.txt"
REMOTE_NAME_RE = re.compile(r"voipbuntu-sauvegarde-\d{8}-\d{4}(?:-auto)?\.(?:json|tar\.gz)")
ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LANG": "C.UTF-8"}


class CopyError(ValueError):
    pass


# ------------------------------------------------------------------ chiffrement
def _master(key_path):
    try:
        with open(key_path, "rb") as h:
            raw = h.read(4096).strip()
    except OSError:
        raise CopyError("Clé de chiffrement de l'appliance absente (/etc/voipbuntu/secrets.key).") from None
    try:
        key = base64.b64decode(raw, validate=True)
    except ValueError:
        key = raw
    if len(key) < 16:
        raise CopyError("Clé de chiffrement de l'appliance invalide.")
    return key


def _stream(key, nonce, length):
    out, counter = b"", 0
    while len(out) < length:
        out += hmac.new(key, nonce + counter.to_bytes(8, "big"), hashlib.sha256).digest()
        counter += 1
    return out[:length]


def encrypt(text, key_path=DEFAULT_KEY):
    """Chiffre puis authentifie (HMAC-SHA256 en mode compteur, puis HMAC-SHA256 du tout)."""
    master = _master(key_path)
    ek = hmac.new(master, b"voipbuntu-backup-copy:enc", hashlib.sha256).digest()
    mk = hmac.new(master, b"voipbuntu-backup-copy:mac", hashlib.sha256).digest()
    nonce = secrets.token_bytes(16)
    data = text.encode("utf-8")
    ct = bytes(a ^ b for a, b in zip(data, _stream(ek, nonce, len(data))))
    tag = hmac.new(mk, nonce + ct, hashlib.sha256).digest()
    return "v1:" + base64.b64encode(nonce + ct + tag).decode("ascii")


def decrypt(token, key_path=DEFAULT_KEY):
    if not isinstance(token, str) or not token.startswith("v1:"):
        raise CopyError("Mot de passe du partage non renseigné.")
    master = _master(key_path)
    ek = hmac.new(master, b"voipbuntu-backup-copy:enc", hashlib.sha256).digest()
    mk = hmac.new(master, b"voipbuntu-backup-copy:mac", hashlib.sha256).digest()
    try:
        raw = base64.b64decode(token[3:], validate=True)
    except ValueError:
        raise CopyError("Mot de passe du partage illisible : ressaisissez-le.") from None
    if len(raw) < 48:
        raise CopyError("Mot de passe du partage illisible : ressaisissez-le.")
    nonce, ct, tag = raw[:16], raw[16:-32], raw[-32:]
    if not hmac.compare_digest(tag, hmac.new(mk, nonce + ct, hashlib.sha256).digest()):
        raise CopyError("Mot de passe du partage illisible (autre appliance ?) : ressaisissez-le.")
    return bytes(a ^ b for a, b in zip(ct, _stream(ek, nonce, len(ct)))).decode("utf-8")


# ------------------------------------------------------------------ réglages
def default_settings():
    return {"mode": "none", "keep": 30,
            "smb": {"server": "", "share": "", "folder": "", "domain": "", "username": "", "password": ""},
            "sftp": {"host": "", "port": 22, "username": "", "folder": "", "fingerprint": ""}}


def _folder(value):
    value = str(value or "").strip().replace("\\", "/").strip("/")
    if not value:
        return ""
    parts = value.split("/")
    if len(parts) > 8 or not all(SEGMENT_RE.match(p) and p not in (".", "..") for p in parts):
        raise CopyError("Dossier invalide : lettres, chiffres, espaces, tirets et points, séparés par /.")
    return "/".join(parts)


def validate(data, current=None, key_path=DEFAULT_KEY):
    """Réglages envoyés par la console. Un mot de passe vide garde celui déjà enregistré."""
    if not isinstance(data, dict):
        raise CopyError("Réglages de copie invalides.")
    cur = current or default_settings()
    s = default_settings()
    mode = data.get("mode", "none")
    if mode not in MODES:
        raise CopyError("Type de copie inconnu.")
    s["mode"] = mode
    try:
        s["keep"] = int(data.get("keep", 30))
    except (TypeError, ValueError):
        raise CopyError("Nombre de copies gardées invalide.") from None
    if not 1 <= s["keep"] <= 365:
        raise CopyError("Nombre de copies gardées entre 1 et 365.")
    smb = data.get("smb") if isinstance(data.get("smb"), dict) else {}
    sftp = data.get("sftp") if isinstance(data.get("sftp"), dict) else {}
    # SMB
    server = str(smb.get("server") or "").strip().lstrip("\\/")
    if server and not HOST_RE.match(server):
        raise CopyError("Serveur du partage invalide : nom ou adresse IP.")
    share = str(smb.get("share") or "").strip().strip("\\/")
    if share and not SHARE_RE.match(share):
        raise CopyError("Nom du partage invalide.")
    domain = str(smb.get("domain") or "").strip()
    if domain and not DOMAIN_RE.match(domain):
        raise CopyError("Domaine invalide.")
    user = str(smb.get("username") or "").strip()
    if "\\" in user and not domain:  # DOMAINE\compte saisi d'un bloc
        domain, user = user.split("\\", 1)
        if not DOMAIN_RE.match(domain):
            raise CopyError("Domaine invalide.")
    if user and not USER_RE.match(user):
        raise CopyError("Compte du partage invalide.")
    password = smb.get("password")
    if password not in (None, ""):
        if not isinstance(password, str) or len(password) > PASSWORD_MAX or any(c in password for c in "\r\n\0"):
            raise CopyError("Mot de passe du partage invalide (128 caractères au plus).")
        enc = encrypt(password, key_path)
    elif smb.get("clear_password"):
        enc = ""
    else:
        enc = cur.get("smb", {}).get("password", "")
    s["smb"] = {"server": server, "share": share, "folder": _folder(smb.get("folder")), "domain": domain,
                "username": user, "password": enc}
    # SFTP
    host = str(sftp.get("host") or "").strip()
    if host and not HOST_RE.match(host):
        raise CopyError("Serveur SFTP invalide : nom ou adresse IP.")
    try:
        port = int(sftp.get("port") or 22)
    except (TypeError, ValueError):
        raise CopyError("Port SFTP invalide.") from None
    if not 1 <= port <= 65535:
        raise CopyError("Port SFTP invalide.")
    suser = str(sftp.get("username") or "").strip()
    if suser and not USER_RE.match(suser):
        raise CopyError("Compte SFTP invalide.")
    fp = str(sftp.get("fingerprint") or "").strip()
    if fp and not FINGERPRINT_RE.match(fp):
        raise CopyError("Empreinte du serveur invalide : SHA256:… (43 caractères après SHA256:).")
    s["sftp"] = {"host": host, "port": port, "username": suser, "folder": _folder(sftp.get("folder")), "fingerprint": fp}
    if mode == "smb" and not (server and share and user):
        raise CopyError("Indiquez le serveur, le partage et le compte.")
    if mode == "smb" and not s["smb"]["password"]:
        raise CopyError("Indiquez le mot de passe du compte.")
    if mode == "sftp" and not (host and suser):
        raise CopyError("Indiquez le serveur SFTP et le compte.")
    return s


def load(path=DEFAULT_SETTINGS):
    try:
        data = backup.read_regular(path, 65536)
        if data is None:
            return default_settings()
        raw = json.loads(data.decode("utf-8"))
        s = default_settings()
        s.update({k: raw[k] for k in ("mode", "keep") if k in raw})
        for part in ("smb", "sftp"):
            if isinstance(raw.get(part), dict):
                s[part].update({k: raw[part][k] for k in s[part] if k in raw[part]})
        return s
    except (OSError, ValueError, UnicodeDecodeError):
        return default_settings()


def save(settings, path=DEFAULT_SETTINGS, owner=None):
    backup.write_json(path, settings, owner=owner, indent=1)
    return settings


def public(settings):
    """Réglages renvoyés à la console : jamais le mot de passe, seulement s'il est renseigné."""
    out = json.loads(json.dumps(settings))
    out["smb"]["password_set"] = bool(out["smb"].pop("password", ""))
    return out


def for_backup(settings):
    """Réglages mis dans l'archive : sans le mot de passe (la clé ne quitte pas l'appliance)."""
    out = json.loads(json.dumps(settings))
    out["smb"]["password"] = ""
    return out


def restore(saved, current):
    """Réglages d'une sauvegarde : le mot de passe actuel est gardé s'il vise le même compte."""
    try:
        s = validate(dict(saved, mode="none"), current, key_path=os.devnull)
    except CopyError:
        return current, False
    s["mode"] = saved.get("mode") if saved.get("mode") in MODES else "none"
    same = all(current["smb"].get(k) == s["smb"][k] for k in ("server", "share", "username"))
    s["smb"]["password"] = current["smb"].get("password", "") if same else ""
    need_password = s["mode"] == "smb" and not s["smb"]["password"]
    return s, need_password


def to_rotate(names, keep):
    """Sauvegardes automatiques distantes à effacer : au-delà des keep plus récentes."""
    autos = sorted({n for n in names if REMOTE_NAME_RE.fullmatch(n) and "-auto." in n}, reverse=True)
    return autos[keep:]


def remote_names(text):
    return sorted(set(REMOTE_NAME_RE.findall(text or "")))


# ------------------------------------------------------------------ SMB (root)
class Runner:
    """Lance les commandes de copie ; les tests remplacent les binaires par des faux."""

    def __init__(self, smbclient="smbclient", sftp="sftp", keyscan="ssh-keyscan", keygen="ssh-keygen", timeout=300):
        self.smbclient, self.sftp, self.keyscan, self.keygen, self.timeout = smbclient, sftp, keyscan, keygen, timeout

    def run(self, argv, data=None, timeout=None):
        try:
            p = subprocess.run(argv, input=data, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=ENV,
                               timeout=timeout or self.timeout, cwd="/")
        except FileNotFoundError:
            raise CopyError("outil absent : %s" % os.path.basename(argv[0])) from None
        except subprocess.TimeoutExpired:
            raise CopyError("serveur injoignable (délai dépassé)") from None
        return p.returncode, p.stdout.decode("utf-8", "replace")


def smb_quote(value):
    return '"%s"' % value


def smb_error(out):
    m = re.search(r"NT_STATUS_[A-Z_]+", out or "")
    return m.group(0) if m else (out or "").strip()[-200:]


SMB_HINTS = {
    "NT_STATUS_LOGON_FAILURE": "compte ou mot de passe refusé",
    "NT_STATUS_ACCESS_DENIED": "accès refusé au dossier",
    "NT_STATUS_BAD_NETWORK_NAME": "partage introuvable",
    "NT_STATUS_OBJECT_PATH_NOT_FOUND": "dossier introuvable",
    "NT_STATUS_HOST_UNREACHABLE": "serveur injoignable",
    "NT_STATUS_IO_TIMEOUT": "serveur injoignable",
    "NT_STATUS_CONNECTION_REFUSED": "serveur injoignable (port 445 fermé)",
    "NT_STATUS_ACCOUNT_LOCKED_OUT": "compte verrouillé",
    "NT_STATUS_PASSWORD_EXPIRED": "mot de passe expiré",
}


def smb_failure(out):
    code = smb_error(out)
    return "%s (%s)" % (SMB_HINTS[code], code) if code in SMB_HINTS else code or "échec"


class Smb:
    def __init__(self, settings, password, runner, workdir):
        self.s, self.r = settings["smb"], runner
        self.auth = os.path.join(workdir, "smb-auth")
        fd = os.open(self.auth, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as h:
            h.write("username = %s\npassword = %s\n" % (self.s["username"], password))
            if self.s["domain"]:
                h.write("domain = %s\n" % self.s["domain"])

    def call(self, commands):
        argv = [self.r.smbclient, "//%s/%s" % (self.s["server"], self.s["share"]), "-A", self.auth,
                "-m", "SMB3", "-c", commands]
        rc, out = self.r.run(argv)
        failed = rc != 0 or "NT_STATUS_" in out
        return not failed, out

    def cd(self):
        return "cd %s; " % smb_quote(self.s["folder"]) if self.s["folder"] else ""

    def prepare(self):
        path = ""
        for part in self.s["folder"].split("/") if self.s["folder"] else []:
            path = path + "/" + part if path else part
            self.call("mkdir %s" % smb_quote(path))  # déjà présent : erreur ignorée

    def put(self, local, name):
        ok, out = self.call(self.cd() + "put %s %s" % (smb_quote(local), smb_quote(name)))
        if not ok:
            raise CopyError("copie refusée par le partage : %s" % smb_failure(out))

    def names(self):
        ok, out = self.call(self.cd() + "ls")
        if not ok:
            raise CopyError("lecture du dossier refusée : %s" % smb_failure(out))
        return out

    def delete(self, name):
        ok, out = self.call(self.cd() + "del %s" % smb_quote(name))
        if not ok:
            raise CopyError("suppression refusée : %s" % smb_failure(out))

    def target(self):
        return "\\\\%s\\%s%s" % (self.s["server"], self.s["share"],
                                 ("\\" + self.s["folder"].replace("/", "\\")) if self.s["folder"] else "")


# ------------------------------------------------------------------ SFTP (root)
def fingerprint(blob_b64):
    raw = base64.b64decode(blob_b64)
    return "SHA256:" + base64.b64encode(hashlib.sha256(raw).digest()).decode("ascii").rstrip("=")


def scan(host, port, runner):
    """Clés du serveur : [(type, base64, empreinte)]."""
    rc, out = runner.run([runner.keyscan, "-T", "10", "-p", str(port), host], timeout=30)
    keys = []
    for line in out.splitlines():
        parts = line.split()
        if len(parts) >= 3 and not line.startswith("#") and parts[1].startswith(("ssh-", "ecdsa-")):
            try:
                keys.append((parts[1], parts[2], fingerprint(parts[2])))
            except ValueError:
                continue
    return keys


class Sftp:
    def __init__(self, settings, runner, workdir, key=None):
        self.s, self.r, self.work = settings["sftp"], runner, workdir
        self.key = key or os.path.join(SFTP_DIR, "id_ed25519")
        if not os.path.isfile(self.key):
            raise CopyError("clé SFTP de l'appliance absente : générez-la depuis la console")
        keys = scan(self.s["host"], self.s["port"], runner)
        self.seen = [k[2] for k in keys]
        if not keys:
            raise CopyError("serveur SFTP injoignable (aucune clé reçue de %s:%d)" % (self.s["host"], self.s["port"]))
        if not self.s["fingerprint"]:
            raise CopyError("empreinte du serveur à épingler : %s" % ", ".join(self.seen))
        pinned = [k for k in keys if hmac.compare_digest(k[2], self.s["fingerprint"])]
        if not pinned:
            raise CopyError("empreinte du serveur différente de celle épinglée (reçue : %s)" % ", ".join(self.seen))
        self.known = os.path.join(workdir, "known_hosts")
        name = self.s["host"] if self.s["port"] == 22 else "[%s]:%d" % (self.s["host"], self.s["port"])
        with open(self.known, "w", encoding="utf-8") as h:
            for ktype, blob, _ in pinned:
                h.write("%s %s %s\n" % (name, ktype, blob))

    def batch(self, lines):
        path = os.path.join(self.work, "batch-%s" % secrets.token_hex(4))
        with open(path, "w", encoding="utf-8") as h:
            h.write("\n".join(lines) + "\n")
        argv = [self.r.sftp, "-b", path, "-P", str(self.s["port"]), "-i", self.key,
                "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes", "-o", "UserKnownHostsFile=" + self.known,
                "-o", "GlobalKnownHostsFile=/dev/null", "-o", "IdentitiesOnly=yes", "-o", "ConnectTimeout=15",
                "-o", "LogLevel=ERROR", "%s@%s" % (self.s["username"], self.s["host"])]
        return self.r.run(argv)

    def path(self, name):
        return '"%s"' % ((self.s["folder"] + "/" + name) if self.s["folder"] else name)

    def prepare(self):
        lines, path = [], ""
        for part in self.s["folder"].split("/") if self.s["folder"] else []:
            path = path + "/" + part if path else part
            lines.append('-mkdir "%s"' % path)
        if lines:
            self.batch(lines)

    def put(self, local, name):
        rc, out = self.batch(['put "%s" %s' % (local, self.path(name + ".part")), "-rm " + self.path(name),
                              "rename %s %s" % (self.path(name + ".part"), self.path(name))])
        if rc != 0:
            raise CopyError("copie SFTP refusée : %s" % sftp_failure(out))

    def names(self):
        rc, out = self.batch(["ls -1 %s" % ('"%s"' % self.s["folder"] if self.s["folder"] else ".")])
        if rc != 0:
            raise CopyError("lecture du dossier SFTP refusée : %s" % sftp_failure(out))
        return out

    def delete(self, name):
        rc, out = self.batch(["rm " + self.path(name)])
        if rc != 0:
            raise CopyError("suppression SFTP refusée : %s" % sftp_failure(out))

    def target(self):
        return "sftp://%s@%s:%d/%s" % (self.s["username"], self.s["host"], self.s["port"], self.s["folder"])


def sftp_failure(out):
    text = (out or "").strip()
    if "Permission denied" in text:
        return "clé refusée par le serveur (ajoutez la clé publique de l'appliance)"
    if "Host key verification failed" in text:
        return "empreinte du serveur refusée"
    return text.splitlines()[-1][-200:] if text else "échec"


# ------------------------------------------------------------------ copie
def connect(settings, runner, workdir, key_path=DEFAULT_KEY, sftp_key=None):
    if settings["mode"] == "smb":
        return Smb(settings, decrypt(settings["smb"]["password"], key_path), runner, workdir)
    if settings["mode"] == "sftp":
        return Sftp(settings, runner, workdir, sftp_key)
    raise CopyError("copie hors de l'appliance désactivée")


def copy(path, settings, runner, key_path=DEFAULT_KEY, sftp_key=None):
    """Copie une sauvegarde puis efface les copies automatiques au-delà de keep. Renvoie un message."""
    work = tempfile.mkdtemp(prefix="voipbuntu-copy-")
    try:
        os.chmod(work, 0o700)
        dest = connect(settings, runner, work, key_path, sftp_key)
        dest.prepare()
        name = os.path.basename(path)
        dest.put(path, name)
        present = remote_names(dest.names())
        if name not in present:
            raise CopyError("copie introuvable sur la destination après l'envoi")
        removed = to_rotate(present, settings["keep"])
        for old in removed:
            dest.delete(old)
        return "copie envoyée vers %s%s" % (dest.target(), " ; %d ancienne(s) copie(s) effacée(s)" % len(removed)
                                             if removed else "")
    finally:
        _rmtree(work)


def test(settings, runner, key_path=DEFAULT_KEY, sftp_key=None):
    """Essai : envoi d'un petit fichier, relecture du dossier, suppression. Renvoie un message."""
    work = tempfile.mkdtemp(prefix="voipbuntu-copy-")
    try:
        os.chmod(work, 0o700)
        dest = connect(settings, runner, work, key_path, sftp_key)
        dest.prepare()
        local = os.path.join(work, TEST_NAME)
        with open(local, "w", encoding="utf-8") as h:
            h.write("Essai de copie VOIPbuntu : ce fichier peut être supprimé.\n")
        dest.put(local, TEST_NAME)
        listing = dest.names()
        if TEST_NAME not in listing:
            raise CopyError("fichier d'essai introuvable après l'envoi")
        dest.delete(TEST_NAME)
        return "essai réussi : écriture, lecture et suppression dans %s" % dest.target()
    finally:
        _rmtree(work)


def _rmtree(path):
    import shutil
    shutil.rmtree(path, ignore_errors=True)
