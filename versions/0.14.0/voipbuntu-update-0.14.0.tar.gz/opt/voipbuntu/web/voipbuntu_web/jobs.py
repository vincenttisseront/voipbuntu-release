"""Client de la file d'attente unique des tâches longues (voipbuntu-worker).

La console ne détient aucun privilège : elle dépose une demande sur le socket
Unix du worker, qui n'exécute qu'une liste fixe d'actions.
"""

import json
import socket

DEFAULT_SOCKET = "/run/voipbuntu/worker.sock"
ACTIONS = ("apt-refresh", "apt-security-upgrade", "update-check", "update-apply", "pbx-apply", "networks-apply", "mail-test", "backup-run", "alerts-test", "restart-web", "reboot", "poweroff")
ACTIONS = ACTIONS + ("network-apply", "net-check")  # réseau et système de l'appliance

ACTIONS = ACTIONS + ("sounds-apply",)  # accueil vocal : annonces envoyées depuis la console
ACTIONS = ACTIONS + ("backup-copy-test", "backup-sftp-key", "voicemail-restore")  # sauvegardes complètes et copie
ACTIONS = ACTIONS + ("tls-apply",)  # certificat HTTPS de l'entreprise
ACTIONS = ACTIONS + ("ldap-apply",)  # annuaire LDAP des téléphones
ACTIONS = ACTIONS + ("provision-apply",)  # provisionnement des téléphones SIP
ACTIONS = ACTIONS + ("capture-start", "capture-stop")  # diagnostic SIP (capture réseau, trace d'un poste)
ACTIONS = ACTIONS + ("update-rollback", "maintenance-security", "support-bundle")  # maintenance et support
ACTIONS = ACTIONS + ("ad-sync", "ad-test")  # Active Directory : import des contacts, essai de connexion
ACTIONS = ACTIONS + ("live-hangup",)  # supervision : raccrocher un appel (demande revalidée en root)
ACTIONS = ACTIONS + ("pbx-forward-cancel",)  # renvoi du combiné (*72) annulé par un administrateur
ACTIONS = ACTIONS + ("sipguard-apply", "sipguard-unban")  # protection contre les attaques SIP


class WorkerUnavailable(Exception):
    pass


class WorkerClient:
    def __init__(self, path=DEFAULT_SOCKET, timeout=5):
        self.path = path
        self.timeout = timeout

    def call(self, request):
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
                sock.settimeout(self.timeout)
                sock.connect(self.path)
                sock.sendall(json.dumps(request).encode("utf-8") + b"\n")
                data = b""
                while not data.endswith(b"\n"):
                    chunk = sock.recv(65536)
                    if not chunk:
                        break
                    data += chunk
                    if len(data) > 4 * 1024 * 1024:
                        raise WorkerUnavailable("réponse trop longue")
        except OSError as exc:
            raise WorkerUnavailable(str(exc)) from None
        try:
            return json.loads(data.decode("utf-8"))
        except ValueError:
            raise WorkerUnavailable("réponse invalide") from None

    def submit(self, action, username):
        if action not in ACTIONS:
            raise ValueError(action)
        return self.call({"op": "submit", "action": action, "user": username})

    def list(self):
        return self.call({"op": "list"})

    def pbx_status(self):
        return self.call({"op": "pbx-status"})

    def pbx_calls(self):
        return self.call({"op": "pbx-calls"})

    def logs(self, source):
        return self.call({"op": "logs", "source": source})

    # ------------------------------------------- diagnostic SIP et enregistrements des appels
    def capture_status(self):
        return self.call({"op": "capture-status"})

    def recordings(self):
        return self.call({"op": "recordings"})

    def sipguard_status(self):
        return self.call({"op": "sipguard-status"})

    def open_file(self, kind, name=""):
        """Fichier transmis par le worker : (taille, morceaux). La taille vient avant le contenu."""
        try:
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.settimeout(30)
            sock.connect(self.path)
            sock.sendall(json.dumps({"op": "file", "kind": kind, "name": name}).encode("utf-8") + b"\n")
            reader = sock.makefile("rb")
            line = reader.readline(4096)
            head = json.loads(line.decode("utf-8"))
        except (OSError, ValueError) as exc:
            try:
                sock.close()
            except (OSError, UnboundLocalError):
                pass
            raise WorkerUnavailable(str(exc)) from None
        if not isinstance(head, dict) or not isinstance(head.get("size"), int):
            sock.close()
            return None, iter(())

        def chunks():
            left = head["size"]
            try:
                while left > 0:
                    chunk = reader.read(min(65536, left))
                    if not chunk:
                        break
                    left -= len(chunk)
                    yield chunk
            finally:
                reader.close()
                sock.close()
        return head["size"], chunks()
