"""État du système et mesures périodiques, lus dans /proc sans privilège."""

import os
import socket
import subprocess
import threading
import time

SAMPLE_SECONDS = 15
RETENTION_SECONDS = 24 * 3600
RANGES = {"15m": 15 * 60, "1h": 3600, "6h": 6 * 3600, "24h": 24 * 3600}
POINTS_PER_RANGE = 60
SERVICES = ["asterisk", "voipbuntu-web", "voipbuntu-worker", "nginx", "nftables", "ssh", "unattended-upgrades"]
METRIC_COLUMNS = ("cpu", "mem", "disk", "rx", "tx", "load1")


def read_file(path, default=""):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            return handle.read()
    except OSError:
        return default


def cpu_times(proc="/proc"):
    line = read_file(os.path.join(proc, "stat")).split("\n", 1)[0].split()
    if not line or line[0] != "cpu":
        return 0, 0
    values = [int(v) for v in line[1:]]
    idle = values[3] + (values[4] if len(values) > 4 else 0)
    return sum(values), idle


def memory_percent(proc="/proc"):
    info = {}
    for line in read_file(os.path.join(proc, "meminfo")).splitlines():
        parts = line.split()
        if len(parts) >= 2:
            info[parts[0].rstrip(":")] = int(parts[1])
    total = info.get("MemTotal", 0)
    if not total:
        return 0.0, 0
    available = info.get("MemAvailable", info.get("MemFree", 0))
    return round(100.0 * (total - available) / total, 1), total * 1024


def net_bytes(proc="/proc"):
    rx = tx = 0
    for line in read_file(os.path.join(proc, "net/dev")).splitlines()[2:]:
        if ":" not in line:
            continue
        name, data = line.split(":", 1)
        if name.strip() == "lo":
            continue
        fields = data.split()
        if len(fields) >= 9:
            rx += int(fields[0])
            tx += int(fields[8])
    return rx, tx


def disk_usage(path):
    try:
        st = os.statvfs(path)
    except OSError:
        return 0.0, 0, 0
    total = st.f_blocks * st.f_frsize
    free = st.f_bavail * st.f_frsize
    if not total:
        return 0.0, 0, 0
    return round(100.0 * (total - free) / total, 1), total, free


def uptime_seconds(proc="/proc"):
    try:
        return int(float(read_file(os.path.join(proc, "uptime"), "0").split()[0]))
    except (ValueError, IndexError):
        return 0


def load_average(proc="/proc"):
    try:
        return [float(x) for x in read_file(os.path.join(proc, "loadavg")).split()[:3]]
    except ValueError:
        return [0.0, 0.0, 0.0]


def ip_addresses():
    addresses = []
    try:
        out = subprocess.run(["ip", "-o", "addr", "show", "scope", "global"],
                             capture_output=True, text=True, timeout=5).stdout
    except (OSError, subprocess.SubprocessError):
        return addresses
    for line in out.splitlines():
        parts = line.split()
        if len(parts) >= 4 and parts[2] in ("inet", "inet6"):
            addresses.append({"interface": parts[1], "address": parts[3]})
    return addresses


def service_states(names=SERVICES):
    states = []
    for name in names:
        try:
            state = subprocess.run(["systemctl", "is-active", name + ".service"],
                                   capture_output=True, text=True, timeout=5).stdout.strip()
        except (OSError, subprocess.SubprocessError):
            state = "unknown"
        states.append({"name": name, "state": state or "unknown"})
    return states


class Sampler:
    def __init__(self, db, data_path="/srv/voipbuntu", proc="/proc", clock=time.time):
        self.db = db
        self.data_path = data_path if os.path.isdir(data_path) else "/"
        self.proc = proc
        self.clock = clock
        self._prev = None
        self._stop = threading.Event()

    def sample(self):
        now = self.clock()
        total, idle = cpu_times(self.proc)
        rx, tx = net_bytes(self.proc)
        mem, _ = memory_percent(self.proc)
        disk, _, _ = disk_usage(self.data_path)
        load1 = load_average(self.proc)[0]
        row = None
        if self._prev is not None:
            p_now, p_total, p_idle, p_rx, p_tx = self._prev
            dt = max(now - p_now, 1e-6)
            dtotal = total - p_total
            cpu = round(100.0 * (dtotal - (idle - p_idle)) / dtotal, 1) if dtotal > 0 else 0.0
            row = (int(now), cpu, mem, disk, max(rx - p_rx, 0) / dt, max(tx - p_tx, 0) / dt, load1)
            with self.db.lock:
                self.db.conn.execute(
                    "INSERT OR REPLACE INTO metrics(ts, cpu, mem, disk, rx, tx, load1) VALUES (?,?,?,?,?,?,?)", row)
                self.db.conn.execute("DELETE FROM metrics WHERE ts < ?", (int(now - RETENTION_SECONDS),))
                self.db.conn.commit()
        self._prev = (now, total, idle, rx, tx)
        return row

    def run(self):
        while not self._stop.is_set():
            try:
                self.sample()
            except Exception:  # une mesure ratée ne doit pas arrêter la console
                pass
            self._stop.wait(SAMPLE_SECONDS)

    def start(self):
        thread = threading.Thread(target=self.run, name="sampler", daemon=True)
        thread.start()
        return thread

    def stop(self):
        self._stop.set()


def series(db, range_name, now=None):
    """Séries à intervalles fixes : un seau sans mesure vaut None."""
    span = RANGES.get(range_name)
    if span is None:
        raise ValueError(range_name)
    now = int(now if now is not None else time.time())
    width = span // POINTS_PER_RANGE
    start = now - span
    with db.lock:
        rows = db.conn.execute(
            "SELECT ts, cpu, mem, disk, rx, tx, load1 FROM metrics WHERE ts > ? AND ts <= ? ORDER BY ts",
            (start, now)).fetchall()
    buckets = [[] for _ in range(POINTS_PER_RANGE)]
    for row in rows:
        index = min(int((row[0] - start - 1) // width), POINTS_PER_RANGE - 1)
        buckets[index].append(row)
    result = {"range": range_name, "width": width, "start": start,
              "t": [start + (i + 1) * width for i in range(POINTS_PER_RANGE)]}
    for col_index, name in enumerate(METRIC_COLUMNS, start=1):
        values = []
        for bucket in buckets:
            if bucket:
                values.append(round(sum(r[col_index] for r in bucket) / len(bucket), 2))
            else:
                values.append(None)
        result[name] = values
    return result


def status(version, data_path="/srv/voipbuntu", proc="/proc"):
    mem, mem_total = memory_percent(proc)
    disk, disk_total, disk_free = disk_usage(data_path if os.path.isdir(data_path) else "/")
    return {
        "hostname": socket.gethostname(),
        "version": version,
        "uptime": uptime_seconds(proc),
        "load": load_average(proc),
        "memory": {"percent": mem, "total": mem_total},
        "disk": {"percent": disk, "total": disk_total, "free": disk_free},
        "addresses": ip_addresses(),
        "os": os_release(),
    }


def os_release():
    for line in read_file("/etc/os-release").splitlines():
        if line.startswith("PRETTY_NAME="):
            return line.split("=", 1)[1].strip().strip('"')
    return ""
