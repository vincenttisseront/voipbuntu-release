"""Client de la file d'attente unique des tâches longues (voipbuntu-worker).

La console ne détient aucun privilège : elle dépose une demande sur le socket
Unix du worker, qui n'exécute qu'une liste fixe d'actions.
"""

import json
import socket

DEFAULT_SOCKET = "/run/voipbuntu/worker.sock"
ACTIONS = ("apt-refresh", "apt-security-upgrade", "update-check", "update-apply", "pbx-apply", "networks-apply", "mail-test", "backup-run", "restart-web", "reboot", "poweroff")


class WorkerUnavailable(Exception):
    pass


class WorkerClient:
    def __init__(self, path=DEFAULT_SOCKET, timeout=5):
        self.path = path
        self.timeout = timeout

    def call(self, request):
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
                sock.settimeout(self.timeout)
                sock.connect(self.path)
                sock.sendall(json.dumps(request).encode("utf-8") + b"\n")
                data = b""
                while not data.endswith(b"\n"):
                    chunk = sock.recv(65536)
                    if not chunk:
                        break
                    data += chunk
                    if len(data) > 4 * 1024 * 1024:
                        raise WorkerUnavailable("réponse trop longue")
        except OSError as exc:
            raise WorkerUnavailable(str(exc)) from None
        try:
            return json.loads(data.decode("utf-8"))
        except ValueError:
            raise WorkerUnavailable("réponse invalide") from None

    def submit(self, action, username):
        if action not in ACTIONS:
            raise ValueError(action)
        return self.call({"op": "submit", "action": action, "user": username})

    def list(self):
        return self.call({"op": "list"})

    def pbx_status(self):
        return self.call({"op": "pbx-status"})

    def pbx_calls(self):
        return self.call({"op": "pbx-calls"})

    def logs(self, source):
        return self.call({"op": "logs", "source": source})
