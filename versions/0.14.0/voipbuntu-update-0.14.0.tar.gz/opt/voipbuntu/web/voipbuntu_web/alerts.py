"""Supervision de VOIPbuntu et alertes par e-mail.

voipbuntu-alerts (root, minuteur voipbuntu-alerts.timer, chaque minute) relève
l'état de l'appliance, décide des alertes avec evaluate() et les envoie par
msmtp avec le serveur d'envoi de la messagerie (pbx.json > mail).

Garde-fous : au plus une alerte par cause et par heure ; une alerte « rétabli »
part quand une cause signalée disparaît. Réglages (écrits par la console) :
/var/lib/voipbuntu/alerts-settings.json ; état et historique (écrits par root,
lisibles par la console) : /var/lib/voipbuntu/alerts.json.
"""

import json
import os

from . import pbx

DEFAULT_SETTINGS = "/var/lib/voipbuntu/alerts-settings.json"
DEFAULT_STATE = "/var/lib/voipbuntu/alerts.json"
MAX_RECIPIENTS = 5
HISTORY = 50
RATE = 3600  # au plus une alerte par cause et par heure
DISK_LIMIT = 85.0
LOGIN_WINDOW = 15 * 60
LOGIN_LIMIT = 5

# Ordre d'affichage, libellé et délai avant alerte (secondes) de chaque cause
CAUSES = (
    ("trunk", "Ligne de l'opérateur désenregistrée", 300),
    ("asterisk", "Asterisk arrêté", 0),
    ("disk", "Disque presque plein", 0),
    ("backup", "Sauvegarde automatique en échec", 0),
    ("update", "Nouvelle version disponible", 0),
    ("login", "Échecs de connexion répétés à la console", 0),
)
CAUSES = CAUSES + (("sip", "Adresse bannie pour attaque SIP", 0),)  # protection SIP (lot O)
LABELS = {k: label for k, label, _ in CAUSES}
DELAYS = {k: delay for k, _, delay in CAUSES}
RESOLVED = {
    "trunk": "La ligne de l'opérateur est de nouveau enregistrée.",
    "asterisk": "Asterisk fonctionne de nouveau.",
    "disk": "L'occupation du disque est repassée sous le seuil.",
    "backup": "La dernière sauvegarde automatique a réussi.",
    "update": "VOIPbuntu est à jour.",
    "login": "Plus d'échec de connexion répété à la console.",
    "sip": "Plus aucune adresse bannie par la protection SIP.",
}


class AlertError(ValueError):
    pass


def default_settings():
    return {"recipients": [], "causes": {k: True for k, _, _ in CAUSES}}


def validate_settings(data):
    if not isinstance(data, dict):
        raise AlertError("Réglages des alertes invalides.")
    s = default_settings()
    rcpt = data.get("recipients", [])
    if isinstance(rcpt, str):
        rcpt = rcpt.replace(";", ",").replace("\n", ",").split(",")
    if not isinstance(rcpt, list):
        raise AlertError("Réglages des alertes invalides.")
    clean = []
    for r in rcpt:
        if not isinstance(r, str):
            raise AlertError("Adresse e-mail invalide.")
        r = r.strip()
        if not r:
            continue
        if len(r) > 254 or not pbx.EMAIL_RE.match(r):
            raise AlertError("Adresse e-mail invalide.")
        if r.lower() not in [c.lower() for c in clean]:
            clean.append(r)
    if len(clean) > MAX_RECIPIENTS:
        raise AlertError("Cinq destinataires au plus.")
    s["recipients"] = clean
    causes = data.get("causes", {})
    if not isinstance(causes, dict):
        raise AlertError("Réglages des alertes invalides.")
    for k in s["causes"]:
        if k in causes:
            s["causes"][k] = bool(causes[k])
    return s


def _read(path):
    with open(path, encoding="utf-8") as h:
        return json.load(h)


def _write(path, data, owner=None):
    tmp = path + ".tmp"
    old = os.umask(0o077)
    try:
        with open(tmp, "w", encoding="utf-8") as h:
            json.dump(data, h, ensure_ascii=False, indent=1, sort_keys=True)
        if owner:
            os.chown(tmp, owner[0], owner[1])
        os.replace(tmp, path)
    finally:
        os.umask(old)


def load_settings(path=DEFAULT_SETTINGS):
    try:
        return validate_settings(_read(path))
    except (OSError, ValueError):
        return default_settings()


def save_settings(settings, path=DEFAULT_SETTINGS):
    settings = validate_settings(settings)
    _write(path, settings)
    return settings


def empty_state():
    return {"causes": {}, "history": [], "last_run": None}


def load_state(path=DEFAULT_STATE):
    try:
        data = _read(path)
    except (OSError, ValueError):
        return empty_state()
    if not isinstance(data, dict):
        return empty_state()
    state = empty_state()
    if isinstance(data.get("causes"), dict):
        state["causes"] = {k: v for k, v in data["causes"].items() if k in LABELS and isinstance(v, dict)}
    if isinstance(data.get("history"), list):
        state["history"] = [h for h in data["history"] if isinstance(h, dict)][-HISTORY:]
    if isinstance(data.get("last_run"), (int, float)):
        state["last_run"] = data["last_run"]
    return state


def save_state(state, path=DEFAULT_STATE, owner=None):
    state["history"] = state["history"][-HISTORY:]
    _write(path, state, owner)


def public(state):
    """Vue de l'état pour la console : causes en cours et historique, du plus récent au plus ancien."""
    def text(v, n=300):
        return v[:n] if isinstance(v, str) else ""
    active = []
    for k, label, _ in CAUSES:
        c = state["causes"].get(k) or {}
        if c.get("since") is not None:
            active.append({"cause": k, "label": label, "since": c.get("since"), "notified": bool(c.get("notified")),
                           "detail": text(c.get("detail"))})
    history = []
    for h in reversed(state["history"]):
        history.append({"ts": h.get("ts"), "cause": h.get("cause") if h.get("cause") in LABELS or h.get("cause") == "test" else "",
                        "kind": h.get("kind") if h.get("kind") in ("alerte", "rétabli", "essai") else "",
                        "detail": text(h.get("detail")), "sent": bool(h.get("sent")), "error": text(h.get("error"))})
    return {"active": active, "history": history, "last_run": state.get("last_run")}


def evaluate(state, observations, settings, now):
    """Fait évoluer l'état et renvoie les e-mails à envoyer.

    observations : {cause: None (inconnu, rien ne change) ou (problème: bool, détail: str, repère: str)}.
    Le repère distingue deux problèmes d'une même cause (par ex. la version disponible).
    Renvoie une liste de dictionnaires {cause, kind, detail}. L'appelant envoie chaque e-mail puis
    appelle record() avec le résultat.
    """
    out = []
    for k, _, _ in CAUSES:
        c = state["causes"].setdefault(k, {})
        if not settings["causes"].get(k, True):
            c.clear()  # cause décochée : oubliée, sans « rétabli »
            continue
        obs = observations.get(k)
        if obs is None:
            continue
        bad, detail, mark = obs
        if bad:
            if c.get("since") is None:
                c["since"] = now
            c["detail"] = detail
            if c.get("notified") and c.get("mark") != mark:
                c["notified"] = False  # nouveau problème de la même cause (nouvelle version…)
            if c.get("notified") or now - c["since"] < DELAYS[k]:
                continue
            last = c.get("last_alert")
            if last is not None and now - last < RATE:
                continue
            c["last_alert"] = now
            c["pending_mark"] = mark
            out.append({"cause": k, "kind": "alerte", "detail": detail})
        else:
            notified = c.get("notified")
            last_alert = c.get("last_alert")
            c.clear()
            if last_alert is not None:
                c["last_alert"] = last_alert  # la limite d'une alerte par heure survit au rétablissement
            if notified:
                out.append({"cause": k, "kind": "rétabli", "detail": RESOLVED[k]})
    return out


def record(state, event, now, sent, error="", recipients=()):
    """Inscrit un e-mail (envoyé ou non) dans l'historique et l'état de sa cause."""
    c = state["causes"].get(event["cause"])
    if c is not None and event["kind"] == "alerte":
        c["notified"] = bool(sent)
        c["mark"] = c.pop("pending_mark", "")
    state["history"].append({"ts": now, "cause": event["cause"], "kind": event["kind"], "detail": event["detail"][:300],
                             "sent": bool(sent), "error": (error or "")[:300], "to": list(recipients)})
    state["history"] = state["history"][-HISTORY:]


def subject(event, host):
    if event["kind"] == "essai":
        return "[VOIPbuntu %s] E-mail d'essai des alertes" % host
    label = LABELS.get(event["cause"], event["cause"])
    return "[VOIPbuntu %s] %s : %s" % (host, "Rétabli" if event["kind"] == "rétabli" else "Alerte", label)
