"""Réseaux des téléphones (bases DECT, VLAN des téléphones SIP).

La liste effective est PHONE_NETS dans /etc/voipbuntu/appliance.conf (root) :
elle ouvre SIP et RTP dans le pare-feu. La console tient la liste voulue, avec
un nom par réseau, dans /var/lib/voipbuntu/networks.json ; voipbuntu-networks
(root, via la file d'attente) la valide de nouveau et l'applique.
"""

import ipaddress
import json
import os
import re

DEFAULT_STATE = "/var/lib/voipbuntu/networks.json"
MAX_NETWORKS = 16
LABEL_RE = re.compile(r"^[^\x00-\x1f\x7f\"<>;\[\]\\=,|$`']{0,40}$")


class NetworkError(ValueError):
    pass


def normalize(cidr):
    try:
        net = ipaddress.ip_network(str(cidr).strip(), strict=False)
    except ValueError:
        raise NetworkError("réseau invalide : %s" % str(cidr)[:50]) from None
    if net.prefixlen == 0:
        raise NetworkError("réseau trop large : %s" % net)
    return str(net)


def validate(data):
    if not isinstance(data, dict) or not isinstance(data.get("networks"), list):
        raise NetworkError("format invalide")
    if len(data["networks"]) > MAX_NETWORKS:
        raise NetworkError("%d réseaux au plus" % MAX_NETWORKS)
    out, seen = [], set()
    for item in data["networks"]:
        if not isinstance(item, dict):
            raise NetworkError("réseau invalide")
        cidr = normalize(item.get("cidr", ""))
        label = str(item.get("label", "")).strip()
        if not LABEL_RE.match(label):
            raise NetworkError("nom invalide pour %s" % cidr)
        if cidr in seen:
            raise NetworkError("réseau en double : %s" % cidr)
        seen.add(cidr)
        out.append({"cidr": cidr, "label": label})
    return {"networks": out}


def load(path=DEFAULT_STATE):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return validate(json.load(handle))
    except FileNotFoundError:
        return {"networks": []}
    except (OSError, ValueError):
        raise NetworkError("liste des réseaux illisible") from None


def save(state, path=DEFAULT_STATE):
    state = validate(state)
    tmp = path + ".tmp"
    old = os.umask(0o077)
    try:
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(state, handle, indent=1)
        os.replace(tmp, path)
    finally:
        os.umask(old)
    return state


def read_conf_nets(path="/etc/voipbuntu/appliance.conf"):
    """PHONE_NETS effectif, en liste de CIDR normalisés (entrées invalides ignorées)."""
    from .pbx import read_phone_nets
    out = []
    for item in read_phone_nets(path).replace(",", " ").split():
        try:
            out.append(normalize(item))
        except NetworkError:
            continue
    return out


def view(state, conf_nets):
    """Réseaux affichés : ceux de appliance.conf (effectifs) avec leur nom, puis ceux en attente."""
    labels = {n["cidr"]: n["label"] for n in state["networks"]}
    wanted = [n["cidr"] for n in state["networks"]]
    rows = [{"cidr": c, "label": labels.get(c, ""), "applied": True} for c in conf_nets]
    rows += [{"cidr": c, "label": labels[c], "applied": False} for c in wanted if c not in conf_nets]
    removed = [c for c in conf_nets if state["networks"] and c not in wanted]
    return {"networks": rows, "pending_removal": removed}


def label_for(cidr, state):
    for n in state["networks"]:
        if n["cidr"] == cidr:
            return n["label"]
    return ""


def set_conf_nets(text, nets):
    """Remplace (ou ajoute) la ligne PHONE_NETS d'un appliance.conf, sans toucher au reste."""
    line = 'PHONE_NETS="%s"' % " ".join(nets)
    lines = text.splitlines()
    done = False
    for i, current in enumerate(lines):
        if re.match(r"^\s*PHONE_NETS\s*=", current):
            if not done:
                lines[i] = line
                done = True
            else:
                lines[i] = "# " + current
    if not done:
        lines.append(line)
    return "\n".join(lines) + "\n"
