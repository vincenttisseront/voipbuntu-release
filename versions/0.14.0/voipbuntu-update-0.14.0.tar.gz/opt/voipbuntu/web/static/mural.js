/* Panneau mural VOIPbuntu : supervision en lecture seule, plein écran, rafraîchie toutes les 2 à 5 s.
   Utilisable par un compte lecture. Aucun innerHTML : tout passe par textContent. */
(function () {
  "use strict";
  var t = function (s) { return window.I18N.t(s); };
  var KINDS = { incoming: "Entrant (ligne)", outgoing: "Sortant (ligne)", internal: "Interne" };
  var CALL_STATES = { up: "en communication", ringing: "sonne", queue: "en attente", voicemail: "messagerie", dialing: "numérotation" };
  var EXT_STATES = { free: "libre", ringing: "sonne", busy: "en ligne", offline: "non enregistré", dnd: "ne pas déranger", unknown: "inconnu" };
  var ERRORS = { absent: "Supervision indisponible : service voipbuntu-live arrêté.", stale: "Supervision indisponible : données trop anciennes.", ami: "Supervision indisponible : serveur de téléphonie injoignable." };
  var params = new URLSearchParams(location.search);
  var delay = Math.min(5, Math.max(2, parseInt(params.get("s"), 10) || 3)) * 1000;
  var timer = null, ticks = 0;

  function $(id) { return document.getElementById(id); }
  function el(tag, text, cls) {
    var node = document.createElement(tag);
    if (text !== undefined && text !== null) { node.textContent = text; }
    if (cls) { node.className = cls; }
    return node;
  }
  function clock(s) {
    var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
    return (h ? h + ":" + (m < 10 ? "0" : "") : "") + m + ":" + (r < 10 ? "0" : "") + r;
  }
  function party(num, name) { return name && name !== num ? num + " " + name : (num || "–"); }
  function setText(id, value) { var n = $(id); if (n.textContent !== String(value)) { n.textContent = value; } }

  function render(d) {
    setText("mural-status", d.available ? "" : t(ERRORS[d.error] || ERRORS.absent));
    $("mural-status").className = "mural-status" + (d.available ? "" : " error");
    setText("mural-kpi-calls", d.available ? d.counts.calls : "–");
    setText("mural-kpi-trunk", d.available ? d.counts.incoming + d.counts.outgoing : "–");
    setText("mural-kpi-waiting", d.available ? d.counts.waiting : "–");
    setText("mural-kpi-free", d.available ? d.counts.free + " / " + d.extensions.length : "–");
    var list = $("mural-calls");
    list.textContent = "";
    d.calls.forEach(function (c) {
      var li = el("li", null, "mural-call is-" + c.status);
      li.appendChild(el("span", party(c.caller, c.caller_name), "mural-party"));
      li.appendChild(el("span", "→", "mural-arrow"));
      li.appendChild(el("span", party(c.callee, c.callee_name), "mural-party"));
      li.appendChild(el("span", t(KINDS[c.kind] || c.kind) + " · " + t(CALL_STATES[c.status] || c.status), "mural-meta"));
      li.appendChild(el("span", clock(c.seconds), "mural-time"));
      list.appendChild(li);
    });
    $("mural-calls-empty").hidden = d.calls.length > 0;
    var ql = $("mural-queues");
    ql.textContent = "";
    d.queues.forEach(function (q) {
      var li = el("li", null, "mural-queue" + (q.waiting ? " mural-waiting" : ""));
      li.appendChild(el("span", q.number + " " + q.name, "mural-party"));
      li.appendChild(el("span", q.waiting + " " + t("en attente") + (q.waiting ? " · " + t("plus longue") + " " + clock(q.longest) : ""), "mural-meta"));
      li.appendChild(el("span", (q.available === null ? "–" : q.available + " / " + q.members) + " " + t("disponibles"), "mural-time"));
      ql.appendChild(li);
    });
    $("mural-queues-empty").hidden = d.queues.length > 0;
    var grid = $("mural-exts");
    grid.textContent = "";
    d.extensions.forEach(function (x) {
      var li = el("li", null, "live-ext live-" + x.state);
      li.appendChild(el("strong", x.number));
      li.appendChild(el("span", x.name));
      li.appendChild(el("span", t(EXT_STATES[x.state] || x.state), "live-state"));
      grid.appendChild(li);
    });
  }

  function tick() {
    timer = null;
    setText("mural-clock", new Date().toLocaleTimeString(window.I18N.lang() === "en" ? "en-GB" : "fr-FR", { hour: "2-digit", minute: "2-digit" }));
    fetch("/api/live", { credentials: "same-origin", headers: { "Accept": "application/json" }, cache: "no-store" })
      .then(function (r) {
        if (r.status === 401) { $("mural-login").hidden = false; throw new Error("session"); }
        return r.json();
      })
      .then(function (d) { $("mural-login").hidden = true; render(d); })
      .catch(function (e) {
        if (e.message !== "session") { setText("mural-status", t("Console injoignable, nouvel essai…")); $("mural-status").className = "mural-status error"; }
      })
      .then(function () {
        ticks += 1;
        document.body.setAttribute("data-ticks", String(ticks));  // suivi par le test d'endurance
        timer = setTimeout(tick, delay);
      });
  }

  function init() {
    try { var saved = localStorage.getItem("pxb_theme"); if (saved) { document.documentElement.setAttribute("data-theme", saved); } }
    catch (e) { /* stockage indisponible */ }
    $("mural-full").addEventListener("click", function () {
      if (document.fullscreenElement) { document.exitFullscreen(); }
      else if (document.documentElement.requestFullscreen) { document.documentElement.requestFullscreen().catch(function () {}); }
    });
    fetch("/api/session", { credentials: "same-origin" }).then(function (r) { return r.json(); })
      .then(function (s) { return window.I18N.load(s.lang === "en" ? "en" : "fr"); })
      .catch(function () { return null; })
      .then(function () { window.I18N.apply(); tick(); });
  }

  document.addEventListener("DOMContentLoaded", init);
})();
