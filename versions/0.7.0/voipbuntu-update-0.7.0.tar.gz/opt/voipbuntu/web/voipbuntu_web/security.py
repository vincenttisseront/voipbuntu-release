"""Primitives de sécurité de la console : mots de passe, sessions, anti-force brute.

Aucun secret n'est journalisé ni stocké en clair : les mots de passe sont
hachés en PBKDF2-SHA256, les jetons de session sont conservés sous forme
d'empreinte SHA-256.
"""

import hashlib
import hmac
import os
import secrets
import time

PBKDF2_ITERATIONS = 600_000
SESSION_IDLE_SECONDS = 30 * 60
SESSION_MAX_SECONDS = 12 * 3600
LOCK_THRESHOLD = 5
LOCK_BASE_SECONDS = 30
LOCK_MAX_SECONDS = 15 * 60
PASSWORD_MIN_LENGTH = 12


def hash_password(password, iterations=PBKDF2_ITERATIONS):
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return "pbkdf2_sha256$%d$%s$%s" % (iterations, salt.hex(), digest.hex())


def verify_password(password, stored):
    try:
        algo, iterations, salt_hex, digest_hex = stored.split("$")
        iterations = int(iterations)
        if algo != "pbkdf2_sha256" or iterations < 1000:
            return False
        salt = bytes.fromhex(salt_hex)
        expected = bytes.fromhex(digest_hex)
    except (ValueError, AttributeError):
        return False
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return hmac.compare_digest(digest, expected)


def password_problem(password):
    """Retourne la clé du message d'erreur, ou None si le mot de passe convient."""
    if not isinstance(password, str) or len(password) < PASSWORD_MIN_LENGTH:
        return "Le mot de passe doit contenir au moins 12 caractères."
    if len(password) > 256:
        return "Le mot de passe est trop long."
    classes = sum([
        any(c.islower() for c in password),
        any(c.isupper() for c in password),
        any(c.isdigit() for c in password),
        any(not c.isalnum() for c in password),
    ])
    if classes < 3:
        return "Le mot de passe doit mélanger au moins trois types de caractères."
    return None


def token_digest(token):
    return hashlib.sha256(token.encode("ascii", "replace")).hexdigest()


def new_token():
    return secrets.token_urlsafe(32)


class SessionStore:
    def __init__(self, db, clock=time.time):
        self.db = db
        self.clock = clock

    def create(self, username):
        token = new_token()
        csrf = new_token()
        now = self.clock()
        with self.db.lock:
            self.db.conn.execute(
                "INSERT INTO sessions(token_hash, username, csrf, created, last_seen) VALUES (?,?,?,?,?)",
                (token_digest(token), username, csrf, now, now),
            )
            self.db.conn.commit()
        return token, csrf

    def get(self, token):
        if not token or len(token) > 128:
            return None
        now = self.clock()
        digest = token_digest(token)
        with self.db.lock:
            row = self.db.conn.execute(
                "SELECT username, csrf, created, last_seen FROM sessions WHERE token_hash=?",
                (digest,),
            ).fetchone()
            if row is None:
                return None
            username, csrf, created, last_seen = row
            if now - last_seen > SESSION_IDLE_SECONDS or now - created > SESSION_MAX_SECONDS:
                self.db.conn.execute("DELETE FROM sessions WHERE token_hash=?", (digest,))
                self.db.conn.commit()
                return None
            self.db.conn.execute("UPDATE sessions SET last_seen=? WHERE token_hash=?", (now, digest))
            self.db.conn.commit()
        return {"username": username, "csrf": csrf}

    def delete(self, token):
        with self.db.lock:
            self.db.conn.execute("DELETE FROM sessions WHERE token_hash=?", (token_digest(token or ""),))
            self.db.conn.commit()

    def delete_user(self, username):
        with self.db.lock:
            self.db.conn.execute("DELETE FROM sessions WHERE username=?", (username,))
            self.db.conn.commit()


class LoginThrottle:
    """Verrouillage progressif par adresse IP et par identifiant."""

    def __init__(self, db, clock=time.time):
        self.db = db
        self.clock = clock

    def _row(self, key):
        return self.db.conn.execute(
            "SELECT failures, locked_until FROM login_failures WHERE key=?", (key,)
        ).fetchone()

    def locked_for(self, keys):
        now = self.clock()
        wait = 0
        with self.db.lock:
            for key in keys:
                row = self._row(key)
                if row and row[1] > now:
                    wait = max(wait, int(row[1] - now) + 1)
        return wait

    def failure(self, keys):
        now = self.clock()
        with self.db.lock:
            for key in keys:
                row = self._row(key)
                failures = (row[0] if row else 0) + 1
                locked_until = 0
                if failures >= LOCK_THRESHOLD:
                    delay = min(LOCK_BASE_SECONDS * (2 ** (failures - LOCK_THRESHOLD)), LOCK_MAX_SECONDS)
                    locked_until = now + delay
                self.db.conn.execute(
                    "INSERT INTO login_failures(key, failures, locked_until) VALUES (?,?,?) "
                    "ON CONFLICT(key) DO UPDATE SET failures=excluded.failures, locked_until=excluded.locked_until",
                    (key, failures, locked_until),
                )
            self.db.conn.commit()

    def success(self, keys):
        with self.db.lock:
            for key in keys:
                self.db.conn.execute("DELETE FROM login_failures WHERE key=?", (key,))
            self.db.conn.commit()
