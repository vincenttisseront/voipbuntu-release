"""Console web VOIPbuntu."""
