"""Sauvegardes de VOIPbuntu.

Depuis la 0.9, une sauvegarde est une archive .tar.gz « voipbuntu-backup »
format 2 (voir build_archive) : configuration téléphonique, réseaux, annonces,
messages vocaux et réglages de l'appliance. Les fichiers JSON des versions 0.2
à 0.8 (format 1 : pbx.json, mots de passe SIP compris, et noms des réseaux des
téléphones) restent restaurables. Les sauvegardes automatiques sont écrites par voipbuntu-backup
(root, minuteur systemd) dans /var/lib/voipbuntu/backups, lisibles par la
seule console ; les réglages sont dans /var/lib/voipbuntu/backup.json.
"""

import hashlib
import io
import json
import os
import re
import stat
import tarfile
import tempfile
import time
import zlib

from . import networks, pbx

FORMAT = "voipbuntu-backup"
DEFAULT_DIR = "/var/lib/voipbuntu/backups"
DEFAULT_SETTINGS = "/var/lib/voipbuntu/backup.json"
NAME_RE = re.compile(r"^voipbuntu-sauvegarde-(\d{8})-(\d{4})(?:-auto)?\.(?:json|tar\.gz)$")
MAX_FILE = 4 * 1024 * 1024


class BackupError(ValueError):
    pass


def payload(state, nets, version, created=None):
    return {"format": FORMAT, "format_version": 1, "version": version,
            "created": int(created if created is not None else time.time()), "pbx": state, "networks": nets}


def read_payload(data):
    """Valide une sauvegarde ; renvoie (état pbx, réseaux ou None pour les sauvegardes 0.2 sans réseaux)."""
    if not isinstance(data, dict) or data.get("format") != FORMAT or data.get("format_version") != 1:
        raise BackupError("Ce fichier n'est pas une sauvegarde VOIPbuntu.")
    try:
        state = pbx.validate(data.get("pbx"))
    except pbx.PbxError:
        raise BackupError("Sauvegarde invalide : configuration téléphonique incohérente.") from None
    nets = None
    if data.get("networks") is not None:
        try:
            nets = networks.validate(data["networks"])
        except networks.NetworkError:
            raise BackupError("Sauvegarde invalide : réseaux des téléphones incohérents.") from None
    return state, nets


def default_settings():
    return {"enabled": True, "hour": 2, "keep": 14, "email": "", "voicemail": True}


def validate_settings(data):
    if not isinstance(data, dict):
        raise BackupError("Réglages de sauvegarde invalides.")
    s = default_settings()
    s["enabled"] = bool(data.get("enabled", True))
    s["voicemail"] = bool(data.get("voicemail", True))  # messages vocaux dans l'archive (0.9)
    try:
        s["hour"], s["keep"] = int(data.get("hour", 2)), int(data.get("keep", 14))
    except (TypeError, ValueError):
        raise BackupError("Réglages de sauvegarde invalides.") from None
    if not 0 <= s["hour"] <= 23:
        raise BackupError("Heure de sauvegarde invalide (0 à 23).")
    if not 1 <= s["keep"] <= 90:
        raise BackupError("Nombre de sauvegardes conservées entre 1 et 90.")
    email = str(data.get("email") or "").strip()
    if email and (len(email) > 254 or not pbx.EMAIL_RE.match(email)):
        raise BackupError("Adresse e-mail invalide.")
    s["email"] = email
    return s


def load_settings(path=DEFAULT_SETTINGS):
    try:
        with open(path, encoding="utf-8") as h:
            return validate_settings(json.load(h))
    except FileNotFoundError:
        return default_settings()
    except (OSError, ValueError):
        return default_settings()


def save_settings(settings, path=DEFAULT_SETTINGS):
    settings = validate_settings(settings)
    tmp = path + ".tmp"
    old = os.umask(0o077)
    try:
        with open(tmp, "w", encoding="utf-8") as h:
            json.dump(settings, h, indent=1, sort_keys=True)
        os.replace(tmp, path)
    finally:
        os.umask(old)
    return settings


def listing(directory=DEFAULT_DIR):
    """Sauvegardes présentes, de la plus récente à la plus ancienne."""
    out = []
    try:
        names = os.listdir(directory)
    except OSError:
        return out
    for name in names:
        m = NAME_RE.match(name)
        if not m:
            continue
        try:
            st = os.stat(os.path.join(directory, name))
        except OSError:
            continue
        try:  # date du nom (heure locale de l'appliance), plus sûre que la date de modification
            created = int(time.mktime(time.strptime(m.group(1) + m.group(2), "%Y%m%d%H%M")))
        except ValueError:
            created = int(st.st_mtime)
        out.append({"name": name, "size": st.st_size, "created": created, "auto": "-auto." in name})
    out.sort(key=lambda b: (b["created"], b["name"]), reverse=True)
    return out


def path_of(name, directory=DEFAULT_DIR):
    """Chemin d'une sauvegarde à partir de son nom (jamais de chemin fourni par l'utilisateur)."""
    if not isinstance(name, str) or not NAME_RE.match(name):
        raise BackupError("Sauvegarde introuvable.")
    path = os.path.join(directory, name)
    if not os.path.isfile(path):
        raise BackupError("Sauvegarde introuvable.")
    return path


def read_file(name, directory=DEFAULT_DIR):
    path = path_of(name, directory)
    if os.path.getsize(path) > MAX_FILE:
        raise BackupError("Sauvegarde trop volumineuse.")
    with open(path, encoding="utf-8") as h:
        try:
            return json.load(h)
        except ValueError:
            raise BackupError("Ce fichier n'est pas une sauvegarde VOIPbuntu.") from None


def write_json(path, data, owner=None, indent=None):
    """Écriture atomique dans un dossier de la console, sûre même en root : fichier temporaire
    au nom aléatoire créé en O_EXCL (un lien symbolique posé à l'avance n'est jamais suivi),
    droits et propriétaire réglés sur le descripteur, puis renommage."""
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path) or ".", prefix=".voipbuntu-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as h:
            os.fchmod(h.fileno(), 0o600)
            if owner:
                os.fchown(h.fileno(), owner[0], owner[1])
            json.dump(data, h, ensure_ascii=False, indent=indent)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def write(data, directory=DEFAULT_DIR, keep=14, now=None, owner=None):
    """Écrit une sauvegarde automatique (archive en octets, ou JSON 0.7) puis ne garde que
    les keep plus récentes ; renvoie son chemin."""
    os.makedirs(directory, mode=0o700, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M", time.localtime(now if now is not None else time.time()))
    if isinstance(data, bytes):
        path = os.path.join(directory, "voipbuntu-sauvegarde-%s-auto.tar.gz" % stamp)
        write_bytes(path, data, owner=owner)
    else:
        path = os.path.join(directory, "voipbuntu-sauvegarde-%s-auto.json" % stamp)
        write_json(path, data, owner=owner, indent=1)
    autos = [b for b in listing(directory) if b["auto"]]
    for b in autos[keep:]:
        try:
            os.unlink(os.path.join(directory, b["name"]))
        except OSError:
            pass
    return path



# ---------------------------------------------------------------------------
# Format 2 (0.9) : archive .tar.gz qui reconstruit l'appliance à l'identique
#
#   voipbuntu-backup.json   manifeste : pbx.json, réseaux des téléphones, alertes, réseau et
#                           système de l'appliance, réglages de sauvegarde et de copie (sans
#                           mot de passe), liste des fichiers et leurs empreintes SHA-256
#   sounds/<nom>.wav        annonces de l'accueil vocal et musique d'attente (pbx.SOUNDS)
#   voicemail/<boîte>/...   messages vocaux (/var/spool/asterisk/voicemail/default), en option
#
# Les sauvegardes JSON 0.2 à 0.8 (format 1) restent restaurables : load_any lit les deux.

ARCHIVE_VERSION = 2
MANIFEST = "voipbuntu-backup.json"
MAX_ARCHIVE = 50 * 1024 * 1024        # archive envoyée ou téléchargée
MAX_CONTENT = 50 * 1024 * 1024        # contenu décompressé
MAX_MEMBERS = 5000
VOICEMAIL_DIR = "/var/spool/asterisk/voicemail/default"
PART_RE = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}$")


def is_archive(raw):
    return isinstance(raw, (bytes, bytearray)) and raw[:2] == b"\x1f\x8b"


def sound_path(name, sounds_dir):
    """Même emplacement que voipbuntu-sounds : la musique d'attente a son propre dossier."""
    if name == "attente":
        return os.path.join(sounds_dir, "attente", "attente.wav")
    return os.path.join(sounds_dir, name + ".wav")


def voicemail_member_ok(rel):
    """voicemail/<boîte>/<fichier> ou voicemail/<boîte>/<dossier>/<fichier>, sans .. ni fichier caché."""
    parts = rel.split("/")
    return parts[0] == "voicemail" and 3 <= len(parts) <= 4 and all(PART_RE.match(p) for p in parts[1:])


def read_regular(path, limit):
    """Lit un fichier ordinaire sans suivre de lien symbolique ; None s'il n'existe pas."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except OSError:
        return None
    with os.fdopen(fd, "rb") as h:
        st = os.fstat(h.fileno())
        if not stat.S_ISREG(st.st_mode) or st.st_size > limit:
            return None
        return h.read(limit + 1)[:limit]


def voicemail_files(directory=VOICEMAIL_DIR):
    """Messages et annonces des boîtes vocales : [(chemin relatif « voicemail/... », chemin, mtime)]."""
    out = []
    if not os.path.isdir(directory):
        return out
    for root, dirs, files in os.walk(directory, followlinks=False):
        rel_root = os.path.relpath(root, directory)
        depth = 0 if rel_root == "." else rel_root.count(os.sep) + 1
        dirs[:] = sorted(d for d in dirs if PART_RE.match(d) and depth < 2)
        for name in sorted(files):
            rel = "voicemail/" + (name if rel_root == "." else rel_root.replace(os.sep, "/") + "/" + name)
            full = os.path.join(root, name)
            if voicemail_member_ok(rel) and os.path.isfile(full) and not os.path.islink(full):
                out.append((rel, full, int(os.lstat(full).st_mtime)))
    return out


def build_archive(manifest, sounds_dir, voicemail_dir=None, limit=MAX_CONTENT):
    """Archive format 2 en octets. manifest : clés pbx, networks, et facultativement alerts,
    netconf, settings, copy, version, created. Renvoie (archive, notes)."""
    notes = []
    files = []  # (nom dans l'archive, octets, mtime)
    for name in pbx.SOUNDS:
        data = read_regular(sound_path(name, sounds_dir), 25 * 1024 * 1024)
        if data is not None:
            files.append(("sounds/%s.wav" % name, data, int(time.time())))
    size = sum(len(f[1]) for f in files)
    voicemail = []
    if voicemail_dir:
        total = 0
        for rel, full, mtime in voicemail_files(voicemail_dir):
            data = read_regular(full, limit)
            if data is None:
                continue
            voicemail.append((rel, data, mtime))
            total += len(data)
        if size + total > limit - 1024 * 1024:
            notes.append("messages vocaux non inclus : %d Mo, au-delà de la limite de %d Mo"
                         % (total // (1024 * 1024) + 1, limit // (1024 * 1024)))
            voicemail = []
    files += voicemail
    man = {"format": FORMAT, "format_version": ARCHIVE_VERSION,
           "version": manifest.get("version") or "inconnue",
           "created": int(manifest.get("created") or time.time()),
           "pbx": manifest["pbx"], "networks": manifest.get("networks"),
           "alerts": manifest.get("alerts"), "netconf": manifest.get("netconf"),
           "settings": manifest.get("settings"), "copy": manifest.get("copy"),
           "sounds": sorted(n.split("/")[1][:-4] for n, _, _ in files if n.startswith("sounds/")),
           "voicemail": bool(voicemail_dir) and not notes, "voicemail_files": len(voicemail),
           "files": {n: hashlib.sha256(d).hexdigest() for n, d, _ in files}}
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz", compresslevel=6, format=tarfile.PAX_FORMAT) as tar:
        body = json.dumps(man, ensure_ascii=False, indent=1).encode("utf-8")
        for name, data, mtime in [(MANIFEST, body, man["created"])] + files:
            info = tarfile.TarInfo(name)
            info.size, info.mtime, info.mode = len(data), mtime, 0o600
            info.uid = info.gid = 0
            info.uname = info.gname = "root"
            tar.addfile(info, io.BytesIO(data))
    raw = buf.getvalue()
    if len(raw) > MAX_ARCHIVE:
        raise BackupError("Sauvegarde trop volumineuse (50 Mo au plus).")
    return raw, notes


def read_archive(raw):
    """Valide une archive format 2. Renvoie un dict : pbx, networks, alerts, netconf, settings,
    copy, sounds {nom: octets}, voicemail [(chemin relatif, octets, mtime)], manifest."""
    if len(raw) > MAX_ARCHIVE:
        raise BackupError("Sauvegarde trop volumineuse (50 Mo au plus).")
    bad = BackupError("Ce fichier n'est pas une sauvegarde VOIPbuntu.")
    try:
        tar = tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz")
    except (tarfile.TarError, OSError, EOFError):
        raise bad from None
    contents, total = {}, 0
    try:
        for count, m in enumerate(tar):
            if count >= MAX_MEMBERS:
                raise BackupError("Sauvegarde invalide : trop de fichiers.")
            name = m.name
            if not m.isfile() or name in contents:
                raise BackupError("Sauvegarde invalide : contenu inattendu (%s)." % name[:80])
            if name != MANIFEST and not re.match(r"^sounds/[a-z]+\.wav$", name) and not voicemail_member_ok(name):
                raise BackupError("Sauvegarde invalide : contenu inattendu (%s)." % name[:80])
            total += m.size
            if total > MAX_CONTENT + 4 * 1024 * 1024:
                raise BackupError("Sauvegarde trop volumineuse (50 Mo au plus).")
            h = tar.extractfile(m)
            data = h.read(m.size + 1) if h else b""
            if len(data) != m.size:
                raise bad
            contents[name] = (data, int(m.mtime))
    except (tarfile.TarError, OSError, EOFError, zlib.error):
        raise bad from None
    finally:
        tar.close()
    if MANIFEST not in contents:
        raise bad
    try:
        man = json.loads(contents[MANIFEST][0].decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise bad from None
    if not isinstance(man, dict) or man.get("format") != FORMAT or man.get("format_version") != ARCHIVE_VERSION:
        raise bad
    sums = man.get("files")
    if not isinstance(sums, dict) or set(sums) != set(contents) - {MANIFEST}:
        raise BackupError("Sauvegarde invalide : liste des fichiers incohérente.")
    for name, (data, _) in contents.items():
        if name != MANIFEST and hashlib.sha256(data).hexdigest() != sums[name]:
            raise BackupError("Sauvegarde abîmée : empreinte différente pour %s." % name[:80])
    state, nets = read_payload(dict(man, format_version=1))
    sounds = {}
    for name in pbx.SOUNDS:
        if "sounds/%s.wav" % name in contents:
            sounds[name] = contents["sounds/%s.wav" % name][0]
    if len(sounds) != len([n for n in contents if n.startswith("sounds/")]):
        raise BackupError("Sauvegarde invalide : annonce inconnue.")
    voicemail = sorted((n, d, t) for n, (d, t) in contents.items() if n.startswith("voicemail/"))
    return {"pbx": state, "networks": nets, "alerts": man.get("alerts"), "netconf": man.get("netconf"),
            "settings": man.get("settings"), "copy": man.get("copy"), "sounds": sounds,
            "voicemail": voicemail, "has_voicemail": bool(man.get("voicemail")), "manifest": man, "archive": True}


def load_any(raw):
    """Sauvegarde envoyée ou stockée, en octets : archive format 2 ou JSON 0.2 à 0.8."""
    if is_archive(raw):
        return read_archive(bytes(raw))
    if len(raw) > MAX_FILE:
        raise BackupError("Sauvegarde trop volumineuse.")
    try:
        data = json.loads(bytes(raw).decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise BackupError("Ce fichier n'est pas une sauvegarde VOIPbuntu.") from None
    state, nets = read_payload(data)
    return {"pbx": state, "networks": nets, "alerts": None, "netconf": None, "settings": None, "copy": None,
            "sounds": {}, "voicemail": [], "has_voicemail": False, "manifest": data, "archive": False}


def read_bytes(name, directory=DEFAULT_DIR):
    path = path_of(name, directory)
    data = read_regular(path, MAX_ARCHIVE)
    if data is None or len(data) >= MAX_ARCHIVE:
        raise BackupError("Sauvegarde trop volumineuse.")
    return data


def write_bytes(path, data, owner=None, mode=0o600):
    """Comme write_json, pour une archive : fichier temporaire exclusif, fchown, renommage."""
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path) or ".", prefix=".voipbuntu-", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as h:
            os.fchmod(h.fileno(), mode)
            if owner:
                os.fchown(h.fileno(), owner[0], owner[1])
            h.write(data)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
