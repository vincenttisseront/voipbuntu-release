"""Traducteur côté serveur. Le français est la langue source ; le catalogue
static/i18n/en.json associe chaque texte français à sa traduction.

La normalisation des espaces est identique à celle de static/i18n.js, pour que
les deux traducteurs donnent le même résultat.
"""

import json
import os
import re

_SPACES = re.compile(r"\s+")
LANGUAGES = ("fr", "en")


def normalize(text):
    return _SPACES.sub(" ", text).strip()


class Translator:
    def __init__(self, static_dir):
        self.catalogs = {"fr": {}}
        path = os.path.join(static_dir, "i18n", "en.json")
        with open(path, "r", encoding="utf-8") as handle:
            raw = json.load(handle)
        self.catalogs["en"] = {normalize(k): v for k, v in raw.items()}

    def translate(self, text, lang):
        if lang not in self.catalogs or lang == "fr":
            return text
        return self.catalogs[lang].get(normalize(text), text)
