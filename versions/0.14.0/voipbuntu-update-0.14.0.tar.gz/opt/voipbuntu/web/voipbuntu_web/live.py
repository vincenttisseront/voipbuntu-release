"""Supervision en direct : lecture de l'instantané écrit par voipbuntu-live (root, AMI locale).

La console ne parle jamais à l'AMI : elle lit /run/voipbuntu-live/live.json et y ajoute les
noms des postes et des files de pbx.json. Rien ici n'écrit dans la configuration d'Asterisk.
"""

import json
import os
import re
import time

from . import pbx

SNAPSHOT = "/run/voipbuntu-live/live.json"
REQUEST = "/var/lib/voipbuntu/live-hangup.json"
STALE_SECONDS = 10
MAX_SNAPSHOT = 4 * 1024 * 1024
CALL_ID_RE = re.compile(r"^[0-9]{1,12}\.[0-9]{1,9}$")
QUEUE_PREFIX = "voipbuntu-file-"
# État d'un appareil selon Asterisk (DeviceStateList) -> état affiché du poste
DEVICE_STATES = {"NOT_INUSE": "free", "INUSE": "busy", "BUSY": "busy", "ONHOLD": "busy", "RINGINUSE": "busy",
                 "RINGING": "ringing", "UNAVAILABLE": "offline", "INVALID": "offline", "UNKNOWN": "offline"}
# Ne pas déranger (lot J) : AstDB DND/<poste> non nul, ou état d'appareil Custom:DND<poste> à BUSY ou INUSE
DND_STATES = ("BUSY", "INUSE", "ONHOLD")
# Membre de file disponible : AST_DEVICE_NOT_INUSE (1), ni en pause ni déjà en ligne
MEMBER_FREE = 1


def read_snapshot(path=SNAPSHOT):
    try:
        with open(path, "rb") as handle:
            data = handle.read(MAX_SNAPSHOT + 1)
    except OSError:
        return None
    if len(data) > MAX_SNAPSHOT:
        return None
    try:
        snap = json.loads(data.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return None
    return snap if isinstance(snap, dict) else None


def endpoint_of(channel):
    """PJSIP/101-0000002a -> 101 ; None pour un canal qui n'est pas PJSIP (Local, messagerie...)."""
    m = re.match(r"^PJSIP/(.+)-[0-9a-f]{8}$", channel or "")
    return m.group(1) if m else None


def _str(value, size=80):
    return str(value)[:size] if isinstance(value, (str, int, float)) else ""


def _int(value):
    return int(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else 0


def build_calls(channels, by_user, trunk=pbx.TRUNK, queue_names=None):
    """Appels en cours, un par appel (Linkedid) : appelant, appelé, durée, ligne ou interne."""
    queue_names = queue_names or {}
    groups = {}
    for ch in channels:
        if isinstance(ch, dict) and CALL_ID_RE.match(_str(ch.get("linkedid"), 32)):
            groups.setdefault(ch["linkedid"], []).append(ch)
    calls = []
    for call_id, chans in groups.items():
        origin = next((c for c in chans if c.get("uniqueid") == call_id), chans[0])
        others = [c for c in chans if c is not origin]
        o_ep = endpoint_of(origin.get("channel"))
        eps = [endpoint_of(c.get("channel")) for c in others]
        if o_ep == trunk:
            kind = "incoming"
        elif trunk in eps:
            kind = "outgoing"
        else:
            kind = "internal"
        if o_ep in by_user:
            caller, caller_name = by_user[o_ep]["number"], by_user[o_ep]["name"]
        else:
            caller, caller_name = _str(origin.get("caller"), 40), _str(origin.get("caller_name"), 60)
        partner = next((c for c in others if endpoint_of(c.get("channel")) in by_user), None) if kind != "outgoing" \
            else next((c for c in others if endpoint_of(c.get("channel")) == trunk), None)
        dialed = _str(origin.get("exten"), 40)
        if partner is not None and endpoint_of(partner.get("channel")) in by_user:
            ext = by_user[endpoint_of(partner["channel"])]
            callee, callee_name = ext["number"], ext["name"]
        elif kind == "outgoing":
            callee = _str(origin.get("connected"), 40) or dialed
            callee_name = ""
        else:
            callee, callee_name = dialed, ""
        app = _str(origin.get("application"), 30)
        states = [_str(c.get("state"), 20) for c in others]
        if partner is not None and _str(partner.get("state"), 20) == "Up" and origin.get("state") == "Up":
            status = "up"
        elif any(s in ("Ringing", "Ring") for s in states) or origin.get("state") in ("Ring", "Ringing"):
            status = "ringing"
        elif app == "Queue":
            status = "queue"
        elif app == "VoiceMail":
            status = "voicemail"
        elif origin.get("state") == "Up":
            status = "up"
        else:
            status = "dialing"
        queue = queue_names.get(callee) if app == "Queue" else None
        calls.append({"id": call_id, "caller": caller, "caller_name": caller_name, "callee": callee,
                      "callee_name": callee_name or (queue or ""), "seconds": _int(origin.get("seconds")),
                      "kind": kind, "status": status, "channels": len(chans)})
    calls.sort(key=lambda c: -c["seconds"])
    return calls


def build(snapshot, state, now=None):
    """Vue de la console : appels, postes, files. state : pbx.json validé."""
    now = time.time() if now is None else now
    exts = state.get("extensions", [])
    by_user = {e["sip_user"]: e for e in exts}
    view = {"available": False, "error": None, "age": None, "calls": [], "extensions": [], "queues": [],
            "updated": None}
    if snapshot is None:
        view["error"] = "absent"
    else:
        ts = snapshot.get("ts") if isinstance(snapshot.get("ts"), (int, float)) else 0
        view["age"] = round(max(0, now - ts), 1)
        view["updated"] = ts or None
        if now - ts > STALE_SECONDS:
            view["error"] = "stale"
        elif snapshot.get("ok") is not True:
            view["error"] = "ami"
        else:
            view["available"] = True
    snap = snapshot if view["available"] else {}
    channels = snap.get("channels") if isinstance(snap.get("channels"), list) else []
    devices = snap.get("devices") if isinstance(snap.get("devices"), dict) else {}
    queues = {q["number"]: q for q in state.get("queues", [])}
    dnd_list = {str(n) for n in snap.get("dnd", []) if isinstance(n, str)} if isinstance(snap.get("dnd"), list) else set()
    view["calls"] = build_calls(channels, by_user, queue_names={n: q["name"] for n, q in queues.items()})
    ringing = {endpoint_of(c.get("channel")) for c in channels if isinstance(c, dict) and c.get("state") in ("Ringing", "Ring")}
    talking = {endpoint_of(c.get("channel")) for c in channels if isinstance(c, dict) and c.get("state") == "Up"}
    for e in exts:
        dnd = False
        if not view["available"]:
            st = "unknown"
        else:
            st = DEVICE_STATES.get(_str(devices.get("PJSIP/%s" % e["sip_user"]), 20), "offline")
            if st == "free" and e["sip_user"] in ringing:
                st = "ringing"
            elif st == "free" and e["sip_user"] in talking:
                st = "busy"
            if (_str(devices.get("Custom:DND%s" % e["number"]), 20) in DND_STATES or e["number"] in dnd_list) \
                    and st != "offline":
                st = "dnd" if st == "free" else st
                dnd = True
        view["extensions"].append({"number": e["number"], "name": e["name"], "state": st,
                                   "dnd": dnd})
    live_queues = {}
    for q in snap.get("queues") if isinstance(snap.get("queues"), list) else []:
        if isinstance(q, dict) and _str(q.get("queue")).startswith(QUEUE_PREFIX):
            live_queues[_str(q["queue"])[len(QUEUE_PREFIX):]] = q
    for number, q in queues.items():
        lq = live_queues.get(number, {})
        entries = [x for x in lq.get("entries", []) if isinstance(x, dict)] if isinstance(lq.get("entries"), list) else []
        members = [m for m in lq.get("members", []) if isinstance(m, dict)] if isinstance(lq.get("members"), list) else []
        free = sum(1 for m in members if _int(m.get("status")) == MEMBER_FREE and not m.get("paused") and not m.get("in_call"))
        view["queues"].append({"number": number, "name": q["name"], "waiting": len(entries),
                               "longest": max([_int(x.get("wait")) for x in entries] or [0]),
                               "available": free if view["available"] else None,
                               "members": len(q.get("members", []))})
    counts = {"calls": len(view["calls"]), "incoming": sum(1 for c in view["calls"] if c["kind"] == "incoming"),
              "outgoing": sum(1 for c in view["calls"] if c["kind"] == "outgoing"),
              "waiting": sum(q["waiting"] for q in view["queues"])}
    for s in ("free", "ringing", "busy", "offline", "dnd", "unknown"):
        counts[s] = sum(1 for e in view["extensions"] if e["state"] == s)
    view["counts"] = counts
    return view


def write_request(path, call_id):
    """Demande de raccrochage pour voipbuntu-live hangup (root la relit et la revalide)."""
    tmp = path + ".tmp"
    old = os.umask(0o077)
    try:
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump({"call": call_id, "ts": time.time()}, handle)
        os.replace(tmp, path)
    finally:
        os.umask(old)
