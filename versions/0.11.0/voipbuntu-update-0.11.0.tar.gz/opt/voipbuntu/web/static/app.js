/* Console VOIPbuntu : navigation par onglets, API JSON, graphiques SVG.
   Aucun innerHTML : tout le contenu dynamique passe par textContent. */
(function () {
  "use strict";
  var t = function (s) { return window.I18N.t(s); };
  var state = { csrf: "", range: "1h", metric: "cpu", timer: null, series: null, statsTick: 0 };
  var SCREENS = { tableau: ["indicateurs", "services"], telephonie: ["postes", "etat", "reseaux", "groupes", "ligne", "menu-vocal", "messagerie", "annuaire", "appels"], systeme: ["general", "maj", "taches", "sauvegarde", "journaux", "compte", "journal"] };
  var SVG = "http://www.w3.org/2000/svg";
  SCREENS.systeme.splice(SCREENS.systeme.indexOf("sauvegarde") + 1, 0, "alertes");
  SCREENS.telephonie.splice(SCREENS.telephonie.indexOf("menu-vocal") + 1, 0, "files");  // files d'attente
  SCREENS.systeme.splice(SCREENS.systeme.indexOf("journaux") + 1, 0, "diagnostic");  // diagnostic SIP
  SCREENS.systeme.splice(SCREENS.systeme.indexOf("compte") + 1, 0, "ad");  // Active Directory
  SCREENS.supervision = ["direct"];  // supervision en direct

  function $(id) { return document.getElementById(id); }
  function el(tag, text, cls) {
    var node = document.createElement(tag);
    if (text !== undefined && text !== null) { node.textContent = text; }
    if (cls) { node.className = cls; }
    return node;
  }
  function svg(tag, attrs) {
    var node = document.createElementNS(SVG, tag);
    Object.keys(attrs || {}).forEach(function (k) { node.setAttribute(k, attrs[k]); });
    return node;
  }

  function api(method, path, body) {
    var opts = { method: method, credentials: "same-origin", headers: { "Accept": "application/json" } };
    if (body !== undefined) {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(body);
    }
    if (method !== "GET") { opts.headers["X-CSRF-Token"] = state.csrf; }
    return fetch(path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (data) {
        if (r.status === 401 && path.indexOf("/api/login") !== 0) { showLogin(); }
        if (!r.ok) { var e = new Error(data.error || t("Erreur interne.")); e.status = r.status; e.restart = data.restart === true; throw e; }
        return data;
      });
    });
  }

  function toast(message) {
    var box = $("toast");
    box.textContent = message;
    box.hidden = false;
    clearTimeout(toast.timer);
    toast.timer = setTimeout(function () { box.hidden = true; }, 4000);
  }

  function confirmDialog(title, text) {
    var dialog = $("dialog");
    $("dialog-title").textContent = title;
    $("dialog-text").textContent = text;
    return new Promise(function (resolve) {
      dialog.addEventListener("close", function handler() {
        dialog.removeEventListener("close", handler);
        resolve(dialog.returnValue === "ok");
      });
      dialog.showModal();
    });
  }

  /* ---------------------------------------------------------- formats */
  function fmtBytes(v) {
    if (v === null || v === undefined) { return "–"; }
    var units = ["o", "Ko", "Mo", "Go", "To"];
    var i = 0;
    while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
    return (i ? v.toFixed(1) : Math.round(v)) + " " + t(units[i]);
  }
  function fmtDuration(s) {
    var d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
    return (d ? d + " " + t("j") + " " : "") + h + " h " + m + " min";
  }
  function fmtTime(ts) {
    return new Date(ts * 1000).toLocaleString(window.I18N.lang() === "en" ? "en-GB" : "fr-FR");
  }
  function last(values) {
    for (var i = values.length - 1; i >= 0; i--) { if (values[i] !== null) { return values[i]; } }
    return null;
  }

  /* ---------------------------------------------------------- navigation */
  function route() {
    var parts = (location.hash || "#tableau").slice(1).split("/");
    var screen = SCREENS[parts[0]] ? parts[0] : "tableau";
    var tab = SCREENS[screen].indexOf(parts[1]) >= 0 ? parts[1] : SCREENS[screen][0];
    document.querySelectorAll(".screen").forEach(function (s) { s.hidden = s.getAttribute("data-screen") !== screen; });
    document.querySelectorAll("nav a").forEach(function (a) {
      if (a.getAttribute("data-screen") === screen) { a.setAttribute("aria-current", "page"); }
      else { a.removeAttribute("aria-current"); }
    });
    var current = document.querySelector('.screen[data-screen="' + screen + '"]');
    current.querySelectorAll('[role="tab"]').forEach(function (b) {
      var on = b.getAttribute("data-tab") === tab;
      b.setAttribute("aria-selected", on ? "true" : "false");
      b.tabIndex = on ? 0 : -1;
    });
    current.querySelectorAll('[role="tabpanel"]').forEach(function (p) { p.hidden = p.getAttribute("data-tab") !== tab; });
    refresh(screen, tab);
  }

  function bindTabs() {
    /* état ARIA initial, y compris pour les écrans pas encore ouverts */
    document.querySelectorAll('[role="tab"]').forEach(function (b) { b.setAttribute("aria-selected", "false"); b.tabIndex = -1; });
    document.querySelectorAll('[role="tablist"]').forEach(function (list) {
      var screen = list.closest(".screen").getAttribute("data-screen");
      list.addEventListener("click", function (ev) {
        var b = ev.target.closest('[role="tab"]');
        if (b) { location.hash = screen + "/" + b.getAttribute("data-tab"); }
      });
      list.addEventListener("keydown", function (ev) {
        if (ev.key !== "ArrowRight" && ev.key !== "ArrowLeft") { return; }
        var tabs = Array.prototype.slice.call(list.querySelectorAll('[role="tab"]'));
        var i = tabs.indexOf(document.activeElement);
        var next = tabs[(i + (ev.key === "ArrowRight" ? 1 : tabs.length - 1)) % tabs.length];
        next.focus();
        location.hash = screen + "/" + next.getAttribute("data-tab");
      });
    });
  }

  /* ---------------------------------------------------------- données */
  function refresh(screen, tab) {
    clearInterval(state.timer);
    var first = true;
    var run = function () {
      if (screen === "tableau") { loadStatus(); if (tab === "indicateurs") { loadMetrics(); if (first || ++state.statsTick % 4 === 0) { loadMissed(); } } }
      if (screen === "telephonie" && tab === "annuaire") { if (first) { loadDirectory(); loadSpeedDials(); loadLdap(); } return; }
      if (screen === "telephonie" && tab === "menu-vocal") { loadIvr(first); return; }
      if (screen === "telephonie" && tab === "postes") { loadProvisioning(first); }  // provisionnement des téléphones
      if (screen === "telephonie" && tab === "postes") { loadCallerIds(first); }  // numéro présenté, ne pas déranger
      if (screen === "telephonie" && tab === "ligne") { loadSda(first); }  // numéros directs et fermetures
      if (screen === "telephonie" && tab === "files") { loadQueues(first); return; }
      if (screen === "telephonie") {
        if (tab === "appels") { loadCalls(); if (first) { loadCallStats(); } } else if (tab === "reseaux") { if (first) { loadNetworks(); } }
        else if (tab === "ligne") { loadLine(first); } else if (tab === "groupes") { loadGroups(first); }
        else if (tab === "messagerie") { if (first) { loadMail(); } } else { loadPbx(); }
      }
      if (screen === "systeme") {
        if (tab === "journaux" && (first || $("log-follow").checked)) { loadLogs(); }
        if (tab === "general") { loadStatus(); }
        if (tab === "reseau-appliance") { loadNetconf(first).catch(function (e) { toast(e.message); }); }
        if (tab === "maj") { loadUpdate(); loadMaintenance(first); }
        if (tab === "taches") { loadJobs(); }
        if (tab === "journal") { loadAudit(); }
        if (tab === "sauvegarde") { loadBackups(first); loadCopy(first); }
        if (tab === "alertes") { loadAlerts(first); }
        if (tab === "compte") { loadAccounts(); }
        if (tab === "diagnostic") { loadDiagnostic(first); }
        if (tab === "ad") { loadAd(first); }
      }
    };
    if (screen === "supervision") { run = loadLive; }  // supervision en direct : toutes les 3 secondes
    run();
    first = false;
    state.timer = setInterval(run, screen === "supervision" ? 3000 : screen === "systeme" && tab === "journaux" ? 5000 : 15000);
  }

  function loadStatus() {
    return api("GET", "/api/status").then(function (s) {
      $("kpi-mem").textContent = s.memory.percent + " %";
      $("kpi-disk").textContent = s.disk.percent + " %";
      $("kpi-uptime").textContent = fmtDuration(s.uptime);
      $("sys-hostname").textContent = s.hostname;
      $("sys-version").textContent = s.version;
      $("sys-os").textContent = s.os;
      $("sys-addresses").textContent = s.addresses.map(function (a) { return a.interface + " " + a.address; }).join(", ") || "–";
      var body = $("services-body");
      body.textContent = "";
      s.services.forEach(function (svc) {
        var tr = el("tr");
        tr.appendChild(el("td", svc.name));
        var td = el("td");
        var badge = el("span", t(svc.state === "active" ? "actif" : svc.state === "inactive" ? "inactif" : svc.state === "failed" ? "en échec" : "inconnu"),
          "state " + (svc.state === "active" ? "ok" : svc.state === "failed" ? "bad" : "warn"));
        td.appendChild(badge);
        tr.appendChild(td);
        body.appendChild(tr);
      });
    }).catch(function () {});
  }

  function loadPbx() {
    return api("GET", "/api/pbx").then(function (p) {
      var body = $("ext-body"), reg = $("reg-body"), count = 0;
      body.textContent = "";
      reg.textContent = "";
      state.extensions = p.extensions;
      $("ext-empty").hidden = p.extensions.length > 0;
      p.extensions.forEach(function (x) {
        var tr = el("tr");
        tr.appendChild(el("td", x.number));
        tr.appendChild(el("td", x.name));
        tr.appendChild(el("td", x.sip_user, x.sip_user === x.number ? "muted" : ""));
        tr.appendChild(el("td", x.voicemail ? (x.email ? t("oui") + ", " + x.email : t("oui")) : t("non")));
        var st = el("td");
        st.appendChild(el("span", x.registered ? t("enregistré") : t("non enregistré"), "state " + (x.registered ? "ok" : "warn")));
        if (x.dnd) { st.appendChild(document.createTextNode(" ")); st.appendChild(el("span", t("ne pas déranger"), "state warn")); }
        tr.appendChild(st);
        var act = el("td");
        var show = el("button", t("Fiche"), "ghost small");
        show.type = "button";
        show.setAttribute("aria-label", t("Fiche du poste") + " " + x.number);
        show.addEventListener("click", function () { revealSecret(x.number, false); });
        var edit = el("button", t("Modifier"), "ghost small");
        edit.type = "button";
        edit.setAttribute("aria-label", t("Modifier le poste") + " " + x.number);
        edit.addEventListener("click", function () { openEdit(x); });
        var renew = el("button", t("Nouveau mot de passe"), "ghost small");
        renew.type = "button";
        renew.addEventListener("click", function () {
          confirmDialog(t("Nouveau mot de passe"), t("Le poste devra être reconfiguré avec le nouveau mot de passe SIP. Continuer ?")).then(function (ok) {
            if (ok) { revealSecret(x.number, true); }
          });
        });
        var del = el("button", t("Supprimer"), "danger small");
        del.type = "button";
        del.addEventListener("click", function () {
          confirmDialog(t("Supprimer"), t("Supprimer le poste") + " " + x.number + " ?").then(function (ok) {
            if (!ok) { return; }
            api("POST", "/api/pbx/delete", { number: x.number }).then(function () {
              toast(t("Poste supprimé."));
              loadPbx();
            }).catch(function (e) { toast(e.message); });
          });
        });
        act.appendChild(show); act.appendChild(edit); act.appendChild(renew); act.appendChild(del);
        var assoc = el("button", t("Associer un téléphone"), "ghost small");  // provisionnement
        assoc.type = "button";
        assoc.addEventListener("click", function () { provAssociate(x.number); });
        act.appendChild(assoc);
        tr.appendChild(act);
        body.appendChild(tr);
        if (x.registered) {
          count += 1;
          var r = el("tr");
          r.appendChild(el("td", x.number));
          r.appendChild(el("td", x.name));
          r.appendChild(el("td", x.user_agent || "–"));
          r.appendChild(el("td", x.network ? (x.network_label ? x.network_label + " (" + x.network + ")" : x.network) : t("hors réseaux déclarés")));
          r.appendChild(el("td", x.address || "–"));
          r.appendChild(el("td", x.rtt ? Math.round(parseFloat(x.rtt)) + " ms" : "–"));
          reg.appendChild(r);
        }
      });
      var run = $("pbx-running");
      run.textContent = "";
      run.appendChild(el("span", p.running ? t("actif") : p.running === false ? t("arrêté") : t("inconnu"),
        "state " + (p.running ? "ok" : "bad")));
      $("pbx-count").textContent = count + " / " + p.extensions.length;
      $("reg-empty").hidden = count > 0;
      var att = $("att-body");
      att.textContent = "";
      (p.attempts || []).forEach(function (a) {
        var tr = el("tr");
        tr.appendChild(el("td", a.user));
        tr.appendChild(el("td", a.address));
        tr.appendChild(el("td", a.network ? (a.network_label || a.network) : t("hors réseaux déclarés")));
        var why = el("td");
        why.appendChild(el("span", a.reason === "auth" ? t("mot de passe refusé") + " (" + a.extension + ")" : t("identifiant inconnu"), "state warn"));
        tr.appendChild(why);
        tr.appendChild(el("td", a.last + " (" + a.count + "×)"));
        var act = el("td");
        var b;
        if (a.reason === "auth") {
          b = el("button", t("Fiche"), "ghost small");
          b.addEventListener("click", function () { revealSecret(a.extension, false); });
        } else {
          b = el("button", t("Attribuer un numéro"), "primary small");
          b.addEventListener("click", function () {
            location.hash = "telephonie/postes";
            $("ext-sip").value = a.user;
            if (/^[1-9][0-9]{1,5}$/.test(a.user)) { $("ext-number").value = a.user; }
            $("ext-name").focus();
          });
        }
        b.type = "button";
        act.appendChild(b);
        tr.appendChild(act);
        att.appendChild(tr);
      });
      $("att-empty").hidden = (p.attempts || []).length > 0;
      $("pbx-calls").textContent = p.calls === null || p.calls === undefined ? "–" : String(p.calls);
    }).catch(function () {});
  }

  var DISPOSITIONS = { "ANSWERED": "répondu", "NO ANSWER": "sans réponse", "BUSY": "occupé", "FAILED": "échec", "CONGESTION": "échec" };

  var DIRECTIONS = { "interne": "interne", "sortant": "sortant", "entrant": "entrant" };

  function fmtCallDuration(s) {
    var m = Math.floor(s / 60), r = s % 60;
    return m + ":" + (r < 10 ? "0" : "") + r;
  }

  function callFilters() {
    var q = [];
    [["ext", "cf-ext"], ["direction", "cf-direction"], ["status", "cf-status"], ["from", "cf-from"], ["to", "cf-to"]].forEach(function (f) {
      var v = $(f[1]).value;
      if (v) { q.push(f[0] + "=" + encodeURIComponent(v)); }
    });
    return q.join("&");
  }

  function loadCalls() {
    var q = callFilters();
    $("calls-export").href = "/api/pbx/calls?format=csv" + (q ? "&" + q : "");
    return api("GET", "/api/pbx/calls" + (q ? "?" + q : "")).then(function (d) {
      var body = $("calls-body");
      body.textContent = "";
      $("calls-empty").hidden = d.calls.length > 0;
      $("calls-count").textContent = d.total ? d.total + " " + (d.total === 1 ? t("appel") : t("appels")) : "";
      d.calls.forEach(function (c) {
        var tr = el("tr");
        tr.appendChild(el("td", c.start));
        tr.appendChild(el("td", t(DIRECTIONS[c.direction] || "interne")));
        var who = c.direction === "entrant" && c.contact ? c.contact : c.src_name;
        tr.appendChild(el("td", c.src + (who ? " (" + who + ")" : "")));
        tr.appendChild(el("td", c.dst + (c.direction === "sortant" && c.contact ? " (" + c.contact + ")" : "")));
        tr.appendChild(el("td", c.disposition === "ANSWERED" ? fmtCallDuration(c.billsec) : "–"));
        var st = el("td");
        var label = c.status ? statusLabel(c.status) : c.voicemail ? t("messagerie") : t(DISPOSITIONS[c.disposition] || "échec");
        st.appendChild(el("span", label, "state " + (c.disposition === "ANSWERED" && !c.voicemail ? "ok" : c.voicemail ? "warn" : "bad")));
        tr.appendChild(st);
        body.appendChild(tr);
      });
    }).catch(function (e) { toast(e.message); });
  }

  /* ---------------------------------- annuaire, numéros abrégés, statistiques */
  function statusLabel(s) {
    return { repondu: t("répondu"), manque: t("manqué"), occupe: t("occupé"), messagerie: t("messagerie") }[s] || s;
  }

  function kindLabel(k) {
    return { bureau: t("bureau"), mobile: t("mobile"), domicile: t("domicile"), autre: t("autre") }[k] || k;
  }

  function fmtNumber(n) {
    return /^0[1-9][0-9]{8}$/.test(n) ? n.replace(/(\d\d)(?=\d)/g, "$1 ") : n;
  }

  function loadMissed() {
    return api("GET", "/api/pbx/calls/stats").then(function (d) {
      var body = $("missed-body");
      body.textContent = "";
      $("missed-empty").hidden = d.missed.length > 0;
      d.missed.forEach(function (m) {
        var tr = el("tr");
        tr.appendChild(el("td", m.number + " " + m.name));
        var today = el("td");
        today.appendChild(el("span", String(m.today), m.today ? "state bad" : "muted"));
        tr.appendChild(today);
        tr.appendChild(el("td", String(m.week)));
        body.appendChild(tr);
      });
    }).catch(function () {});
  }

  function loadCallStats() {
    api("GET", "/api/pbx").then(function (p) {
      var sel = $("cf-ext"), keep = sel.value;
      while (sel.options.length > 1) { sel.remove(1); }
      p.extensions.forEach(function (x) { var o = el("option", x.number + " " + x.name); o.value = x.number; sel.appendChild(o); });
      sel.value = keep;
    }).catch(function () {});
    return api("GET", "/api/pbx/calls/stats").then(function (d) {
      $("cs-total").textContent = String(d.total);
      $("cs-average").textContent = d.answered ? fmtCallDuration(d.average_seconds) : "–";
      $("cs-missed").textContent = d.inbound ? Math.round(d.inbound_missed_ratio * 100) + " % (" + d.inbound_missed + "/" + d.inbound + ")" : "–";
      drawCallChart(d.days);
    }).catch(function (e) { toast(e.message); });
  }

  function drawCallChart(days) {
    var box = $("cs-chart");
    box.textContent = "";
    var W = 720, H = 200, L = 36, R = 8, T = 10, B = 24, max = 1;
    days.forEach(function (d) { if (d.total > max) { max = d.total; } });
    var step = (W - L - R) / days.length, bw = Math.max(2, step * 0.7);
    var y = function (v) { return T + (H - T - B) * (1 - v / max); };
    var root = svg("svg", { viewBox: "0 0 " + W + " " + H, preserveAspectRatio: "none", "class": "chart-svg" });
    [0, Math.ceil(max / 2), max].forEach(function (gv) {
      root.appendChild(svg("line", { x1: L, x2: W - R, y1: y(gv), y2: y(gv), "class": "grid" }));
      var label = svg("text", { x: L - 6, y: y(gv) + 4, "text-anchor": "end", "class": "axis" });
      label.textContent = String(gv);
      root.appendChild(label);
    });
    days.forEach(function (d, i) {
      var x = L + i * step + (step - bw) / 2;
      var answered = d.total - d.manque;
      if (answered > 0) { root.appendChild(svg("rect", { x: x, width: bw, y: y(d.total), height: y(d.manque) - y(d.total), "class": "bar s0" })); }
      if (d.manque > 0) { root.appendChild(svg("rect", { x: x, width: bw, y: y(d.manque), height: y(0) - y(d.manque), "class": "bar s1" })); }
      var title = svg("title", {});
      title.textContent = d.day + " : " + d.total + " " + t("appels") + ", " + d.manque + " " + t("non répondus");
      var hit = svg("rect", { x: L + i * step, width: step, y: T, height: H - T - B, fill: "transparent" });
      hit.appendChild(title);
      root.appendChild(hit);
      if (i === 0 || i === days.length - 1 || i === Math.floor(days.length / 2)) {
        var tl = svg("text", { x: x + bw / 2, y: H - 8, "text-anchor": i === 0 ? "start" : i === days.length - 1 ? "end" : "middle", "class": "axis" });
        tl.textContent = d.day.slice(8, 10) + "/" + d.day.slice(5, 7);
        root.appendChild(tl);
      }
    });
    box.appendChild(root);
    var legend = el("div", null, "legend");
    [["s0", t("répondus")], ["s1", t("non répondus")]].forEach(function (l) {
      var item = el("span");
      item.appendChild(el("span", "", "swatch " + l[0]));
      item.appendChild(document.createTextNode(l[1]));
      legend.appendChild(item);
    });
    box.appendChild(legend);
  }

  function numberRows(numbers) {
    var box = $("dir-numbers");
    box.textContent = "";
    for (var i = 0; i < 4; i++) {
      var n = numbers[i] || { kind: i === 0 ? "bureau" : i === 1 ? "mobile" : "autre", number: "" };
      var row = el("div", null, "dir-number");
      var sel = el("select");
      sel.setAttribute("aria-label", t("Type de numéro") + " " + (i + 1));
      ["bureau", "mobile", "domicile", "autre"].forEach(function (k) { var o = el("option", kindLabel(k)); o.value = k; sel.appendChild(o); });
      sel.value = n.kind;
      var input = el("input");
      input.maxLength = 30;
      input.inputMode = "tel";
      input.value = n.number;
      input.setAttribute("aria-label", t("Numéro") + " " + (i + 1));
      row.appendChild(sel);
      row.appendChild(input);
      box.appendChild(row);
    }
  }

  function resetContactForm() {
    $("dir-edit").value = "";
    $("dir-name").value = "";
    $("dir-company").value = "";
    $("dir-title").textContent = t("Ajouter un contact");
    $("dir-cancel").hidden = true;
    numberRows([]);
  }

  function editContact(c) {
    $("dir-edit").value = c.id;
    $("dir-name").value = c.name;
    $("dir-company").value = c.company;
    $("dir-title").textContent = t("Modifier le contact");
    $("dir-cancel").hidden = false;
    numberRows(c.numbers);
    $("dir-name").focus();
  }

  function loadDirectory() {
    var q = $("dir-search").value.trim();
    return api("GET", "/api/directory" + (q ? "?q=" + encodeURIComponent(q) : "")).then(function (d) {
      var body = $("dir-body");
      body.textContent = "";
      $("dir-empty").hidden = d.contacts.length > 0;
      $("dir-count").textContent = d.count + " / " + d.max + " " + t("contacts") + (d.total > d.contacts.length ? " – " + t("affinez la recherche pour voir les autres") : "");
      d.contacts.forEach(function (c) {
        var tr = el("tr");
        var who = el("td", c.name || "–");
        if (c.source === "ad") { var adb = el("span", "AD", "badge ad"); adb.title = t("Importé de l'Active Directory"); who.appendChild(adb); }
        tr.appendChild(who);
        tr.appendChild(el("td", c.company || "–"));
        var nums = el("td");
        c.numbers.forEach(function (n) { nums.appendChild(el("span", fmtNumber(n.number) + " (" + kindLabel(n.kind) + ")", "subtle")); });
        tr.appendChild(nums);
        var act = el("td"), edit = el("button", t("Modifier"), "ghost small"), del = el("button", t("Supprimer"), "danger small");
        edit.type = "button"; del.type = "button";
        edit.setAttribute("aria-label", t("Modifier le contact") + " " + (c.name || c.company));
        del.setAttribute("aria-label", t("Supprimer le contact") + " " + (c.name || c.company));
        edit.addEventListener("click", function () { editContact(c); });
        del.addEventListener("click", function () {
          confirmDialog(t("Supprimer"), t("Supprimer le contact") + " " + (c.name || c.company) + " ?").then(function (ok) {
            if (!ok) { return; }
            api("POST", "/api/directory/delete", { id: c.id }).then(function () {
              if ($("dir-edit").value === c.id) { resetContactForm(); }
              loadDirectory();
            }).catch(function (e) { toast(e.message); });
          });
        });
        if (c.source === "ad") { act.appendChild(el("span", t("géré dans l'AD"), "muted")); } else { act.appendChild(edit); act.appendChild(del); }
        tr.appendChild(act);
        body.appendChild(tr);
      });
    }).catch(function (e) { toast(e.message); });
  }

  function loadSpeedDials() {
    return api("GET", "/api/pbx").then(function (p) {
      state.speedDials = p.speed_dials || [];
      $("sd-trunk").hidden = p.trunk.enabled;
      var body = $("sd-body");
      body.textContent = "";
      $("sd-empty").hidden = state.speedDials.length > 0;
      state.speedDials.forEach(function (d) {
        var tr = el("tr");
        tr.appendChild(el("td", "*1" + d.code));
        tr.appendChild(el("td", d.name || "–"));
        tr.appendChild(el("td", fmtNumber(d.number)));
        var act = el("td"), del = el("button", t("Supprimer"), "danger small");
        del.type = "button";
        del.setAttribute("aria-label", t("Supprimer le numéro abrégé") + " *1" + d.code);
        del.addEventListener("click", function () {
          saveSpeedDials(state.speedDials.filter(function (o) { return o.code !== d.code; }));
        });
        act.appendChild(del); tr.appendChild(act);
        body.appendChild(tr);
      });
    }).catch(function (e) { toast(e.message); });
  }

  function saveSpeedDials(list, done) {
    var msg = $("sd-message");
    msg.textContent = ""; msg.className = "";
    return api("POST", "/api/pbx/speed-dials", { speed_dials: list }).then(function () {
      msg.textContent = t("Numéros abrégés enregistrés.");
      if (done) { done(); }
      loadSpeedDials();
    }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
  }

  function readFileBase64(file) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function () {
        var bytes = new Uint8Array(reader.result), bin = "";
        for (var i = 0; i < bytes.length; i += 8192) { bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192)); }
        resolve(btoa(bin));
      };
      reader.onerror = function () { reject(new Error(t("Fichier CSV illisible."))); };
      reader.readAsArrayBuffer(file);
    });
  }

  function bindDirectory() {
    numberRows([]);
    $("dir-search").addEventListener("input", function () {
      clearTimeout(state.dirSearch);
      state.dirSearch = setTimeout(loadDirectory, 250);
    });
    $("dir-cancel").addEventListener("click", resetContactForm);
    $("dir-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("dir-message");
      msg.textContent = ""; msg.className = "";
      var numbers = Array.prototype.map.call($("dir-numbers").querySelectorAll(".dir-number"), function (row) {
        return { kind: row.querySelector("select").value, number: row.querySelector("input").value.trim() };
      }).filter(function (n) { return n.number; });
      var body = { id: $("dir-edit").value, name: $("dir-name").value.trim(), company: $("dir-company").value.trim(), numbers: numbers };
      api("POST", "/api/directory", body).then(function () {
        msg.textContent = t("Contact enregistré.");
        resetContactForm();
        loadDirectory();
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
    $("dir-import-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("dir-import-message"), file = $("dir-file").files[0];
      msg.textContent = ""; msg.className = "";
      if (!file) { msg.textContent = t("Choisissez un fichier CSV."); msg.className = "error"; return; }
      var replace = $("dir-replace").checked;
      var go = replace ? confirmDialog(t("Importer"), t("Remplacer tout l'annuaire par les contacts du fichier ?")) : Promise.resolve(true);
      go.then(function (ok) {
        if (!ok) { return; }
        return readFileBase64(file).then(function (data) {
          return api("POST", "/api/directory/import", { data: data, replace: replace });
        }).then(function (r) {
          msg.textContent = r.added + " " + t("ajoutés") + ", " + r.updated + " " + t("mis à jour") + (r.skipped ? ", " + r.skipped + " " + t("lignes ignorées (sans nom ou sans numéro valable)") : "") + ".";
          ev.target.reset();
          loadDirectory();
        });
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
    $("sd-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var code = $("sd-code").value.trim();
      if (code.length === 1) { code = "0" + code; }
      var list = (state.speedDials || []).filter(function (o) { return o.code !== code; });
      list.push({ code: code, name: $("sd-name").value.trim(), number: $("sd-number").value.trim() });
      saveSpeedDials(list, function () { ev.target.reset(); });
    });
    $("calls-filters").addEventListener("change", function () { loadCalls(); });
    $("calls-filters").addEventListener("submit", function (ev) { ev.preventDefault(); loadCalls(); });
  }

  // Annuaire LDAP des téléphones : réglages, compte de lecture (mot de passe affiché une seule fois)
  function showLdap(d) {
    $("ldap-enabled").checked = d.enabled;
    $("ldap-anonymous").checked = d.anonymous;
    $("ldap-nonets").hidden = d.phone_nets;
    $("ldap-state").textContent = d.enabled ? t("actif") : t("inactif");
    $("ldap-server").textContent = d.servers && d.servers.length ? d.servers.join(t(" ou ")) : location.hostname;
    $("ldap-port").textContent = d.port;
    $("ldap-base").textContent = d.base_dn;
    $("ldap-user").textContent = d.has_account ? d.bind_dn : t("aucun compte (créé à l'activation)");
    $("ldap-name-filter").textContent = d.name_filter;
    $("ldap-number-filter").textContent = d.number_filter;
    $("ldap-entries").textContent = d.contacts + " " + t("contacts") + ", " + d.extensions + " " + t("postes");
    $("ldap-renew").hidden = !d.has_account;
    var box = $("ldap-secret");
    box.hidden = !d.password;
    box.textContent = d.password ? t("Mot de passe du compte de lecture, à recopier maintenant dans les téléphones (il ne sera plus affiché) :") + " " + d.password : "";
  }

  function loadLdap() {
    return api("GET", "/api/directory/ldap").then(showLdap).catch(function (e) { toast(e.message); });
  }

  function bindLdap() {
    $("ldap-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("ldap-message");
      msg.textContent = ""; msg.className = "";
      api("POST", "/api/directory/ldap", { enabled: $("ldap-enabled").checked, anonymous: $("ldap-anonymous").checked }).then(function (d) {
        showLdap(d);
        msg.textContent = t("Réglages de l'annuaire LDAP enregistrés.");
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
    $("ldap-renew").addEventListener("click", function () {
      var msg = $("ldap-message");
      msg.textContent = ""; msg.className = "";
      confirmDialog(t("Renouveler le mot de passe"), t("Les téléphones qui utilisent l'ancien mot de passe ne pourront plus consulter l'annuaire tant qu'il n'est pas remplacé. Continuer ?")).then(function (ok) {
        if (!ok) { return; }
        return api("POST", "/api/directory/ldap/password", {}).then(function (d) {
          showLdap(d);
          msg.textContent = t("Nouveau mot de passe créé.");
        });
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  function loadLogs() {
    var source = $("log-source").value;
    return api("GET", "/api/logs?source=" + encodeURIComponent(source)).then(function (d) {
      var box = $("log-lines");
      var atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 30;
      box.textContent = d.lines.length ? d.lines.join("\n") : t("Journal vide.");
      if (atBottom || box.dataset.source !== source) { box.scrollTop = box.scrollHeight; }
      box.dataset.source = source;
    }).catch(function (e) { toast(e.message); });
  }

  function bindOps() {
    $("log-source").addEventListener("change", loadLogs);
    $("restore-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("restore-message");
      msg.textContent = "";
      msg.className = "";
      var file = $("restore-file").files[0];
      if (!file) { msg.textContent = t("Choisissez un fichier de sauvegarde."); msg.className = "error"; return; }
      if (!/\.json$/i.test(file.name)) { restoreArchive(ev.target, file, msg); return; }
      if (file.size > 900 * 1024) { msg.textContent = t("Ce fichier n'est pas une sauvegarde VOIPbuntu."); msg.className = "error"; return; }
      file.text().then(function (text) {
        var data;
        try { data = JSON.parse(text); } catch (e) { throw new Error(t("Ce fichier n'est pas une sauvegarde VOIPbuntu.")); }
        var count = data && data.pbx && Array.isArray(data.pbx.extensions) ? data.pbx.extensions.length : 0;
        return confirmDialog(t("Restaurer"), t("Remplacer la configuration actuelle par celle de la sauvegarde") + " (" + count + " " + (count === 1 ? t("poste") : t("postes")) + ") ?").then(function (ok) {
          if (!ok) { return; }
          return api("POST", "/api/restore", data).then(function (r) {
            ev.target.reset();
            msg.textContent = restoreDone(r);
          });
        });
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  function restoreDone(r) {
    var text = t("Configuration restaurée") + " : " + r.extensions + " " + (r.extensions === 1 ? t("poste") : t("postes")) +
      (r.networks !== null && r.networks !== undefined ? ", " + r.networks + " " + t("réseau(x) des téléphones") : "");
    if (r.archive) {
      text += ", " + r.sounds + " " + t("annonce(s)");
      if (r.voicemail !== null && r.voicemail !== undefined) { text += ", " + r.voicemail + " " + t("fichier(s) de messagerie vocale"); }
      if (r.network === "restored") { text += ", " + t("réseau de l'appliance en cours d'application"); }
    }
    text += ".";
    if (r.copy_password) { text += " " + t("Ressaisissez le mot de passe du partage réseau pour la copie automatique."); }
    return text;
  }

  /* ------------------------------------------- sauvegardes complètes et copie */
  function restoreArchive(form, file, msg) {
    if (file.size > 50 * 1024 * 1024) { msg.textContent = t("Sauvegarde trop volumineuse (50 Mo au plus)."); msg.className = "error"; return; }
    var network = $("restore-network").checked;
    confirmDialog(t("Restaurer"), t("Remplacer la configuration, les annonces et les messages vocaux par ceux de la sauvegarde ?")).then(function (ok) {
      if (!ok) { return; }
      msg.textContent = t("Restauration en cours…"); msg.className = "";
      return fetch("/api/restore" + (network ? "?network=1" : ""), {
        method: "POST", credentials: "same-origin", body: file,
        headers: { "Accept": "application/json", "Content-Type": "application/gzip", "X-CSRF-Token": state.csrf }
      }).then(function (r) {
        return r.json().catch(function () { return {}; }).then(function (data) {
          if (r.status === 401) { showLogin(); }
          if (!r.ok) { throw new Error(data.error || (r.status === 413 ? t("Sauvegarde trop volumineuse (50 Mo au plus).") : t("Erreur interne."))); }
          form.reset();
          msg.textContent = restoreDone(data); msg.className = "";
        });
      });
    }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
  }

  function copyShowMode() {
    var mode = $("copy-mode").value;
    $("copy-smb").hidden = mode !== "smb";
    $("copy-sftp").hidden = mode !== "sftp";
  }

  function loadCopy(fill) {
    return api("GET", "/api/backups/copy").then(function (d) {
      var s = d.settings, st = d.status, last = $("copy-last");
      if (fill || !state.copyDirty) {
        $("copy-mode").value = s.mode;
        $("copy-keep").value = s.keep;
        $("copy-smb-server").value = s.smb.server; $("copy-smb-share").value = s.smb.share;
        $("copy-smb-folder").value = s.smb.folder; $("copy-smb-domain").value = s.smb.domain;
        $("copy-smb-user").value = s.smb.username; $("copy-smb-pass").value = "";
        $("copy-sftp-host").value = s.sftp.host; $("copy-sftp-port").value = s.sftp.port;
        $("copy-sftp-user").value = s.sftp.username; $("copy-sftp-folder").value = s.sftp.folder;
        $("copy-sftp-fp").value = s.sftp.fingerprint;
        copyShowMode();
      }
      $("copy-smb-pass-state").textContent = s.smb.password_set ? t("Mot de passe enregistré : laissez vide pour le garder.") : "";
      $("copy-sftp-key").textContent = d.sftp_public_key || t("aucune clé pour l'instant");
      last.textContent = "";
      if (st && st.last_run) {
        last.appendChild(el("span", fmtTime(st.last_run) + " : " + (st.kind === "test" ? (st.ok ? t("essai réussi") : t("essai en échec")) : (st.ok ? t("copie réussie") : t("copie en échec"))),
                            "state " + (st.ok ? "ok" : "bad")));
        if (st.message) { last.appendChild(el("div", st.message, "muted")); }
        (st.fingerprints || []).forEach(function (fp) {
          var b = el("button", t("Épingler") + " " + fp, "ghost small");
          b.type = "button";
          b.addEventListener("click", function () { $("copy-sftp-fp").value = fp; state.copyDirty = true; });
          last.appendChild(b);
        });
      } else {
        last.textContent = t("aucune pour l'instant");
      }
    }).catch(function (e) { toast(e.message); });
  }

  function copyPayload() {
    var keep = parseInt($("copy-keep").value, 10), port = parseInt($("copy-sftp-port").value, 10);
    return {
      mode: $("copy-mode").value, keep: isNaN(keep) ? 0 : keep,
      smb: { server: $("copy-smb-server").value.trim(), share: $("copy-smb-share").value.trim(), folder: $("copy-smb-folder").value.trim(),
             domain: $("copy-smb-domain").value.trim(), username: $("copy-smb-user").value.trim(), password: $("copy-smb-pass").value },
      sftp: { host: $("copy-sftp-host").value.trim(), port: isNaN(port) ? 0 : port, username: $("copy-sftp-user").value.trim(),
              folder: $("copy-sftp-folder").value.trim(), fingerprint: $("copy-sftp-fp").value.trim() }
    };
  }

  function copyJob(action, text) {
    var msg = $("copy-message");
    return api("POST", "/api/jobs", { action: action }).then(function () {
      msg.textContent = text; msg.className = "";
      setTimeout(function () { loadCopy(false); }, 5000);
    });
  }

  function bindCopy() {
    $("copy-form").addEventListener("input", function () { state.copyDirty = true; });
    $("copy-mode").addEventListener("change", copyShowMode);
    $("copy-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("copy-message");
      msg.textContent = ""; msg.className = "";
      api("POST", "/api/backups/copy", copyPayload()).then(function () {
        state.copyDirty = false;
        msg.textContent = t("Réglages enregistrés.");
        loadCopy(true);
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
    $("copy-test").addEventListener("click", function () {
      var msg = $("copy-message");
      api("POST", "/api/backups/copy", copyPayload()).then(function () {
        state.copyDirty = false;
        return copyJob("backup-copy-test", t("Essai demandé : le résultat s'affiche dans quelques secondes."));
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
    $("copy-sftp-keygen").addEventListener("click", function () {
      copyJob("backup-sftp-key", t("Création de la clé demandée.")).catch(function (e) { toast(e.message); });
    });
  }

  function loadBackups(fill) {
    return api("GET", "/api/backups").then(function (d) {
      var s = d.settings, st = d.status, last = $("auto-last");
      if (fill || !state.autoDirty) {
        $("auto-enabled").checked = s.enabled;
        $("auto-hour").value = s.hour;
        $("auto-keep").value = s.keep;
        $("auto-email").value = s.email;
        $("auto-voicemail").checked = s.voicemail !== false;
      }
      last.textContent = "";
      if (st && st.last_run) {
        var warn = st.mail_failed ? t("faite, copie par e-mail en échec") : st.copy_failed ? t("faite, copie hors de l'appliance en échec") : t("réussie");
        last.appendChild(el("span", fmtTime(st.last_run) + " : " + (st.ok ? warn : t("en échec")),
                            "state " + (st.ok && !st.mail_failed && !st.copy_failed ? "ok" : st.ok ? "warn" : "bad")));
        if (st.message) { last.appendChild(el("div", st.message, "muted")); }
      } else {
        last.textContent = t("aucune pour l'instant");
      }
      var body = $("auto-body");
      body.textContent = "";
      $("auto-empty").hidden = d.backups.length > 0;
      d.backups.forEach(function (b) {
        var tr = el("tr");
        tr.appendChild(el("td", fmtTime(b.created)));
        tr.appendChild(el("td", b.name));
        tr.appendChild(el("td", fmtBytes(b.size)));
        var act = el("td"), dl = el("a", t("Télécharger"), "button ghost small"), rs = el("button", t("Restaurer"), "danger small");
        dl.href = "/api/backups/file?name=" + encodeURIComponent(b.name);
        dl.setAttribute("download", b.name);
        rs.type = "button";
        rs.setAttribute("aria-label", t("Restaurer") + " " + b.name);
        rs.addEventListener("click", function () {
          confirmDialog(t("Restaurer"), t("Remplacer la configuration actuelle par la sauvegarde du") + " " + fmtTime(b.created) + " ?").then(function (ok) {
            if (!ok) { return; }
            api("POST", "/api/backups/restore", { name: b.name }).then(function (r) { toast(restoreDone(r)); })
              .catch(function (e) { toast(e.message); });
          });
        });
        act.appendChild(dl); act.appendChild(rs); tr.appendChild(act);
        body.appendChild(tr);
      });
    }).catch(function (e) { toast(e.message); });
  }

  function bindBackups() {
    $("auto-form").addEventListener("input", function () { state.autoDirty = true; });
    $("auto-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("auto-message"), hour = parseInt($("auto-hour").value, 10), keep = parseInt($("auto-keep").value, 10);
      msg.textContent = ""; msg.className = "";
      api("POST", "/api/backups/settings", { enabled: $("auto-enabled").checked, hour: isNaN(hour) ? -1 : hour,
                                             keep: isNaN(keep) ? 0 : keep, email: $("auto-email").value.trim(),
                                             voicemail: $("auto-voicemail").checked }).then(function () {
        state.autoDirty = false;
        msg.textContent = t("Réglages enregistrés.");
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
    $("auto-now").addEventListener("click", function () {
      var msg = $("auto-message");
      api("POST", "/api/jobs", { action: "backup-run" }).then(function () {
        msg.textContent = t("Sauvegarde demandée : elle apparaît ci-dessous dans quelques secondes."); msg.className = "";
        setTimeout(function () { loadBackups(false); }, 4000);
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  /* ---------------------------------------------------------- alertes */
  var ALERT_CAUSES = {
    trunk: "Ligne de l'opérateur désenregistrée", asterisk: "Asterisk arrêté", disk: "Disque presque plein",
    backup: "Sauvegarde automatique en échec", update: "Nouvelle version disponible",
    login: "Échecs de connexion répétés à la console", test: "E-mail d'essai"
  };
  var ALERT_KINDS = { "alerte": "Alerte", "rétabli": "Rétabli", "essai": "Essai" };

  function loadAlerts(fill) {
    return api("GET", "/api/alerts").then(function (d) {
      $("alerts-nomail").hidden = d.mail_enabled;
      if (fill || !state.alertsDirty) {
        $("alerts-recipients").value = d.settings.recipients.join(", ");
        var box = $("alerts-causes");
        box.textContent = "";
        d.causes.forEach(function (c) {
          var label = el("label", null, "check"), input = el("input");
          input.type = "checkbox";
          input.setAttribute("data-cause", c.cause);
          input.checked = d.settings.causes[c.cause] !== false;
          label.appendChild(input);
          label.appendChild(el("span", t(ALERT_CAUSES[c.cause] || c.label)));
          box.appendChild(label);
        });
      }
      $("alerts-last").textContent = d.last_run ? fmtTime(d.last_run) : t("pas encore faite");
      var list = $("alerts-active");
      list.textContent = "";
      d.active.forEach(function (a) {
        var li = el("li");
        li.appendChild(el("span", t(ALERT_CAUSES[a.cause] || a.label), "state bad"));
        li.appendChild(el("span", " " + t("depuis le") + " " + fmtTime(a.since) + (a.notified ? " (" + t("alerte envoyée") + ")" : "")));
        if (a.detail) { li.appendChild(el("div", a.detail, "muted")); }
        list.appendChild(li);
      });
      $("alerts-ok").hidden = d.active.length > 0 || !d.last_run;
      var body = $("alerts-body");
      body.textContent = "";
      $("alerts-empty").hidden = d.history.length > 0;
      d.history.forEach(function (h) {
        var tr = el("tr");
        tr.appendChild(el("td", fmtTime(h.ts)));
        tr.appendChild(el("td", t(ALERT_KINDS[h.kind] || h.kind), "state " + (h.kind === "alerte" ? "bad" : "ok")));
        tr.appendChild(el("td", t(ALERT_CAUSES[h.cause] || h.cause)));
        tr.appendChild(el("td", h.detail));
        tr.appendChild(el("td", h.sent ? t("envoyé") : t("non envoyé") + (h.error ? " : " + h.error : ""), h.sent ? "" : "state warn"));
        body.appendChild(tr);
      });
    }).catch(function (e) { toast(e.message); });
  }

  function bindAlerts() {
    $("alerts-form").addEventListener("input", function () { state.alertsDirty = true; });
    $("alerts-form").addEventListener("change", function () { state.alertsDirty = true; });
    $("alerts-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("alerts-message"), causes = {};
      msg.textContent = ""; msg.className = "";
      document.querySelectorAll("#alerts-causes input[data-cause]").forEach(function (i) { causes[i.getAttribute("data-cause")] = i.checked; });
      var rcpt = $("alerts-recipients").value.split(/[,;\s]+/).filter(function (x) { return x; });
      api("POST", "/api/alerts", { recipients: rcpt, causes: causes }).then(function (r) {
        state.alertsDirty = false;
        $("alerts-recipients").value = r.settings.recipients.join(", ");
        msg.textContent = t("Réglages enregistrés.");
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
    $("alerts-test").addEventListener("click", function () {
      var msg = $("alerts-message");
      if (state.alertsDirty) { msg.textContent = t("Enregistrez d'abord les destinataires."); msg.className = "error"; return; }
      api("POST", "/api/jobs", { action: "alerts-test" }).then(function () {
        msg.textContent = t("E-mail d'essai demandé : le résultat apparaît dans l'historique dans quelques secondes."); msg.className = "";
        setTimeout(function () { loadAlerts(false); }, 5000);
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  /* ------------------------------------- provisionnement des téléphones SIP */
  function provResult(status) {
    if (status === 200) { return t("téléchargé"); }
    if (status === 401) { return t("identifiants refusés"); }
    if (status === 403) { return t("réseau refusé"); }
    if (status === 404) { return t("fichier d'un autre téléphone ou absent"); }
    if (status === 429) { return t("trop de demandes"); }
    return String(status);
  }

  function provShowCredentials(number, d) {
    $("prov-cred-number").textContent = number;
    $("prov-cred-url").textContent = d.urls && d.urls.https ? d.urls.https + (d.urls.http ? " " + t("ou") + " " + d.urls.http : "") : "–";
    $("prov-cred-user").textContent = d.user;
    $("prov-cred-password").textContent = d.password;
    $("prov-cred-full").textContent = d.url_with_credentials || "–";
    $("prov-cred").showModal();
  }

  function provFillModels() {
    var vendor = (state.prov && state.prov.vendors[$("prov-vendor").value]) || { models: [] };
    var list = $("prov-models");
    list.textContent = "";
    vendor.models.forEach(function (m) { var o = el("option"); o.value = m; list.appendChild(o); });
  }

  function provAssociate(number) {
    location.hash = "telephonie/postes";
    var sel = $("prov-number");
    if (sel) { sel.value = number; }
    $("prov-form").scrollIntoView({ block: "center" });
    $("prov-mac").focus();
  }

  function loadProvisioning(fill) {
    return Promise.all([api("GET", "/api/provisioning"), api("GET", "/api/provisioning/log").catch(function () { return { entries: [] }; })]).then(function (r) {
      var d = r[0], log = r[1].entries || [];
      state.prov = d;
      var lastByMac = {};
      log.forEach(function (e) { if (e.ok && e.mac && !lastByMac[e.mac]) { lastByMac[e.mac] = e; } });
      var body = $("prov-body");
      body.textContent = "";
      d.phones.forEach(function (p) {
        var tr = el("tr");
        tr.appendChild(el("td", p.orphan ? p.number + " (" + t("poste supprimé") + ")" : p.number + " " + p.name));
        tr.appendChild(el("td", d.vendors[p.vendor].label + " " + p.model));
        tr.appendChild(el("td", p.mac_display));
        tr.appendChild(el("td", p.files.join(", "), "subtle"));
        var seen = lastByMac[p.mac];
        tr.appendChild(el("td", seen ? seen.ts.replace("T", " ").slice(0, 19) + " (" + seen.ip + ")" : t("jamais")));
        var act = el("td");
        var renew = el("button", t("Nouveau mot de passe"), "ghost small");
        renew.type = "button";
        renew.addEventListener("click", function () {
          confirmDialog(t("Nouveau mot de passe"), t("Le téléphone devra recevoir le nouveau mot de passe de provisionnement. Continuer ?")).then(function (ok) {
            if (!ok) { return; }
            api("POST", "/api/provisioning/renew", { mac: p.mac }).then(function (c) { provShowCredentials(p.number, c); })
              .catch(function (e) { toast(e.message); });
          });
        });
        var del = el("button", t("Dissocier"), "danger small");
        del.type = "button";
        del.addEventListener("click", function () {
          confirmDialog(t("Dissocier"), t("Dissocier le téléphone") + " " + p.mac_display + " ?").then(function (ok) {
            if (!ok) { return; }
            api("POST", "/api/provisioning/delete", { mac: p.mac }).then(function () {
              toast(t("Téléphone dissocié : ses fichiers sont supprimés."));
              loadProvisioning(false);
            }).catch(function (e) { toast(e.message); });
          });
        });
        act.appendChild(renew); act.appendChild(del);
        tr.appendChild(act);
        body.appendChild(tr);
      });
      $("prov-empty").hidden = d.phones.length > 0;
      $("prov-url-https").textContent = d.urls.https || t("adresse de l'appliance inconnue");
      $("prov-url-http").textContent = d.urls.http || t("coupé");
      var sel = $("prov-number"), keep = sel.value;
      sel.textContent = "";
      d.extensions.forEach(function (x) { var o = el("option", x.number + " " + x.name); o.value = x.number; sel.appendChild(o); });
      if (keep) { sel.value = keep; }
      if (fill) {
        var vs = $("prov-vendor");
        vs.textContent = "";
        Object.keys(d.vendors).forEach(function (k) { var o = el("option", d.vendors[k].label); o.value = k; vs.appendChild(o); });
        provFillModels();
        $("prov-server").value = d.settings.server;
        $("prov-server").placeholder = d.server || "";
        $("prov-ntp").value = d.settings.ntp;
        $("prov-ntp").placeholder = d.default_ntp;
        $("prov-http").checked = d.settings.http;
      }
      var lb = $("prov-log-body");
      lb.textContent = "";
      log.slice(0, 50).forEach(function (e) {
        var tr = el("tr");
        tr.appendChild(el("td", e.ts.replace("T", " ").slice(0, 19)));
        tr.appendChild(el("td", e.ip));
        tr.appendChild(el("td", e.mac || "–"));
        tr.appendChild(el("td", e.number || "–"));
        tr.appendChild(el("td", e.file || "–"));
        var st = el("td");
        st.appendChild(el("span", provResult(e.status), "state " + (e.ok ? "ok" : "warn")));
        tr.appendChild(st);
        lb.appendChild(tr);
      });
      $("prov-log-empty").hidden = log.length > 0;
    }).catch(function () {});
  }

  function bindProvisioning() {
    $("prov-vendor").addEventListener("change", function () { $("prov-model").value = ""; provFillModels(); });
    $("prov-cred-close").addEventListener("click", function () { $("prov-cred").close(); });
    $("prov-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("prov-message");
      var number = $("prov-number").value;
      api("POST", "/api/provisioning", { number: number, vendor: $("prov-vendor").value, model: $("prov-model").value.trim(),
        mac: $("prov-mac").value.trim() }).then(function (d) {
        msg.textContent = t("Téléphone associé.");
        msg.className = "";
        $("prov-mac").value = "";
        provShowCredentials(number, d);
        loadProvisioning(false);
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
    $("prov-settings").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("prov-settings-message");
      api("POST", "/api/provisioning/settings", { server: $("prov-server").value.trim(), ntp: $("prov-ntp").value.trim(),
        http: $("prov-http").checked }).then(function () {
        msg.textContent = t("Réglages enregistrés : les fichiers des téléphones sont régénérés.");
        msg.className = "";
        loadProvisioning(false);
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  function showSheet(d, title) {
    $("sheet-title").textContent = title + " " + d.number;
    $("sheet-server").textContent = (d.servers && d.servers.length ? d.servers.join(t(" ou ")) : location.hostname);
    $("sheet-port").textContent = d.port + " / " + d.transport;
    $("sheet-user").textContent = d.sip_user || d.number;
    $("sheet-auth").textContent = d.sip_user || d.number;
    $("sheet-secret").textContent = d.secret;
    $("sheet-name").textContent = d.name;
    $("sheet-vm").textContent = d.voicemail ? d.voicemail_code + " · " + t("Code de messagerie") + " : " + d.pin : t("non");
    $("sheet").showModal();
  }

  function revealSecret(number, renew) {
    api("POST", "/api/pbx/secret", { number: number, renew: renew }).then(function (d) {
      showSheet(d, t("Fiche du poste"));
      if (renew) { loadPbx(); }
    }).catch(function (e) { toast(e.message); });
  }

  function openEdit(x) {
    state.editing = x.number;
    $("edit-title").textContent = t("Modifier le poste") + " " + x.number;
    $("edit-number").value = x.number;
    $("edit-name").value = x.name;
    $("edit-voicemail").checked = x.voicemail;
    $("edit-email").value = x.email || "";
    $("edit-message").textContent = "";
    $("edit").showModal();
    $("edit-number").focus();
  }

  /* ---------------------------------------------------------- réseaux */
  function netRow(n) {
    var tr = el("tr");
    tr.dataset.cidr = n.cidr;
    tr.appendChild(el("td", n.cidr));
    var td = el("td");
    var input = el("input");
    input.value = n.label || "";
    input.maxLength = 40;
    input.className = "net-label";
    input.setAttribute("aria-label", t("Nom") + " " + n.cidr);
    td.appendChild(input);
    tr.appendChild(td);
    var st = el("td");
    st.appendChild(el("span", n.removing ? t("retrait en attente") : n.applied ? t("appliqué") : t("à appliquer"),
      "state " + (n.applied && !n.removing ? "ok" : "warn")));
    tr.appendChild(st);
    var act = el("td");
    var del = el("button", t("Retirer"), "danger small");
    del.type = "button";
    del.addEventListener("click", function () { state.netDirty = true; tr.remove(); });
    input.addEventListener("input", function () { state.netDirty = true; });
    act.appendChild(del);
    tr.appendChild(act);
    return tr;
  }

  function loadNetworks() {
    return api("GET", "/api/networks").then(function (d) {
      if (state.netDirty) { return; }  /* modifications en cours : ne pas les écraser */
      var body = $("net-body");
      body.textContent = "";
      d.networks.forEach(function (n) {
        if (d.pending_removal.indexOf(n.cidr) < 0) { body.appendChild(netRow(n)); }
      });
    }).catch(function (e) { toast(e.message); });
  }

  function bindNetworks() {
    $("net-add").addEventListener("click", function () {
      var cidr = $("net-cidr").value.trim(), msg = $("net-message");
      msg.textContent = ""; msg.className = "";
      if (!/^[0-9a-fA-F.:]+(\/[0-9]{1,3})?$/.test(cidr)) { msg.textContent = t("Réseau invalide, par exemple 192.168.20.0/24."); msg.className = "error"; return; }
      state.netDirty = true;
      $("net-body").appendChild(netRow({ cidr: cidr, label: $("net-label").value.trim(), applied: false }));
      $("net-cidr").value = ""; $("net-label").value = "";
    });
    $("net-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("net-message");
      msg.textContent = ""; msg.className = "";
      var list = Array.prototype.map.call($("net-body").querySelectorAll("tr"), function (tr) {
        return { cidr: tr.dataset.cidr, label: tr.querySelector(".net-label").value.trim() };
      });
      var go = list.length ? Promise.resolve(true)
        : confirmDialog(t("Réseaux des téléphones"), t("Sans aucun réseau, plus aucun téléphone ne pourra joindre la téléphonie. Continuer ?"));
      go.then(function (ok) {
        if (!ok) { return; }
        return api("POST", "/api/networks", { networks: list }).then(function (r) {
          state.netDirty = false;
          msg.textContent = r.applied ? t("Réseaux enregistrés : application en cours (pare-feu).") : t("Réseaux enregistrés, mais la file d'attente est indisponible.");
          setTimeout(loadNetworks, 4000);
        });
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  /* ------------------------------------------- réseau de l'appliance */
  SCREENS.systeme.splice(1, 0, "reseau-appliance");

  function ncList(value) { return value.split(/[\s,;]+/).filter(function (x) { return x; }); }
  function ncMask(prefix) {
    if (prefix === null || prefix === undefined || prefix === "") { return ""; }
    var bits = [];
    for (var i = 0; i < 4; i++) { var n = Math.max(0, Math.min(8, prefix - 8 * i)); bits.push(256 - Math.pow(2, 8 - n)); }
    return bits.join(".");
  }
  function ncStepLabel(id) {
    if (id === "resolvers") { return t("Serveurs DNS utilisés"); }
    if (id === "gateway") { return t("Passerelle (ping)"); }
    if (id.indexOf("dns:") === 0) { return t("Résolution DNS de") + " " + id.slice(4); }
    if (id.indexOf("https:") === 0) { return t("Connexion HTTPS à") + " " + id.slice(6); }
    return id;
  }
  function ncError(code) {
    if (code === "dns") { return t("nom introuvable : vérifiez les serveurs DNS"); }
    if (code === "timeout") { return t("délai dépassé"); }
    if (code === "tls") { return t("certificat refusé"); }
    if (code === "refused") { return t("connexion refusée"); }
    if (code === "no-gateway") { return t("aucune passerelle par défaut"); }
    if (code === "http") { return t("erreur du serveur"); }
    return code ? t("injoignable") : "";
  }
  function ncStatusText(s) {
    if (!s) { return ["–", ""]; }
    if (s.pending) { return [t("en attente de confirmation par la console"), "warn"]; }
    if (s.state === "applied") { return [t("appliqué") + (s.ts ? " (" + fmtTime(s.ts) + ")" : ""), "ok"]; }
    if (s.state === "rolled-back") { return [t("ancienne configuration rétablie : la console ne répondait plus") + (s.ts ? " (" + fmtTime(s.ts) + ")" : ""), "bad"]; }
    if (s.state === "failed") { return [t("refusé") + " : " + s.message, "bad"]; }
    return [t("interrompu"), "warn"];
  }
  function ncShowMode() { $("nc-static").hidden = $("nc-mode").value !== "static"; }

  function ncConfirm(d) {
    if (!d.status || !d.status.pending || state.ncConfirmed === d.status.deadline) { return Promise.resolve(false); }
    state.ncConfirmed = d.status.deadline;
    return api("POST", "/api/system/network/confirm", {}).then(function () {
      toast(t("Nouvelle configuration réseau confirmée."));
      return true;
    }).catch(function (e) { state.ncConfirmed = null; toast(e.message); return false; });
  }

  /* Après une connexion à la nouvelle adresse, la confirmation part d'elle-même. */
  function ncConfirmPending() {
    return api("GET", "/api/system/network").then(ncConfirm).catch(function () {});
  }

  function fillNetconf(d) {
    var s = d.settings, net = s.network || {}, iface = $("nc-interface"), tz = $("ns-timezone");
    iface.textContent = "";
    d.live.interfaces.forEach(function (i) {
      var o = el("option", i.name + (i.mac ? " (" + i.mac + ")" : ""));
      o.value = i.name;
      iface.appendChild(o);
    });
    iface.value = net.interface || "";
    $("nc-mode").value = net.mode === "static" ? "static" : "dhcp";
    $("nc-address").value = net.address || "";
    $("nc-mask").value = ncMask(net.prefix);
    $("nc-gateway").value = net.gateway || "";
    $("nc-dns").value = (net.dns || []).join(" ");
    $("nc-search").value = (net.search || []).join(" ");
    ncShowMode();
    $("ns-hostname").value = s.hostname || "";
    $("ns-ntp").value = (s.ntp || []).join(" ");
    tz.textContent = "";
    var zones = d.timezones.length ? d.timezones : [s.timezone || "UTC"];
    zones.forEach(function (z) { var o = el("option", z); o.value = z; tz.appendChild(o); });
    tz.value = s.timezone || "UTC";
  }

  function loadNetconf(fill) {
    return api("GET", "/api/system/network").then(function (d) {
      var live = d.live;
      $("nc-live-address").textContent = live.interfaces.map(function (i) {
        return i.name + " " + (i.addresses.join(", ") || "–") + (i.dhcp ? " (DHCP)" : "");
      }).join(" ; ") || "–";
      $("nc-live-gateway").textContent = live.gateway || "–";
      $("nc-live-dns").textContent = live.dns.join(", ") || "–";
      var st = ncStatusText(d.status), box = $("nc-status");
      box.textContent = "";
      box.appendChild(el("span", st[0], "state " + st[1]));
      $("ns-synced").textContent = live.ntp_synced === true ? t("oui") : live.ntp_synced === false ? t("non") : "–";
      if (fill && !state.ncDirty) { fillNetconf(d); }
      var body = $("nc-check-body");
      body.textContent = "";
      ((d.check && d.check.steps) || []).forEach(function (step) {
        var tr = el("tr");
        tr.appendChild(el("td", ncStepLabel(step.id)));
        var td = el("td");
        td.appendChild(el("span", step.ok ? t("réussi") : t("en échec"), "state " + (step.ok ? "ok" : step.id === "gateway" ? "warn" : "bad")));
        tr.appendChild(td);
        tr.appendChild(el("td", [step.detail, ncError(step.error)].filter(function (x) { return x; }).join(" – ") || "–"));
        body.appendChild(tr);
      });
      state.ncCheckTs = d.check ? d.check.ts : null;
      if (d.check) {
        $("nc-check-when").textContent = (d.check.ok ? t("Accès à Internet et aux mises à jour : correct.") : t("Accès à Internet ou aux mises à jour : en échec.")) + " " + t("Dernier test") + " : " + fmtTime(d.check.ts);
      } else if (!state.ncChecking) {
        $("nc-check-when").textContent = t("Aucun test pour l'instant.");
      }
      return ncConfirm(d).then(function () { return d; });
    });
  }

  function ncPoll(seconds, until) {
    clearInterval(state.ncPoll);
    var end = Date.now() + seconds * 1000;
    state.ncPoll = setInterval(function () {
      if (Date.now() > end) { clearInterval(state.ncPoll); return; }
      loadNetconf(false).then(function (d) { if (until && until(d)) { clearInterval(state.ncPoll); } })
        .catch(function () { /* adresse changée : la page d'origine ne répond plus */ });
    }, 2000);
  }

  function ncSave(body, msg) {
    msg.textContent = ""; msg.className = "";
    return api("POST", "/api/system/network", body).then(function (r) {
      state.ncDirty = false;
      if (!r.applied) { msg.textContent = t("Réglages enregistrés, mais la file d'attente est indisponible."); return; }
      if (r.new_address) {
        var url = "https://" + r.new_address + "/", link = el("a", url);
        link.href = url;
        msg.appendChild(document.createTextNode(t("L'appliance passe à l'adresse") + " " + r.new_address + ". " + t("Ouvrez") + " "));
        msg.appendChild(link);
        msg.appendChild(document.createTextNode(" " + t("et reconnectez-vous dans les 3 minutes pour confirmer ; sinon l'ancienne configuration revient d'elle-même.")));
      } else {
        msg.textContent = t("Réglages enregistrés : application en cours.");
      }
      ncPoll(r.confirm_seconds + 30, function (d) { return d.status && !d.status.pending && d.status.ts && d.status.ts * 1000 > Date.now() - 60000; });
    }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
  }

  function bindNetconf() {
    ["nc-form", "ns-form"].forEach(function (id) {
      $(id).addEventListener("input", function () { state.ncDirty = true; });
      $(id).addEventListener("change", function () { state.ncDirty = true; });
    });
    $("nc-mode").addEventListener("change", ncShowMode);
    $("nc-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("nc-message"), stat = $("nc-mode").value === "static";
      var net = { interface: $("nc-interface").value, mode: $("nc-mode").value, dns: ncList($("nc-dns").value),
                  search: ncList($("nc-search").value) };
      if (stat) { net.address = $("nc-address").value.trim(); net.mask = $("nc-mask").value.trim(); net.gateway = $("nc-gateway").value.trim(); }
      confirmDialog(t("Adresse de l'appliance"), t("La console peut être coupée quelques secondes. Si elle ne répond plus, l'ancienne configuration est rétablie au bout de 3 minutes. Continuer ?")).then(function (ok) {
        if (ok) { ncSave({ network: net }, msg); }
      });
    });
    $("ns-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      ncSave({ hostname: $("ns-hostname").value.trim(), ntp: ncList($("ns-ntp").value), timezone: $("ns-timezone").value }, $("ns-message"));
    });
    $("nc-check").addEventListener("click", function () {
      var before = state.ncCheckTs;
      state.ncChecking = true;
      $("nc-check-when").textContent = t("Test en cours…");
      api("POST", "/api/jobs", { action: "net-check" }).then(function () {
        ncPoll(60, function (d) {
          var done = d.check && d.check.ts !== before;
          if (done) { state.ncChecking = false; }
          return done;
        });
      }).catch(function (e) { state.ncChecking = false; $("nc-check-when").textContent = e.message; });
    });
  }

  /* ------------------------------------------------ ligne et accueil */
  var DAY_LABELS = [["mon", "lun."], ["tue", "mar."], ["wed", "mer."], ["thu", "jeu."], ["fri", "ven."], ["sat", "sam."], ["sun", "dim."]];
  var TRUNK_STATES = { "registered": ["enregistrée auprès de l'opérateur", "ok"], "unregistered": ["en cours d'enregistrement", "warn"],
                       "rejected": ["refusée par l'opérateur : vérifiez l'identifiant et le mot de passe", "bad"] };

  function trunkState(p) {
    var box = $("trunk-state"), tr = p.trunk;
    box.textContent = "";
    if (!tr.enabled) { box.appendChild(el("span", t("désactivée"), "state")); return; }
    if (!tr.register) { box.appendChild(el("span", t("active, sans enregistrement"), "state ok")); return; }
    var st = TRUNK_STATES[tr.state] || ["inconnu", "warn"];
    box.appendChild(el("span", t(st[0]), "state " + st[1]));
  }

  function fillLine(p) {
    var tr = p.trunk, rec = p.reception;
    $("trunk-enabled").checked = tr.enabled;
    $("trunk-host").value = tr.host;
    $("trunk-port").value = tr.port;
    $("trunk-user").value = tr.username;
    $("trunk-auth").value = tr.auth_username;
    $("trunk-pass").value = "";
    $("trunk-pass").placeholder = tr.password_set ? t("inchangé") : "";
    $("trunk-cid").value = tr.caller_id;
    $("trunk-public").value = tr.public_address;
    $("trunk-register").checked = tr.register;
    $("trunk-intl").checked = tr.international;
    var members = $("rec-members"), box = $("rec-box");
    members.textContent = "";
    p.extensions.forEach(function (x) {
      var label = el("label", null, "check"), input = el("input");
      input.type = "checkbox"; input.value = x.number; input.checked = rec.members.indexOf(x.number) >= 0;
      label.appendChild(input);
      label.appendChild(el("span", x.number + " " + x.name));
      members.appendChild(label);
    });
    if (!p.extensions.length) { members.appendChild(el("p", t("Aucun poste : créez d'abord les postes."), "muted")); }
    box.textContent = "";
    var none = el("option", t("aucune (raccrocher)")); none.value = ""; box.appendChild(none);
    p.extensions.forEach(function (x) {
      if (!x.voicemail) { return; }
      var o = el("option", x.number + " " + x.name); o.value = x.number; box.appendChild(o);
    });
    box.value = rec.voicemail_box;
    $("rec-ring").value = rec.ring_seconds;
    $("rec-hours-on").checked = !!rec.hours;
    var days = rec.hours ? rec.hours.days : ["mon", "tue", "wed", "thu", "fri"];
    $("rec-days").querySelectorAll("input").forEach(function (i) { i.checked = days.indexOf(i.value) >= 0; });
    $("rec-start").value = rec.hours ? rec.hours.start : "09:00";
    $("rec-end").value = rec.hours ? rec.hours.end : "18:00";
    $("rec-hours").hidden = !rec.hours;
  }

  function loadLine(fill) {
    return api("GET", "/api/pbx").then(function (p) {
      trunkState(p);
      if (fill || !state.lineDirty) { fillLine(p); }
    }).catch(function (e) { toast(e.message); });
  }

  function bindLine() {
    var days = $("rec-days");
    DAY_LABELS.forEach(function (d) {
      var label = el("label", null, "check"), input = el("input");
      input.type = "checkbox"; input.value = d[0];
      label.appendChild(input);
      label.appendChild(el("span", d[1]));
      label.lastChild.setAttribute("data-i18n", "");
      days.appendChild(label);
    });
    ["trunk-form", "rec-form"].forEach(function (id) {
      $(id).addEventListener("input", function () { state.lineDirty = true; });
      $(id).addEventListener("change", function () { state.lineDirty = true; });
    });
    $("rec-hours-on").addEventListener("change", function () { $("rec-hours").hidden = !$("rec-hours-on").checked; });
    $("trunk-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("trunk-message");
      msg.textContent = ""; msg.className = "";
      var port = parseInt($("trunk-port").value, 10);
      api("POST", "/api/pbx/trunk", {
        enabled: $("trunk-enabled").checked, host: $("trunk-host").value.trim(), port: isNaN(port) ? 0 : port,
        username: $("trunk-user").value.trim(), auth_username: $("trunk-auth").value.trim(),
        password: $("trunk-pass").value, caller_id: $("trunk-cid").value.trim(),
        public_address: $("trunk-public").value.trim(), register: $("trunk-register").checked,
        international: $("trunk-intl").checked
      }).then(function (r) {
        state.lineDirty = false;
        msg.textContent = r.applied ? t("Ligne enregistrée : application en cours.") : t("Ligne enregistrée, mais la file d'attente est indisponible.");
        setTimeout(function () { loadLine(true); }, 4000);
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
    $("rec-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("rec-message");
      msg.textContent = ""; msg.className = "";
      var ring = parseInt($("rec-ring").value, 10);
      var hours = null;
      if ($("rec-hours-on").checked) {
        hours = { days: Array.prototype.filter.call(days.querySelectorAll("input"), function (i) { return i.checked; }).map(function (i) { return i.value; }),
                  start: $("rec-start").value, end: $("rec-end").value };
      }
      api("POST", "/api/pbx/reception", {
        members: Array.prototype.filter.call($("rec-members").querySelectorAll("input"), function (i) { return i.checked; }).map(function (i) { return i.value; }),
        ring_seconds: isNaN(ring) ? 0 : ring, hours: hours, voicemail_box: $("rec-box").value
      }).then(function (r) {
        state.lineDirty = false;
        msg.textContent = r.applied ? t("Accueil enregistré : application en cours.") : t("Accueil enregistré, mais la file d'attente est indisponible.");
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  /* ------------------------------------------------- accueil vocal */
  var IVR_DIGITS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"];

  function soundLabels() {
    return [["accueil", t("Annonce d'accueil"), t("Jouée dès que l'appel est décroché.")],
            ["menu", t("Annonce du menu"), t("« Tapez 1 pour…, tapez 2 pour… », rejouée après une erreur.")],
            ["fermeture", t("Annonce de fermeture"), t("Hors des horaires d'ouverture, avant la messagerie.")],
            ["attente", t("Musique d'attente"), t("Pendant la sonnerie (option du menu) et quand un poste met un appel en attente.")],
            ["file", t("Annonce d'attente"), t("Files d'attente : jouée à l'arrivée, puis chaque minute.")],
            ["enregistrement", t("Annonce d'information"), t("« Cet appel peut être enregistré… » : obligatoire pour enregistrer les appels.")]];
  }

  function ivrChoices(p, withNone) {
    var out = [];
    if (withNone) { out.push(["", t("non utilisée")]); }
    out.push([withNone ? "accueil" : "", t("Postes de l'accueil (sonnerie)")]);
    p.extensions.forEach(function (x) { out.push([x.number, t("Poste") + " " + x.number + " " + x.name]); });
    p.groups.forEach(function (g) { out.push([g.number, t("Groupe") + " " + g.number + " " + g.name]); });
    (p.queues || []).forEach(function (q) { out.push([q.number, t("File d'attente") + " " + q.number + " " + q.name]); });
    p.extensions.forEach(function (x) {
      if (x.voicemail) { out.push(["vm:" + x.number, t("Messagerie du poste") + " " + x.number + " " + x.name]); }
    });
    return out;
  }

  function fillSelect(select, choices, value) {
    select.textContent = "";
    choices.forEach(function (c) { var o = el("option", c[1]); o.value = c[0]; select.appendChild(o); });
    select.value = value === "accueil" && !choices.some(function (c) { return c[0] === "accueil"; }) ? "" : (value || "");
  }

  function fillIvr(p) {
    var ivr = p.ivr, body = $("ivr-options"), targets = {};
    ivr.options.forEach(function (o) { targets[o.digit] = o.target; });
    $("ivr-enabled").checked = ivr.enabled;
    $("ivr-timeout").value = ivr.timeout;
    $("ivr-moh").checked = ivr.hold_music;
    body.textContent = "";
    IVR_DIGITS.forEach(function (d) {
      var tr = el("tr"), td = el("td"), select = el("select", null, "ivr-target");
      tr.appendChild(el("td", d));
      select.dataset.digit = d;
      select.setAttribute("aria-label", t("Destination de la touche") + " " + d);
      fillSelect(select, ivrChoices(p, true), targets[d] || "");
      td.appendChild(select); tr.appendChild(td);
      body.appendChild(tr);
    });
    fillSelect($("ivr-default"), ivrChoices(p, false), ivr["default"]);
  }

  function soundState(s) {
    if (s.pending) { return [t("conversion en cours"), "warn"]; }
    if (s.error) { return [t("refusée :") + " " + s.error, "bad"]; }
    if (s.present) { return [t("présente") + (s.seconds !== null ? " (" + String(s.seconds).replace(".", window.I18N.lang() === "fr" ? "," : ".") + " s)" : ""), "ok"]; }
    return [t("aucune"), ""];
  }

  function uploadSound(name, input) {
    var msg = $("snd-message"), file = input.files[0];
    msg.textContent = ""; msg.className = "";
    if (!file) { msg.textContent = t("Choisissez d'abord un fichier WAV ou MP3."); msg.className = "error"; return; }
    if (file.size > 20 * 1024 * 1024) { msg.textContent = t("Fichier trop volumineux (20 Mo au plus)."); msg.className = "error"; return; }
    fetch("/api/sounds/upload?name=" + encodeURIComponent(name), {
      method: "POST", credentials: "same-origin", body: file,
      headers: { "Accept": "application/json", "Content-Type": "application/octet-stream", "X-CSRF-Token": state.csrf }
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (data) {
        if (r.status === 401) { showLogin(); }
        if (!r.ok) { throw new Error(data.error || (r.status === 413 ? t("Fichier trop volumineux (20 Mo au plus).") : t("Erreur interne."))); }
        msg.textContent = data.applied ? t("Annonce envoyée : conversion en cours.") : t("Annonce envoyée, mais la file d'attente est indisponible.");
        input.value = "";
        loadSounds();
        setTimeout(loadSounds, 4000);
      });
    }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
  }

  function loadSounds() {
    return api("GET", "/api/sounds").then(function (d) {
      var body = $("snd-body");
      state.sounds = d.sounds;
      body.textContent = "";
      soundLabels().forEach(function (l) {
        var s = d.sounds[l[0]], tr = el("tr"), td = el("td"), st = soundState(s);
        tr.dataset.sound = l[0];
        td.appendChild(el("strong", l[1]));
        td.appendChild(el("div", l[2], "muted"));
        tr.appendChild(td);
        td = el("td");
        td.appendChild(el("span", st[0], "state " + st[1]));
        tr.appendChild(td);
        var input = el("input"); td = el("td");
        input.type = "file"; input.accept = ".wav,.mp3,audio/wav,audio/mpeg";
        input.setAttribute("aria-label", t("Fichier pour") + " " + l[1]);
        td.appendChild(input); tr.appendChild(td);
        td = el("td");
        var send = el("button", t("Envoyer"), "ghost small");
        send.type = "button";
        send.addEventListener("click", function () { uploadSound(l[0], input); });
        td.appendChild(send);
        if (s.present && !s.pending) {
          var del = el("button", t("Supprimer"), "ghost small");
          del.type = "button";
          del.addEventListener("click", function () {
            confirmDialog(t("Supprimer"), t("Supprimer l'annonce") + " « " + l[1] + " » ?").then(function (ok) {
              if (!ok) { return; }
              api("POST", "/api/sounds/delete", { name: l[0] }).then(function () {
                $("snd-message").textContent = t("Suppression en cours.");
                loadSounds();
                setTimeout(loadSounds, 4000);
              }).catch(function (e) { toast(e.message); });
            });
          });
          td.appendChild(del);
        }
        tr.appendChild(td);
        body.appendChild(tr);
      });
      $("snd-converter").hidden = !d.checked || !!d.converter;
      $("ivr-warning").hidden = !$("ivr-enabled").checked || d.sounds.menu.present || d.sounds.menu.pending;
    }).catch(function (e) { toast(e.message); });
  }

  function loadIvr(fill) {
    return api("GET", "/api/pbx").then(function (p) {
      state.pbx = p;
      if (fill || !state.ivrDirty) { fillIvr(p); }
      return loadSounds();
    }).catch(function (e) { toast(e.message); });
  }

  function bindIvr() {
    $("ivr-form").addEventListener("input", function () { state.ivrDirty = true; });
    $("ivr-form").addEventListener("change", function () { state.ivrDirty = true; });
    $("ivr-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("ivr-message"), timeout = parseInt($("ivr-timeout").value, 10);
      msg.textContent = ""; msg.className = "";
      var options = [];
      $("ivr-options").querySelectorAll("select").forEach(function (s) {
        if (s.value) { options.push({ digit: s.dataset.digit, target: s.value }); }
      });
      api("POST", "/api/pbx/ivr", { enabled: $("ivr-enabled").checked, options: options, timeout: isNaN(timeout) ? 0 : timeout,
                                    "default": $("ivr-default").value, hold_music: $("ivr-moh").checked }).then(function (r) {
        state.ivrDirty = false;
        msg.textContent = r.applied ? t("Menu enregistré : application en cours.") : t("Menu enregistré, mais la file d'attente est indisponible.");
        loadIvr(true);
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  /* ----------------------------------------------- groupes et renvois */
  var FORWARD_MODES = [["off", "aucun"], ["always", "toujours"], ["noanswer", "sans réponse"]];

  function checkboxes(box, extensions, selected) {
    box.textContent = "";
    extensions.forEach(function (x) {
      var label = el("label", null, "check"), input = el("input");
      input.type = "checkbox"; input.value = x.number; input.checked = selected.indexOf(x.number) >= 0;
      label.appendChild(input);
      label.appendChild(el("span", x.number + " " + x.name));
      box.appendChild(label);
    });
  }

  function boxOptions(select, extensions, value) {
    select.textContent = "";
    var none = el("option", t("aucune (raccrocher)")); none.value = ""; select.appendChild(none);
    extensions.forEach(function (x) {
      if (!x.voicemail) { return; }
      var o = el("option", x.number + " " + x.name); o.value = x.number; select.appendChild(o);
    });
    select.value = value || "";
  }

  function resetGroupForm() {
    $("grp-edit").value = "";
    $("grp-number").value = ""; $("grp-number").disabled = false;
    $("grp-name").value = ""; $("grp-ring").value = "25";
    $("grp-title").textContent = t("Ajouter un groupe");
    $("grp-cancel").hidden = true;
    checkboxes($("grp-members"), state.pbx.extensions, []);
    boxOptions($("grp-box"), state.pbx.extensions, "");
  }

  function editGroup(g) {
    $("grp-edit").value = g.number;
    $("grp-number").value = g.number;
    $("grp-name").value = g.name;
    $("grp-ring").value = g.ring_seconds;
    $("grp-title").textContent = t("Modifier le groupe") + " " + g.number;
    $("grp-cancel").hidden = false;
    checkboxes($("grp-members"), state.pbx.extensions, g.members);
    boxOptions($("grp-box"), state.pbx.extensions, g.voicemail_box);
    $("grp-name").focus();
  }

  function saveGroups(groups, msg, done) {
    msg.textContent = ""; msg.className = "";
    return api("POST", "/api/pbx/groups", { groups: groups }).then(function (r) {
      state.grpDirty = false;
      msg.textContent = r.applied ? t("Groupes enregistrés : application en cours.") : t("Groupes enregistrés, mais la file d'attente est indisponible.");
      if (done) { done(); }
      return loadGroups(true);
    }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
  }

  function forwardRow(x, p) {
    var tr = el("tr"), f = x.forward;
    tr.dataset.number = x.number;
    tr.appendChild(el("td", x.number + " " + x.name));
    var mode = el("select", null, "fwd-mode"), td = el("td");
    mode.setAttribute("aria-label", t("Renvoi du poste") + " " + x.number);
    FORWARD_MODES.forEach(function (m) { var o = el("option", t(m[1])); o.value = m[0]; mode.appendChild(o); });
    mode.value = f.mode;
    td.appendChild(mode); tr.appendChild(td);
    var target = el("input", null, "fwd-target"); td = el("td");
    target.setAttribute("list", "fwd-targets"); target.maxLength = 20; target.value = f.target;
    target.setAttribute("aria-label", t("Destination du renvoi") + " " + x.number);
    td.appendChild(target); tr.appendChild(td);
    var ring = el("input", null, "fwd-ring"); td = el("td");
    ring.inputMode = "numeric"; ring.maxLength = 3; ring.value = f.ring_seconds; ring.size = 3;
    ring.setAttribute("aria-label", t("Durée de sonnerie (secondes)") + " " + x.number);
    td.appendChild(ring); tr.appendChild(td);
    var sync = function () { target.disabled = mode.value === "off"; ring.disabled = mode.value !== "noanswer"; };
    mode.addEventListener("change", function () { state.grpDirty = true; sync(); });
    target.addEventListener("input", function () { state.grpDirty = true; });
    ring.addEventListener("input", function () { state.grpDirty = true; });
    sync();
    var save = el("button", t("Enregistrer"), "ghost small"); td = el("td");
    save.type = "button";
    save.addEventListener("click", function () {
      var msg = $("fwd-message"), secs = parseInt(ring.value, 10);
      msg.textContent = ""; msg.className = "";
      api("POST", "/api/pbx/forward", { number: x.number, mode: mode.value, target: target.value.trim(),
                                         ring_seconds: isNaN(secs) ? 0 : secs }).then(function (r) {
        state.grpDirty = false;
        msg.textContent = t("Renvoi du poste") + " " + x.number + " : " + (r.applied ? t("enregistré, application en cours.") : t("enregistré, mais la file d'attente est indisponible."));
        loadGroups(true);
      }).catch(function (e) { msg.textContent = x.number + " : " + e.message; msg.className = "error"; });
    });
    td.appendChild(save); tr.appendChild(td);
    return tr;
  }

  function loadGroups(fill) {
    return api("GET", "/api/pbx").then(function (p) {
      if (!fill && state.grpDirty) { return; }
      state.pbx = p;
      var body = $("grp-body"), names = {};
      p.extensions.forEach(function (x) { names[x.number] = x.name; });
      body.textContent = "";
      $("grp-empty").hidden = p.groups.length > 0;
      p.groups.forEach(function (g) {
        var tr = el("tr");
        tr.appendChild(el("td", g.number));
        tr.appendChild(el("td", g.name));
        tr.appendChild(el("td", g.members.map(function (m) { return m + " " + (names[m] || ""); }).join(", ")));
        tr.appendChild(el("td", g.ring_seconds + " s"));
        tr.appendChild(el("td", g.voicemail_box || "–"));
        var act = el("td"), edit = el("button", t("Modifier"), "ghost small"), del = el("button", t("Supprimer"), "danger small");
        edit.type = "button"; del.type = "button";
        edit.setAttribute("aria-label", t("Modifier le groupe") + " " + g.number);
        del.setAttribute("aria-label", t("Supprimer le groupe") + " " + g.number);
        edit.addEventListener("click", function () { editGroup(g); });
        del.addEventListener("click", function () {
          confirmDialog(t("Supprimer"), t("Supprimer le groupe") + " " + g.number + " ?").then(function (ok) {
            if (!ok) { return; }
            saveGroups(p.groups.filter(function (o) { return o.number !== g.number; }), $("grp-message"));
          });
        });
        act.appendChild(edit); act.appendChild(del); tr.appendChild(act);
        body.appendChild(tr);
      });
      if (!$("grp-edit").value) { resetGroupForm(); }
      var list = $("fwd-targets");
      list.textContent = "";
      p.extensions.concat(p.groups).forEach(function (x) { var o = el("option"); o.value = x.number; o.label = x.name; list.appendChild(o); });
      var fwd = $("fwd-body");
      fwd.textContent = "";
      p.extensions.forEach(function (x) { fwd.appendChild(forwardRow(x, p)); });
    }).catch(function (e) { toast(e.message); });
  }

  function bindGroups() {
    $("grp-form").addEventListener("input", function () { state.grpDirty = true; });
    $("grp-cancel").addEventListener("click", function () { state.grpDirty = false; resetGroupForm(); });
    $("grp-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var editing = $("grp-edit").value, ring = parseInt($("grp-ring").value, 10);
      var g = { number: $("grp-number").value.trim(), name: $("grp-name").value.trim(),
                members: Array.prototype.filter.call($("grp-members").querySelectorAll("input"), function (i) { return i.checked; }).map(function (i) { return i.value; }),
                ring_seconds: isNaN(ring) ? 0 : ring, voicemail_box: $("grp-box").value };
      var groups = (state.pbx ? state.pbx.groups : []).filter(function (o) { return o.number !== editing; });
      groups.push(g);
      saveGroups(groups, $("grp-message"), resetGroupForm);
    });
  }

  /* --------------------------------- files d'attente et enregistrement */
  function overflowChoices(p) {
    var out = [["", t("raccrocher")]];
    p.extensions.forEach(function (x) { out.push([x.number, t("Poste") + " " + x.number + " " + x.name]); });
    p.groups.forEach(function (g) { out.push([g.number, t("Groupe") + " " + g.number + " " + g.name]); });
    p.extensions.forEach(function (x) {
      if (x.voicemail) { out.push(["vm:" + x.number, t("Messagerie du poste") + " " + x.number + " " + x.name]); }
    });
    return out;
  }

  function resetQueueForm() {
    var p = state.pbx || { extensions: [], groups: [] };
    $("que-edit").value = "";
    $("que-number").value = ""; $("que-number").disabled = false;
    $("que-name").value = ""; $("que-ring").value = "15"; $("que-wait").value = "120";
    $("que-strategy").value = "ringall";
    $("que-announce").checked = true; $("que-record").checked = false;
    $("que-title").textContent = t("Ajouter une file");
    $("que-cancel").hidden = true;
    checkboxes($("que-members"), p.extensions, []);
    fillSelect($("que-overflow"), overflowChoices(p), "");
  }

  function editQueue(q) {
    state.queDirty = true;
    $("que-edit").value = q.number;
    $("que-number").value = q.number;
    $("que-name").value = q.name;
    $("que-ring").value = q.ring_seconds;
    $("que-wait").value = q.max_wait;
    $("que-strategy").value = q.strategy;
    $("que-announce").checked = q.announce;
    $("que-record").checked = q.record;
    $("que-title").textContent = t("Modifier la file") + " " + q.number;
    $("que-cancel").hidden = false;
    checkboxes($("que-members"), state.pbx.extensions, q.members);
    fillSelect($("que-overflow"), overflowChoices(state.pbx), q.overflow);
    $("que-name").focus();
  }

  function saveQueues(queues, msg, done) {
    msg.textContent = ""; msg.className = "";
    return api("POST", "/api/pbx/queues", { queues: queues }).then(function (r) {
      state.queDirty = false;
      msg.textContent = r.applied ? t("Files enregistrées : application en cours.") : t("Files enregistrées, mais la file d'attente est indisponible.");
      if (done) { done(); }
      return loadQueues(true);
    }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
  }

  function targetLabel(p, target) {
    if (!target) { return t("raccrocher"); }
    var found = overflowChoices(p).filter(function (c) { return c[0] === target; })[0];
    return found ? found[1] : target;
  }

  function loadQueues(fill) {
    return api("GET", "/api/pbx").then(function (p) {
      state.pbx = p;
      var body = $("que-body"), names = {};
      p.extensions.forEach(function (x) { names[x.number] = x.name; });
      body.textContent = "";
      $("que-empty").hidden = p.queues.length > 0;
      p.queues.forEach(function (q) {
        var tr = el("tr");
        tr.appendChild(el("td", q.number));
        tr.appendChild(el("td", q.name + (q.record ? " · " + t("enregistrée") : "")));
        tr.appendChild(el("td", q.members.map(function (m) { return m + " " + (names[m] || ""); }).join(", ")));
        tr.appendChild(el("td", (q.strategy === "ringall" ? t("Tous ensemble") : t("Chacun son tour")) + ", " + q.ring_seconds + " s"));
        tr.appendChild(el("td", q.max_wait + " s"));
        tr.appendChild(el("td", targetLabel(p, q.overflow)));
        var act = el("td"), edit = el("button", t("Modifier"), "ghost small"), del = el("button", t("Supprimer"), "danger small");
        edit.type = "button"; del.type = "button";
        edit.setAttribute("aria-label", t("Modifier la file") + " " + q.number);
        del.setAttribute("aria-label", t("Supprimer la file") + " " + q.number);
        edit.addEventListener("click", function () { editQueue(q); });
        del.addEventListener("click", function () {
          confirmDialog(t("Supprimer"), t("Supprimer la file") + " " + q.number + " ?").then(function (ok) {
            if (!ok) { return; }
            saveQueues(p.queues.filter(function (o) { return o.number !== q.number; }), $("que-message"));
          });
        });
        act.appendChild(edit); act.appendChild(del); tr.appendChild(act);
        body.appendChild(tr);
      });
      if (fill || !state.queDirty) { resetQueueForm(); }
      if (fill || !state.rcdDirty) {
        checkboxes($("rcd-members"), p.extensions, p.extensions.filter(function (x) { return x.record; }).map(function (x) { return x.number; }));
        $("rcd-keep").value = p.recording.keep_days;
      }
      api("GET", "/api/sounds").then(function (d) { $("rcd-warning").hidden = d.sounds.enregistrement.present; }).catch(function () {});
      if (document.body.getAttribute("data-role") === "admin") { return loadRecordings(); }
      return null;
    }).catch(function (e) { toast(e.message); });
  }

  function loadRecordings() {
    return api("GET", "/api/recordings").then(function (d) {
      var body = $("rcd-body");
      body.textContent = "";
      $("rcd-empty").hidden = d.recordings.length > 0;
      d.recordings.forEach(function (r) {
        var tr = el("tr"), url = "/api/recordings/file?name=" + encodeURIComponent(r.name);
        tr.appendChild(el("td", r.start));
        tr.appendChild(el("td", r.caller || t("inconnu")));
        tr.appendChild(el("td", r.target));
        tr.appendChild(el("td", fmtBytes(r.size)));
        var act = el("td"), play = el("button", t("Écouter"), "ghost small"), dl = el("a", t("Télécharger"), "button small");
        play.type = "button";
        play.addEventListener("click", function () {
          var player = $("rcd-player");
          player.hidden = false;
          player.src = url + "&play=1";
          player.play().catch(function () {});
        });
        dl.href = url;
        dl.setAttribute("download", r.name);
        act.appendChild(play); act.appendChild(dl); tr.appendChild(act);
        body.appendChild(tr);
      });
    }).catch(function (e) { toast(e.message); });
  }

  function bindQueues() {
    $("que-form").addEventListener("input", function () { state.queDirty = true; });
    $("que-cancel").addEventListener("click", function () { state.queDirty = false; resetQueueForm(); });
    $("que-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var editing = $("que-edit").value, ring = parseInt($("que-ring").value, 10), wait = parseInt($("que-wait").value, 10);
      var q = { number: $("que-number").value.trim(), name: $("que-name").value.trim(),
                members: Array.prototype.filter.call($("que-members").querySelectorAll("input"), function (i) { return i.checked; }).map(function (i) { return i.value; }),
                strategy: $("que-strategy").value, ring_seconds: isNaN(ring) ? 0 : ring, max_wait: isNaN(wait) ? 0 : wait,
                overflow: $("que-overflow").value, announce: $("que-announce").checked, record: $("que-record").checked };
      var queues = (state.pbx ? state.pbx.queues : []).filter(function (o) { return o.number !== editing; });
      queues.push(q);
      saveQueues(queues, $("que-message"), resetQueueForm);
    });
    $("rcd-form").addEventListener("input", function () { state.rcdDirty = true; });
    $("rcd-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("rcd-message"), keep = parseInt($("rcd-keep").value, 10);
      msg.textContent = ""; msg.className = "";
      var numbers = Array.prototype.filter.call($("rcd-members").querySelectorAll("input"), function (i) { return i.checked; }).map(function (i) { return i.value; });
      api("POST", "/api/pbx/recording", { extensions: numbers, keep_days: isNaN(keep) ? 0 : keep }).then(function (r) {
        state.rcdDirty = false;
        msg.textContent = r.applied ? t("Réglages enregistrés : application en cours.") : t("Réglages enregistrés, mais la file d'attente est indisponible.");
        loadQueues(true);
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  /* ------------------------------------------------- diagnostic SIP */
  var DIAG_REASONS = { "durée": "fin de la durée", "taille": "limite de 20 Mo atteinte", "arrêt": "arrêtée à la demande",
                       "interrompue": "interrompue" };

  function diagFile(f) {
    return f ? fmtTime(f.mtime) + " · " + fmtBytes(f.size) : t("aucune");
  }

  function loadDiagnostic(fill) {
    if (document.body.getAttribute("data-role") !== "admin") { return null; }
    if (fill) {
      document.querySelectorAll(".diag-minutes").forEach(function (sel) {
        if (sel.options.length) { return; }
        for (var m = 1; m <= 10; m++) { var o = el("option", String(m)); o.value = String(m); sel.appendChild(o); }
        sel.value = "2";
      });
      api("GET", "/api/pbx").then(function (p) {
        var sel = $("diag-trace-ext");
        sel.textContent = "";
        p.extensions.forEach(function (x) { var o = el("option", x.number + " " + x.name + (x.registered ? "" : " (" + t("non enregistré") + ")")); o.value = x.number; sel.appendChild(o); });
      }).catch(function () {});
    }
    return api("GET", "/api/diagnostic").then(function (d) {
      var running = d.state === "running" || d.state === "starting", text;
      if (running) {
        text = (d.kind === "trace" ? t("Trace du poste") + " " + d.number : t("Capture réseau")) + " " + t("en cours") +
          (d.ends ? ", " + t("fin à") + " " + fmtTime(d.ends) : "") + (d.size ? " · " + fmtBytes(d.size) : "");
      } else {
        text = t("Aucun diagnostic en cours");
        if (d.reason && DIAG_REASONS[d.reason]) { text += " (" + t("dernier :") + " " + t(DIAG_REASONS[d.reason]) + ")"; }
      }
      $("diag-state").textContent = text;
      $("diag-state").className = running ? "state warn" : "";
      $("diag-capture").textContent = diagFile(d.files.capture);
      $("diag-trace").textContent = diagFile(d.files.trace);
      $("diag-capture-dl").hidden = !d.files.capture;
      $("diag-trace-dl").hidden = !d.files.trace;
      $("diag-stop").hidden = !running;
      document.querySelectorAll("#diag-capture-form button, #diag-trace-form button").forEach(function (b) { b.disabled = running; });
      var msg = $("diag-message");
      if (d.error) { msg.textContent = d.error; msg.className = "error"; }
      else if (!d.tcpdump) { msg.textContent = t("tcpdump absent : installez la dernière mise à jour."); msg.className = "error"; }
      else if (msg.className === "error") { msg.textContent = ""; msg.className = ""; }
    }).catch(function (e) { toast(e.message); });
  }

  function diagStart(body) {
    var msg = $("diag-message");
    msg.textContent = ""; msg.className = "";
    api("POST", "/api/diagnostic/start", body).then(function () {
      msg.textContent = t("Diagnostic demandé.");
      setTimeout(function () { loadDiagnostic(false); }, 2000);
    }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
  }

  function bindDiagnostic() {
    $("diag-capture-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      diagStart({ kind: "capture", minutes: parseInt($("diag-capture-minutes").value, 10) });
    });
    $("diag-trace-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      diagStart({ kind: "trace", minutes: parseInt($("diag-trace-minutes").value, 10), number: $("diag-trace-ext").value });
    });
    $("diag-stop").addEventListener("click", function () {
      api("POST", "/api/diagnostic/stop", {}).then(function () {
        $("diag-message").textContent = t("Arrêt demandé.");
        setTimeout(function () { loadDiagnostic(false); }, 2000);
      }).catch(function (e) { toast(e.message); });
    });
  }

  /* ------------------------------------------- messagerie par e-mail */
  function loadMail() {
    return api("GET", "/api/pbx").then(function (p) {
      var m = p.mail;
      $("mail-enabled").checked = m.enabled;
      $("mail-host").value = m.host;
      $("mail-port").value = m.port;
      $("mail-security").value = m.security;
      $("mail-user").value = m.username;
      $("mail-pass").value = "";
      $("mail-pass").placeholder = m.password_set ? t("inchangé") : "";
      $("mail-from").value = m.from_address;
      $("mail-test").disabled = !m.enabled;
      $("mail-form").dataset.loaded = "1";
      var missing = p.extensions.filter(function (x) { return x.voicemail && !x.email; }).length;
      if (m.enabled && missing) {
        $("mail-message").textContent = missing + " " + t("poste(s) avec messagerie sans adresse e-mail : à renseigner dans Postes > Modifier.");
        $("mail-message").className = "";
      }
    }).catch(function (e) { toast(e.message); });
  }

  function bindMail() {
    $("mail-security").addEventListener("change", function () {
      var port = { starttls: "587", tls: "465", none: "25" }[$("mail-security").value];
      if (["587", "465", "25", ""].indexOf($("mail-port").value) >= 0) { $("mail-port").value = port; }
    });
    $("mail-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("mail-message"), port = parseInt($("mail-port").value, 10);
      msg.textContent = ""; msg.className = "";
      api("POST", "/api/pbx/mail", {
        enabled: $("mail-enabled").checked, host: $("mail-host").value.trim(), port: isNaN(port) ? 0 : port,
        security: $("mail-security").value, username: $("mail-user").value.trim(), password: $("mail-pass").value,
        from_address: $("mail-from").value.trim()
      }).then(function (r) {
        msg.textContent = r.applied ? t("Réglages enregistrés : application en cours.") : t("Réglages enregistrés, mais la file d'attente est indisponible.");
        $("mail-pass").value = "";
        $("mail-pass").placeholder = r.mail.password_set ? t("inchangé") : "";
        $("mail-test").disabled = !r.mail.enabled;
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
    $("mail-test").addEventListener("click", function () {
      var msg = $("mail-message");
      api("POST", "/api/jobs", { action: "mail-test" }).then(function () {
        msg.textContent = t("E-mail d'essai demandé : résultat dans Système > Tâches."); msg.className = "";
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  function bindPbx() {
    bindNetworks();
    $("edit-cancel").addEventListener("click", function () { $("edit").close(); });
    $("edit-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("edit-message");
      msg.textContent = ""; msg.className = "";
      api("POST", "/api/pbx/update", { number: state.editing, new_number: $("edit-number").value.trim(),
        name: $("edit-name").value.trim(), voicemail: $("edit-voicemail").checked,
        email: $("edit-email").value.trim() }).then(function () {
        $("edit").close();
        toast(t("Poste modifié."));
        loadPbx();
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
    $("sheet-close").addEventListener("click", function () { $("sheet").close(); });
    $("sheet-print").addEventListener("click", function () { window.print(); });
    $("ext-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("ext-message");
      msg.textContent = "";
      api("POST", "/api/pbx/extensions", {
        number: $("ext-number").value.trim(), name: $("ext-name").value.trim(), voicemail: $("ext-voicemail").checked,
        sip_user: $("ext-sip").value.trim(), email: $("ext-email").value.trim()
      }).then(function (d) {
        $("ext-form").reset();
        loadPbx();
        showSheet(d, t("Poste créé"));
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  function loadUpdate() {
    return api("GET", "/api/update").then(function (u) {
      $("upd-current").textContent = u.current || "–";
      $("upd-latest").textContent = u.latest || "–";
      $("upd-checked").textContent = u.checked ? fmtTime(u.checked) : t("jamais");
      var st = $("upd-state");
      st.textContent = "";
      var label = u.error ? t("vérification en échec") : u.available ? t("nouvelle version disponible") : u.latest ? t("à jour") : t("non vérifié");
      st.appendChild(el("span", label, "state " + (u.error ? "bad" : u.available ? "warn" : u.latest ? "ok" : "warn")));
      if (u.error) { st.appendChild(el("span", " " + u.error, "muted")); }
      $("upd-notes").textContent = u.notes || "–";
      $("upd-apply").disabled = !u.available;
    }).catch(function () {});
  }

  function loadMetrics() {
    return api("GET", "/api/metrics?range=" + encodeURIComponent(state.range)).then(function (m) {
      state.series = m;
      var cpu = last(m.cpu), rx = last(m.rx), tx = last(m.tx);
      $("kpi-cpu").textContent = cpu === null ? "–" : cpu + " %";
      $("kpi-net").textContent = rx === null ? "–" : "↓ " + fmtBytes(rx) + "/s ↑ " + fmtBytes(tx) + "/s";
      drawChart();
    }).catch(function () {});
  }

  function drawChart() {
    var m = state.series;
    var box = $("chart");
    box.textContent = "";
    if (!m) { return; }
    var lines = state.metric === "net" ? [["rx", t("Reçu")], ["tx", t("Émis")]] : [[state.metric, ""]];
    var W = 720, H = 220, L = 56, R = 12, T = 12, B = 28;
    var max = 0;
    lines.forEach(function (l) { m[l[0]].forEach(function (v) { if (v !== null && v > max) { max = v; } }); });
    if (state.metric === "cpu" || state.metric === "mem") { max = 100; }
    if (!max) { max = 1; }
    var n = m.t.length;
    var x = function (i) { return L + (W - L - R) * (i / (n - 1)); };
    var y = function (v) { return T + (H - T - B) * (1 - v / max); };
    var root = svg("svg", { viewBox: "0 0 " + W + " " + H, preserveAspectRatio: "none", "class": "chart-svg" });
    for (var g = 0; g <= 4; g++) {
      var gv = max * g / 4;
      root.appendChild(svg("line", { x1: L, x2: W - R, y1: y(gv), y2: y(gv), "class": "grid" }));
      var label = svg("text", { x: L - 6, y: y(gv) + 4, "text-anchor": "end", "class": "axis" });
      label.textContent = state.metric === "net" ? fmtBytes(gv) : (Math.round(gv * 10) / 10).toString();
      root.appendChild(label);
    }
    [0, Math.floor(n / 2), n - 1].forEach(function (i) {
      var tl = svg("text", { x: x(i), y: H - 8, "text-anchor": i === 0 ? "start" : i === n - 1 ? "end" : "middle", "class": "axis" });
      tl.textContent = new Date(m.t[i] * 1000).toLocaleTimeString(window.I18N.lang() === "en" ? "en-GB" : "fr-FR", { hour: "2-digit", minute: "2-digit" });
      root.appendChild(tl);
    });
    lines.forEach(function (l, li) {
      var values = m[l[0]], d = "", pen = false;
      values.forEach(function (v, i) {
        if (v === null) { pen = false; return; }
        d += (pen ? "L" : "M") + x(i).toFixed(1) + " " + y(v).toFixed(1);
        var isolated = (i === 0 || values[i - 1] === null) && (i === n - 1 || values[i + 1] === null);
        if (isolated) { root.appendChild(svg("circle", { cx: x(i), cy: y(v), r: 2.5, "class": "dot s" + li })); }
        pen = true;
      });
      if (d) { root.appendChild(svg("path", { d: d, "class": "line s" + li })); }
    });
    var cursor = svg("line", { x1: 0, x2: 0, y1: T, y2: H - B, "class": "cursor", visibility: "hidden" });
    root.appendChild(cursor);
    var tip = $("chart-tip");
    root.addEventListener("mousemove", function (ev) {
      var rect = root.getBoundingClientRect();
      var px = (ev.clientX - rect.left) / rect.width * W;
      var i = Math.max(0, Math.min(n - 1, Math.round((px - L) / (W - L - R) * (n - 1))));
      cursor.setAttribute("x1", x(i)); cursor.setAttribute("x2", x(i)); cursor.setAttribute("visibility", "visible");
      var parts = [new Date(m.t[i] * 1000).toLocaleTimeString(window.I18N.lang() === "en" ? "en-GB" : "fr-FR")];
      lines.forEach(function (l) {
        var v = m[l[0]][i];
        parts.push((l[1] ? l[1] + " : " : "") + (v === null ? "–" : state.metric === "net" ? fmtBytes(v) + "/s" : v));
      });
      tip.textContent = parts.join("  ·  ");
      tip.hidden = false;
    });
    root.addEventListener("mouseleave", function () { cursor.setAttribute("visibility", "hidden"); tip.hidden = true; });
    box.appendChild(root);
  }

  function loadJobs() {
    return api("GET", "/api/jobs").then(function (data) {
      var body = $("jobs-body");
      body.textContent = "";
      (data.jobs || []).forEach(function (j) {
        var tr = el("tr");
        tr.appendChild(el("td", String(j.id)));
        tr.appendChild(el("td", t(JOB_LABELS[j.action] || j.action)));
        tr.appendChild(el("td", j.user || "–"));
        var st = el("td");
        st.appendChild(el("span", t(JOB_STATES[j.state] || j.state), "state " + (j.state === "done" ? "ok" : j.state === "failed" ? "bad" : "warn")));
        tr.appendChild(st);
        tr.appendChild(el("td", j.started ? fmtTime(j.started) : "–"));
        tr.tabIndex = 0;
        tr.addEventListener("click", function () { var out = $("job-output"); out.textContent = j.output || ""; out.hidden = !j.output; });
        body.appendChild(tr);
      });
    }).catch(function (e) { toast(e.message); });
  }

  function loadAudit() {
    return api("GET", "/api/audit").then(function (data) {
      var body = $("audit-body");
      body.textContent = "";
      data.events.forEach(function (ev) {
        var tr = el("tr");
        tr.appendChild(el("td", fmtTime(ev.ts)));
        tr.appendChild(el("td", ev.user || "–"));
        tr.appendChild(el("td", ev.remote || "–"));
        tr.appendChild(el("td", ev.event, ev.event.indexOf("failed") >= 0 ? "error-text" : ""));
        body.appendChild(tr);
      });
    }).catch(function () {});
  }

  var JOB_LABELS = {
    "apt-refresh": "Rechercher les mises à jour Ubuntu",
    "update-check": "Rechercher une nouvelle version",
    "update-apply": "Installer la nouvelle version",
    "pbx-apply": "Appliquer la configuration téléphonique",
    "ldap-apply": "Appliquer l'annuaire LDAP des téléphones",
    "networks-apply": "Appliquer les réseaux des téléphones",
    "network-apply": "Appliquer le réseau et le système de l'appliance",
    "net-check": "Tester la joignabilité",
    "mail-test": "Envoyer un e-mail d'essai",
    "backup-run": "Sauvegarder maintenant",
    "alerts-test": "E-mail d'essai des alertes",
    "apt-security-upgrade": "Installer les correctifs de sécurité",
    "restart-web": "Redémarrer la console",
    "reboot": "Redémarrer l'appliance",
    "poweroff": "Arrêter l'appliance"
  };
  JOB_LABELS["sounds-apply"] = "Convertir les annonces vocales";
  JOB_LABELS["backup-copy-test"] = "Tester la copie des sauvegardes";
  JOB_LABELS["backup-sftp-key"] = "Créer la clé SFTP de l'appliance";
  JOB_LABELS["voicemail-restore"] = "Restaurer les messages vocaux";
  JOB_LABELS["tls-apply"] = "Appliquer le certificat HTTPS";
  JOB_LABELS["capture-start"] = "Lancer le diagnostic SIP";
  JOB_LABELS["capture-stop"] = "Arrêter le diagnostic SIP";
  JOB_LABELS["update-rollback"] = "Revenir à la version précédente";
  JOB_LABELS["maintenance-security"] = "Installer les mises à jour de sécurité Ubuntu";
  JOB_LABELS["support-bundle"] = "Préparer l'archive pour le support";
  JOB_LABELS["ad-sync"] = "Synchroniser avec l'Active Directory";
  JOB_LABELS["ad-test"] = "Tester la connexion à l'Active Directory";
  JOB_LABELS["live-hangup"] = "Raccrocher un appel";
  var JOB_STATES = { queued: "en attente", running: "en cours", done: "terminée", failed: "en échec" };

  /* ---------------------------------------------------------- supervision en direct */
  var LIVE_KINDS = { incoming: "Entrant (ligne)", outgoing: "Sortant (ligne)", internal: "Interne" };
  var LIVE_CALL_STATES = { up: "en communication", ringing: "sonne", queue: "en attente", voicemail: "messagerie", dialing: "numérotation" };
  var LIVE_EXT_STATES = { free: "libre", ringing: "sonne", busy: "en ligne", offline: "non enregistré", dnd: "ne pas déranger", unknown: "inconnu" };
  var LIVE_ERRORS = { absent: "Supervision indisponible : service voipbuntu-live arrêté.", stale: "Supervision indisponible : données trop anciennes.", ami: "Supervision indisponible : serveur de téléphonie injoignable." };

  function fmtClock(s) {
    var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
    return (h ? h + ":" + (m < 10 ? "0" : "") : "") + m + ":" + (r < 10 ? "0" : "") + r;
  }
  function liveParty(num, name) { return name && name !== num ? num + " " + name : (num || "–"); }

  function loadLive() {
    return api("GET", "/api/live").then(function (d) {
      $("live-status").textContent = d.available ? t("Mis à jour à") + " " + fmtTime(d.updated) : t(LIVE_ERRORS[d.error] || LIVE_ERRORS.absent);
      $("live-status").className = d.available ? "muted" : "error";
      $("live-kpi-calls").textContent = d.available ? d.counts.calls : "–";
      $("live-kpi-trunk").textContent = d.available ? d.counts.incoming + d.counts.outgoing : "–";
      $("live-kpi-waiting").textContent = d.available ? d.counts.waiting : "–";
      $("live-kpi-free").textContent = d.available ? d.counts.free + " / " + d.extensions.length : "–";
      var body = $("live-calls-body");
      body.textContent = "";
      d.calls.forEach(function (c) {
        var tr = el("tr");
        tr.appendChild(el("td", liveParty(c.caller, c.caller_name)));
        tr.appendChild(el("td", liveParty(c.callee, c.callee_name)));
        tr.appendChild(el("td", t(LIVE_KINDS[c.kind] || c.kind)));
        var st = el("td");
        st.appendChild(el("span", t(LIVE_CALL_STATES[c.status] || c.status), "state " + (c.status === "up" ? "ok" : "warn")));
        tr.appendChild(st);
        tr.appendChild(el("td", fmtClock(c.seconds)));
        var act = el("td", null, "admin-only");
        if (d.can_hangup) {
          var b = el("button", t("Raccrocher"), "ghost small");
          b.type = "button";
          b.setAttribute("aria-label", t("Raccrocher l'appel de") + " " + c.caller);
          b.addEventListener("click", function () { liveHangup(c); });
          act.appendChild(b);
        }
        tr.appendChild(act);
        body.appendChild(tr);
      });
      $("live-calls-empty").hidden = d.calls.length > 0;
      var grid = $("live-exts");
      grid.textContent = "";
      d.extensions.forEach(function (x) {
        var li = el("li", null, "live-ext live-" + x.state);
        li.appendChild(el("strong", x.number));
        li.appendChild(el("span", x.name));
        li.appendChild(el("span", t(LIVE_EXT_STATES[x.state] || x.state), "live-state"));
        grid.appendChild(li);
      });
      $("live-exts-empty").hidden = d.extensions.length > 0;
      var qb = $("live-queues-body");
      qb.textContent = "";
      d.queues.forEach(function (q) {
        var tr = el("tr");
        tr.appendChild(el("td", q.number + " " + q.name));
        tr.appendChild(el("td", String(q.waiting)));
        tr.appendChild(el("td", q.waiting ? fmtClock(q.longest) : "–"));
        tr.appendChild(el("td", q.available === null ? "–" : q.available + " / " + q.members));
        qb.appendChild(tr);
      });
      $("live-queues-empty").hidden = d.queues.length > 0;
    }).catch(function (e) { $("live-status").textContent = e.message; $("live-status").className = "error"; });
  }

  function liveHangup(c) {
    confirmDialog(t("Raccrocher un appel"), t("L'appel de") + " " + liveParty(c.caller, c.caller_name) + " " + t("vers") + " " +
      liveParty(c.callee, c.callee_name) + " " + t("sera coupé pour tous les participants. Continuer ?")).then(function (ok) {
      if (!ok) { return; }
      api("POST", "/api/live/hangup", { call: c.id }).then(function () {
        toast(t("Raccrochage demandé."));
        setTimeout(loadLive, 1500);
      }).catch(function (e) { toast(e.message); });
    });
  }

  function bindJobs() {
    document.querySelectorAll("[data-job]").forEach(function (b) {
      b.addEventListener("click", function () {
        var action = b.getAttribute("data-job");
        confirmDialog(t(JOB_LABELS[action]), t("Cette action est ajoutée à la file d'attente. Continuer ?")).then(function (ok) {
          if (!ok) { return; }
          api("POST", "/api/jobs", { action: action }).then(function () {
            toast(t("Tâche ajoutée à la file d'attente."));
            if (location.hash.indexOf("taches") >= 0) { loadJobs(); }
            if (location.hash.indexOf("maj") >= 0) { setTimeout(function () { loadUpdate(); loadMaintenance(false); }, 3000); }
          }).catch(function (e) { toast(e.message); });
        });
      });
    });
  }

  /* ------------------------------------- maintenance : fenêtre, retour arrière, sécurité, support */
  var WATCH_STATES = { pending: ["contrôle en cours", "warn"], confirmed: ["nouvelle version confirmée", "ok"],
                       "rolled-back": ["retour à la version précédente", "bad"] };

  function fillMaintenance(m) {
    var s = m.settings;
    $("mt-days").querySelectorAll("input").forEach(function (i) { i.checked = s.days.indexOf(parseInt(i.value, 10)) >= 0; });
    $("mt-start").value = s.start;
    $("mt-hours").value = String(s.hours);
    $("mt-auto").checked = s.auto_update;
    $("mt-security").checked = s.security;
    $("mt-reboot").checked = s.reboot;
    $("mt-notify").checked = s.notify;
    state.mtDirty = false;
  }

  function loadMaintenance(fill) {
    return api("GET", "/api/maintenance").then(function (m) {
      if (fill || !state.mtDirty) { fillMaintenance(m); }
      $("mt-rollback").textContent = m.rollback ? m.rollback.version + " (" + t("gardée le") + " " + fmtTime(m.rollback.created) + ")" : t("aucune");
      $("mt-rollback-btn").disabled = !m.rollback;
      var w = $("mt-watch");
      w.textContent = "";
      if (m.watch && WATCH_STATES[m.watch.status]) {
        var ws = WATCH_STATES[m.watch.status];
        w.appendChild(el("span", t(ws[0]), "state " + ws[1]));
        w.appendChild(el("span", " " + (m.watch.previous || "?") + " → " + (m.watch.version || "?") +
          (m.watch.reason ? " : " + m.watch.reason : ""), "muted"));
      } else { w.textContent = "–"; }
      $("mt-next").textContent = m.next_window ? fmtTime(m.next_window) : t("aucune");
      var win = m.window;
      $("mt-last").textContent = win ? fmtTime(win.started) + (win.running ? " · " + t("en cours") : "") : t("jamais");
      var steps = $("mt-steps");
      steps.textContent = "";
      (win ? win.steps : []).forEach(function (x) {
        var li = el("li");
        li.appendChild(el("span", x.ok ? t("réussi") : t("échec"), "state " + (x.ok ? "ok" : "bad")));
        li.appendChild(el("span", " " + x.what + (x.detail ? " : " + x.detail : "")));
        steps.appendChild(li);
      });
      $("mt-mail").textContent = !m.mail_enabled ? t("E-mails impossibles : activez la messagerie par e-mail (Téléphonie).")
        : !m.recipients ? t("E-mails impossibles : aucun destinataire dans Système > Alertes.") : "";
      var sec = m.security;
      $("mt-sec-ran").textContent = sec ? fmtTime(sec.ran) + (sec.ok ? "" : " · " + t("en échec") + (sec.error ? " : " + sec.error : "")) : t("jamais");
      var body = $("mt-sec-body");
      body.textContent = "";
      (sec ? sec.packages : []).forEach(function (p) {
        var tr = el("tr");
        [p.name, p.from || "–", p.to].forEach(function (v) { tr.appendChild(el("td", v)); });
        body.appendChild(tr);
      });
      $("mt-sec-empty").hidden = !!(sec && sec.packages.length);
      var rs = $("mt-reboot-state");
      rs.textContent = "";
      rs.appendChild(el("span", m.reboot_required ? t("redémarrage nécessaire") : t("non nécessaire"), "state " + (m.reboot_required ? "warn" : "ok")));
      if (m.reboot_required && m.reboot_packages.length) { rs.appendChild(el("span", " " + m.reboot_packages.join(", "), "muted")); }
      $("mt-reboot-planned").textContent = m.reboot_planned ? fmtTime(m.reboot_planned) : t("aucun");
      $("mt-reboot-cancel").hidden = !m.reboot_planned;
      $("mt-support").textContent = m.support ? fmtTime(m.support.created) + " · " + fmtBytes(m.support.size) : t("aucune");
      $("mt-support-dl").hidden = !m.support;
    }).catch(function () {});
  }

  function bindMaintenance() {
    var days = $("mt-days");
    DAY_LABELS.forEach(function (d, i) {
      var label = el("label", null, "check"), input = el("input");
      input.type = "checkbox"; input.value = String(i);
      label.appendChild(input);
      label.appendChild(el("span", d[1]));
      label.lastChild.setAttribute("data-i18n", "");
      days.appendChild(label);
    });
    for (var h = 1; h <= 8; h++) { var o = el("option", String(h)); o.value = String(h); $("mt-hours").appendChild(o); }
    $("mt-form").addEventListener("input", function () { state.mtDirty = true; });
    $("mt-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("mt-message");
      msg.textContent = ""; msg.className = "";
      var chosen = Array.prototype.filter.call(days.querySelectorAll("input"), function (i) { return i.checked; })
        .map(function (i) { return parseInt(i.value, 10); });
      api("POST", "/api/maintenance", {
        days: chosen, start: $("mt-start").value, hours: parseInt($("mt-hours").value, 10),
        auto_update: $("mt-auto").checked, security: $("mt-security").checked,
        reboot: $("mt-reboot").checked, notify: $("mt-notify").checked
      }).then(function () {
        state.mtDirty = false;
        msg.textContent = t("Fenêtre de maintenance enregistrée.");
        loadMaintenance(true);
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
    $("mt-reboot-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var value = $("mt-reboot-at").value, at = value ? Math.floor(new Date(value).getTime() / 1000) : NaN;
      if (isNaN(at)) { setMsg("mt-reboot-message", t("Choisissez la date et l'heure du redémarrage."), true); return; }
      api("POST", "/api/maintenance/reboot", { at: at }).then(function () {
        setMsg("mt-reboot-message", t("Redémarrage planifié."));
        loadMaintenance(false);
      }).catch(function (e) { setMsg("mt-reboot-message", e.message, true); });
    });
    $("mt-reboot-cancel").addEventListener("click", function () {
      api("POST", "/api/maintenance/reboot", { at: null }).then(function () {
        setMsg("mt-reboot-message", t("Redémarrage planifié annulé."));
        loadMaintenance(false);
      }).catch(function (e) { setMsg("mt-reboot-message", e.message, true); });
    });
  }

  /* ------------------------------------- comptes, double authentification, certificat */
  var ROLE_LABELS = { admin: "Administrateur", lecture: "Lecture seule" };

  function setMsg(id, text, error) {
    var msg = $(id);
    msg.textContent = text || "";
    msg.className = error ? "error" : "";
  }

  function loadAccounts() {
    return Promise.all([api("GET", "/api/account"), api("GET", "/api/users"), loadTls()]).then(function (r) {
      var me = r[0], list = r[1];
      $("password-form").hidden = me.source === "ad";  // mot de passe AD : changé dans Windows
      var st = $("totp-state");
      st.textContent = me.totp ? t("activée") + " (" + me.recovery_left + " " + t("codes de secours restants") + ")" : t("désactivée");
      st.className = "state " + (me.totp ? "ok" : "warn");
      if (!state.totpSetup) {
        $("totp-enable-start").hidden = me.totp;
        $("totp-disable").hidden = !me.totp;
        $("totp-recovery-new").hidden = !me.totp;
      }
      var body = $("users-body");
      body.textContent = "";
      list.users.forEach(function (u) {
        var tr = el("tr"), ad = u.source === "ad";
        var who = el("td", u.username);
        if (ad) { var adb = el("span", "AD", "badge ad"); adb.title = t("Compte Active Directory : rôle donné par ses groupes AD"); who.appendChild(adb); }
        tr.appendChild(who);
        tr.appendChild(el("td", t(ROLE_LABELS[u.role] || u.role)));
        var s = el("td");
        s.appendChild(el("span", u.disabled ? t("désactivé") : t("actif"), "state " + (u.disabled ? "bad" : "ok")));
        tr.appendChild(s);
        tr.appendChild(el("td", u.totp ? t("activée") : t("non")));
        tr.appendChild(el("td", u.last_login ? fmtTime(u.last_login) : "–"));
        var td = el("td");
        if (u.username !== me.username) {
          var acts = el("div", null, "actions admin-only");
          var role = el("button", u.role === "admin" ? t("Passer en lecture seule") : t("Passer administrateur"), "ghost");
          role.type = "button";
          role.addEventListener("click", function () { userAction("/api/users/update", { username: u.username, role: u.role === "admin" ? "lecture" : "admin" }); });
          var dis = el("button", u.disabled ? t("Réactiver") : t("Désactiver"), "ghost");
          dis.type = "button";
          dis.addEventListener("click", function () { userAction("/api/users/update", { username: u.username, disabled: !u.disabled }); });
          var pw = el("button", t("Mot de passe"), "ghost");
          pw.type = "button";
          pw.addEventListener("click", function () {
            state.resetUser = u.username;
            $("user-reset-name").textContent = u.username;
            $("user-reset").hidden = false;
            $("user-reset-pass").focus();
          });
          if (!ad) { acts.appendChild(role); }
          acts.appendChild(dis);
          if (!ad) { acts.appendChild(pw); }
          if (u.totp) {
            var otp = el("button", t("Retirer la double authentification"), "ghost");
            otp.type = "button";
            otp.addEventListener("click", function () {
              confirmDialog(t("Double authentification"), t("Retirer la double authentification de") + " " + u.username + " ?").then(function (ok) {
                if (ok) { userAction("/api/users/password", { username: u.username, totp_reset: true }); }
              });
            });
            acts.appendChild(otp);
          }
          var del = el("button", t("Supprimer"), "danger");
          del.type = "button";
          del.addEventListener("click", function () {
            confirmDialog(t("Supprimer"), t("Supprimer le compte") + " " + u.username + " ?").then(function (ok) {
              if (ok) { userAction("/api/users/delete", { username: u.username }); }
            });
          });
          acts.appendChild(del);
          td.appendChild(acts);
        } else {
          td.appendChild(el("span", t("vous"), "muted"));
        }
        tr.appendChild(td);
        body.appendChild(tr);
      });
    }).catch(function (e) { toast(e.message); });
  }

  function userAction(path, body) {
    return api("POST", path, body).then(function () {
      setMsg("users-message", t("Compte mis à jour."));
      return loadAccounts();
    }).catch(function (e) { setMsg("users-message", e.message, true); });
  }

  function accountsReset() {
    // Rien du compte précédent ne reste à l'écran (codes de secours, QR code)
    state.totpSetup = false;
    $("totp-codes-list").textContent = "";
    $("totp-codes").hidden = true;
    $("totp-confirm").hidden = true;
    $("totp-start").hidden = false;
    $("totp-qr").removeAttribute("src");
    $("totp-secret").textContent = "";
    ["totp-message", "users-message", "pw-message"].forEach(function (id) { setMsg(id, ""); });
  }

  function showRecovery(codes) {
    var list = $("totp-codes-list");
    list.textContent = "";
    codes.forEach(function (c) { list.appendChild(el("li", c)); });
    $("totp-codes").hidden = false;
  }

  function bindAccounts() {
    $("totp-start").addEventListener("submit", function (ev) {
      ev.preventDefault();
      api("POST", "/api/account/totp/setup", { password: $("totp-password").value }).then(function (r) {
        $("totp-password").value = "";
        state.totpSetup = true;
        $("totp-qr").src = "data:image/svg+xml;base64," + btoa(r.svg);
        $("totp-secret").textContent = r.secret.replace(/(.{4})/g, "$1 ").trim();
        $("totp-start").hidden = true;
        $("totp-codes").hidden = true;
        $("totp-confirm").hidden = false;
        $("totp-code").focus();
        setMsg("totp-message", "");
      }).catch(function (e) { setMsg("totp-message", e.message, true); });
    });
    $("totp-cancel").addEventListener("click", function () {
      state.totpSetup = false;
      $("totp-confirm").hidden = true;
      $("totp-start").hidden = false;
    });
    $("totp-confirm").addEventListener("submit", function (ev) {
      ev.preventDefault();
      api("POST", "/api/account/totp/enable", { code: $("totp-code").value.trim() }).then(function (r) {
        state.totpSetup = false;
        $("totp-code").value = "";
        $("totp-confirm").hidden = true;
        $("totp-start").hidden = false;
        showRecovery(r.recovery);
        setMsg("totp-message", t("Double authentification activée."));
        loadAccounts();
      }).catch(function (e) { setMsg("totp-message", e.message, true); });
    });
    $("totp-disable").addEventListener("click", function () {
      api("POST", "/api/account/totp/disable", { password: $("totp-password").value }).then(function () {
        $("totp-password").value = "";
        $("totp-codes").hidden = true;
        setMsg("totp-message", t("Double authentification désactivée."));
        loadAccounts();
      }).catch(function (e) { setMsg("totp-message", e.message, true); });
    });
    $("totp-recovery-new").addEventListener("click", function () {
      api("POST", "/api/account/totp/recovery", { password: $("totp-password").value }).then(function (r) {
        $("totp-password").value = "";
        showRecovery(r.recovery);
        setMsg("totp-message", t("Nouveaux codes de secours créés : les anciens ne servent plus."));
        loadAccounts();
      }).catch(function (e) { setMsg("totp-message", e.message, true); });
    });
    $("user-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      api("POST", "/api/users", { username: $("user-name").value.trim(), role: $("user-role").value, password: $("user-pass").value }).then(function () {
        ev.target.reset();
        setMsg("users-message", t("Compte créé."));
        loadAccounts();
      }).catch(function (e) { setMsg("users-message", e.message, true); });
    });
    $("user-reset-cancel").addEventListener("click", function () { $("user-reset").hidden = true; });
    $("user-reset").addEventListener("submit", function (ev) {
      ev.preventDefault();
      api("POST", "/api/users/password", { username: state.resetUser, password: $("user-reset-pass").value }).then(function () {
        ev.target.reset();
        ev.target.hidden = true;
        setMsg("users-message", t("Mot de passe réinitialisé : les sessions du compte sont fermées."));
      }).catch(function (e) { setMsg("users-message", e.message, true); });
    });
    bindTls();
  }

  // Active Directory : réglages (mot de passe du compte de service jamais renvoyé), état, postes proposés
  function adStamp(x) {
    if (!x) { return t("jamais"); }
    return (x.ok ? t("réussi") : t("en échec")) + " – " + fmtTime(x.ts) + (x.message ? " – " + x.message : "");
  }

  function showAd(d, fill) {
    var s = d.settings;
    if (fill) {
      $("ad-hosts").value = s.hosts.join(" ");
      $("ad-mode").value = s.mode;
      $("ad-port").value = s.port;
      $("ad-domain").value = s.domain;
      $("ad-base").value = s.base_dn;
      $("ad-ca").value = s.ca_pem;
      $("ad-enabled").checked = s.enabled;
      $("ad-admin-group").value = s.admin_group;
      $("ad-read-group").value = s.read_group;
      $("ad-bind-user").value = s.bind_user;
      $("ad-bind-pass").value = "";
      $("ad-ou").value = s.contacts_ou;
      $("ad-import").checked = s.import_enabled;
      $("ad-propose").checked = s.propose_extensions;
    }
    $("ad-pass-state").textContent = s.has_password ? t("Mot de passe enregistré (chiffré) : laissez vide pour le garder.") : t("Aucun mot de passe enregistré.");
    $("ad-chain").textContent = d.company_chain ? d.company_chain + " " + t("certificats d'autorité repris du certificat HTTPS de l'entreprise.") : t("Aucun certificat de l'entreprise importé : collez le certificat de l'autorité si le contrôleur n'est pas reconnu.");
    $("ad-test-state").textContent = d.test ? (d.test.ok ? t("réussi") : t("en échec")) + " – " + fmtTime(d.test.ts) : t("jamais");
    var steps = $("ad-test-steps");
    steps.textContent = "";
    ((d.test && d.test.steps) || []).forEach(function (line) { steps.appendChild(el("li", line)); });
    $("ad-sync-state").textContent = adStamp(d.sync);
    $("ad-contacts").textContent = String(d.ad_contacts);
    var body = $("ad-accounts");
    body.textContent = "";
    $("ad-accounts-empty").hidden = d.accounts.length > 0;
    d.accounts.forEach(function (a) {
      var tr = el("tr");
      tr.appendChild(el("td", a.username));
      tr.appendChild(el("td", t(ROLE_LABELS[a.role] || a.role)));
      var st = el("td");
      st.appendChild(el("span", a.disabled ? t("désactivé") : t("actif"), "state " + (a.disabled ? "bad" : "ok")));
      tr.appendChild(st);
      tr.appendChild(el("td", a.last_login ? fmtTime(a.last_login) : "–"));
      body.appendChild(tr);
    });
    $("ad-proposals-card").hidden = !s.propose_extensions && !d.proposals.length;
    var offers = $("ad-proposals");
    offers.textContent = "";
    $("ad-proposals-empty").hidden = d.proposals.length > 0;
    d.proposals.forEach(function (p) {
      var tr = el("tr");
      tr.appendChild(el("td", p.number));
      tr.appendChild(el("td", p.name));
      tr.appendChild(el("td", p.email || "–"));
      var td = el("td"), b = el("button", t("Créer le poste"), "ghost small admin-only");
      b.type = "button";
      b.setAttribute("aria-label", t("Créer le poste") + " " + p.number);
      b.addEventListener("click", function () {
        confirmDialog(t("Créer le poste"), t("Créer le poste") + " " + p.number + " (" + p.name + ") ?").then(function (ok) {
          if (!ok) { return; }
          return api("POST", "/api/pbx/extensions", { number: p.number, name: p.name, email: p.email, voicemail: true }).then(function () {
            setMsg("ad-message", t("Poste créé : sa fiche est dans Téléphonie > Postes."));
            loadAd(false);
          });
        }).catch(function (e) { setMsg("ad-message", e.message, true); });
      });
      td.appendChild(b);
      tr.appendChild(td);
      offers.appendChild(tr);
    });
  }

  function loadAd(fill) {
    return api("GET", "/api/ad").then(function (d) { showAd(d, fill); }).catch(function (e) { toast(e.message); });
  }

  function bindAd() {
    $("ad-mode").addEventListener("change", function () { $("ad-port").value = $("ad-mode").value === "ldaps" ? "636" : "389"; });
    $("ad-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      setMsg("ad-message", "");
      var body = {
        hosts: $("ad-hosts").value.trim(), mode: $("ad-mode").value, port: parseInt($("ad-port").value, 10) || null,
        domain: $("ad-domain").value.trim(), base_dn: $("ad-base").value.trim(), ca_pem: $("ad-ca").value.trim(),
        enabled: $("ad-enabled").checked, admin_group: $("ad-admin-group").value.trim(), read_group: $("ad-read-group").value.trim(),
        bind_user: $("ad-bind-user").value.trim(), contacts_ou: $("ad-ou").value.trim(),
        import_enabled: $("ad-import").checked, propose_extensions: $("ad-propose").checked
      };
      if ($("ad-bind-pass").value) { body.password = $("ad-bind-pass").value; }
      api("POST", "/api/ad", body).then(function (d) {
        showAd(d, true);
        setMsg("ad-message", t("Réglages Active Directory enregistrés.") + (d.applied ? " " + t("Synchronisation ajoutée à la file d'attente.") : ""));
      }).catch(function (e) { setMsg("ad-message", e.message, true); });
    });
    $("ad-test").addEventListener("click", function () {
      setMsg("ad-message", "");
      api("POST", "/api/ad/test", {}).then(function () {
        setMsg("ad-message", t("Essai ajouté à la file d'attente : le résultat s'affiche dans l'état ci-dessous."));
        setTimeout(function () { loadAd(false); }, 4000);
      }).catch(function (e) { setMsg("ad-message", e.message, true); });
    });
    $("ad-sync").addEventListener("click", function () {
      setMsg("ad-message", "");
      api("POST", "/api/ad/sync", {}).then(function () {
        setMsg("ad-message", t("Synchronisation ajoutée à la file d'attente."));
        setTimeout(function () { loadAd(false); }, 4000);
      }).catch(function (e) { setMsg("ad-message", e.message, true); });
    });
  }

  function loadTls() {
    return api("GET", "/api/tls").then(function (d) {
      var c = d.current;
      $("tls-subject").textContent = c ? c.subject + (c.self_signed ? " (" + t("auto-signé") + ")" : "") : t("inconnu");
      $("tls-issuer").textContent = c ? c.issuer : "–";
      $("tls-names").textContent = c && c.names && c.names.length ? c.names.join(", ") : "–";
      var exp = $("tls-expires");
      exp.textContent = c && c.expires ? fmtTime(c.expires) + " (" + c.days_left + " " + t("jours") + ")" : "–";
      exp.className = c && c.days_left !== null && c.days_left < 30 ? "state warn" : "";
      $("tls-chain").textContent = c ? (c.chain ? c.chain + " " + t("certificat(s) d'autorité") : t("aucune")) : "–";
      $("tls-fingerprint").textContent = c ? c.fingerprint : "–";
      var last = $("tls-last");
      if (d.pending) { last.textContent = t("Certificat en cours d'application…"); last.className = "state warn"; }
      else if (d.last) {
        last.textContent = fmtTime(d.last.ts) + " : " + t(d.last.message);
        last.className = "state " + (d.last.ok ? "ok" : "bad");
      } else { last.textContent = ""; }
      var warn = $("tls-warnings");
      warn.textContent = "";
      ((d.last && d.last.warnings) || []).forEach(function (w) { warn.appendChild(el("li", t(w), "state warn")); });
      if (!c && !d.pending && !state.tlsRefreshed && document.body.getAttribute("data-role") === "admin") {
        state.tlsRefreshed = true;  // état absent (après une mise à jour) : relu une fois par la file d'attente
        api("POST", "/api/tls/refresh", {}).then(function () { setTimeout(loadTls, 4000); }).catch(function () {});
      }
      return d;
    });
  }

  function waitTls(tries) {
    setTimeout(function () {
      loadTls().then(function (d) { if (d.pending && tries > 0) { waitTls(tries - 1); } }).catch(function () {});
    }, 2000);
  }

  function fileBase64(file) {
    return file.arrayBuffer().then(function (buf) {
      var bytes = new Uint8Array(buf), bin = "";
      for (var i = 0; i < bytes.length; i++) { bin += String.fromCharCode(bytes[i]); }
      return btoa(bin);
    });
  }

  function bindTls() {
    document.querySelectorAll('input[name="tls-format"]').forEach(function (r) {
      r.addEventListener("change", function () {
        var p12 = document.querySelector('input[name="tls-format"]:checked').value === "p12";
        $("tls-p12").hidden = !p12;
        $("tls-pem").hidden = p12;
      });
    });
    $("tls-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var p12 = document.querySelector('input[name="tls-format"]:checked').value === "p12";
      var job;
      if (p12) {
        var f = $("tls-p12-file").files[0];
        if (!f) { toast(t("Choisissez le fichier du certificat.")); return; }
        job = fileBase64(f).then(function (b64) { return { format: "p12", p12: b64, password: $("tls-p12-pass").value }; });
      } else {
        var cert = $("tls-cert").files[0], key = $("tls-key").files[0];
        if (!cert || !key) { toast(t("Choisissez le certificat et la clé privée.")); return; }
        job = Promise.all([cert.text(), key.text()]).then(function (x) { return { format: "pem", cert: x[0], key: x[1] }; });
      }
      job.then(function (body) { return api("POST", "/api/tls", body); }).then(function () {
        ev.target.reset();
        $("tls-p12").hidden = true;
        $("tls-pem").hidden = false;
        toast(t("Certificat envoyé : vérification puis application par la file d'attente."));
        waitTls(30);
      }).catch(function (e) { toast(e.message); });
    });
    $("tls-reset").addEventListener("click", function () {
      confirmDialog(t("Certificat HTTPS"), t("Remplacer le certificat actuel par un nouveau certificat auto-signé ?")).then(function (ok) {
        if (!ok) { return; }
        api("POST", "/api/tls/reset", {}).then(function () { waitTls(30); }).catch(function (e) { toast(e.message); });
      });
    });
  }

  /* ---------------------------------------------------------- session */
  function showLogin() {
    clearInterval(state.timer);
    accountsReset();
    $("app-view").hidden = true;
    $("login-view").hidden = false;
    $("login-user").focus();
  }

  function showApp(session) {
    state.csrf = session.csrf;
    $("whoami").textContent = session.user;
    document.body.setAttribute("data-role", session.role || "admin");
    $("readonly-badge").hidden = session.role !== "lecture";
    $("version").textContent = "v" + session.version;
    $("login-view").hidden = true;
    $("app-view").hidden = false;
    route();
    ncConfirmPending();
  }

  function setLang(lang) {
    document.cookie = "pxb_lang=" + lang + "; Path=/; SameSite=Strict; Secure; Max-Age=31536000";
    return window.I18N.load(lang).then(function () {
      window.I18N.apply();
      $("lang-toggle").textContent = lang === "fr" ? "EN" : "FR";
      if (state.series) { drawChart(); }
    });
  }

  /* ------------------- numéros directs, fermetures, numéro présenté (lot J) */
  function fmtDate(iso) {
    var p = String(iso || "").split("-");
    return p.length === 3 ? p[2] + "/" + p[1] + "/" + p[0] : iso;
  }

  function sdaChoices(p) {
    var out = [["accueil", t("Accueil (postes de l'accueil, accueil vocal)")]];
    p.extensions.forEach(function (x) { out.push([x.number, t("Poste") + " " + x.number + " " + x.name]); });
    p.groups.forEach(function (g) { out.push([g.number, t("Groupe") + " " + g.number + " " + g.name]); });
    (p.queues || []).forEach(function (q) { out.push([q.number, t("File d'attente") + " " + q.number + " " + q.name]); });
    p.extensions.forEach(function (x) {
      if (x.voicemail) { out.push(["vm:" + x.number, t("Messagerie du poste") + " " + x.number + " " + x.name]); }
    });
    return out;
  }

  function saveDids(list, msg, done) {
    msg.textContent = ""; msg.className = "";
    return api("POST", "/api/pbx/dids", { dids: list }).then(function (r) {
      msg.textContent = r.applied ? t("Numéros directs enregistrés : application en cours.") : t("Numéros directs enregistrés, mais la file d'attente est indisponible.");
      if (done) { done(); }
      return loadSda(true);
    }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
  }

  function cloRows() {
    var body = $("clo-body");
    body.textContent = "";
    $("clo-empty").hidden = state.cloPeriods.length > 0;
    state.cloPeriods.forEach(function (c, i) {
      var tr = el("tr");
      tr.appendChild(el("td", fmtDate(c.start)));
      tr.appendChild(el("td", fmtDate(c.end)));
      tr.appendChild(el("td", c.name || "–"));
      var act = el("td"), del = el("button", t("Retirer"), "ghost small");
      del.type = "button";
      del.addEventListener("click", function () { state.cloPeriods.splice(i, 1); state.cloDirty = true; cloRows(); });
      act.appendChild(del); tr.appendChild(act);
      body.appendChild(tr);
    });
  }

  function fillClosures(p) {
    var c = p.closures, box = $("clo-holidays"), dates = {}, labels = {};
    $("clo-holidays-on").checked = c.holidays_enabled;
    (p.holidays || []).forEach(function (h) { (dates[h.key] = dates[h.key] || []).push(fmtDate(h.date)); labels[h.key] = h.label; });
    box.textContent = "";
    Object.keys(labels).forEach(function (key) {
      var label = el("label", null, "check"), input = el("input");
      input.type = "checkbox"; input.value = key; input.checked = c.holidays.indexOf(key) >= 0;
      label.appendChild(input);
      label.appendChild(el("span", t(labels[key]) + " (" + dates[key].join(", ") + ")"));
      box.appendChild(label);
    });
    box.hidden = !c.holidays_enabled;
    state.cloPeriods = c.periods.map(function (x) { return { start: x.start, end: x.end, name: x.name }; });
    cloRows();
  }

  function loadSda(fill) {
    return api("GET", "/api/pbx").then(function (p) {
      var choices = sdaChoices(p), body = $("sda-body");
      state.dids = p.dids || [];
      body.textContent = "";
      $("sda-empty").hidden = state.dids.length > 0;
      state.dids.forEach(function (d) {
        var tr = el("tr"), found = choices.filter(function (c) { return c[0] === d.target; })[0];
        tr.appendChild(el("td", fmtNumber(d.number)));
        tr.appendChild(el("td", d.name || "–"));
        tr.appendChild(el("td", found ? found[1] : d.target));
        tr.appendChild(el("td", d.hours ? t("suit l'accueil") : t("toujours")));
        var act = el("td"), del = el("button", t("Supprimer"), "danger small");
        del.type = "button";
        del.setAttribute("aria-label", t("Supprimer le numéro direct") + " " + d.number);
        del.addEventListener("click", function () {
          confirmDialog(t("Supprimer"), t("Supprimer le numéro direct") + " " + fmtNumber(d.number) + " ?").then(function (ok) {
            if (ok) { saveDids(state.dids.filter(function (o) { return o.number !== d.number; }), $("sda-message")); }
          });
        });
        act.appendChild(del); tr.appendChild(act);
        body.appendChild(tr);
      });
      if (fill || !state.sdaDirty) { fillSelect($("sda-target"), choices, $("sda-target").value || "accueil"); }
      if (fill || !state.cloDirty) { fillClosures(p); }
    }).catch(function (e) { toast(e.message); });
  }

  function loadCallerIds(fill) {
    return api("GET", "/api/pbx").then(function (p) {
      var body = $("cid-body");
      if (!fill && state.cidDirty) { return; }
      body.textContent = "";
      p.extensions.forEach(function (x) {
        var tr = el("tr"), td = el("td"), sel = el("select");
        tr.appendChild(el("td", x.number + " " + x.name));
        sel.setAttribute("data-number", x.number);
        sel.setAttribute("aria-label", t("Numéro présenté du poste") + " " + x.number);
        fillSelect(sel, [["", t("numéro de la ligne") + (p.trunk.caller_id ? " (" + p.trunk.caller_id + ")" : "")]].concat(
          (p.dids || []).map(function (d) { return [d.number, fmtNumber(d.number) + (d.name ? " " + d.name : "")]; })), x.caller_id || "");
        td.appendChild(sel); tr.appendChild(td);
        var dnd = el("td");
        dnd.appendChild(el("span", x.dnd ? t("activé (*76)") : t("non"), "state " + (x.dnd ? "warn" : "")));
        tr.appendChild(dnd);
        body.appendChild(tr);
      });
      $("cid-parking").checked = p.services.parking;
    }).catch(function (e) { toast(e.message); });
  }

  function bindSda() {
    ["sda-form"].forEach(function (id) { $(id).addEventListener("input", function () { state.sdaDirty = true; }); });
    $("clo-form").addEventListener("change", function () { state.cloDirty = true; });
    $("cid-form").addEventListener("change", function () { state.cidDirty = true; });
    $("clo-holidays-on").addEventListener("change", function () { $("clo-holidays").hidden = !$("clo-holidays-on").checked; });
    $("sda-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var d = { number: $("sda-number").value.trim(), name: $("sda-name").value.trim(), target: $("sda-target").value,
                hours: $("sda-hours").checked };
      saveDids((state.dids || []).concat([d]), $("sda-message"), function () { state.sdaDirty = false; ev.target.reset(); });
    });
    $("clo-add").addEventListener("click", function () {
      var msg = $("clo-message"), start = $("clo-start").value, end = $("clo-end").value || start;
      msg.textContent = ""; msg.className = "";
      if (!start) { msg.textContent = t("Choisissez la date de début de la période."); msg.className = "error"; return; }
      state.cloPeriods.push({ start: start, end: end, name: $("clo-name").value.trim() });
      state.cloDirty = true;
      $("clo-start").value = ""; $("clo-end").value = ""; $("clo-name").value = "";
      cloRows();
    });
    $("clo-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("clo-message");
      msg.textContent = ""; msg.className = "";
      api("POST", "/api/pbx/closures", {
        holidays_enabled: $("clo-holidays-on").checked,
        holidays: Array.prototype.filter.call($("clo-holidays").querySelectorAll("input"), function (i) { return i.checked; }).map(function (i) { return i.value; }),
        periods: state.cloPeriods
      }).then(function (r) {
        state.cloDirty = false;
        msg.textContent = r.applied ? t("Fermetures enregistrées : application en cours.") : t("Fermetures enregistrées, mais la file d'attente est indisponible.");
        loadSda(true);
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
    $("cid-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("cid-message"), cids = {};
      msg.textContent = ""; msg.className = "";
      $("cid-body").querySelectorAll("select").forEach(function (s) { cids[s.getAttribute("data-number")] = s.value; });
      api("POST", "/api/pbx/caller-ids", { caller_ids: cids, parking: $("cid-parking").checked }).then(function (r) {
        state.cidDirty = false;
        msg.textContent = r.applied ? t("Réglages enregistrés : application en cours.") : t("Réglages enregistrés, mais la file d'attente est indisponible.");
        loadCallerIds(true);
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  function setTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    try { localStorage.setItem("pxb_theme", theme); } catch (e) { /* stockage indisponible */ }
  }

  function init() {
    var saved = null;
    try { saved = localStorage.getItem("pxb_theme"); } catch (e) { saved = null; }
    if (saved) { setTheme(saved); }
    bindTabs();
    bindJobs();
    bindPbx();
    bindLine();
    bindGroups();
    bindQueues();
    bindSda();
    bindDiagnostic();
    bindMaintenance();  // fenêtre de maintenance, retour arrière, support
    bindMail();
    bindIvr();
    bindDirectory();
    bindLdap();
    bindProvisioning();
    bindNetconf();
    bindBackups();
    bindCopy();
    bindAlerts();
    bindOps();
    bindAccounts();
    bindAd();
    window.addEventListener("hashchange", route);
    $("theme-toggle").addEventListener("click", function () {
      var dark = document.documentElement.getAttribute("data-theme") === "dark" ||
        (!document.documentElement.getAttribute("data-theme") && window.matchMedia("(prefers-color-scheme: dark)").matches);
      setTheme(dark ? "light" : "dark");
    });
    $("lang-toggle").addEventListener("click", function () { setLang(window.I18N.lang() === "fr" ? "en" : "fr"); });
    document.querySelectorAll("[data-range]").forEach(function (b) {
      b.addEventListener("click", function () {
        state.range = b.getAttribute("data-range");
        document.querySelectorAll("[data-range]").forEach(function (o) { o.setAttribute("aria-pressed", o === b ? "true" : "false"); });
        loadMetrics();
      });
    });
    $("chart-metric").addEventListener("change", function (ev) { state.metric = ev.target.value; drawChart(); });
    var loginStep = function (two) {
      state.ticket = two || null;
      $("login-step1").hidden = !!two;
      $("login-step2").hidden = !two;
      $("login-code").value = "";
      (two ? $("login-code") : $("login-pass")).focus();
    };
    $("login-back").addEventListener("click", function () { $("login-error").textContent = ""; loginStep(null); });
    $("login-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      $("login-error").textContent = "";
      var call = state.ticket
        ? api("POST", "/api/login/totp", { ticket: state.ticket, code: $("login-code").value.trim() })
        : api("POST", "/api/login", { username: $("login-user").value.trim(), password: $("login-pass").value });
      call.then(function (s) {
        $("login-pass").value = "";
        if (s.totp_required) { loginStep(s.ticket); return null; }
        loginStep(null);
        return api("GET", "/api/session").then(showApp);
      }).catch(function (e) {
        $("login-error").textContent = e.message;
        if (state.ticket && e.restart) { loginStep(null); }
      });
    });
    $("logout").addEventListener("click", function () {
      api("POST", "/api/logout", {}).then(showLogin, showLogin);
    });
    $("password-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("pw-message");
      msg.className = "";
      if ($("pw-new").value !== $("pw-confirm").value) {
        msg.textContent = t("Les deux mots de passe ne correspondent pas.");
        msg.className = "error";
        return;
      }
      api("POST", "/api/password", { current: $("pw-current").value, "new": $("pw-new").value }).then(function (r) {
        state.csrf = r.csrf;
        ev.target.reset();
        msg.textContent = t("Mot de passe modifié.");
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });

    api("GET", "/api/session").then(function (s) {
      return setLang(s.lang).then(function () {
        $("login-unconfigured").hidden = s.configured;
        if (s.user) { showApp(s); } else { showLogin(); }
      });
    }).catch(showLogin);
  }

  document.addEventListener("DOMContentLoaded", init);
})();
