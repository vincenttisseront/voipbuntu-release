"""Double authentification TOTP (RFC 6238) et QR code SVG, sans dépendance.

Le QR code est calculé ici (mode octet, correction M, versions 1 à 15) pour
que le secret ne quitte jamais l'appliance : aucun service extérieur.
"""

import base64
import hashlib
import hmac
import secrets
import struct
import time
from urllib.parse import quote

PERIOD = 30
DIGITS = 6
WINDOW = 1  # une période d'écart tolérée de chaque côté (horloge du téléphone)
RECOVERY_COUNT = 8
RECOVERY_ALPHABET = "abcdefghjkmnpqrstuvwxyz23456789"  # sans 0/o ni 1/l/i


# ------------------------------------------------------------------ TOTP
def new_secret():
    return base64.b32encode(secrets.token_bytes(20)).decode("ascii").rstrip("=")


def _key(secret):
    secret = secret.strip().replace(" ", "").upper()
    return base64.b32decode(secret + "=" * (-len(secret) % 8))


def code_at(secret, step):
    digest = hmac.new(_key(secret), struct.pack(">Q", step), hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    value = struct.unpack(">I", digest[offset:offset + 4])[0] & 0x7FFFFFFF
    return str(value % (10 ** DIGITS)).zfill(DIGITS)


def now_code(secret, now=None):
    return code_at(secret, int((time.time() if now is None else now) // PERIOD))


def verify(secret, code, last_step=0, now=None):
    """Retourne la période du code accepté, ou None.

    Un code déjà utilisé (période <= last_step) est refusé : pas de rejeu.
    """
    code = str(code or "").strip().replace(" ", "")
    if len(code) != DIGITS or not code.isdigit():
        return None
    current = int((time.time() if now is None else now) // PERIOD)
    for step in range(current - WINDOW, current + WINDOW + 1):
        if step > (last_step or 0) and hmac.compare_digest(code_at(secret, step), code):
            return step
    return None


def otpauth_uri(secret, account, issuer="VOIPbuntu"):
    label = quote("%s:%s" % (issuer, account), safe="")
    return "otpauth://totp/%s?secret=%s&issuer=%s&algorithm=SHA1&digits=%d&period=%d" % (
        label, secret, quote(issuer, safe=""), DIGITS, PERIOD)


def new_recovery_codes(count=RECOVERY_COUNT):
    codes = []
    for _ in range(count):
        raw = "".join(secrets.choice(RECOVERY_ALPHABET) for _ in range(10))
        codes.append(raw[:5] + "-" + raw[5:])
    return codes


def normalize_recovery(code):
    return str(code or "").strip().lower().replace(" ", "").replace("-", "")


def recovery_digest(code):
    return hashlib.sha256(normalize_recovery(code).encode("ascii", "replace")).hexdigest()


# --------------------------------------------------------------- QR code
# Correction M : octets de correction par bloc et nombre de blocs, versions 1 à 15.
_ECC_M = [None, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24]
_BLOCKS_M = [None, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10]
_FORMAT_M = 0  # bits de format du niveau M


def _gf_mul(x, y):
    z = 0
    for i in reversed(range(8)):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _rs_divisor(degree):
    result = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(degree):
            result[j] = _gf_mul(result[j], root)
            if j + 1 < degree:
                result[j] ^= result[j + 1]
        root = _gf_mul(root, 0x02)
    return result


def _rs_remainder(data, divisor):
    result = [0] * len(divisor)
    for b in data:
        factor = b ^ result.pop(0)
        result.append(0)
        for i, coef in enumerate(divisor):
            result[i] ^= _gf_mul(coef, factor)
    return result


def _raw_modules(ver):
    result = (16 * ver + 128) * ver + 64
    if ver >= 2:
        num_align = ver // 7 + 2
        result -= (25 * num_align - 10) * num_align - 55
        if ver >= 7:
            result -= 36
    return result


def _data_codewords(ver):
    return _raw_modules(ver) // 8 - _ECC_M[ver] * _BLOCKS_M[ver]


def _align_positions(ver):
    if ver == 1:
        return []
    num_align = ver // 7 + 2
    size = ver * 4 + 17
    step = (ver * 8 + num_align * 3 + 5) // (num_align * 4 - 4) * 2
    return [6] + sorted(size - 7 - i * step for i in range(num_align - 1))


class QrError(ValueError):
    pass


def qr_matrix(text):
    """Matrice (liste de listes de booléens) du QR code de `text`."""
    data = text.encode("utf-8")
    ver = None
    for v in range(1, 16):
        count_bits = 8 if v < 10 else 16
        if 4 + count_bits + len(data) * 8 <= _data_codewords(v) * 8:
            ver = v
            break
    if ver is None:
        raise QrError("texte trop long pour le QR code")
    count_bits = 8 if ver < 10 else 16
    bits = []

    def put(value, n):
        bits.extend((value >> i) & 1 for i in reversed(range(n)))
    put(0b0100, 4)
    put(len(data), count_bits)
    for b in data:
        put(b, 8)
    capacity = _data_codewords(ver) * 8
    put(0, min(4, capacity - len(bits)))
    put(0, -len(bits) % 8)
    pad = 0xEC
    while len(bits) < capacity:
        put(pad, 8)
        pad ^= 0xEC ^ 0x11
    codewords = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]

    # Blocs, correction Reed-Solomon et entrelacement
    num_blocks, ecc_len = _BLOCKS_M[ver], _ECC_M[ver]
    raw = _raw_modules(ver) // 8
    num_short = num_blocks - raw % num_blocks
    short_len = raw // num_blocks
    divisor = _rs_divisor(ecc_len)
    blocks, k = [], 0
    for i in range(num_blocks):
        length = short_len - ecc_len + (0 if i < num_short else 1)
        dat = codewords[k:k + length]
        k += length
        ecc = _rs_remainder(dat, divisor)
        if i < num_short:
            dat = dat + [0]
        blocks.append(dat + ecc)
    final = []
    for i in range(len(blocks[0])):
        for j, blk in enumerate(blocks):
            if i != short_len - ecc_len or j >= num_short:
                final.append(blk[i])

    size = ver * 4 + 17
    modules = [[False] * size for _ in range(size)]
    function = [[False] * size for _ in range(size)]

    def setf(x, y, dark):
        modules[y][x] = bool(dark)
        function[y][x] = True

    for i in range(size):
        setf(6, i, i % 2 == 0)
        setf(i, 6, i % 2 == 0)
    for cx, cy in ((3, 3), (size - 4, 3), (3, size - 4)):
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                x, y = cx + dx, cy + dy
                if 0 <= x < size and 0 <= y < size:
                    setf(x, y, max(abs(dx), abs(dy)) not in (2, 4))
    pos = _align_positions(ver)
    last = len(pos) - 1
    for i, ax in enumerate(pos):
        for j, ay in enumerate(pos):
            if (i == 0 and j == 0) or (i == 0 and j == last) or (i == last and j == 0):
                continue
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    setf(ax + dx, ay + dy, max(abs(dx), abs(dy)) != 1)

    def draw_format(mask):
        value = _FORMAT_M << 3 | mask
        rem = value
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        fbits = (value << 10 | rem) ^ 0x5412

        def bit(i):
            return (fbits >> i) & 1
        for i in range(6):
            setf(8, i, bit(i))
        setf(8, 7, bit(6))
        setf(8, 8, bit(7))
        setf(7, 8, bit(8))
        for i in range(9, 15):
            setf(14 - i, 8, bit(i))
        for i in range(8):
            setf(size - 1 - i, 8, bit(i))
        for i in range(8, 15):
            setf(8, size - 15 + i, bit(i))
        setf(8, size - 8, True)

    draw_format(0)  # réserve les emplacements
    if ver >= 7:
        rem = ver
        for _ in range(12):
            rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
        vbits = ver << 12 | rem
        for i in range(18):
            b = (vbits >> i) & 1
            a, c = size - 11 + i % 3, i // 3
            setf(a, c, b)
            setf(c, a, b)

    i = 0
    right = size - 1
    while right >= 1:
        if right == 6:
            right = 5
        for vert in range(size):
            for j in range(2):
                x = right - j
                upward = ((right + 1) & 2) == 0
                y = size - 1 - vert if upward else vert
                if not function[y][x] and i < len(final) * 8:
                    modules[y][x] = bool((final[i >> 3] >> (7 - (i & 7))) & 1)
                    i += 1
        right -= 2

    masks = [
        lambda x, y: (x + y) % 2 == 0,
        lambda x, y: y % 2 == 0,
        lambda x, y: x % 3 == 0,
        lambda x, y: (x + y) % 3 == 0,
        lambda x, y: (x // 3 + y // 2) % 2 == 0,
        lambda x, y: x * y % 2 + x * y % 3 == 0,
        lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
        lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0,
    ]
    base = [row[:] for row in modules]
    best, best_score = None, None
    for m, fn in enumerate(masks):
        for y in range(size):
            for x in range(size):
                modules[y][x] = base[y][x] ^ (not function[y][x] and fn(x, y))
        draw_format(m)
        score = _penalty(modules)
        if best_score is None or score < best_score:
            best, best_score = [row[:] for row in modules], score
    return best


def _penalty(m):
    size = len(m)
    score = 0
    lines = [row for row in m] + [[m[y][x] for y in range(size)] for x in range(size)]
    pattern = [True, False, True, True, True, False, True]
    for line in lines:
        run, prev = 0, None
        for v in line:
            if v == prev:
                run += 1
            else:
                if run >= 5:
                    score += run - 2
                run, prev = 1, v
        if run >= 5:
            score += run - 2
        for i in range(size - 6):
            if line[i:i + 7] == pattern:
                before = line[max(0, i - 4):i]
                after = line[i + 7:i + 11]
                if (len(before) == 4 or i < 4) and not any(before):
                    score += 40
                elif (len(after) == 4 or i + 11 > size) and not any(after):
                    score += 40
    for y in range(size - 1):
        for x in range(size - 1):
            if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                score += 3
    dark = sum(sum(row) for row in m)
    total = size * size
    k = (abs(dark * 20 - total * 10) + total - 1) // total - 1
    return score + max(k, 0) * 10


def qr_svg(text, scale=4, border=4):
    """QR code en SVG : modules noirs sur fond blanc, lisible par tout téléphone."""
    matrix = qr_matrix(text)
    size = len(matrix)
    full = size + 2 * border
    parts = []
    for y, row in enumerate(matrix):
        for x, dark in enumerate(row):
            if dark:
                parts.append("M%d %dh1v1h-1z" % (x + border, y + border))
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d" '
            'shape-rendering="crispEdges"><rect width="100%%" height="100%%" fill="#fff"/>'
            '<path fill="#000" d="%s"/></svg>') % (full, full, full * scale, full * scale, "".join(parts))
