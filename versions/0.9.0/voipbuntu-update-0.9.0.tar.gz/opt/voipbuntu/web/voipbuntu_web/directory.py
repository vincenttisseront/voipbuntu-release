"""Annuaire partagé de VOIPbuntu : contacts (nom, société, numéros), import et export CSV.

L'annuaire est rangé dans pbx.json (clé « directory ») : il est donc validé de
nouveau par voipbuntu-pbx (root) avant d'écrire le plan de numérotation, et il
fait partie des sauvegardes. Le nom d'un contact est présenté sur les postes
(CALLERID(name)) quand il appelle : voir pbx.render_directory().
"""

import csv
import io
import re
import secrets
import unicodedata

MAX_CONTACTS = 1000
MAX_NUMBERS = 4
MAX_CSV = 512 * 1024
KINDS = ("bureau", "mobile", "domicile", "autre")
ID_RE = re.compile(r"^[0-9a-f]{12}$")
# Numéro composable après normalisation : national à 10 chiffres, international 00…, ou numéro court (3949…)
NUMBER_RE = re.compile(r"^(0[1-9][0-9]{8}|00[1-9][0-9]{3,16}|[1-9][0-9]{2,5})$")
CONTROL_RE = re.compile(r"[\x00-\x1f\x7f]")
# Caractères gardés dans le nom présenté sur les postes : rien qui ait un sens dans le plan de numérotation
CALLERID_UNSAFE = re.compile(r"[^\w .'&@/+-]", re.UNICODE)


class DirectoryError(ValueError):
    pass


def new_id():
    return secrets.token_hex(6)


def clean_text(value, limit=80):
    text = CONTROL_RE.sub(" ", str(value or ""))
    return re.sub(r"\s+", " ", unicodedata.normalize("NFC", text)).strip()[:limit]


def normalize_number(raw):
    """Numéro saisi ou importé (« +33 (0)6 12 34 56 78 », « 06.12.34.56.78 ») vers sa forme composable."""
    text = str(raw or "").strip()
    if not text:
        return ""
    text = text.replace("(0)", "")
    plus = text.startswith("+")
    digits = re.sub(r"[\s.\-/()]", "", text.lstrip("+"))
    if not digits.isdigit():
        return None
    if plus:
        digits = "00" + digits
    if digits.startswith("0033"):
        digits = "0" + digits[4:]
    elif digits.startswith("33") and len(digits) == 11:
        digits = "0" + digits[2:]
    return digits if NUMBER_RE.match(digits) else None


def empty():
    return {"contacts": []}


def validate(data):
    """Annuaire complet ; refuse plutôt que de corriger en silence (sauf l'identifiant, créé s'il manque)."""
    if data is None:
        return empty()
    if not isinstance(data, dict):
        raise DirectoryError("annuaire : format invalide")
    contacts = data.get("contacts", [])
    if not isinstance(contacts, list) or len(contacts) > MAX_CONTACTS:
        raise DirectoryError("annuaire : %d contacts au plus" % MAX_CONTACTS)
    out, ids = [], set()
    for c in contacts:
        c = validate_contact(c)
        if c["id"] in ids:
            c["id"] = new_id()
        ids.add(c["id"])
        out.append(c)
    out.sort(key=sort_key)
    return {"contacts": out}


def sort_key(c):
    return (unicodedata.normalize("NFKD", (c["name"] or c["company"]).casefold()), c["id"])


def validate_contact(c):
    if not isinstance(c, dict):
        raise DirectoryError("annuaire : contact invalide")
    name, company = clean_text(c.get("name")), clean_text(c.get("company"))
    if not (name or company):
        raise DirectoryError("annuaire : un contact doit avoir un nom ou une société")
    numbers = c.get("numbers", [])
    if not isinstance(numbers, list) or len(numbers) > MAX_NUMBERS:
        raise DirectoryError("annuaire : %d numéros au plus par contact" % MAX_NUMBERS)
    clean, seen = [], set()
    for n in numbers:
        if not isinstance(n, dict):
            raise DirectoryError("annuaire : numéro invalide")
        kind = str(n.get("kind", "bureau"))
        if kind not in KINDS:
            raise DirectoryError("annuaire : type de numéro invalide")
        number = normalize_number(n.get("number"))
        if number == "":
            continue
        if number is None:
            raise DirectoryError("annuaire : numéro invalide pour %s" % (name or company)[:40])
        if number not in seen:
            seen.add(number)
            clean.append({"kind": kind, "number": number})
    if not clean:
        raise DirectoryError("annuaire : %s n'a aucun numéro" % (name or company)[:40])
    cid = str(c.get("id") or "")
    return {"id": cid if ID_RE.match(cid) else new_id(), "name": name, "company": company, "numbers": clean}


def callerid_name(c):
    """Nom affiché sur les postes : « Nom - Société », 40 caractères au plus, sans caractère spécial."""
    label = c["name"] + (" - " + c["company"] if c["name"] and c["company"] else c["company"] if not c["name"] else "")
    label = re.sub(r"\s+", " ", CALLERID_UNSAFE.sub(" ", label)).strip()
    return label[:40].strip() or "Contact"


def by_number(state):
    """{numéro: contact}, le premier contact gagne quand deux contacts partagent un numéro."""
    out = {}
    for c in (state or empty())["contacts"]:
        for n in c["numbers"]:
            out.setdefault(n["number"], c)
    return out


def search(state, query="", limit=200):
    q = clean_text(query).casefold()
    digits = re.sub(r"\D", "", q)
    out = []
    for c in state["contacts"]:
        if q and q not in (c["name"] + " " + c["company"]).casefold() and not (
                digits and any(digits in n["number"] for n in c["numbers"])):
            continue
        out.append(c)
    return out[:limit], len(out)


# ------------------------------------------------------------------ CSV
# En-têtes reconnus (en minuscules, sans accents) : Outlook français et anglais, Google Contacts, VOIPbuntu
NAME_COLS = ("nom complet", "name", "full name", "display name", "nom a afficher", "nom affiche")
FIRST_COLS = ("prenom", "first name", "given name")
LAST_COLS = ("nom", "last name", "family name", "nom de famille")
COMPANY_COLS = ("societe", "company", "organization 1 - name", "organization name", "entreprise", "organisation")
PHONE_COLS = (
    ("bureau", ("bureau", "telephone (bureau)", "tel. bureau", "business phone", "telephone bureau",
                "telephone professionnel", "work phone")),
    ("bureau", ("telephone (bureau 2)", "business phone 2", "telephone de la societe", "company main phone",
                "telephone principal", "primary phone", "telephone")),
    ("mobile", ("mobile", "tel. mobile", "telephone mobile", "mobile phone", "portable")),
    ("domicile", ("domicile", "telephone (domicile)", "tel. domicile", "home phone", "telephone domicile")),
    ("autre", ("autre", "autre telephone", "other phone", "telephone (autre)")),
)


def fold(text):
    text = unicodedata.normalize("NFKD", str(text or "").strip().strip("﻿").casefold())
    return "".join(ch for ch in text if not unicodedata.combining(ch))


def decode(raw):
    """UTF-8 (avec ou sans BOM), sinon Windows-1252 (export Outlook « ANSI »)."""
    if isinstance(raw, str):
        return raw.lstrip("﻿")
    if raw.startswith(b"\xff\xfe") or raw.startswith(b"\xfe\xff"):
        return raw.decode("utf-16").lstrip("﻿")
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return raw.decode("cp1252", "replace")


def delimiter(text):
    head = text.split("\n", 1)[0]
    counts = {d: head.count(d) for d in (";", ",", "\t")}
    return max(counts, key=lambda d: counts[d]) if any(counts.values()) else ","


def parse_csv(raw):
    """Lit un CSV d'Outlook, de Google Contacts ou de VOIPbuntu ; renvoie (contacts, lignes ignorées)."""
    if len(raw) > MAX_CSV:
        raise DirectoryError("annuaire : fichier CSV trop gros (512 Ko au plus)")
    text = decode(raw)
    reader = csv.reader(io.StringIO(text), delimiter=delimiter(text))
    try:
        header = [fold(h) for h in next(reader)]
    except StopIteration:
        raise DirectoryError("annuaire : fichier CSV vide") from None

    def col(names):
        for name in names:
            if name in header:
                return header.index(name)
        return None

    full, first, last, company = col(NAME_COLS), col(FIRST_COLS), col(LAST_COLS), col(COMPANY_COLS)
    phones = [(kind, i) for kind, names in PHONE_COLS for i in [col(names)] if i is not None]
    # Google Contacts : « Phone 1 - Type », « Phone 1 - Value »…
    for i, h in enumerate(header):
        m = re.match(r"^phone (\d+) - value$", h)
        if m:
            t = col(("phone %s - type" % m.group(1),))
            phones.append((("google", t), i))
    if not phones or (full is None and first is None and last is None and company is None):
        raise DirectoryError("annuaire : colonnes nom et téléphone introuvables dans le CSV")
    contacts, skipped = [], 0
    for row in reader:
        if not any(cell.strip() for cell in row):
            continue

        def cell(i):
            return row[i] if i is not None and i < len(row) else ""

        name = cell(full) if full is not None else ""
        if not name.strip():
            name = " ".join(x for x in (cell(first).strip(), cell(last).strip()) if x)
        numbers = []
        for kind, i in phones:
            if isinstance(kind, tuple):
                label = fold(cell(kind[1]))
                kind = "mobile" if "mobile" in label else "domicile" if "home" in label else "bureau" if "work" in label else "autre"
            for value in re.split(r"\s*:::\s*", cell(i)):
                n = normalize_number(value)
                if n and n not in [x["number"] for x in numbers] and len(numbers) < MAX_NUMBERS:
                    numbers.append({"kind": kind, "number": n})
        try:
            contacts.append(validate_contact({"name": name, "company": cell(company), "numbers": numbers}))
        except DirectoryError:
            skipped += 1
    return contacts, skipped


def merge(state, imported, replace=False):
    """Ajoute les contacts importés ; un contact au même nom et à la même société est mis à jour."""
    current = [] if replace else list(state["contacts"])
    index = {(fold(c["name"]), fold(c["company"])): c for c in current}
    added = updated = 0
    for c in imported:
        key = (fold(c["name"]), fold(c["company"]))
        if key in index:
            old = index[key]
            known = {n["number"] for n in old["numbers"]}
            old["numbers"] = (old["numbers"] + [n for n in c["numbers"] if n["number"] not in known])[:MAX_NUMBERS]
            updated += 1
        else:
            current.append(c)
            index[key] = c
            added += 1
    if len(current) > MAX_CONTACTS:
        raise DirectoryError("annuaire : %d contacts au plus" % MAX_CONTACTS)
    return validate({"contacts": current}), added, updated


def csv_cell(value):
    """Une cellule qui commence par = + - @ serait une formule dans Excel : on la neutralise."""
    value = str(value)
    return "'" + value if value[:1] in ("=", "+", "-", "@") else value


def export_csv(state):
    """CSV pour Excel : UTF-8 avec BOM, séparateur « ; », une colonne par type de numéro."""
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";", lineterminator="\r\n")
    w.writerow(["Nom complet", "Société", "Bureau", "Mobile", "Domicile", "Autre"])
    for c in state["contacts"]:
        cols = {k: [] for k in KINDS}
        for n in c["numbers"]:
            cols[n["kind"]].append(n["number"])
        w.writerow([csv_cell(c["name"]), csv_cell(c["company"])] + [" ::: ".join(cols[k]) for k in KINDS])
    return ("﻿" + buf.getvalue()).encode("utf-8")
