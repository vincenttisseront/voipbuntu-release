"""Serveur HTTP de la console VOIPbuntu (bibliothèque standard uniquement).

Il écoute en local (127.0.0.1:8080) ; nginx assure le TLS devant lui et lui
transmet l'adresse du client dans X-Real-IP.
"""

import argparse
import hmac
import json
import logging
import mimetypes
import os
import re
import sys
import tempfile
import time
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs

from . import alerts, backup, networks, pbx, security, sysinfo
from . import netconf
from . import backupcopy
from . import calllog, directory
from . import totp
from . import provisioning
from . import maintenance
from . import adsync
from . import live
from .db import Database
from .i18n import Translator, LANGUAGES
from .jobs import WorkerClient, WorkerUnavailable, ACTIONS

LOG = logging.getLogger("voipbuntu-web")
COOKIE = "pxb_session"
MAX_BODY = 1024 * 1024  # restauration d'une sauvegarde (200 postes, groupes, renvois)
LOG_SOURCES = ("asterisk", "system")
MAX_IGNORED = 200  # appareils découverts écartés par un administrateur
USERNAME_RE = re.compile(r"^[a-z_][a-z0-9_.-]{0,31}$")
mimetypes.add_type("font/woff2", ".woff2")  # police de la console, quel que soit /etc/mime.types
ROLES = ("admin", "lecture")
# Écritures permises à un compte lecture : uniquement sur son propre compte.
SELF_SERVICE = frozenset(("/api/logout", "/api/password", "/api/account/totp/setup", "/api/account/totp/enable",
                          "/api/account/totp/disable", "/api/account/totp/recovery"))
CSP = ("default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
       "connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
CSP = CSP.replace("font-src 'self';", "font-src 'self'; media-src 'self';")  # écoute des enregistrements (admin)


class ApiError(Exception):
    def __init__(self, status, message, extra=None):
        super().__init__(message)
        self.status = status
        self.message = message
        self.extra = extra or {}


class Context:
    def __init__(self, db, static_dir, version, worker, data_path, trust_proxy, secure_cookie,
                 update_state="/var/lib/voipbuntu/update.json", pbx_state=pbx.DEFAULT_STATE,
                 networks_state=networks.DEFAULT_STATE):
        self.db = db
        self.networks_state = networks_state
        self.pbx_state = pbx_state
        self.appliance_conf = "/etc/voipbuntu/appliance.conf"
        self.backup_dir = backup.DEFAULT_DIR
        self.backup_settings = backup.DEFAULT_SETTINGS
        self.backup_status = "/var/lib/voipbuntu/backup-status.json"
        self.alerts_settings = alerts.DEFAULT_SETTINGS
        self.alerts_state = alerts.DEFAULT_STATE
        self.sounds_dir = pbx.SOUNDS_DIR
        self.capture_request = "/var/lib/voipbuntu/capture-request.json"  # diagnostic SIP (lot I)
        self.maintenance_settings = maintenance.DEFAULT_SETTINGS  # fenêtre de maintenance (lot L)
        self.maintenance_state = maintenance.DEFAULT_STATE
        self.reboot_required = maintenance.REBOOT_REQUIRED
        self.secrets_key = backupcopy.DEFAULT_KEY
        self.sftp_public = backupcopy.SFTP_PUBLIC
        self.update_state = update_state
        self.static_dir = os.path.realpath(static_dir)
        self.version = version
        self.worker = worker
        self.data_path = data_path
        self.trust_proxy = trust_proxy
        self.secure_cookie = secure_cookie
        self.sessions = security.SessionStore(db)
        self.throttle = security.LoginThrottle(db)
        self.translator = Translator(static_dir)
        # Empreinte factice : un identifiant inconnu coûte autant qu'un vrai.
        self.dummy_hash = security.hash_password(security.new_token())


class Handler(BaseHTTPRequestHandler):
    server_version = "VOIPbuntu"
    sys_version = ""
    protocol_version = "HTTP/1.1"
    ctx = None  # renseigné par make_server

    # ------------------------------------------------------------ utilitaires
    def log_message(self, fmt, *args):  # journal sans corps ni cookie
        LOG.info("%s %s", self.remote, fmt % args)

    @property
    def remote(self):
        if self.ctx.trust_proxy:
            real = self.headers.get("X-Real-IP", "")
            if real and len(real) < 64:
                return real
        return self.client_address[0]

    @property
    def lang(self):
        cookie = self.cookies.get("pxb_lang")
        if cookie and cookie.value in LANGUAGES:
            return cookie.value
        accept = self.headers.get("Accept-Language", "")
        return "en" if accept[:2].lower() == "en" else "fr"

    @property
    def cookies(self):
        jar = SimpleCookie()
        try:
            jar.load(self.headers.get("Cookie", ""))
        except Exception:
            pass
        return jar

    def t(self, text):
        return self.ctx.translator.translate(text, self.lang)

    def security_headers(self):
        self.send_header("Content-Security-Policy", CSP)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")

    def send_json(self, status, payload, cookies=()):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for cookie in cookies:
            self.send_header("Set-Cookie", cookie)
        if self.body_unread():
            # Corps non lu (refus avant lecture, compte lecture seule…) : il serait pris pour
            # la requête suivante sur la même connexion, qui est donc fermée.
            self.send_header("Connection", "close")
        self.security_headers()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def session_cookie(self, token, max_age=None):
        parts = ["%s=%s" % (COOKIE, token), "Path=/", "HttpOnly", "SameSite=Strict"]
        if self.ctx.secure_cookie:
            parts.append("Secure")
        if max_age is not None:
            parts.append("Max-Age=%d" % max_age)
        return "; ".join(parts)

    def body_unread(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        return length > 0 and not getattr(self, "body_read", False)

    def read_json(self):
        if getattr(self, "json_cache", None) is not None:  # corps déjà lu (contrôles du lot M avant la route)
            return self.json_cache
        ctype = self.headers.get("Content-Type", "").split(";")[0].strip().lower()
        if ctype != "application/json":
            raise ApiError(HTTPStatus.UNSUPPORTED_MEDIA_TYPE, "Requête invalide.")
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.") from None
        if length < 0 or length > MAX_BODY:
            raise ApiError(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "Requête trop volumineuse.")
        self.body_read = True
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode("utf-8")) if raw else {}
        except (ValueError, UnicodeDecodeError):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.") from None
        if not isinstance(data, dict):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.")
        self.json_cache = data
        return data

    def check_origin(self):
        origin = self.headers.get("Origin")
        if origin is None:
            return
        host = self.headers.get("Host", "")
        if urlsplit(origin).netloc != host:
            raise ApiError(HTTPStatus.FORBIDDEN, "Origine refusée.")

    def current_session(self):
        morsel = self.cookies.get(COOKIE)
        return self.ctx.sessions.get(morsel.value if morsel else None)

    def require_session(self, write=False):
        session = self.current_session()
        if session is None:
            raise ApiError(HTTPStatus.UNAUTHORIZED, "Session expirée, reconnectez-vous.")
        if write:
            self.check_origin()
            token = self.headers.get("X-CSRF-Token", "")
            if not token or not hmac.compare_digest(token, session["csrf"]):
                raise ApiError(HTTPStatus.FORBIDDEN, "Jeton de sécurité invalide, rechargez la page.")
            # Rôle vérifié côté serveur sur chaque écriture : un compte lecture ne garde
            # que son propre mot de passe, sa double authentification et la déconnexion.
            if session.get("role") != "admin" and urlsplit(self.path).path not in SELF_SERVICE:
                raise ApiError(HTTPStatus.FORBIDDEN, "Compte en lecture seule : modification impossible.")
        return session

    def require_admin(self):
        """Lecture de données secrètes (export de sauvegarde) : admin uniquement."""
        session = self.require_session()
        if session.get("role") != "admin":
            raise ApiError(HTTPStatus.FORBIDDEN, "Réservé aux administrateurs.")
        return session

    # ---------------------------------------------------------------- routage
    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        self.dispatch("GET")

    def do_POST(self):
        self.dispatch("POST")

    def do_PUT(self):
        self.dispatch("PUT")

    def do_DELETE(self):
        self.dispatch("DELETE")

    def dispatch(self, method):
        self.body_read = False
        self.json_cache = None
        path = urlsplit(self.path).path
        try:
            if path.startswith("/api/"):
                route = ROUTES.get((method if method != "HEAD" else "GET", path))
                if route is None:
                    raise ApiError(HTTPStatus.NOT_FOUND, "Ressource introuvable.")
                route(self)
            elif method in ("GET", "HEAD"):
                self.serve_static(path)
            else:
                raise ApiError(HTTPStatus.METHOD_NOT_ALLOWED, "Méthode non autorisée.")
        except ApiError as exc:
            payload = {"error": self.t(exc.message)}
            payload.update(exc.extra)
            self.send_json(exc.status, payload)
        except Exception:
            LOG.exception("erreur interne sur %s %s", method, path)
            self.send_json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": self.t("Erreur interne.")})

    def serve_static(self, path):
        if path in ("/", ""):
            path = "/index.html"
        path = STATIC_PAGES.get(path, path)  # pages sans extension (panneau mural)
        relative = os.path.normpath(path.lstrip("/"))
        full = os.path.realpath(os.path.join(self.ctx.static_dir, relative))
        if not full.startswith(self.ctx.static_dir + os.sep) or not os.path.isfile(full):
            raise ApiError(HTTPStatus.NOT_FOUND, "Ressource introuvable.")
        ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript", "application/json"):
            ctype += "; charset=utf-8"
        with open(full, "rb") as handle:
            body = handle.read()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.security_headers()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    # ------------------------------------------------------------------- API
    def api_login(self):
        self.check_origin()
        data = self.read_json()
        username = data.get("username")
        password = data.get("password")
        ad = self.ad_login_settings()
        if ad and isinstance(username, str):
            username = self.ad_local_name(ad, username)  # DOMAINE\nom ou nom@domaine
        if not isinstance(username, str) or not isinstance(password, str) or not USERNAME_RE.match(username) \
                or len(password) > 256:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Identifiant ou mot de passe incorrect.")
        keys = ["ip:" + self.remote, "user:" + username]
        wait = self.ctx.throttle.locked_for(keys)
        if wait:
            raise ApiError(HTTPStatus.TOO_MANY_REQUESTS, "Trop de tentatives, réessayez plus tard.", {"retry": wait})
        user = self.ctx.db.get_account(username)
        if ad and (user is None or user.get("source") == "ad"):
            return self.login_ad(ad, username, password, keys, user)  # compte local : jamais l'AD
        stored = user["password_hash"] if user else self.ctx.dummy_hash
        if not security.verify_password(password, stored) or user is None or user["disabled"]:
            self.ctx.throttle.failure(keys)
            self.ctx.db.audit("login-failed", username, self.remote)
            raise ApiError(HTTPStatus.UNAUTHORIZED, "Identifiant ou mot de passe incorrect.")
        if user["totp_secret"]:
            # Deuxième étape : le mot de passe seul n'ouvre pas de session.
            self.send_json(HTTPStatus.OK, {"totp_required": True, "ticket": self.login_ticket(username)})
            return
        self.login_done(username, keys)

    def login_done(self, username, keys, event="login"):
        self.ctx.throttle.success(keys)
        self.ctx.db.update_account(username, last_login=time.time())
        token, csrf = self.ctx.sessions.create(username)
        self.ctx.db.audit(event, username, self.remote)
        self.send_json(HTTPStatus.OK, {"user": username, "csrf": csrf}, [self.session_cookie(token)])

    def api_logout(self):
        session = self.require_session(write=True)
        morsel = self.cookies.get(COOKIE)
        self.ctx.sessions.delete(morsel.value if morsel else "")
        self.ctx.db.audit("logout", session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True}, [self.session_cookie("", max_age=0)])

    def api_session(self):
        session = self.current_session()
        payload = {"version": self.ctx.version, "lang": self.lang, "configured": self.ctx.db.has_users()}
        if session:
            payload.update({"user": session["username"], "csrf": session["csrf"], "role": session["role"]})
        self.send_json(HTTPStatus.OK, payload)

    def api_status(self):
        self.require_session()
        payload = sysinfo.status(self.ctx.version, self.ctx.data_path)
        payload["services"] = sysinfo.service_states()
        self.send_json(HTTPStatus.OK, payload)

    def api_metrics(self):
        self.require_session()
        query = parse_qs(urlsplit(self.path).query)
        range_name = (query.get("range") or ["1h"])[0]
        if range_name not in sysinfo.RANGES:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Période inconnue.")
        self.send_json(HTTPStatus.OK, sysinfo.series(self.ctx.db, range_name))

    def api_password(self):
        session = self.require_session(write=True)
        data = self.read_json()
        current, new = data.get("current"), data.get("new")
        if not isinstance(current, str) or not isinstance(new, str):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.")
        user = self.ctx.db.get_user(session["username"])
        if user is None or not security.verify_password(current, user[1]):
            self.ctx.db.audit("password-change-failed", session["username"], self.remote)
            raise ApiError(HTTPStatus.FORBIDDEN, "Mot de passe actuel incorrect.")
        problem = security.password_problem(new)
        if problem:
            raise ApiError(HTTPStatus.BAD_REQUEST, problem)
        self.ctx.db.set_password(session["username"], security.hash_password(new))
        self.ctx.sessions.delete_user(session["username"])
        token, csrf = self.ctx.sessions.create(session["username"])
        self.ctx.db.audit("password-changed", session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "csrf": csrf}, [self.session_cookie(token)])

    def api_update(self):
        self.require_session()
        state = {}
        try:
            with open(self.ctx.update_state, "r", encoding="utf-8") as handle:
                state = json.load(handle)
        except (OSError, ValueError):
            state = {}
        if not isinstance(state, dict):
            state = {}
        version_re = re.compile(r"^\d+\.\d+\.\d+$")
        latest = state.get("latest") if isinstance(state.get("latest"), str) and version_re.match(state["latest"]) else None
        checked = state.get("checked") if isinstance(state.get("checked"), (int, float)) else None
        error = state.get("error") if isinstance(state.get("error"), str) else None
        notes = state.get("notes") if isinstance(state.get("notes"), str) else ""
        self.send_json(HTTPStatus.OK, {
            "current": self.ctx.version, "latest": latest, "checked": checked,
            "available": bool(latest) and _vtuple(latest) > _vtuple(self.ctx.version),
            "notes": notes[:4000], "error": error[:300] if error else None})

    # ------------------------------------------------------------ téléphonie
    def pbx_load(self):
        try:
            return pbx.load(self.ctx.pbx_state)
        except pbx.PbxError:
            raise ApiError(HTTPStatus.INTERNAL_SERVER_ERROR, "Configuration téléphonique illisible.") from None

    def pbx_commit(self, state, username, event):
        try:
            pbx.save(state, self.ctx.pbx_state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        self.ctx.db.audit(event, username, self.remote)
        try:
            self.ctx.worker.submit("pbx-apply", username)
            return True
        except WorkerUnavailable:
            return False

    def api_pbx(self):
        self.require_session()
        state = self.pbx_load()
        try:
            live = self.ctx.worker.pbx_status()
        except WorkerUnavailable:
            live = {"running": None, "contacts": {}}
        contacts = live.get("contacts") if isinstance(live.get("contacts"), dict) else {}
        view = pbx.public(state)
        phone_nets = pbx.read_phone_nets(self.ctx.appliance_conf)
        labels = self.networks_load()
        registered_users = set()
        for ext in view["extensions"]:
            c = contacts.get(ext["sip_user"]) or {}
            ext["registered"] = c.get("status") in ("Avail", "NonQual", "Created")
            ext["address"] = c.get("address")
            ext["rtt"] = c.get("rtt")
            ext["user_agent"] = str(c.get("user_agent") or "")[:80]
            ext["network"] = pbx.network_of(c.get("address"), phone_nets) if c else None
            ext["network_label"] = networks.label_for(ext["network"], labels) if ext["network"] else ""
            if ext["registered"]:
                registered_users.add(ext["sip_user"].lower())
            # Combiné DECT pris pour un téléphone SIP : modèle de base reconnu ou adresse d'une base déclarée
            dev = pbx.guess_device(ext["user_agent"])
            ext["looks_dect"] = ext["kind"] != "dect" and bool(
                dev.get("dect") or (ext["address"] and pbx.base_at(state, ext["address"])))
        known = {e["sip_user"].lower(): e["number"] for e in view["extensions"]}
        ignored = self.discovery_ignored()
        attempts = []
        for a in live.get("attempts") if isinstance(live.get("attempts"), list) else []:
            if not isinstance(a, dict) or not pbx.SIP_ID_RE.match(str(a.get("user", ""))):
                continue
            user = str(a["user"])
            if user.lower() in registered_users:
                continue  # appareil configuré depuis : plus rien à faire
            address = str(a.get("address", ""))[:45]
            net = pbx.network_of(address, phone_nets)
            reason = "auth" if user.lower() in known else "unknown"
            agent = re.sub(r"[\x00-\x1f\x7f]", "", str(a.get("user_agent") or ""))[:80]
            mac = str(a.get("mac") or "").lower()
            methods = [m for m in a.get("methods", []) if m in pbx.SIP_METHODS] if isinstance(a.get("methods"), list) else []
            item = {"user": user, "address": address,
                    "count": int(a.get("count", 0)) if str(a.get("count", "")).isdigit() else 0,
                    "last": str(a.get("last", ""))[:19], "extension": known.get(user.lower()),
                    "reason": reason, "methods": methods, "user_agent": agent,
                    "mac": mac if re.match(r"^([0-9a-f]{2}:){5}[0-9a-f]{2}$", mac) else "",
                    "suspect": a.get("suspect") is True, "ignored": (user.lower(), address) in ignored,
                    "network": net, "network_label": networks.label_for(net, labels) if net else ""}
            # Proposé à l'ajout : inconnu, depuis un réseau des téléphones, pas un balayage, pas écarté.
            # Jamais créé sans l'action d'un administrateur.
            item["proposable"] = reason == "unknown" and bool(net) and not item["suspect"] and not item["ignored"]
            base = pbx.base_at(state, address)
            item["base"] = base["id"] if base else ""
            device = pbx.guess_device(agent)
            # Une base DECT n'a pas de numéro : ses OPTIONS seules (maintien de connexion) viennent de la base
            # elle-même, jamais d'un combiné. Seuls REGISTER ou INVITE viennent d'un compte de combiné.
            item["base_itself"] = (bool(base) or bool(device.get("dect"))) and bool(methods) and set(methods) <= {"OPTIONS"}
            if item["base_itself"] and base:
                item["proposable"] = False  # base déjà déclarée : rien à créer
            if item["proposable"]:
                item["device"] = device
                item["suggested_number"] = pbx.suggest_number(state, user)
                item["suggested_kind"] = ("base" if item["base_itself"] else
                                          "dect" if base or device.get("dect") else "sip")
            # Plusieurs identifiants depuis une adresse des téléphones : peut-être une base DECT à déclarer
            item["base_candidate"] = item["suspect"] and bool(net) and not base
            attempts.append(item)
        attempts.sort(key=lambda x: not x["proposable"])  # nouveaux appareils d'abord, ordre récent conservé
        view["attempts"] = attempts[:50]
        view["trunk"]["state"] = live.get("trunk") if live.get("trunk") in ("registered", "unregistered", "rejected") else None
        view["running"] = live.get("running")
        view["calls"] = live.get("calls") if isinstance(live.get("calls"), int) else None
        view["next_number"] = pbx.suggest_number(state)  # premier numéro libre (combinés à ajouter)
        for b in view["dect_bases"]:  # combinés rattachés et enregistrés, adresse vue d'Asterisk
            mine = [e for e in view["extensions"] if e["base"] == b["id"]]
            b["handsets"] = len(mine)
            b["registered"] = sum(1 for e in mine if e["registered"])
            b["seen_at"] = sorted({pbx.host_of(e["address"]) for e in mine if e["registered"] and e["address"]})[:3]
        dnd = {str(n) for n in live.get("dnd")} if isinstance(live.get("dnd"), list) else set()
        for ext in view["extensions"]:  # ne pas déranger (*76), lu dans Asterisk
            ext["dnd"] = ext["number"] in dnd
        self.send_json(HTTPStatus.OK, view)

    def api_pbx_calls(self):
        """Journal des appels : filtres ?ext=&direction=&status=&from=&to=, export CSV avec ?format=csv."""
        session = self.require_session()
        query = parse_qs(urlsplit(self.path).query)
        try:
            filters = calllog.parse_filters(query)
        except ValueError:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Filtre du journal invalide.") from None
        calls, error = self.calls_load()
        calls = calllog.apply_filters(calls, filters)
        if (query.get("format") or [""])[0] == "csv":
            self.send_file(calllog.export_csv(calls, self.lang), "text/csv; charset=utf-8",
                           "voipbuntu-appels-%s.csv" % time.strftime("%Y%m%d-%H%M"))
            self.ctx.db.audit("calls:export", session["username"], self.remote)
            return
        self.send_json(HTTPStatus.OK, {"calls": calls[:500], "total": len(calls), "error": error})

    def api_logs(self):
        self.require_session()
        source = (parse_qs(urlsplit(self.path).query).get("source") or ["asterisk"])[0]
        if source not in LOG_SOURCES:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Journal inconnu.")
        try:
            data = self.ctx.worker.logs(source)
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None
        lines = data.get("lines") if isinstance(data.get("lines"), list) else []
        self.send_json(HTTPStatus.OK, {"source": source, "lines": [str(x)[:500] for x in lines[-200:]],
                                       "error": bool(data.get("error"))})

    # ------------------------------------------------------------ sauvegarde
    def api_backup(self):
        session = self.require_admin()  # mots de passe SIP en clair dans l'export
        state = self.pbx_load()
        payload = backup.payload(state, self.networks_load(), self.ctx.version)
        self.send_backup(payload, "voipbuntu-sauvegarde-%s.json" % time.strftime("%Y%m%d-%H%M"))
        self.ctx.db.audit("backup:export", session["username"], self.remote)

    def send_backup(self, payload, filename):
        body = json.dumps(payload, ensure_ascii=False, indent=1).encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Disposition", 'attachment; filename="%s"' % filename)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.security_headers()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def api_restore(self):
        session = self.require_session(write=True)
        ctype = self.headers.get("Content-Type", "").split(";")[0].strip().lower()
        if ctype in ARCHIVE_TYPES:  # archive .tar.gz (0.9) : jusqu'à 50 Mo
            self.restore_raw(self.read_archive_body(), session, "backup:restore")
            return
        self.restore(self.read_json(), session, "backup:restore")

    def restore(self, data, session, event):
        try:
            state, nets = backup.read_payload(data)
        except backup.BackupError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, str(exc)) from None
        if nets is not None:
            networks.save(nets, self.ctx.networks_state)
        applied = self.pbx_commit(state, session["username"], event)
        if nets is not None and applied:
            try:
                self.ctx.worker.submit("networks-apply", session["username"])
            except WorkerUnavailable:
                applied = False
        self.send_json(HTTPStatus.OK, {"ok": True, "extensions": len(state["extensions"]), "applied": applied,
                                       "networks": None if nets is None else len(nets["networks"])})

    def api_backups(self):
        self.require_session()
        try:
            with open(self.ctx.backup_status, encoding="utf-8") as h:
                status = json.load(h)
            status = {k: status.get(k) for k in ("last_run", "ok", "message", "file", "mail_failed", "copy_failed")} if isinstance(status, dict) else None
        except (OSError, ValueError):
            status = None
        self.send_json(HTTPStatus.OK, {"settings": backup.load_settings(self.ctx.backup_settings), "status": status,
                                       "backups": backup.listing(self.ctx.backup_dir)})

    def api_backups_settings(self):
        session = self.require_session(write=True)
        try:
            settings = backup.save_settings(self.read_json(), self.ctx.backup_settings)
        except backup.BackupError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, str(exc)) from None
        self.ctx.db.audit("backup:settings:%s" % ("on" if settings["enabled"] else "off"), session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "settings": settings})

    def api_backups_file(self):
        session = self.require_admin()  # mots de passe SIP en clair dans l'export
        name = (parse_qs(urlsplit(self.path).query).get("name") or [""])[0]
        try:
            if name.endswith(".tar.gz"):
                raw = backup.read_bytes(name, self.ctx.backup_dir)
            else:
                data = backup.read_file(name, self.ctx.backup_dir)
        except backup.BackupError as exc:
            raise ApiError(HTTPStatus.NOT_FOUND, str(exc)) from None
        if name.endswith(".tar.gz"):
            self.send_archive(raw, name)
        else:
            self.send_backup(data, name)
        self.ctx.db.audit("backup:download:" + name, session["username"], self.remote)

    def api_backups_restore(self):
        session = self.require_session(write=True)
        body = self.read_json()
        name = str(body.get("name", ""))
        try:
            if name.endswith(".tar.gz"):
                raw = backup.read_bytes(name, self.ctx.backup_dir)
            else:
                data = backup.read_file(name, self.ctx.backup_dir)
        except backup.BackupError as exc:
            raise ApiError(HTTPStatus.NOT_FOUND, str(exc)) from None
        if name.endswith(".tar.gz"):
            self.restore_raw(raw, session, "backup:restore:" + name, bool(body.get("network")))
        else:
            self.restore(data, session, "backup:restore:" + name)

    # ------------------------------------------------ sauvegardes complètes (format 2)
    def read_archive_body(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.") from None
        if length > backup.MAX_ARCHIVE:
            self.close_connection = True  # corps non lu : la connexion ne peut pas resservir
            raise ApiError(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "Sauvegarde trop volumineuse (50 Mo au plus).")
        if length <= 0:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Fichier vide.")
        raw = self.rfile.read(length)
        if len(raw) != length:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.")
        return raw

    def send_archive(self, raw, filename):
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "application/gzip")
        self.send_header("Content-Disposition", 'attachment; filename="%s"' % filename)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.security_headers()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(raw)

    def copy_paths(self):
        base = os.path.dirname(os.path.abspath(self.ctx.backup_settings))
        return {"settings": os.path.join(base, "backup-copy.json"), "status": os.path.join(base, "backup-copy-status.json"),
                "pending": os.path.join(base, "restore", "pending.tar.gz"), "alerts": self.ctx.alerts_settings}

    def api_backups_archive(self):
        """Archive complète construite à la demande (sans les messages vocaux, illisibles par la console)."""
        session = self.require_admin()  # mots de passe SIP en clair dans l'archive
        try:
            net = self.netconf_stored(self.netconf_files())
            raw, _ = backup.build_archive({
                "pbx": self.pbx_load(), "networks": self.networks_load(), "version": self.ctx.version,
                "alerts": alerts.load_settings(self.ctx.alerts_settings), "netconf": net,
                "settings": backup.load_settings(self.ctx.backup_settings),
                "copy": backupcopy.for_backup(backupcopy.load(self.copy_paths()["settings"]))}, self.ctx.sounds_dir)
        except backup.BackupError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, str(exc)) from None
        self.send_archive(raw, "voipbuntu-sauvegarde-%s.tar.gz" % time.strftime("%Y%m%d-%H%M"))
        self.ctx.db.audit("backup:export:archive", session["username"], self.remote)

    def restore_raw(self, raw, session, event, with_network=None):
        if with_network is None:
            with_network = (parse_qs(urlsplit(self.path).query).get("network") or [""])[0] == "1"
        try:
            parsed = backup.load_any(raw)
        except backup.BackupError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, str(exc)) from None
        if not parsed["archive"]:
            self.restore(parsed["manifest"], session, event)
            return
        state, nets = parsed["pbx"], parsed["networks"]
        user, paths = session["username"], self.copy_paths()
        # Fichiers de l'archive d'abord : la configuration n'est remplacée que si tout a pu être déposé
        drops = {name: parsed["sounds"].get(name) for name in pbx.SOUNDS}
        if parsed["has_voicemail"]:
            os.makedirs(os.path.dirname(paths["pending"]), mode=0o700, exist_ok=True)
            backup.write_bytes(paths["pending"], raw)
        for name, data in drops.items():
            self.sound_drop(name, ".upload" if data is not None else ".delete", data)
        if nets is not None:
            networks.save(nets, self.ctx.networks_state)
        applied = self.pbx_commit(state, user, event)
        result = {"ok": True, "extensions": len(state["extensions"]), "applied": applied,
                  "networks": None if nets is None else len(nets["networks"]), "archive": True,
                  "sounds": len(parsed["sounds"]), "voicemail": len(parsed["voicemail"]) if parsed["has_voicemail"] else None,
                  "network": "absent", "copy_password": False, "version": str(parsed["manifest"].get("version", ""))[:20]}
        if isinstance(parsed["alerts"], dict):
            try:
                alerts.save_settings(parsed["alerts"], self.ctx.alerts_settings)
                result["alerts"] = True
            except alerts.AlertError:
                result["alerts"] = False
        if isinstance(parsed["settings"], dict):
            try:
                backup.save_settings(parsed["settings"], self.ctx.backup_settings)
            except backup.BackupError:
                pass
        if isinstance(parsed["copy"], dict):
            current = backupcopy.load(paths["settings"])
            restored, need = backupcopy.restore(parsed["copy"], current)
            backupcopy.save(restored, paths["settings"])
            result["copy_password"] = need
        if isinstance(parsed["netconf"], dict):
            result["network"] = self.restore_netconf(parsed["netconf"], user) if with_network else "skipped"
        jobs = ["sounds-apply"] + (["networks-apply"] if nets is not None else []) + \
            (["voicemail-restore"] if parsed["has_voicemail"] else []) + (["network-apply"] if result["network"] == "restored" else [])
        for job in jobs:
            try:
                self.ctx.worker.submit(job, user)
            except WorkerUnavailable:
                result["applied"] = False
        self.ctx.db.audit(("%s:sons=%d:messagerie=%s:reseau=%s" % (event, result["sounds"], result["voicemail"],
                                                                      result["network"]))[:200], user, self.remote)
        self.send_json(HTTPStatus.OK, result)

    def restore_netconf(self, saved, user):
        """Réseau et système de l'appliance : seulement si l'interface existe ici, avec confirmation habituelle."""
        files = self.netconf_files()
        if self.netconf_pending(netconf.read_status(files["status"])):
            return "pending"
        try:
            state = netconf.validate(saved)
        except netconf.NetconfError:
            return "invalid"
        if state["network"] and state["network"]["interface"] not in [i["name"] for i in netconf.live()["interfaces"]]:
            state["network"] = None  # autre matériel : on garde le réseau actuel, le reste est restauré
        netconf.save(state, files["state"])
        return "restored"

    def api_backups_copy(self):
        self.require_session()
        paths = self.copy_paths()
        try:
            status = json.loads(backup.read_regular(paths["status"], 65536).decode("utf-8"))
            status = {k: status.get(k) for k in ("last_run", "ok", "message", "kind", "mode", "fingerprints")}
        except (AttributeError, ValueError, UnicodeDecodeError):
            status = None
        pub = backup.read_regular(self.ctx.sftp_public, 4096)
        self.send_json(HTTPStatus.OK, {"settings": backupcopy.public(backupcopy.load(paths["settings"])), "status": status,
                                       "sftp_public_key": pub.decode("ascii", "replace").strip() if pub else ""})

    def api_backups_copy_save(self):
        session = self.require_session(write=True)
        path = self.copy_paths()["settings"]
        try:
            settings = backupcopy.validate(self.read_json(), backupcopy.load(path), self.ctx.secrets_key)
        except backupcopy.CopyError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, str(exc)) from None
        backupcopy.save(settings, path)
        target = {"smb": lambda s: "//%s/%s/%s" % (s["smb"]["server"], s["smb"]["share"], s["smb"]["folder"]),
                  "sftp": lambda s: "%s@%s:%d" % (s["sftp"]["username"], s["sftp"]["host"], s["sftp"]["port"]),
                  "none": lambda s: "aucune"}[settings["mode"]](settings)
        self.ctx.db.audit(("backup:copy:%s:%s:garder=%d" % (settings["mode"], target, settings["keep"]))[:200],
                          session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "settings": backupcopy.public(settings)})

    def api_pbx_create(self):
        session = self.require_session(write=True)
        data = self.read_json()
        number, name = str(data.get("number", "")).strip(), str(data.get("name", "")).strip()
        if not pbx.NUMBER_RE.match(number):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Numéro invalide : de 2 à 6 chiffres, sans 0 en tête.")
        if not pbx.NAME_RE.match(name):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Nom invalide : 1 à 40 caractères, sans guillemets ni crochets.")
        state = self.pbx_load()
        if any(e["number"] == number for e in state["extensions"] + state["groups"]):
            raise ApiError(HTTPStatus.CONFLICT, "Ce numéro existe déjà.")
        if len(state["extensions"]) >= pbx.MAX_EXTENSIONS:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Nombre maximal de postes atteint.")
        if number in pbx.EMERGENCY:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Ce numéro est réservé aux urgences.")
        sip_user = str(data.get("sip_user") or "").strip() or number
        self.check_sip_user(state, sip_user)
        email = self.check_email(data.get("email"))
        kind, base = self.check_kind(state, data)
        ext = {"number": number, "name": name, "sip_user": sip_user, "secret": pbx.new_secret(),
               "pin": pbx.new_pin(), "voicemail": bool(data.get("voicemail", True)), "email": email,
               "kind": kind, "base": base}
        state["extensions"].append(ext)
        applied = self.pbx_commit(state, session["username"], "pbx:create:" + number)
        self.send_json(HTTPStatus.CREATED, dict(self.sheet(ext), applied=applied))

    def check_kind(self, state, data, ext=None):
        """Type de poste (téléphone SIP, combiné DECT, logiciel) et base DECT de rattachement."""
        kind = str(data.get("kind") or (ext or {}).get("kind") or "sip")
        if kind not in pbx.KINDS:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Type de poste invalide.")
        base = str(data.get("base", (ext or {}).get("base", "")) or "") if kind == "dect" else ""
        if base and not any(b["id"] == base for b in state.get("dect_bases", [])):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Base DECT inconnue.")
        return kind, base

    def check_email(self, value):
        email = str(value or "").strip()
        if email and (len(email) > 254 or not pbx.EMAIL_RE.match(email)):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Adresse e-mail invalide.")
        return email

    def check_sip_user(self, state, sip_user, keep=None):
        if not pbx.SIP_ID_RE.match(sip_user) or sip_user.lower() in pbx.RESERVED_IDS:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Identifiant SIP invalide : lettres, chiffres, point, tiret, 32 caractères au plus.")
        if any(e["sip_user"].lower() == sip_user.lower() and e["number"] != keep for e in state["extensions"]):
            raise ApiError(HTTPStatus.CONFLICT, "Cet identifiant SIP est déjà utilisé par un autre poste.")

    def api_pbx_update(self):
        """Modifie un poste : numéro court, nom, messagerie. Identifiant et mot de passe SIP inchangés."""
        session = self.require_session(write=True)
        data = self.read_json()
        current = str(data.get("number", ""))
        state = self.pbx_load()
        ext = next((e for e in state["extensions"] if e["number"] == current), None)
        if ext is None:
            raise ApiError(HTTPStatus.NOT_FOUND, "Poste introuvable.")
        new_number = str(data.get("new_number", current)).strip()
        name = str(data.get("name", ext["name"])).strip()
        if not pbx.NUMBER_RE.match(new_number):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Numéro invalide : de 2 à 6 chiffres, sans 0 en tête.")
        if new_number in pbx.EMERGENCY:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Ce numéro est réservé aux urgences.")
        if not pbx.NAME_RE.match(name):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Nom invalide : 1 à 40 caractères, sans guillemets ni crochets.")
        if new_number != current and any(e["number"] == new_number for e in state["extensions"] + state["groups"]):
            raise ApiError(HTTPStatus.CONFLICT, "Ce numéro existe déjà.")
        ext["number"], ext["name"] = new_number, name
        if "voicemail" in data:
            ext["voicemail"] = bool(data["voicemail"])
        if "email" in data:
            ext["email"] = self.check_email(data["email"])
        if "kind" in data or "base" in data:
            ext["kind"], ext["base"] = self.check_kind(state, data, ext)
        pbx.rename_number(state, current, new_number)
        if not ext["voicemail"]:
            pbx.drop_voicemail(state, new_number)
        event = "pbx:update:%s" % current + ("->%s" % new_number if new_number != current else "")
        applied = self.pbx_commit(state, session["username"], event)
        self.send_json(HTTPStatus.OK, {"ok": True, "number": new_number, "sip_user": ext["sip_user"], "applied": applied})

    def api_pbx_trunk(self):
        """Ligne de l'opérateur. Un mot de passe vide conserve celui déjà enregistré."""
        session = self.require_session(write=True)
        data = self.read_json()
        state = self.pbx_load()
        fields = ("enabled", "host", "port", "username", "auth_username", "password", "register",
                  "caller_id", "public_address", "international")
        trunk = {k: data[k] for k in fields if k in data}
        if not trunk.get("password"):
            trunk["password"] = state["trunk"]["password"]
        state["trunk"] = trunk
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        applied = self.pbx_commit(state, session["username"],
                                  "pbx:trunk:%s" % ("on" if state["trunk"]["enabled"] else "off"))
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "trunk": pbx.public(state)["trunk"]})

    def api_pbx_reception(self):
        session = self.require_session(write=True)
        data = self.read_json()
        state = self.pbx_load()
        state["reception"] = {k: data.get(k) for k in ("members", "ring_seconds", "hours", "voicemail_box")}
        if state["reception"]["ring_seconds"] is None:
            state["reception"]["ring_seconds"] = 25
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        applied = self.pbx_commit(state, session["username"], "pbx:reception")
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "reception": state["reception"]})

    def api_pbx_mail(self):
        """Serveur d'envoi des messages vocaux. Un mot de passe vide conserve celui déjà enregistré."""
        session = self.require_session(write=True)
        data = self.read_json()
        state = self.pbx_load()
        mail = {k: data[k] for k in ("enabled", "host", "port", "security", "username", "password", "from_address") if k in data}
        if not mail.get("password") and mail.get("username") and mail.get("username") == state["mail"]["username"]:
            mail["password"] = state["mail"]["password"]
        state["mail"] = mail
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        applied = self.pbx_commit(state, session["username"], "pbx:mail:%s" % ("on" if state["mail"]["enabled"] else "off"))
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "mail": pbx.public(state)["mail"]})

    def api_pbx_groups(self):
        """Groupes d'appel : la liste complète est remplacée. Les renvois vers un groupe retiré sont coupés."""
        session = self.require_session(write=True)
        data = self.read_json()
        groups = data.get("groups")
        if not isinstance(groups, list):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Liste de groupes invalide.")
        state = self.pbx_load()
        kept = {str(g.get("number", "")) for g in groups if isinstance(g, dict)}
        for g in state["groups"]:
            if g["number"] not in kept:
                pbx.drop_number(state, g["number"])
        state["groups"] = groups
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        applied = self.pbx_commit(state, session["username"], "pbx:groups:%d" % len(state["groups"]))
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "groups": state["groups"]})

    def api_pbx_forward(self):
        session = self.require_session(write=True)
        data = self.read_json()
        number = str(data.get("number", ""))
        state = self.pbx_load()
        ext = next((e for e in state["extensions"] if e["number"] == number), None)
        if ext is None:
            raise ApiError(HTTPStatus.NOT_FOUND, "Poste introuvable.")
        ext["forward"] = {k: data.get(k) for k in ("mode", "target", "ring_seconds")}
        if ext["forward"]["ring_seconds"] is None:
            ext["forward"]["ring_seconds"] = 20
        if ext["forward"]["target"] is None:
            ext["forward"]["target"] = ""
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        fwd = next(e for e in state["extensions"] if e["number"] == number)["forward"]
        applied = self.pbx_commit(state, session["username"], "pbx:forward:%s:%s" % (number, fwd["mode"]))
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "forward": fwd})

    PBX_MESSAGES = (
        # Bases DECT
        ("bases DECT : nom", "Nom de base invalide : 1 à 40 caractères, sans guillemets ni crochets."),
        ("bases DECT : modèle", "Modèle de base invalide : 40 caractères au plus, sans guillemets ni crochets."),
        ("bases DECT : adresse IP", "Adresse IP de la base invalide."),
        ("bases DECT : adresse en double", "Une autre base DECT a déjà cette adresse IP."),
        ("bases DECT : adresse MAC", "Adresse MAC de la base invalide."),
        ("bases DECT :", "Base DECT invalide."),
        ("type de poste", "Type de poste invalide."),
        ("base DECT inconnue", "Base DECT inconnue."),
        # Files d'attente et enregistrement des appels
        ("files : numéro invalide", "Numéro de file invalide : de 2 à 6 chiffres, sans 0 en tête, hors numéros d'urgence."),
        ("files : le numéro", "Ce numéro de file est déjà pris par un poste, un groupe ou une autre file."),
        ("files : nom", "Nom de file invalide : 1 à 40 caractères, sans guillemets ni crochets."),
        ("files : la file", "Une file doit contenir au moins un poste."),
        ("files : poste", "Poste inconnu dans la file."),
        ("files : stratégie", "Stratégie de sonnerie invalide."),
        ("files : sonnerie", "Sonnerie de chaque poste entre 5 et 60 secondes."),
        ("files : attente", "Attente maximale entre 10 secondes et 30 minutes."),
        ("files : débordement", "Destination de débordement invalide : un poste, un groupe ou une messagerie."),
        ("files : liste", "Dix files au plus."),
        ("files :", "File d'attente invalide."),
        ("enregistrement : durée", "Durée de conservation entre 1 et 365 jours."),
        ("ligne opérateur : serveur invalide", "Serveur SIP invalide : nom de domaine ou adresse IP."),
        ("ligne opérateur : port invalide", "Port invalide (1 à 65535)."),
        ("ligne opérateur : identifiant invalide", "Identifiant de la ligne invalide."),
        ("ligne opérateur : mot de passe invalide", "Mot de passe de la ligne invalide : espaces, guillemets, points-virgules, crochets, dièses et barres obliques inverses refusés."),
        ("ligne opérateur : numéro présenté invalide", "Numéro présenté invalide (chiffres, + en tête possible)."),
        ("ligne opérateur : adresse publique", "Adresse IP publique invalide (IPv4)."),
        ("ligne opérateur : serveur, identifiant et mot de passe", "Serveur, identifiant et mot de passe sont requis pour activer la ligne."),
        ("porte un numéro d'urgence", "Un poste porte un numéro d'urgence : renumérotez-le avant d'activer la ligne."),
        ("accueil : durée de sonnerie", "Durée de sonnerie entre 5 et 120 secondes."),
        ("accueil : la messagerie de secours", "La messagerie de secours doit être celle d'un poste qui en a une."),
        ("accueil : jours", "Choisissez au moins un jour d'ouverture."),
        ("accueil : horaires", "Horaires invalides : HH:MM, ouverture avant fermeture."),
        ("accueil : poste", "Poste inconnu dans l'accueil."),
        ("groupes : numéro invalide", "Numéro de groupe invalide : de 2 à 6 chiffres, sans 0 en tête, hors numéros d'urgence."),
        ("groupes : le numéro", "Ce numéro de groupe est déjà pris par un poste ou un autre groupe."),
        ("groupes : nom", "Nom de groupe invalide : 1 à 40 caractères, sans guillemets ni crochets."),
        ("aucun poste", "Un groupe doit contenir au moins un poste."),
        ("groupes : durée de sonnerie", "Durée de sonnerie entre 5 et 120 secondes."),
        ("groupes : la messagerie de secours", "La messagerie de secours doit être celle d'un poste qui en a une."),
        ("groupes : poste", "Poste inconnu dans le groupe."),
        ("groupes : liste", "Vingt groupes au plus."),
        ("renvoi : boucle", "Ces renvois permanents forment une boucle : un poste renvoie vers un autre qui renvoie vers le premier."),
        ("vers lui-même", "Un poste ne peut pas se renvoyer vers lui-même."),
        ("demande la ligne", "Un renvoi vers un numéro extérieur demande la ligne de l'opérateur : désactivez d'abord ce renvoi, ou activez la ligne."),
        ("international non autorisé", "Renvoi vers l'international : autorisez d'abord l'international sur la ligne."),
        ("renvoi : durée", "Durée de sonnerie avant renvoi entre 5 et 120 secondes."),
        ("renvoi : destination", "Destination invalide : un poste, un groupe ou un numéro à 10 chiffres commençant par 0."),
        ("renvoi : mode", "Type de renvoi invalide."),
        ("e-mail : serveur et adresse", "Serveur SMTP et adresse d'expédition sont requis pour activer l'envoi."),
        ("e-mail : identifiant sans chiffrement", "Avec un identifiant, choisissez STARTTLS ou TLS : le mot de passe ne doit pas circuler en clair."),
        ("e-mail : mot de passe requis", "Mot de passe requis avec un identifiant SMTP."),
        ("e-mail : serveur", "Serveur SMTP invalide : nom de domaine ou adresse IP."),
        ("e-mail : port", "Port invalide (1 à 65535)."),
        ("e-mail : sécurité", "Sécurité de la connexion invalide."),
        ("e-mail : identifiant", "Identifiant SMTP invalide : espaces, guillemets, points-virgules, crochets, dièses et barres obliques inverses refusés."),
        ("e-mail : mot de passe", "Mot de passe SMTP invalide : espaces, guillemets, points-virgules, crochets, dièses et barres obliques inverses refusés."),
        ("e-mail : adresse d'expédition", "Adresse d'expédition invalide."),
        ("adresse e-mail invalide", "Adresse e-mail invalide."),
        ("menu vocal : délai", "Délai de choix entre 2 et 30 secondes."),
        ("menu vocal : touche invalide", "Touche invalide : de 0 à 9."),
        ("en double", "Chaque touche ne peut servir qu'une fois."),
        ("menu vocal : ajoutez", "Ajoutez au moins une touche pour activer le menu vocal."),
        ("menu vocal : touche", "Destination inconnue pour une touche du menu."),
        ("menu vocal : sans choix", "Destination par défaut inconnue."),
        ("menu vocal", "Menu vocal invalide."),
    )

    def pbx_message(self, exc):
        text = str(exc)
        for prefix, message in self.PBX_MESSAGES:
            if prefix in text:
                return message
        return "Configuration téléphonique invalide."

    # ------------------------------------------------------------ accueil vocal
    MAX_SOUND = 20 * 1024 * 1024

    def api_pbx_ivr(self):
        """Menu vocal de l'accueil : touches, délai, destination par défaut, musique d'attente."""
        session = self.require_session(write=True)
        data = self.read_json()
        state = self.pbx_load()
        state["ivr"] = {k: data.get(k) for k in ("enabled", "options", "timeout", "default", "hold_music")}
        if state["ivr"]["timeout"] is None:
            state["ivr"]["timeout"] = 5
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        applied = self.pbx_commit(state, session["username"], "pbx:ivr:%s" % ("on" if state["ivr"]["enabled"] else "off"))
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "ivr": state["ivr"]})

    def sound_name(self, value):
        if value not in pbx.SOUNDS:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Annonce inconnue.")
        return value

    def api_sounds(self):
        self.require_session()
        try:
            with open(self.ctx.sounds_status, "r", encoding="utf-8") as handle:
                status = json.load(handle)
        except (OSError, ValueError):
            status = {}
        known = status.get("sounds") if isinstance(status.get("sounds"), dict) else {}
        out = {}
        for name in pbx.SOUNDS:
            rec = known.get(name) if isinstance(known.get(name), dict) else {}
            seconds = rec.get("seconds")
            out[name] = {"present": rec.get("present") is True,
                         "seconds": seconds if isinstance(seconds, (int, float)) else None,
                         "updated": rec.get("updated") if isinstance(rec.get("updated"), int) else None,
                         "error": str(rec["error"])[:200] if rec.get("error") else None,
                         "pending": any(os.path.lexists(os.path.join(self.ctx.sounds_upload, name + ext))
                                        for ext in (".upload", ".delete"))}
        converter = status.get("converter") if status.get("converter") in ("sox", "ffmpeg") else None
        self.send_json(HTTPStatus.OK, {"sounds": out, "converter": converter, "checked": "converter" in status})

    def sound_drop(self, name, ext, data=None):
        """Dépôt pour voipbuntu-sounds : <nom>.upload (fichier envoyé) ou <nom>.delete (suppression)."""
        os.makedirs(self.ctx.sounds_upload, mode=0o700, exist_ok=True)
        for other in (".upload", ".delete"):
            try:
                os.unlink(os.path.join(self.ctx.sounds_upload, name + other))
            except FileNotFoundError:
                pass
        path = os.path.join(self.ctx.sounds_upload, name + ext)
        tmp = path + ".tmp"
        old = os.umask(0o077)
        try:
            with open(tmp, "wb") as handle:
                handle.write(data or b"")
            os.replace(tmp, path)
        finally:
            os.umask(old)

    def api_sounds_upload(self):
        """Envoi d'une annonce : le fichier brut (WAV ou MP3) dans le corps, le nom dans ?name=."""
        session = self.require_session(write=True)
        name = self.sound_name((parse_qs(urlsplit(self.path).query).get("name") or [""])[0])
        ctype = self.headers.get("Content-Type", "").split(";")[0].strip().lower()
        if ctype not in ("application/octet-stream", "audio/wav", "audio/x-wav", "audio/wave", "audio/mpeg", "audio/mp3"):
            raise ApiError(HTTPStatus.UNSUPPORTED_MEDIA_TYPE, "Envoyez un fichier WAV ou MP3.")
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.") from None
        if length > self.MAX_SOUND:
            self.close_connection = True  # corps non lu : la connexion ne peut pas resservir
            raise ApiError(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "Fichier trop volumineux (20 Mo au plus).")
        if length <= 0:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Fichier vide.")
        self.body_read = True
        data = self.rfile.read(length)
        is_wav = data[:4] == b"RIFF" and data[8:12] == b"WAVE"
        is_mp3 = data[:3] == b"ID3" or (len(data) > 1 and data[0] == 0xFF and data[1] & 0xE0 == 0xE0)
        if len(data) != length or not (is_wav or is_mp3):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Envoyez un fichier WAV ou MP3.")
        self.sound_drop(name, ".upload", data)
        self.ctx.db.audit("sounds:upload:%s" % name, session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": self.sound_submit(session)})

    def api_sounds_delete(self):
        session = self.require_session(write=True)
        name = self.sound_name(str(self.read_json().get("name", "")))
        self.sound_drop(name, ".delete")
        self.ctx.db.audit("sounds:delete:%s" % name, session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": self.sound_submit(session)})

    def sound_submit(self, session):
        try:
            self.ctx.worker.submit("sounds-apply", session["username"])
            return True
        except WorkerUnavailable:
            return False

    # ------------------------------------------------------------ réseaux
    def networks_load(self):
        try:
            return networks.load(self.ctx.networks_state)
        except networks.NetworkError:
            return {"networks": []}

    def api_networks(self):
        self.require_session()
        conf = networks.read_conf_nets(self.ctx.appliance_conf)
        self.send_json(HTTPStatus.OK, networks.view(self.networks_load(), conf))

    def api_networks_save(self):
        session = self.require_session(write=True)
        data = self.read_json()
        try:
            state = networks.save({"networks": data.get("networks")}, self.ctx.networks_state)
        except networks.NetworkError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Liste de réseaux invalide : format (192.168.20.0/24), doublons, 16 réseaux au plus, noms sans caractères spéciaux.", {"detail": str(exc)[:120]}) from None
        self.ctx.db.audit("networks:%s" % ",".join(n["cidr"] for n in state["networks"])[:180],
                          session["username"], self.remote)
        try:
            self.ctx.worker.submit("networks-apply", session["username"])
            applied = True
        except WorkerUnavailable:
            applied = False
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "networks": state["networks"]})

    # ------------------------------------------------ réseau de l'appliance
    def netconf_files(self):
        return netconf.paths(os.path.dirname(os.path.abspath(self.ctx.networks_state)))

    def netconf_stored(self, files):
        try:
            return netconf.load(files["state"])
        except netconf.NetconfError:
            return None

    @staticmethod
    def netconf_pending(status):
        return bool(status and status["state"] == "pending" and "nonce" in status
                    and (status["deadline"] or 0) > time.time())

    def api_system_network(self):
        self.require_session()
        files = self.netconf_files()
        current = netconf.live()
        stored = self.netconf_stored(files)
        settings = netconf.defaults(current)
        if stored:
            settings["ntp"] = stored["ntp"]
            for key in ("hostname", "timezone", "network"):
                if stored[key]:
                    settings[key] = stored[key]
        status = netconf.read_status(files["status"])
        if status:
            status["pending"] = self.netconf_pending(status)
            status.pop("nonce", None)
        self.send_json(HTTPStatus.OK, {"settings": settings, "managed": bool(stored and stored["network"]),
                                       "live": current, "status": status, "check": netconf.read_check(files["check"]),
                                       "timezones": netconf.timezones(), "confirm_seconds": netconf.CONFIRM_SECONDS})

    def api_system_network_save(self):
        """Réseau, nom de machine, NTP, fuseau : seules les parties envoyées changent."""
        session = self.require_session(write=True)
        data = self.read_json()
        changes = {k: data[k] for k in ("network", "hostname", "ntp", "timezone") if k in data}
        if not changes:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.")
        files = self.netconf_files()
        if self.netconf_pending(netconf.read_status(files["status"])):
            raise ApiError(HTTPStatus.CONFLICT, "Une configuration réseau attend déjà sa confirmation.")
        current = netconf.live()
        if isinstance(changes.get("network"), dict):
            names = [i["name"] for i in current["interfaces"]]
            if str(changes["network"].get("interface", "")) not in names:
                raise ApiError(HTTPStatus.BAD_REQUEST, "Interface réseau inconnue.")
        try:
            state = netconf.save(netconf.merge(self.netconf_stored(files), changes), files["state"])
        except netconf.NetconfError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, str(exc)) from None
        net = state["network"]
        parts = []
        if "network" in changes and net:
            parts.append("%s:%s" % (net["interface"], net["mode"] if net["mode"] == "dhcp"
                                    else "%s/%s" % (net["address"], net["prefix"])))
        parts += ["%s=%s" % (k, ",".join(state[k]) if isinstance(state[k], list) else state[k])
                  for k in ("hostname", "ntp", "timezone") if k in changes]
        self.ctx.db.audit(("system:network:" + ";".join(parts))[:200], session["username"], self.remote)
        try:
            self.ctx.worker.submit("network-apply", session["username"])
            applied = True
        except WorkerUnavailable:
            applied = False
        new_address = None
        if "network" in changes and net and net["mode"] == "static":
            iface = next((i for i in current["interfaces"] if i["name"] == net["interface"]), {"addresses": []})
            if not any(a.split("/")[0] == net["address"] for a in iface["addresses"]):
                new_address = net["address"]
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "settings": state, "new_address": new_address,
                                       "confirm_seconds": netconf.CONFIRM_SECONDS})

    def api_system_network_confirm(self):
        """La console est joignable après le changement de réseau : voipbuntu-netconf le garde."""
        session = self.require_session(write=True)
        self.read_json()  # corps vide attendu, lu pour garder la connexion propre
        files = self.netconf_files()
        status = netconf.read_status(files["status"])
        if not self.netconf_pending(status):
            raise ApiError(HTTPStatus.CONFLICT, "Aucune configuration réseau en attente de confirmation.")
        host = self.headers.get("Host", "")
        host = host[1:].split("]", 1)[0] if host.startswith("[") else (host.rsplit(":", 1)[0] if host.count(":") == 1 else host)
        if status["address"] and netconf.is_ip(host) and host != status["address"]:
            raise ApiError(HTTPStatus.CONFLICT, "Confirmez depuis la nouvelle adresse de l'appliance.")
        netconf.write_json(files["confirm"], {"nonce": status["nonce"]})
        self.ctx.db.audit("system:network:confirm", session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True})

    def api_pbx_delete(self):
        session = self.require_session(write=True)
        number = str(self.read_json().get("number", ""))
        state = self.pbx_load()
        kept = [e for e in state["extensions"] if e["number"] != number]
        if len(kept) == len(state["extensions"]):
            raise ApiError(HTTPStatus.NOT_FOUND, "Poste introuvable.")
        state["extensions"] = kept
        pbx.drop_number(state, number)
        applied = self.pbx_commit(state, session["username"], "pbx:delete:" + number)
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied})

    def api_pbx_secret(self):
        session = self.require_session(write=True)
        data = self.read_json()
        number, renew = str(data.get("number", "")), bool(data.get("renew", False))
        state = self.pbx_load()
        ext = next((e for e in state["extensions"] if e["number"] == number), None)
        if ext is None:
            raise ApiError(HTTPStatus.NOT_FOUND, "Poste introuvable.")
        applied = None
        if renew:
            ext["secret"] = pbx.new_secret()
            applied = self.pbx_commit(state, session["username"], "pbx:renew:" + number)
        else:
            self.ctx.db.audit("pbx:reveal:" + number, session["username"], self.remote)
        self.send_json(HTTPStatus.OK, dict(self.sheet(ext), applied=applied))

    # ------------------------------------------------------------ bases DECT
    def api_pbx_dect_base(self):
        """Ajoute (sans id) ou modifie une base DECT : nom, modèle, adresse IP, MAC."""
        session = self.require_session(write=True)
        data = self.read_json()
        state = self.pbx_load()
        bid = str(data.get("id") or "")
        if bid:
            base = next((b for b in state["dect_bases"] if b["id"] == bid), None)
            if base is None:
                raise ApiError(HTTPStatus.NOT_FOUND, "Base DECT introuvable.")
        else:
            if len(state["dect_bases"]) >= pbx.MAX_DECT_BASES:
                raise ApiError(HTTPStatus.BAD_REQUEST, "Dix bases DECT au plus.")
            base = {"id": pbx.new_base_id(state)}
            state["dect_bases"].append(base)
        mac = str(data.get("mac") or "").strip().lower().replace("-", ":")
        if re.match(r"^[0-9a-f]{12}$", mac):
            mac = ":".join(mac[i:i + 2] for i in range(0, 12, 2))
        base.update({"name": str(data.get("name", "")).strip(), "model": str(data.get("model") or "").strip(),
                     "address": str(data.get("address") or "").strip(), "mac": mac})
        # Combinés à rattacher (numéros de postes) : ils deviennent des postes DECT de cette base
        for number in data.get("handsets") or [] if isinstance(data.get("handsets"), list) else []:
            ext = next((e for e in state["extensions"] if e["number"] == str(number)), None)
            if ext is not None:
                ext["kind"], ext["base"] = "dect", base["id"]
        applied = self.pbx_commit(state, session["username"], "pbx:dect-base:%s" % base["id"])
        self.send_json(HTTPStatus.OK, {"ok": True, "id": base["id"], "applied": applied})

    def api_pbx_dect_base_delete(self):
        """Supprime une base : ses combinés restent des postes DECT, sans base."""
        session = self.require_session(write=True)
        bid = str(self.read_json().get("id", ""))
        state = self.pbx_load()
        if not any(b["id"] == bid for b in state["dect_bases"]):
            raise ApiError(HTTPStatus.NOT_FOUND, "Base DECT introuvable.")
        state["dect_bases"] = [b for b in state["dect_bases"] if b["id"] != bid]
        for e in state["extensions"]:
            if e["base"] == bid:
                e["base"] = ""
        applied = self.pbx_commit(state, session["username"], "pbx:dect-base-delete:%s" % bid)
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied})

    def api_pbx_dect_handsets(self):
        """Ajoute N combinés à une base : numéros consécutifs, un compte SIP (identifiant = numéro) chacun."""
        session = self.require_session(write=True)
        data = self.read_json()
        state = self.pbx_load()
        bid = str(data.get("id", ""))
        if not any(b["id"] == bid for b in state["dect_bases"]):
            raise ApiError(HTTPStatus.NOT_FOUND, "Base DECT introuvable.")
        try:
            count = int(data.get("count", 1))
        except (TypeError, ValueError):
            count = 0
        attached = sum(1 for e in state["extensions"] if e["base"] == bid)
        if not 1 <= count <= pbx.BASE_HANDSETS - attached:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Nombre de combinés invalide : 1 à 30 par base.")
        first = str(data.get("first", "")).strip()
        if not pbx.NUMBER_RE.match(first):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Numéro invalide : de 2 à 6 chiffres, sans 0 en tête.")
        prefix = str(data.get("prefix") or "Combiné").strip()
        numbers = [str(int(first) + i) for i in range(count)]
        used = pbx.used_numbers(state)
        taken = [n for n in numbers if n in used or not pbx.NUMBER_RE.match(n)]
        if taken:
            raise ApiError(HTTPStatus.CONFLICT, "Numéros déjà pris ou réservés dans cette plage : choisissez un autre premier numéro.")
        if len(state["extensions"]) + count > pbx.MAX_EXTENSIONS:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Nombre maximal de postes atteint.")
        users = {e["sip_user"].lower() for e in state["extensions"]}
        if any(n in users for n in numbers):
            raise ApiError(HTTPStatus.CONFLICT, "Cet identifiant SIP est déjà utilisé par un autre poste.")
        for n in numbers:
            name = ("%s %s" % (prefix, n))[:40].strip()
            if not pbx.NAME_RE.match(name):
                raise ApiError(HTTPStatus.BAD_REQUEST, "Nom invalide : 1 à 40 caractères, sans guillemets ni crochets.")
            state["extensions"].append({"number": n, "name": name, "sip_user": n, "secret": pbx.new_secret(),
                                        "pin": pbx.new_pin(), "voicemail": bool(data.get("voicemail", True)),
                                        "email": "", "kind": "dect", "base": bid})
        applied = self.pbx_commit(state, session["username"], "pbx:dect-handsets:%s:%s-%s" % (bid, numbers[0], numbers[-1]))
        self.send_json(HTTPStatus.CREATED, {"ok": True, "numbers": numbers, "applied": applied})

    def api_pbx_dect_base_from_extension(self):
        """Poste créé à tort pour une base DECT : il est supprimé et la base déclarée (ou gardée) à sa place."""
        session = self.require_session(write=True)
        data = self.read_json()
        number = str(data.get("number", ""))
        state = self.pbx_load()
        ext = next((e for e in state["extensions"] if e["number"] == number), None)
        if ext is None:
            raise ApiError(HTTPStatus.NOT_FOUND, "Poste introuvable.")
        base = next((b for b in state["dect_bases"] if b["id"] == ext["base"]), None)
        if base is None:
            address = str(data.get("address") or "").strip()
            base = pbx.base_at(state, address) if address else None
        if base is None:
            if len(state["dect_bases"]) >= pbx.MAX_DECT_BASES:
                raise ApiError(HTTPStatus.BAD_REQUEST, "Dix bases DECT au plus.")
            base = {"id": pbx.new_base_id(state), "name": str(data.get("name") or ext["name"]).strip(),
                    "model": str(data.get("model") or "").strip(), "address": str(data.get("address") or "").strip(),
                    "mac": ""}
            state["dect_bases"].append(base)
        state["extensions"] = [e for e in state["extensions"] if e["number"] != number]
        pbx.drop_number(state, number)
        applied = self.pbx_commit(state, session["username"], "pbx:dect-base-from:%s:%s" % (number, base["id"]))
        try:  # téléphone associé à ce poste (provisionnement) : dissocié
            prov = provisioning.load(self.prov_path())
            prov, dropped = provisioning.prune(prov, {e["number"] for e in state["extensions"]})
            if dropped:
                provisioning.save(prov, self.prov_path())
        except provisioning.ProvisioningError:
            pass
        self.send_json(HTTPStatus.OK, {"ok": True, "id": base["id"], "applied": applied})

    def api_pbx_dect_base_sheet(self):
        """Fiche de configuration d'une base : serveur SIP et identifiants de chaque combiné."""
        session = self.require_session(write=True)  # mots de passe SIP en clair, comme la fiche d'un poste
        bid = str(self.read_json().get("id", ""))
        state = self.pbx_load()
        base = next((b for b in state["dect_bases"] if b["id"] == bid), None)
        if base is None:
            raise ApiError(HTTPStatus.NOT_FOUND, "Base DECT introuvable.")
        servers = pbx.sip_servers(sysinfo.ip_addresses(), pbx.read_phone_nets(self.ctx.appliance_conf))
        handsets = [{"number": e["number"], "name": e["name"], "sip_user": e["sip_user"], "secret": e["secret"],
                     "voicemail": e["voicemail"]} for e in state["extensions"] if e["base"] == bid]
        self.ctx.db.audit("pbx:dect-base-reveal:" + bid, session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"base": base, "servers": servers, "port": 5060, "transport": "UDP",
                                       "voicemail_code": "*97", "handsets": handsets})

    def sheet(self, ext):
        """Fiche de configuration d'un poste (base DECT ou téléphone SIP)."""
        servers = pbx.sip_servers(sysinfo.ip_addresses(), pbx.read_phone_nets(self.ctx.appliance_conf))
        return {"number": ext["number"], "name": ext["name"], "sip_user": ext["sip_user"],
                "secret": ext["secret"], "pin": ext["pin"],
                "servers": servers, "port": 5060, "transport": "UDP", "voicemail_code": "*97",
                "voicemail": ext["voicemail"], "kind": ext.get("kind", "sip"), "base": ext.get("base", "")}

    def api_jobs_list(self):
        self.require_session()
        try:
            self.send_json(HTTPStatus.OK, self.ctx.worker.list())
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None

    def api_jobs_submit(self):
        session = self.require_session(write=True)
        data = self.read_json()
        action = data.get("action")
        if action not in ACTIONS:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Action inconnue.")
        try:
            result = self.ctx.worker.submit(action, session["username"])
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None
        self.ctx.db.audit("job:" + action, session["username"], self.remote)
        self.send_json(HTTPStatus.ACCEPTED, result)

    # ---------------------------------------------------------------- alertes
    def api_alerts(self):
        self.require_session()
        try:
            mail = pbx.load(self.ctx.pbx_state)["mail"]["enabled"]
        except pbx.PbxError:
            mail = False
        payload = alerts.public(alerts.load_state(self.ctx.alerts_state))
        payload.update({"settings": alerts.load_settings(self.ctx.alerts_settings), "mail_enabled": mail,
                        "causes": [{"cause": k, "label": label} for k, label, _ in alerts.CAUSES]})
        self.send_json(HTTPStatus.OK, payload)

    def api_alerts_settings(self):
        session = self.require_session(write=True)
        try:
            settings = alerts.save_settings(self.read_json(), self.ctx.alerts_settings)
        except alerts.AlertError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, str(exc)) from None
        on = ",".join(k for k, v in settings["causes"].items() if v) or "aucune"
        self.ctx.db.audit(("alerts:settings:%d-destinataires:%s" % (len(settings["recipients"]), on))[:180],
                          session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "settings": settings})

    def api_audit(self):
        self.require_session()
        with self.ctx.db.lock:
            rows = self.ctx.db.conn.execute(
                "SELECT ts, username, remote, event FROM audit ORDER BY ts DESC LIMIT 200").fetchall()
        self.send_json(HTTPStatus.OK, {"events": [
            {"ts": r[0], "user": r[1], "remote": r[2], "event": r[3]} for r in rows]})

    # ------------------------------------------------- annuaire et journal des appels
    DIRECTORY_MESSAGES = (
        ("contacts au plus", "L'annuaire est plein (1000 contacts au plus)."),
        ("nom ou une société", "Un contact doit avoir un nom ou une société."),
        ("numéros au plus", "Quatre numéros au plus par contact."),
        ("type de numéro", "Type de numéro invalide."),
        ("aucun numéro", "Un contact doit avoir au moins un numéro."),
        ("numéro invalide", "Numéro invalide : 10 chiffres commençant par 0, +33…, 00… ou numéro court."),
        ("trop gros", "Fichier CSV trop gros (512 Ko au plus)."),
        ("vide", "Le fichier CSV est vide."),
        ("colonnes", "Colonnes nom et téléphone introuvables : exportez les contacts d'Outlook ou de Google au format CSV."),
    )

    def directory_message(self, exc):
        text = str(exc)
        for part, message in self.DIRECTORY_MESSAGES:
            if part in text:
                return message
        return "Annuaire invalide."

    def send_file(self, body, ctype, filename):
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Disposition", 'attachment; filename="%s"' % filename)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.security_headers()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def calls_load(self):
        """Appels lus par la file d'attente (root), enrichis : statut, postes qui ont sonné, contact."""
        try:
            data = self.ctx.worker.pbx_calls()
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None
        calls = data.get("calls") if isinstance(data.get("calls"), list) else []
        return calllog.enrich(calls, self.pbx_load()), bool(data.get("error"))

    def api_pbx_calls_stats(self):
        self.require_session()
        calls, error = self.calls_load()
        payload = calllog.stats(calls, self.pbx_load())
        payload["error"] = error
        self.send_json(HTTPStatus.OK, payload)

    def api_directory(self):
        self.require_session()
        query = (parse_qs(urlsplit(self.path).query).get("q") or [""])[0]
        state = self.pbx_load()
        contacts, total = directory.search(state["directory"], query[:80], 500)
        self.send_json(HTTPStatus.OK, {"contacts": contacts, "total": total,
                                       "count": len(state["directory"]["contacts"]), "max": directory.MAX_CONTACTS,
                                       "kinds": list(directory.KINDS)})

    def directory_commit(self, state, book, username, event):
        state["directory"] = book
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.directory_message(exc)) from None
        return self.pbx_commit(state, username, event)

    def api_directory_save(self):
        """Crée un contact, ou le modifie quand l'identifiant est donné."""
        session = self.require_session(write=True)
        data = self.read_json()
        state = self.pbx_load()
        contacts = state["directory"]["contacts"]
        cid = str(data.get("id") or "")
        if cid and not any(c["id"] == cid for c in contacts):
            raise ApiError(HTTPStatus.NOT_FOUND, "Contact introuvable.")
        try:
            contact = directory.validate_contact(dict(data, id=cid or directory.new_id()))
        except directory.DirectoryError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.directory_message(exc)) from None
        if not cid and len(contacts) >= directory.MAX_CONTACTS:
            raise ApiError(HTTPStatus.BAD_REQUEST, "L'annuaire est plein (1000 contacts au plus).")
        others = [c for c in contacts if c["id"] != cid]
        applied = self.directory_commit(state, {"contacts": others + [contact]}, session["username"],
                                        "directory:%s:%s" % ("update" if cid else "create", contact["id"]))
        self.send_json(HTTPStatus.OK if cid else HTTPStatus.CREATED, {"ok": True, "contact": contact, "applied": applied})

    def api_directory_delete(self):
        session = self.require_session(write=True)
        data = self.read_json()
        ids = data.get("ids") if isinstance(data.get("ids"), list) else [data.get("id")]
        ids = {str(i) for i in ids if i}
        state = self.pbx_load()
        contacts = state["directory"]["contacts"]
        kept = [c for c in contacts if c["id"] not in ids]
        if len(kept) == len(contacts):
            raise ApiError(HTTPStatus.NOT_FOUND, "Contact introuvable.")
        applied = self.directory_commit(state, {"contacts": kept}, session["username"],
                                        "directory:delete:%d" % (len(contacts) - len(kept)))
        self.send_json(HTTPStatus.OK, {"ok": True, "deleted": len(contacts) - len(kept), "applied": applied})

    def api_directory_import(self):
        """Import CSV (Outlook, Google, VOIPbuntu) : le fichier brut en base64, pour garder son encodage."""
        import base64
        import binascii
        session = self.require_session(write=True)
        data = self.read_json()
        try:
            raw = base64.b64decode(str(data.get("data", "")), validate=True)
        except (binascii.Error, ValueError):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Fichier CSV illisible.") from None
        state = self.pbx_load()
        try:
            imported, skipped = directory.parse_csv(raw)
            book, added, updated = directory.merge(state["directory"], imported, bool(data.get("replace")))
        except directory.DirectoryError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.directory_message(exc)) from None
        applied = self.directory_commit(state, book, session["username"],
                                        "directory:import:%d-ajoutés:%d-mis-à-jour%s" % (
                                            added, updated, ":remplacé" if data.get("replace") else ""))
        self.send_json(HTTPStatus.OK, {"ok": True, "added": added, "updated": updated, "skipped": skipped,
                                       "count": len(book["contacts"]), "applied": applied})

    def api_directory_export(self):
        session = self.require_session()
        body = directory.export_csv(self.pbx_load()["directory"])
        self.send_file(body, "text/csv; charset=utf-8", "voipbuntu-annuaire-%s.csv" % time.strftime("%Y%m%d"))
        self.ctx.db.audit("directory:export", session["username"], self.remote)

    def api_pbx_speed_dials(self):
        """Numéros abrégés *1XX : la liste complète remplace l'ancienne."""
        session = self.require_session(write=True)
        data = self.read_json()
        state = self.pbx_load()
        state["speed_dials"] = data.get("speed_dials")
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            text = str(exc)
            if "en double" in text:
                raise ApiError(HTTPStatus.BAD_REQUEST, "Ce code de numéro abrégé est déjà pris.") from None
            if "code invalide" in text:
                raise ApiError(HTTPStatus.BAD_REQUEST, "Code invalide : deux chiffres, de 00 à 99 (composé *100 à *199).") from None
            if "numéro extérieur" in text:
                raise ApiError(HTTPStatus.BAD_REQUEST, "Numéro abrégé : un numéro extérieur à 10 chiffres commençant par 0, ou international en 00.") from None
            raise ApiError(HTTPStatus.BAD_REQUEST, "Numéros abrégés invalides (cent au plus).") from None
        applied = self.pbx_commit(state, session["username"], "pbx:speed-dials:%d" % len(state["speed_dials"]))
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "speed_dials": state["speed_dials"]})

    # ------------------------------------------- comptes et double authentification
    LOGIN_TICKET_SECONDS = 300
    LOGIN_TICKET_ATTEMPTS = 5

    def login_ticket(self, username):
        ticket = security.new_token()
        now = time.time()
        with self.ctx.db.lock:
            self.ctx.db.conn.execute("DELETE FROM login_pending WHERE created < ? OR username=?",
                                     (now - self.LOGIN_TICKET_SECONDS, username))
            self.ctx.db.conn.execute("INSERT INTO login_pending(token_hash, username, created) VALUES (?,?,?)",
                                     (security.token_digest(ticket), username, now))
            self.ctx.db.conn.commit()
        self.ctx.db.audit("login-password-ok", username, self.remote)
        return ticket

    def api_login_totp(self):
        """Deuxième étape de la connexion : code TOTP à 6 chiffres ou code de secours."""
        self.check_origin()
        data = self.read_json()
        ticket, code = data.get("ticket"), data.get("code")
        if not isinstance(ticket, str) or not isinstance(code, str) or len(ticket) > 128 or len(code) > 32:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.")
        digest = security.token_digest(ticket)
        with self.ctx.db.lock:
            row = self.ctx.db.conn.execute(
                "SELECT username, created, attempts FROM login_pending WHERE token_hash=?", (digest,)).fetchone()
        if row is None or time.time() - row[1] > self.LOGIN_TICKET_SECONDS or row[2] >= self.LOGIN_TICKET_ATTEMPTS:
            raise ApiError(HTTPStatus.UNAUTHORIZED, "Connexion expirée : saisissez à nouveau votre mot de passe.",
                           {"restart": True})
        username = row[0]
        keys = ["ip:" + self.remote, "user:" + username]
        wait = self.ctx.throttle.locked_for(keys)
        if wait:
            raise ApiError(HTTPStatus.TOO_MANY_REQUESTS, "Trop de tentatives, réessayez plus tard.", {"retry": wait})
        user = self.ctx.db.get_account(username)
        if user is None or user["disabled"] or not user["totp_secret"]:
            raise ApiError(HTTPStatus.UNAUTHORIZED, "Connexion expirée : saisissez à nouveau votre mot de passe.",
                           {"restart": True})
        event = None
        step = totp.verify(self.totp_secret(user["totp_secret"]), code, user["totp_last"] or 0)
        if step is not None:
            self.ctx.db.update_account(username, totp_last=step)
            event = "login"
        else:
            codes = self.recovery_list(user)
            wanted = totp.recovery_digest(code)
            if len(totp.normalize_recovery(code)) == 10 and wanted in codes:
                codes.remove(wanted)
                self.ctx.db.update_account(username, recovery=json.dumps(codes))
                event = "login-recovery-code:%d-restants" % len(codes)
        if event is None:
            with self.ctx.db.lock:
                self.ctx.db.conn.execute("UPDATE login_pending SET attempts=attempts+1 WHERE token_hash=?", (digest,))
                self.ctx.db.conn.commit()
            self.ctx.throttle.failure(keys)
            self.ctx.db.audit("login-totp-failed", username, self.remote)
            raise ApiError(HTTPStatus.UNAUTHORIZED, "Code de vérification incorrect.")
        with self.ctx.db.lock:
            self.ctx.db.conn.execute("DELETE FROM login_pending WHERE token_hash=?", (digest,))
            self.ctx.db.conn.commit()
        self.login_done(username, keys, event)

    def secretbox(self):
        return security.SecretBox(self.ctx.secrets_key)

    def totp_secret(self, stored):
        try:
            return self.secretbox().decrypt(stored)
        except security.SecretBoxError:
            LOG.error("secret TOTP indéchiffrable (clé /etc/voipbuntu/secrets.key changée ?)")
            raise ApiError(HTTPStatus.INTERNAL_SERVER_ERROR,
                           "Double authentification illisible : réinitialisez-la depuis la console de l'appliance (voipbuntu-passwd --sans-2fa).") from None

    @staticmethod
    def recovery_list(user):
        try:
            codes = json.loads(user["recovery"] or "[]")
        except ValueError:
            return []
        return [c for c in codes if isinstance(c, str)] if isinstance(codes, list) else []

    @staticmethod
    def account_view(user):
        return {"username": user["username"], "role": user["role"], "disabled": bool(user["disabled"]),
                "totp": bool(user["totp_secret"]), "created": user["created"], "last_login": user["last_login"],
                "source": user.get("source") or "local",
                "recovery_left": len(Handler.recovery_list(user)) if user["totp_secret"] else None}

    def self_account(self, session, password=None):
        user = self.ctx.db.get_account(session["username"])
        if user is None:
            raise ApiError(HTTPStatus.UNAUTHORIZED, "Session expirée, reconnectez-vous.")
        if password is not None:
            if user.get("source") == "ad":
                valid = isinstance(password, str) and self.ad_check_password(user["username"], password)
            else:
                valid = isinstance(password, str) and security.verify_password(password, user["password_hash"])
            if not valid:
                self.ctx.db.audit("totp-password-failed", session["username"], self.remote)
                raise ApiError(HTTPStatus.FORBIDDEN, "Mot de passe actuel incorrect.")
        return user

    def api_account(self):
        session = self.require_session()
        self.send_json(HTTPStatus.OK, self.account_view(self.self_account(session)))

    def api_totp_setup(self):
        """Prépare l'activation : nouveau secret (chiffré, en attente) et QR code SVG fait ici."""
        session = self.require_session(write=True)
        data = self.read_json()
        self.self_account(session, data.get("password"))
        secret = totp.new_secret()
        self.ctx.db.update_account(session["username"], totp_pending=self.secretbox().encrypt(secret))
        uri = totp.otpauth_uri(secret, session["username"])
        self.ctx.db.audit("totp:setup", session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"secret": secret, "uri": uri, "svg": totp.qr_svg(uri)})

    def api_totp_enable(self):
        session = self.require_session(write=True)
        data = self.read_json()
        user = self.self_account(session)
        if not user["totp_pending"]:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Recommencez l'activation de la double authentification.")
        step = totp.verify(self.totp_secret(user["totp_pending"]), data.get("code"), 0)
        if step is None:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Code de vérification incorrect.")
        codes = totp.new_recovery_codes()
        self.ctx.db.update_account(session["username"], totp_secret=user["totp_pending"], totp_pending=None,
                                   totp_last=step, recovery=json.dumps([totp.recovery_digest(c) for c in codes]))
        self.ctx.db.audit("totp:on", session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "recovery": codes})

    def api_totp_disable(self):
        session = self.require_session(write=True)
        self.self_account(session, self.read_json().get("password"))
        self.ctx.db.update_account(session["username"], totp_secret=None, totp_pending=None, recovery=None, totp_last=0)
        self.ctx.db.audit("totp:off", session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True})

    def api_totp_recovery(self):
        session = self.require_session(write=True)
        user = self.self_account(session, self.read_json().get("password"))
        if not user["totp_secret"]:
            raise ApiError(HTTPStatus.BAD_REQUEST, "La double authentification n'est pas activée.")
        codes = totp.new_recovery_codes()
        self.ctx.db.update_account(session["username"], recovery=json.dumps([totp.recovery_digest(c) for c in codes]))
        self.ctx.db.audit("totp:recovery-renewed", session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "recovery": codes})

    def api_users(self):
        self.require_session()
        self.send_json(HTTPStatus.OK, {"users": [self.account_view(u) for u in self.ctx.db.list_accounts()],
                                       "roles": list(ROLES)})

    def user_target(self, data, session=None, self_forbidden=None):
        username = data.get("username")
        if not isinstance(username, str) or not USERNAME_RE.match(username):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Identifiant invalide : minuscules, chiffres, point, tiret, 32 caractères au plus.")
        user = self.ctx.db.get_account(username)
        if user is None:
            raise ApiError(HTTPStatus.NOT_FOUND, "Compte introuvable.")
        if self_forbidden and session and username == session["username"]:
            raise ApiError(HTTPStatus.BAD_REQUEST, self_forbidden)
        return user

    def keep_admin(self, username, role, disabled):
        """Il reste toujours au moins un administrateur actif."""
        # Un administrateur local reste toujours actif : il sert quand l'AD est injoignable.
        remaining = [a for a in self.ctx.db.active_local_admins() if a != username]
        if not remaining and (role != "admin" or disabled):
            raise ApiError(HTTPStatus.CONFLICT, "Il doit rester au moins un administrateur actif.")

    def api_users_create(self):
        session = self.require_session(write=True)
        data = self.read_json()
        username, password, role = data.get("username"), data.get("password"), data.get("role", "lecture")
        if not isinstance(username, str) or not USERNAME_RE.match(username):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Identifiant invalide : minuscules, chiffres, point, tiret, 32 caractères au plus.")
        if role not in ROLES:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Rôle inconnu.")
        problem = security.password_problem(password)
        if problem:
            raise ApiError(HTTPStatus.BAD_REQUEST, problem)
        if self.ctx.db.get_account(username) is not None:
            raise ApiError(HTTPStatus.CONFLICT, "Ce compte existe déjà.")
        self.ctx.db.create_account(username, security.hash_password(password), role)
        self.ctx.db.audit("users:create:%s:%s" % (username, role), session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True})

    def api_users_update(self):
        """Rôle et désactivation d'un autre compte."""
        session = self.require_session(write=True)
        data = self.read_json()
        user = self.user_target(data, session, "Modifiez votre propre compte depuis un autre administrateur.")
        role = data.get("role", user["role"])
        disabled = data.get("disabled", bool(user["disabled"]))
        if role not in ROLES or not isinstance(disabled, bool):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.")
        self.keep_admin(user["username"], role, disabled)
        self.ctx.db.update_account(user["username"], role=role, disabled=int(disabled))
        if role != user["role"]:
            self.ctx.db.audit("users:role:%s:%s" % (user["username"], role), session["username"], self.remote)
        if disabled != bool(user["disabled"]):
            self.ctx.db.audit("users:%s:%s" % ("disable" if disabled else "enable", user["username"]),
                              session["username"], self.remote)
            if disabled:
                self.ctx.sessions.delete_user(user["username"])
        self.send_json(HTTPStatus.OK, {"ok": True})

    def api_users_delete(self):
        session = self.require_session(write=True)
        user = self.user_target(self.read_json(), session, "Vous ne pouvez pas supprimer votre propre compte.")
        self.keep_admin(user["username"], None, True)
        self.ctx.db.delete_account(user["username"])
        self.ctx.db.audit("users:delete:%s" % user["username"], session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True})

    def api_users_password(self):
        """Réinitialisation du mot de passe d'un autre compte (et, en option, de sa double authentification)."""
        session = self.require_session(write=True)
        data = self.read_json()
        user = self.user_target(data, session, "Changez votre propre mot de passe dans « Changer le mot de passe ».")
        password = data.get("password")
        reset_totp = data.get("totp_reset") is True
        if password is not None:
            problem = security.password_problem(password)
            if problem:
                raise ApiError(HTTPStatus.BAD_REQUEST, problem)
            self.ctx.db.update_account(user["username"], password_hash=security.hash_password(password))
            self.ctx.db.audit("users:password:%s" % user["username"], session["username"], self.remote)
        elif not reset_totp:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.")
        if reset_totp:
            self.ctx.db.update_account(user["username"], totp_secret=None, totp_pending=None, recovery=None, totp_last=0)
            self.ctx.db.audit("users:totp-reset:%s" % user["username"], session["username"], self.remote)
        self.ctx.sessions.delete_user(user["username"])
        self.send_json(HTTPStatus.OK, {"ok": True})

    # ------------------------------------------------------- certificat HTTPS
    TLS_MAX_PEM = 48 * 1024
    PEM_CERT_RE = re.compile(r"-----BEGIN CERTIFICATE-----[A-Za-z0-9+/=\s]+-----END CERTIFICATE-----")
    PEM_KEY_RE = re.compile(r"-----BEGIN (RSA |EC )?PRIVATE KEY-----[A-Za-z0-9+/=\s]+-----END (RSA |EC )?PRIVATE KEY-----")

    def api_tls(self):
        self.require_session()
        try:
            with open(self.ctx.tls_status, "r", encoding="utf-8") as handle:
                status = json.load(handle)
        except (OSError, ValueError):
            status = None
        out = {"current": None, "last": None}
        if isinstance(status, dict):
            cur = status.get("current") if isinstance(status.get("current"), dict) else None
            if cur:
                out["current"] = {k: (str(cur[k])[:300] if isinstance(cur.get(k), str) else cur.get(k))
                                  for k in ("subject", "issuer", "not_before", "not_after", "expires", "self_signed",
                                            "names", "fingerprint", "chain", "days_left", "source")
                                  if k in cur}
            last = status.get("last") if isinstance(status.get("last"), dict) else None
            if last:
                out["last"] = {"ok": last.get("ok") is True, "ts": last.get("ts") if isinstance(last.get("ts"), (int, float)) else None,
                               "message": str(last.get("message") or "")[:400],
                               "warnings": [str(w)[:200] for w in last.get("warnings", []) if isinstance(w, str)][:5]
                               if isinstance(last.get("warnings"), list) else []}
        out["pending"] = os.path.isdir(self.ctx.tls_upload) and bool(os.listdir(self.ctx.tls_upload))
        self.send_json(HTTPStatus.OK, out)

    def tls_drop(self, files):
        """Dépôt pour voipbuntu-tls (root) : fichiers lus puis effacés par l'outil."""
        os.makedirs(self.ctx.tls_upload, mode=0o700, exist_ok=True)
        for name in os.listdir(self.ctx.tls_upload):
            os.unlink(os.path.join(self.ctx.tls_upload, name))
        old = os.umask(0o077)
        try:
            for name, content in files.items():
                path = os.path.join(self.ctx.tls_upload, name)
                with open(path + ".tmp", "wb") as handle:
                    handle.write(content)
                os.replace(path + ".tmp", path)
        finally:
            os.umask(old)

    def tls_submit(self, session):
        try:
            self.ctx.worker.submit("tls-apply", session["username"])
            return True
        except WorkerUnavailable:
            return False

    def api_tls_import(self):
        """Certificat de l'entreprise : PEM (certificat, chaîne, clé) ou PKCS#12 avec mot de passe."""
        import base64
        import binascii
        session = self.require_session(write=True)
        data = self.read_json()
        fmt = data.get("format")
        if fmt == "pem":
            cert, key = data.get("cert"), data.get("key")
            if not isinstance(cert, str) or not isinstance(key, str) or len(cert) > self.TLS_MAX_PEM or len(key) > self.TLS_MAX_PEM:
                raise ApiError(HTTPStatus.BAD_REQUEST, "Collez le certificat et la clé au format PEM.")
            if "ENCRYPTED" in key:
                raise ApiError(HTTPStatus.BAD_REQUEST, "La clé privée est protégée par un mot de passe : exportez-la sans mot de passe, ou envoyez un fichier PKCS#12.")
            if not self.PEM_CERT_RE.search(cert):
                raise ApiError(HTTPStatus.BAD_REQUEST, "Certificat PEM introuvable (-----BEGIN CERTIFICATE-----).")
            if not self.PEM_KEY_RE.search(key):
                raise ApiError(HTTPStatus.BAD_REQUEST, "Clé privée PEM introuvable (-----BEGIN PRIVATE KEY-----).")
            files = {"cert.pem": cert.encode("ascii", "replace"), "key.pem": key.encode("ascii", "replace")}
        elif fmt == "p12":
            blob, password = data.get("p12"), data.get("password", "")
            if not isinstance(blob, str) or not isinstance(password, str) or len(password) > 256 or len(blob) > self.TLS_MAX_PEM:
                raise ApiError(HTTPStatus.BAD_REQUEST, "Fichier PKCS#12 invalide ou trop volumineux.")
            try:
                raw = base64.b64decode(blob, validate=True)
            except (ValueError, binascii.Error):
                raise ApiError(HTTPStatus.BAD_REQUEST, "Fichier PKCS#12 invalide ou trop volumineux.") from None
            if not raw or raw[0] != 0x30:
                raise ApiError(HTTPStatus.BAD_REQUEST, "Fichier PKCS#12 invalide ou trop volumineux.")
            files = {"bundle.p12": raw, "p12.pass": password.encode("utf-8")}
        else:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Requête invalide.")
        self.tls_drop(files)
        self.ctx.db.audit("tls:import:%s" % fmt, session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": self.tls_submit(session)})

    def api_tls_reset(self):
        """Retour au certificat auto-signé de l'appliance."""
        session = self.require_session(write=True)
        self.tls_drop({"reset": b"1"})
        self.ctx.db.audit("tls:reset-self-signed", session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": self.tls_submit(session)})

    def api_tls_refresh(self):
        """Relit le certificat en service (état absent après une mise à jour)."""
        session = self.require_session(write=True)
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": self.tls_submit(session)})

    # ------------------------------------------- annuaire LDAP des téléphones (N670, Yealink, Snom…)
    def ldap_payload(self, settings):
        state = self.pbx_load()
        phone_nets = pbx.read_phone_nets(self.ctx.appliance_conf)
        return {"enabled": settings["enabled"], "anonymous": settings["anonymous"],
                "has_account": bool(settings["bind_hash"]),
                "servers": pbx.sip_servers(sysinfo.ip_addresses(), phone_nets), "phone_nets": bool(phone_nets.split()),
                "port": directory.LDAP_PORT, "base_dn": directory.LDAP_BASE_DN, "bind_dn": directory.LDAP_BIND_DN,
                "name_filter": directory.LDAP_NAME_FILTER, "number_filter": directory.LDAP_NUMBER_FILTER,
                "contacts": len(state["directory"]["contacts"]), "extensions": len(state["extensions"])}

    def ldap_load(self):
        try:
            return directory.ldap_load(self.ctx.ldap_settings)
        except directory.DirectoryError:
            raise ApiError(HTTPStatus.INTERNAL_SERVER_ERROR, "Réglages de l'annuaire LDAP illisibles.") from None

    def ldap_account(self, settings):
        """Nouveau mot de passe du compte de lecture : empreinte pour le serveur, copie chiffrée pour root."""
        password = directory.ldap_new_password()
        try:
            secret = backupcopy.encrypt(password, self.ctx.secrets_key)
        except backupcopy.CopyError:
            raise ApiError(HTTPStatus.INTERNAL_SERVER_ERROR, "Clé de chiffrement de l'appliance absente.") from None
        settings.update(bind_hash=security.hash_password(password), bind_secret=secret)
        return password

    def ldap_commit(self, settings, session, event, password=None):
        try:
            settings = directory.ldap_save(settings, self.ctx.ldap_settings)
        except directory.DirectoryError:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Réglages de l'annuaire LDAP invalides.") from None
        self.ctx.db.audit(event, session["username"], self.remote)
        try:
            self.ctx.worker.submit("ldap-apply", session["username"])
            applied = True
        except WorkerUnavailable:
            applied = False
        payload = dict(self.ldap_payload(settings), ok=True, applied=applied)
        if password:
            payload["password"] = password  # affiché une seule fois : seule l'empreinte est gardée en clair
        self.send_json(HTTPStatus.OK, payload)

    def api_directory_ldap(self):
        self.require_session()
        self.send_json(HTTPStatus.OK, self.ldap_payload(self.ldap_load()))

    def api_directory_ldap_save(self):
        session = self.require_session(write=True)
        data = self.read_json()
        enabled, anonymous = data.get("enabled"), data.get("anonymous", False)
        if not isinstance(enabled, bool) or not isinstance(anonymous, bool):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Réglages de l'annuaire LDAP invalides.")
        settings = self.ldap_load()
        settings.update(enabled=enabled, anonymous=anonymous)
        password = self.ldap_account(settings) if enabled and not settings["bind_hash"] else None
        self.ldap_commit(settings, session, "directory:ldap:%s:anonyme=%s%s" % (
            "on" if enabled else "off", "oui" if anonymous else "non", ":compte-créé" if password else ""), password)

    def api_directory_ldap_password(self):
        session = self.require_session(write=True)
        self.read_json()
        settings = self.ldap_load()
        password = self.ldap_account(settings)
        self.ldap_commit(settings, session, "directory:ldap:password-renewed", password)

    # --------------------------------------------- appareils découverts (auto-découverte)
    def discovery_path(self):
        return os.path.join(os.path.dirname(os.path.abspath(self.ctx.pbx_state)), "discovery.json")

    def discovery_load(self):
        try:
            with open(self.discovery_path(), "r", encoding="utf-8") as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            return []
        items = data.get("ignored") if isinstance(data, dict) else None
        return [i for i in items if isinstance(i, dict) and pbx.SIP_ID_RE.match(str(i.get("user", "")))
                and isinstance(i.get("address"), str) and len(i["address"]) <= 45][:MAX_IGNORED] if isinstance(items, list) else []

    def discovery_ignored(self):
        return {(i["user"].lower(), i["address"]) for i in self.discovery_load()}

    def api_pbx_discovered_ignore(self):
        """Écarte (ou reprend) un appareil découvert : il n'est plus proposé à l'ajout."""
        session = self.require_session(write=True)
        data = self.read_json()
        user, address = str(data.get("user", "")).strip(), str(data.get("address", "")).strip()
        if not pbx.SIP_ID_RE.match(user) or not pbx.is_ip(address):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Appareil invalide.")
        items = [i for i in self.discovery_load() if (i["user"].lower(), i["address"]) != (user.lower(), address)]
        ignore = data.get("ignore", True) is not False
        if ignore:
            items.append({"user": user, "address": address, "ts": int(time.time())})
        items = items[-MAX_IGNORED:]
        path = self.discovery_path()
        try:
            fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), prefix=".discovery.")
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump({"ignored": items}, handle)
            os.replace(tmp, path)
        except OSError:
            raise ApiError(HTTPStatus.INTERNAL_SERVER_ERROR, "Enregistrement impossible.") from None
        self.ctx.db.audit(("pbx:discovery:ignore:" if ignore else "pbx:discovery:restore:") + user + "@" + address,
                          session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True})

    # --------------------------------------------- provisionnement des téléphones SIP
    def prov_path(self):
        return os.path.join(os.path.dirname(os.path.abspath(self.ctx.pbx_state)), "provisioning.json")

    def prov_load(self):
        try:
            return provisioning.load(self.prov_path())
        except provisioning.ProvisioningError:
            raise ApiError(HTTPStatus.INTERNAL_SERVER_ERROR, "Provisionnement illisible.") from None

    @staticmethod
    def prov_error(exc):
        text = str(exc)
        if "MAC déjà associée au poste" in text:
            return ApiError(HTTPStatus.CONFLICT, "Cette adresse MAC est déjà associée à un autre poste.")
        if "adresse MAC" in text:
            return ApiError(HTTPStatus.BAD_REQUEST, "Adresse MAC invalide : 12 chiffres hexadécimaux, par exemple 80:5E:C0:12:34:56.")
        if "marque" in text:
            return ApiError(HTTPStatus.BAD_REQUEST, "Marque inconnue : Yealink, Snom, Grandstream ou Fanvil.")
        if "modèle" in text:
            return ApiError(HTTPStatus.BAD_REQUEST, "Modèle invalide : lettres, chiffres et tirets, 24 caractères au plus.")
        if "serveur NTP" in text:
            return ApiError(HTTPStatus.BAD_REQUEST, "Serveur NTP invalide : nom ou adresse IP.")
        if "adresse du serveur" in text:
            return ApiError(HTTPStatus.BAD_REQUEST, "Adresse de l'appliance invalide : nom ou adresse IP.")
        if "introuvable" in text:
            return ApiError(HTTPStatus.NOT_FOUND, "Téléphone introuvable.")
        return ApiError(HTTPStatus.BAD_REQUEST, "Provisionnement invalide.")

    def prov_server(self, state):
        if state["server"]:
            return state["server"]
        servers = pbx.sip_servers(sysinfo.ip_addresses(), pbx.read_phone_nets(self.ctx.appliance_conf))
        return servers[0] if servers else ""

    def prov_commit(self, state, username, event):
        try:
            provisioning.save(state, self.prov_path())
        except provisioning.ProvisioningError as exc:
            raise self.prov_error(exc) from None
        self.ctx.db.audit(event[:200], username, self.remote)
        try:
            self.ctx.worker.submit("provision-apply", username)
            return True
        except WorkerUnavailable:
            return False

    def prov_credentials(self, state, mac, password, applied):
        """Identifiants du téléphone : montrés une seule fois, seule l'empreinte est gardée."""
        host = self.prov_server(state)
        links = provisioning.urls(host, state["http"])
        out = {"ok": True, "applied": applied, "user": mac, "password": password, "urls": links}
        if links:
            out["url_with_credentials"] = links["https"].replace("https://", "https://%s:%s@" % (mac, password), 1)
        return out

    def api_provisioning(self):
        self.require_session()
        state = self.prov_load()
        exts = {e["number"]: e for e in self.pbx_load()["extensions"]}
        view = provisioning.public(state, set(exts))
        for p in view["phones"]:
            p["name"] = exts[p["number"]]["name"] if p["number"] in exts else ""
        host = self.prov_server(state)
        view["server"] = host
        view["default_ntp"] = provisioning.DEFAULT_NTP
        view["urls"] = provisioning.urls(host, state["http"])
        view["phone_nets"] = pbx.read_phone_nets(self.ctx.appliance_conf)
        view["extensions"] = [{"number": e["number"], "name": e["name"]} for e in exts.values()]
        self.send_json(HTTPStatus.OK, view)

    def api_provisioning_save(self):
        """Associe un téléphone (marque, modèle, MAC) à un poste ; un nouvel appareil remplace l'ancien."""
        session = self.require_session(write=True)
        data = self.read_json()
        number = str(data.get("number", ""))
        if number not in {e["number"] for e in self.pbx_load()["extensions"]}:
            raise ApiError(HTTPStatus.NOT_FOUND, "Poste introuvable.")
        state = self.prov_load()
        try:
            state, password = provisioning.associate(state, number, str(data.get("vendor", "")),
                                                     str(data.get("model", "")), data.get("mac"))
        except provisioning.ProvisioningError as exc:
            raise self.prov_error(exc) from None
        phone = next(p for p in state["phones"] if p["number"] == number)
        applied = self.prov_commit(state, session["username"], "provisioning:associate:%s:%s:%s" % (
            number, phone["vendor"], phone["mac"]))
        self.send_json(HTTPStatus.OK, self.prov_credentials(state, phone["mac"], password, applied))

    def prov_find(self, state, data):
        try:
            mac = provisioning.normalize_mac(data.get("mac"))
        except provisioning.ProvisioningError as exc:
            raise self.prov_error(exc) from None
        if not any(p["mac"] == mac for p in state["phones"]):
            raise ApiError(HTTPStatus.NOT_FOUND, "Téléphone introuvable.")
        return mac

    def api_provisioning_delete(self):
        session = self.require_session(write=True)
        data = self.read_json()
        state = self.prov_load()
        mac = self.prov_find(state, data)
        state["phones"] = [p for p in state["phones"] if p["mac"] != mac]
        applied = self.prov_commit(state, session["username"], "provisioning:delete:" + mac)
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied})

    def api_provisioning_renew(self):
        """Nouveau mot de passe de provisionnement, à ressaisir dans le téléphone."""
        session = self.require_session(write=True)
        data = self.read_json()
        state = self.prov_load()
        mac = self.prov_find(state, data)
        state, password = provisioning.renew(state, mac)
        applied = self.prov_commit(state, session["username"], "provisioning:renew:" + mac)
        self.send_json(HTTPStatus.OK, self.prov_credentials(state, mac, password, applied))

    def api_provisioning_settings(self):
        session = self.require_session(write=True)
        data = self.read_json()
        state = self.prov_load()
        try:
            settings = provisioning.validate_settings(data)
        except provisioning.ProvisioningError as exc:
            raise self.prov_error(exc) from None
        state.update(settings)
        applied = self.prov_commit(state, session["username"], "provisioning:settings:http=%s:serveur=%s:ntp=%s" % (
            "on" if settings["http"] else "off", settings["server"] or "auto", settings["ntp"] or "auto"))
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied})

    def api_provisioning_log(self):
        """Téléchargements des fichiers par les téléphones (journal nginx lu par la file d'attente)."""
        self.require_session()
        try:
            data = self.ctx.worker.logs("provisioning")
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None
        lines = data.get("lines") if isinstance(data.get("lines"), list) else []
        entries = provisioning.read_entries(lines)
        state = self.prov_load()
        by_mac = {p["mac"]: p["number"] for p in state["phones"]}
        for e in entries:
            e["number"] = by_mac.get(e["mac"], "")
        self.send_json(HTTPStatus.OK, {"entries": entries, "error": bool(data.get("error"))})

    def api_pbx_delete_provisioned(self):
        """Suppression d'un poste : son téléphone associé est dissocié (ses fichiers partent avec pbx-apply)."""
        Handler.api_pbx_delete(self)
        try:
            state = provisioning.load(self.prov_path())
            numbers = {e["number"] for e in pbx.load(self.ctx.pbx_state)["extensions"]}
        except (provisioning.ProvisioningError, pbx.PbxError):
            return
        state, dropped = provisioning.prune(state, numbers)
        if dropped:
            provisioning.save(state, self.prov_path())
            session = self.current_session()
            self.ctx.db.audit("provisioning:delete-with-extension:%d" % dropped,
                              session["username"] if session else "?", self.remote)


class QueueHandlers:
    """Lot I : files d'attente, enregistrement des appels et diagnostic SIP (méthodes ajoutées à Handler)."""

    def api_pbx_queues(self):
        """Files d'attente : la liste complète est remplacée. Les touches du menu vers une file retirée sont coupées."""
        session = self.require_session(write=True)
        queues = self.read_json().get("queues")
        if not isinstance(queues, list):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Liste de files invalide.")
        state = self.pbx_load()
        kept = {str(q.get("number", "")) for q in queues if isinstance(q, dict)}
        pbx.drop_ivr_targets(state, {q["number"] for q in state["queues"] if q["number"] not in kept})
        state["queues"] = queues
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        applied = self.pbx_commit(state, session["username"], "pbx:queues:%d" % len(state["queues"]))
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "queues": state["queues"]})

    def api_pbx_recording(self):
        """Enregistrement : postes enregistrés et durée de conservation (les files ont leur propre case)."""
        session = self.require_session(write=True)
        data = self.read_json()
        numbers = data.get("extensions")
        if not isinstance(numbers, list):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Liste de postes invalide.")
        state = self.pbx_load()
        wanted = {str(n) for n in numbers}
        if wanted - {e["number"] for e in state["extensions"]}:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Poste inconnu.")
        for e in state["extensions"]:
            e["record"] = e["number"] in wanted
        state["recording"] = {"keep_days": data.get("keep_days", state["recording"]["keep_days"])}
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        event = "pbx:recording:%s:garder=%d" % (",".join(sorted(wanted)) or "aucun", state["recording"]["keep_days"])
        applied = self.pbx_commit(state, session["username"], event[:200])
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "recording": state["recording"]})

    def announce_present(self):
        try:
            with open(self.ctx.sounds_status, "r", encoding="utf-8") as handle:
                rec = json.load(handle).get("sounds", {}).get("enregistrement", {})
        except (OSError, ValueError, AttributeError):
            return False
        return isinstance(rec, dict) and rec.get("present") is True

    def api_recordings(self):
        """Liste des enregistrements : admin uniquement (conversations des appelants)."""
        self.require_admin()
        try:
            data = self.ctx.worker.recordings()
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None
        items = []
        for r in data.get("recordings") if isinstance(data.get("recordings"), list) else []:
            if isinstance(r, dict) and pbx.RECORDING_RE.match(str(r.get("name", ""))):
                items.append({k: r.get(k) for k in ("name", "size", "start", "caller", "target", "expires")})
        self.send_json(HTTPStatus.OK, {"recordings": items[:500], "total": data.get("total", len(items)),
                                       "announce": self.announce_present(), "error": bool(data.get("error"))})

    def stream_worker_file(self, kind, name, ctype, filename, inline=False):
        try:
            size, chunks = self.ctx.worker.open_file(kind, name)
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None
        if size is None:
            raise ApiError(HTTPStatus.NOT_FOUND, "Fichier introuvable.")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Disposition", '%s; filename="%s"' % ("inline" if inline else "attachment", filename))
        self.send_header("Content-Length", str(size))
        self.send_header("Cache-Control", "no-store")
        self.security_headers()
        self.end_headers()
        for chunk in chunks:
            if self.command != "HEAD":
                self.wfile.write(chunk)

    def api_recordings_file(self):
        """Écoute (?play=1) ou téléchargement d'un enregistrement : admin, chaque accès est audité."""
        session = self.require_admin()
        query = parse_qs(urlsplit(self.path).query)
        name = (query.get("name") or [""])[0]
        if not pbx.RECORDING_RE.match(name):
            raise ApiError(HTTPStatus.NOT_FOUND, "Fichier introuvable.")
        play = (query.get("play") or [""])[0] == "1"
        self.ctx.db.audit("recording:%s:%s" % ("listen" if play else "download", name), session["username"], self.remote)
        self.stream_worker_file("recording", name, "audio/wav", name, inline=play)

    def api_diagnostic(self):
        """Diagnostic SIP : état de la capture ou de la trace en cours, derniers fichiers (admin)."""
        self.require_admin()
        try:
            live = self.ctx.worker.capture_status()
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None
        out = {k: live.get(k) for k in ("state", "kind", "minutes", "number", "started", "ends", "ended", "reason",
                                         "size", "max_bytes", "tcpdump")}
        out["error"] = str(live["error"])[:200] if live.get("error") else None
        files = live.get("files") if isinstance(live.get("files"), dict) else {}
        out["files"] = {k: files.get(k) if isinstance(files.get(k), dict) else None for k in ("capture", "trace")}
        self.send_json(HTTPStatus.OK, out)

    def api_diagnostic_start(self):
        """Lance une capture (1 à 10 minutes) ou la trace SIP d'un poste : demande revalidée en root."""
        session = self.require_session(write=True)
        data = self.read_json()
        kind = data.get("kind")
        minutes = data.get("minutes")
        if kind not in ("capture", "trace") or not isinstance(minutes, int) or isinstance(minutes, bool) \
                or not 1 <= minutes <= 10:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Durée invalide : de 1 à 10 minutes.")
        request = {"kind": kind, "minutes": minutes}
        if kind == "trace":
            number = str(data.get("number", ""))
            if number not in {e["number"] for e in self.pbx_load()["extensions"]}:
                raise ApiError(HTTPStatus.BAD_REQUEST, "Poste inconnu.")
            request["number"] = number
        tmp = self.ctx.capture_request + ".tmp"
        old = os.umask(0o077)
        try:
            with open(tmp, "w", encoding="utf-8") as handle:
                json.dump(request, handle)
            os.replace(tmp, self.ctx.capture_request)
        finally:
            os.umask(old)
        try:
            result = self.ctx.worker.submit("capture-start", session["username"])
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None
        self.ctx.db.audit(("diagnostic:%s:%dmin%s" % (kind, minutes, ":" + request["number"] if kind == "trace" else ""))[:200],
                          session["username"], self.remote)
        self.send_json(HTTPStatus.ACCEPTED, result)

    def api_diagnostic_stop(self):
        session = self.require_session(write=True)
        try:
            result = self.ctx.worker.submit("capture-stop", session["username"])
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None
        self.ctx.db.audit("diagnostic:stop", session["username"], self.remote)
        self.send_json(HTTPStatus.ACCEPTED, result)

    def api_diagnostic_file(self):
        """Téléchargement du pcap (Wireshark) : admin, audité."""
        session = self.require_admin()
        kind = (parse_qs(urlsplit(self.path).query).get("kind") or [""])[0]
        if kind not in ("capture", "trace"):
            raise ApiError(HTTPStatus.NOT_FOUND, "Fichier introuvable.")
        self.ctx.db.audit("diagnostic:download:%s" % kind, session["username"], self.remote)
        self.stream_worker_file(kind, "", "application/vnd.tcpdump.pcap",
                                "voipbuntu-%s-%s.pcap" % (kind, time.strftime("%Y%m%d-%H%M")))


class LiveHandlers:
    """Lot K : supervision en direct (instantané de voipbuntu-live, jamais l'AMI elle-même)."""

    def live_view(self):
        snapshot = live.read_snapshot(getattr(self.ctx, "live_snapshot", live.SNAPSHOT))
        return live.build(snapshot, self.pbx_load())

    def api_live(self):
        """Appels en cours, état des postes et des files : lisible par un compte lecture (panneau mural)."""
        session = self.require_session()
        view = self.live_view()
        view["can_hangup"] = session.get("role") == "admin"
        view["refresh"] = 3
        self.send_json(HTTPStatus.OK, view)

    def api_live_hangup(self):
        """Raccrocher un appel en cours : admin, audité, exécuté en root par la file d'attente."""
        session = self.require_session(write=True)
        data = self.read_json()
        call_id = data.get("call")
        if not isinstance(call_id, str) or not live.CALL_ID_RE.match(call_id):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Appel inconnu.")
        call = next((c for c in self.live_view()["calls"] if c["id"] == call_id), None)
        if call is None:
            raise ApiError(HTTPStatus.NOT_FOUND, "Appel terminé ou inconnu.")
        live.write_request(getattr(self.ctx, "live_request", live.REQUEST), call_id)
        try:
            result = self.ctx.worker.submit("live-hangup", session["username"])
        except WorkerUnavailable:
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE, "File d'attente indisponible.") from None
        self.ctx.db.audit(("live:hangup:%s:%s->%s" % (call_id, call["caller"], call["callee"]))[:200],
                          session["username"], self.remote)
        self.send_json(HTTPStatus.ACCEPTED, result)


for _name, _func in vars(LiveHandlers).items():
    if _name.startswith(("api_", "live_")):
        setattr(Handler, _name, _func)
STATIC_PAGES = {"/mural": "/mural.html"}


for _name, _func in vars(QueueHandlers).items():
    if _name.startswith(("api_", "announce_", "stream_")):
        setattr(Handler, _name, _func)


class MaintenanceHandlers:
    """Lot L : fenêtre de maintenance, retour arrière, mises à jour de sécurité, archive de support."""

    def maintenance_update_state(self):
        try:
            with open(self.ctx.update_state, "r", encoding="utf-8") as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            return {}
        return data if isinstance(data, dict) else {}

    def api_maintenance(self):
        self.require_session()
        settings = maintenance.load_settings(self.ctx.maintenance_settings)
        st = maintenance.load_state(self.ctx.maintenance_state)
        upd = self.maintenance_update_state()
        vre = re.compile(r"^\d+\.\d+\.\d+$")

        def text(v, n=300):
            return v[:n] if isinstance(v, str) else None

        def num(v):
            return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None

        rb = upd.get("rollback") if isinstance(upd.get("rollback"), dict) else None
        rollback = {"version": rb["version"], "created": num(rb.get("created"))} \
            if rb and isinstance(rb.get("version"), str) and vre.match(rb["version"]) else None
        w = upd.get("watch") if isinstance(upd.get("watch"), dict) else None
        watch = None
        if w and w.get("status") in ("pending", "confirmed", "rolled-back"):
            watch = {"status": w["status"], "version": text(w.get("version"), 20), "previous": text(w.get("previous"), 20),
                     "started": num(w.get("started")), "deadline": num(w.get("deadline")), "ended": num(w.get("ended")),
                     "reason": text(w.get("reason")), "auto": bool(w.get("auto"))}
        sec = st.get("security") if isinstance(st.get("security"), dict) else None
        security = None
        if sec:
            pkgs = [{"name": text(p.get("name"), 80), "from": text(p.get("from"), 80), "to": text(p.get("to"), 80)}
                    for p in (sec.get("packages") or [])[:200] if isinstance(p, dict)]
            security = {"ran": num(sec.get("ran")), "ok": bool(sec.get("ok")), "packages": pkgs, "error": text(sec.get("error"))}
        win = st.get("window") if isinstance(st.get("window"), dict) else None
        window = None
        if win:
            window = {"id": text(win.get("id"), 20), "started": num(win.get("started")), "ended": num(win.get("ended")),
                      "running": bool(win.get("running")), "mail_error": text(win.get("mail_error")),
                      "steps": [{"what": text(x.get("what")), "ok": bool(x.get("ok")), "detail": text(x.get("detail"), 500)}
                                for x in (win.get("steps") or [])[:20] if isinstance(x, dict)]}
        history = [{"ts": num(h.get("ts")), "kind": h.get("kind") if h.get("kind") in ("window", "security", "reboot") else "",
                    "ok": bool(h.get("ok")), "detail": text(h.get("detail"))}
                   for h in reversed((st.get("history") or [])[-20:]) if isinstance(h, dict)]
        sup = st.get("support") if isinstance(st.get("support"), dict) else None
        reboot_pkgs = []
        try:
            with open(self.ctx.reboot_required + ".pkgs", "r", encoding="utf-8") as handle:
                reboot_pkgs = sorted({l.strip() for l in handle if re.match(r"^[a-z0-9][a-z0-9+.-]*$", l.strip())})[:50]
        except OSError:
            pass
        try:
            mail = pbx.load(self.ctx.pbx_state)["mail"]["enabled"]
        except pbx.PbxError:
            mail = False
        t = time.time()
        reboot_at = settings.get("reboot_at")
        self.send_json(HTTPStatus.OK, {
            "settings": settings, "next_window": maintenance.next_window(settings, t),
            "reboot_planned": reboot_at if reboot_at and reboot_at > t - 60 and st.get("reboot_done") != reboot_at else None,
            "reboot_required": os.path.exists(self.ctx.reboot_required), "reboot_packages": reboot_pkgs,
            "rollback": rollback, "watch": watch, "skip": text(upd.get("skip"), 20),
            "security": security, "window": window, "history": history, "last_tick": num(st.get("last_tick")),
            "support": {"created": num(sup.get("created")), "size": num(sup.get("size"))} if sup else None,
            "mail_enabled": mail, "recipients": len(alerts.load_settings(self.ctx.alerts_settings)["recipients"])})

    def api_maintenance_save(self):
        session = self.require_session(write=True)
        data = self.read_json()
        current = maintenance.load_settings(self.ctx.maintenance_settings)
        data = dict(data, reboot_at=current.get("reboot_at")) if isinstance(data, dict) else data
        try:
            settings = maintenance.validate_settings(data)
        except maintenance.MaintenanceError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, str(exc)) from None
        backup.write_json(self.ctx.maintenance_settings, settings)
        event = "maintenance:settings:jours=%s:%s:%dh:%s" % (
            "".join(str(d) for d in settings["days"]) or "aucun", settings["start"], settings["hours"],
            ",".join(k for k in ("auto_update", "security", "reboot", "notify") if settings[k]) or "rien")
        self.ctx.db.audit(event[:200], session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "settings": settings,
                                       "next_window": maintenance.next_window(settings, time.time())})

    def api_maintenance_reboot(self):
        """Redémarrage planifié (une fois) : date dans les 30 jours, ou null pour l'annuler."""
        session = self.require_session(write=True)
        at = self.read_json().get("at")
        t = time.time()
        if at is not None and (not isinstance(at, int) or isinstance(at, bool) or at < t + 60
                               or at > t + maintenance.REBOOT_HORIZON):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Date de redémarrage invalide : dans les 30 prochains jours.")
        settings = maintenance.load_settings(self.ctx.maintenance_settings)
        settings["reboot_at"] = at
        backup.write_json(self.ctx.maintenance_settings, maintenance.validate_settings(settings))
        self.ctx.db.audit("maintenance:reboot:%s" % (time.strftime("%Y-%m-%dT%H:%M", time.localtime(at)) if at else "annulé"),
                          session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "reboot_planned": at})

    def api_support_file(self):
        """Archive de diagnostic préparée par root (sans secret) : administrateurs, téléchargement audité."""
        session = self.require_admin()
        self.ctx.db.audit("support:download", session["username"], self.remote)
        self.stream_worker_file("support", "", "application/gzip", "voipbuntu-support-%s.tar.gz" % time.strftime("%Y%m%d-%H%M"))


for _name, _func in vars(MaintenanceHandlers).items():
    if _name.startswith(("api_", "maintenance_")):
        setattr(Handler, _name, _func)


class ADHandlers:
    """Lot M : Active Directory (connexion par groupe AD, import des contacts, postes proposés).

    Méthodes ajoutées à Handler. La console ne voit jamais le mot de passe du compte de service :
    elle le chiffre avec secrets.key à l'enregistrement, seul root (voipbuntu-adsync) le déchiffre.
    """

    AD_KEYS = ("enabled", "hosts", "mode", "port", "domain", "base_dn", "admin_group", "read_group", "bind_user",
               "ca_pem", "import_enabled", "contacts_ou", "propose_extensions")

    def ad_load(self):
        try:
            return adsync.load(self.ctx.ad_settings)
        except adsync.AdError:
            raise ApiError(HTTPStatus.INTERNAL_SERVER_ERROR, "Réglages Active Directory illisibles.") from None

    def ad_login_settings(self):
        """Réglages si la connexion par l'AD est activée, sinon None (comptes locaux seuls)."""
        try:
            settings = adsync.load(self.ctx.ad_settings)
        except adsync.AdError:
            LOG.warning("réglages Active Directory illisibles : connexion par l'AD coupée")
            return None
        return settings if settings["enabled"] else None

    @staticmethod
    def ad_local_name(settings, username):
        sam, _ = adsync.login_name(settings, username)
        return sam or username

    def login_ad(self, ad, username, password, keys, user):
        try:
            found = adsync.authenticate(ad, username, password, chain_path=self.ctx.ad_chain)
        except adsync.BadCredentials:
            self.ctx.throttle.failure(keys)
            self.ctx.db.audit("login-failed", username, self.remote)
            raise ApiError(HTTPStatus.UNAUTHORIZED, "Identifiant ou mot de passe incorrect.") from None
        except adsync.AdError as exc:
            LOG.warning("connexion par l'Active Directory impossible : %s", exc)
            self.ctx.db.audit("login-ad-unreachable", username, self.remote)
            raise ApiError(HTTPStatus.SERVICE_UNAVAILABLE,
                           "Active Directory injoignable : connectez-vous avec un compte local.") from None
        name, role = found["username"], found["role"]
        if not USERNAME_RE.match(name):
            raise ApiError(HTTPStatus.FORBIDDEN, "Identifiant AD incompatible avec la console : minuscules, chiffres, point, tiret.")
        if name != username:
            user = self.ctx.db.get_account(name)
            if user is not None and user.get("source") != "ad":
                raise ApiError(HTTPStatus.UNAUTHORIZED, "Identifiant ou mot de passe incorrect.")
        if role is None:
            self.ctx.db.audit("login-ad-refused:hors-groupe", name, self.remote)
            raise ApiError(HTTPStatus.FORBIDDEN, "Ce compte Active Directory n'appartient à aucun groupe autorisé sur la console.")
        if user is None:
            self.ctx.db.create_ad_account(name, role)
            self.ctx.db.audit("users:create-ad:%s:%s" % (name, role), name, self.remote)
            user = self.ctx.db.get_account(name)
        elif user["disabled"]:
            self.ctx.throttle.failure(keys)
            self.ctx.db.audit("login-failed", name, self.remote)
            raise ApiError(HTTPStatus.UNAUTHORIZED, "Identifiant ou mot de passe incorrect.")
        elif user["role"] != role:
            self.ctx.db.update_account(name, role=role)
            self.ctx.db.audit("users:role-ad:%s:%s" % (name, role), name, self.remote)
        if user["totp_secret"]:
            self.send_json(HTTPStatus.OK, {"totp_required": True, "ticket": self.login_ticket(name)})
            return
        self.login_done(name, keys, "login-ad:%s" % role)

    def ad_check_password(self, username, password):
        """Mot de passe actuel d'un compte AD (activation de la double authentification)."""
        settings = self.ad_login_settings()
        if not settings:
            return False
        try:
            found = adsync.authenticate(settings, username, password, chain_path=self.ctx.ad_chain)
        except adsync.AdError:
            return False
        return found["username"] == username and found["role"] is not None

    def ad_payload(self, settings):
        status = adsync.load_status(self.ctx.ad_dir)
        state = self.pbx_load()
        used = {e["number"] for e in state["extensions"] + state["groups"]}
        offers = [p for p in status.get("proposals") or [] if isinstance(p, dict) and str(p.get("number")) not in used]
        accounts = [a for a in self.ctx.db.list_accounts() if a.get("source") == "ad"]
        last = {}
        for key in ("sync", "test"):
            item = status.get(key)
            if isinstance(item, dict):
                last[key] = {k: item[k] for k in ("ts", "ok", "message", "contacts", "skipped", "truncated", "steps")
                             if k in item}
        return {"settings": adsync.public_view(settings), "sync": last.get("sync"), "test": last.get("test"),
                "proposals": offers[:adsync.MAX_PROPOSALS],
                "ad_contacts": sum(1 for c in state["directory"]["contacts"] if directory.is_ad(c)),
                "accounts": [{"username": a["username"], "role": a["role"], "disabled": bool(a["disabled"]),
                              "last_login": a["last_login"]} for a in accounts],
                "company_chain": len(adsync.company_chain(self.ctx.ad_chain)), "modes": list(adsync.MODES)}

    def api_ad(self):
        self.require_session()
        self.send_json(HTTPStatus.OK, self.ad_payload(self.ad_load()))

    def ad_submit(self, action, session):
        try:
            self.ctx.worker.submit(action, session["username"])
            return True
        except WorkerUnavailable:
            return False

    def api_ad_save(self):
        session = self.require_session(write=True)
        data = self.read_json()
        before = self.ad_load()
        settings = dict(before)
        for key in self.AD_KEYS:
            if key in data:
                settings[key] = data[key]
        password = data.get("password")
        changed_password = False
        if isinstance(password, str) and password:
            if len(password) > 256:
                raise ApiError(HTTPStatus.BAD_REQUEST, "Mot de passe trop long.")
            try:
                settings["bind_secret"] = backupcopy.encrypt(password, self.ctx.secrets_key)
            except backupcopy.CopyError:
                raise ApiError(HTTPStatus.INTERNAL_SERVER_ERROR, "Clé de chiffrement de l'appliance absente.") from None
            changed_password = True
        elif data.get("clear_password") is True:
            settings["bind_secret"] = ""
            changed_password = True
        if settings.get("mode") in adsync.MODES and data.get("mode") and data.get("mode") != before["mode"] \
                and "port" not in data:
            settings["port"] = adsync.DEFAULT_PORTS[settings["mode"]]
        try:
            settings = adsync.save(settings, self.ctx.ad_settings)
        except adsync.AdError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, str(exc)) from None
        self.ctx.db.audit("ad:settings:connexion=%s:import=%s:postes=%s%s" % (
            "on" if settings["enabled"] else "off", "on" if settings["import_enabled"] else "off",
            "on" if settings["propose_extensions"] else "off", ":mot-de-passe" if changed_password else ""),
            session["username"], self.remote)
        if before["enabled"] and not settings["enabled"]:
            for name in self.ctx.db.ad_accounts():  # connexion AD coupée : les sessions AD tombent
                self.ctx.sessions.delete_user(name)
        applied = None
        importing = settings["import_enabled"] or settings["propose_extensions"]
        if importing or before["import_enabled"] or before["propose_extensions"]:
            applied = self.ad_submit("ad-sync", session)
        self.send_json(HTTPStatus.OK, dict(self.ad_payload(settings), ok=True, applied=applied))

    def api_ad_test(self):
        session = self.require_session(write=True)
        self.read_json()
        self.ctx.db.audit("ad:test", session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": self.ad_submit("ad-test", session)})

    def api_ad_sync(self):
        session = self.require_session(write=True)
        self.read_json()
        settings = self.ad_load()
        if not (settings["import_enabled"] or settings["propose_extensions"]):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Activez d'abord l'import des contacts ou les postes proposés.")
        self.ctx.db.audit("ad:sync", session["username"], self.remote)
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": self.ad_submit("ad-sync", session)})

    # Contrôles placés devant les routes existantes (le corps lu reste disponible pour elles)
    AD_CONTACT_LOCKED = "Contact importé de l'Active Directory : modifiez-le dans l'AD, il sera mis à jour à la prochaine synchronisation."

    def ad_contact_ids(self):
        return {c["id"] for c in self.pbx_load()["directory"]["contacts"] if directory.is_ad(c)}

    def api_directory_save_ad(self):
        self.require_session(write=True)
        data = self.read_json()
        if data.get("id") and str(data.get("id")) in self.ad_contact_ids():
            raise ApiError(HTTPStatus.FORBIDDEN, self.AD_CONTACT_LOCKED)
        Handler.api_directory_save(self)

    def api_directory_delete_ad(self):
        self.require_session(write=True)
        data = self.read_json()
        ids = data.get("ids") if isinstance(data.get("ids"), list) else [data.get("id")]
        if {str(i) for i in ids if i} & self.ad_contact_ids():
            raise ApiError(HTTPStatus.FORBIDDEN, self.AD_CONTACT_LOCKED)
        Handler.api_directory_delete(self)

    def ad_target(self):
        data = self.read_json()
        username = data.get("username")
        user = self.ctx.db.get_account(username) if isinstance(username, str) else None
        return data, user if user and user.get("source") == "ad" else None

    def api_users_update_ad(self):
        self.require_session(write=True)
        data, user = self.ad_target()
        if user and "role" in data and data["role"] != user["role"]:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Le rôle d'un compte AD vient de ses groupes dans l'Active Directory.")
        Handler.api_users_update(self)

    def api_users_password_ad(self):
        self.require_session(write=True)
        data, user = self.ad_target()
        if user and data.get("password") is not None:
            raise ApiError(HTTPStatus.BAD_REQUEST, "Le mot de passe d'un compte AD se change dans l'Active Directory.")
        Handler.api_users_password(self)

    def api_password_ad(self):
        session = self.require_session(write=True)
        account = self.ctx.db.get_account(session["username"])
        if account and account.get("source") == "ad":
            raise ApiError(HTTPStatus.BAD_REQUEST, "Le mot de passe d'un compte AD se change dans l'Active Directory.")
        Handler.api_password(self)


for _name, _func in vars(ADHandlers).items():
    if _name.startswith(("api_", "ad_", "login_ad", "AD_")):
        setattr(Handler, _name, _func)


ROUTES = {
    ("POST", "/api/login"): Handler.api_login,
    ("POST", "/api/logout"): Handler.api_logout,
    ("GET", "/api/session"): Handler.api_session,
    ("GET", "/api/status"): Handler.api_status,
    ("GET", "/api/metrics"): Handler.api_metrics,
    ("POST", "/api/password"): Handler.api_password,
    ("GET", "/api/jobs"): Handler.api_jobs_list,
    ("GET", "/api/update"): Handler.api_update,
    ("GET", "/api/pbx"): Handler.api_pbx,
    ("POST", "/api/pbx/extensions"): Handler.api_pbx_create,
    ("POST", "/api/pbx/delete"): Handler.api_pbx_delete,
    ("POST", "/api/pbx/update"): Handler.api_pbx_update,
    ("POST", "/api/pbx/trunk"): Handler.api_pbx_trunk,
    ("POST", "/api/pbx/reception"): Handler.api_pbx_reception,
    ("POST", "/api/pbx/groups"): Handler.api_pbx_groups,
    ("POST", "/api/pbx/forward"): Handler.api_pbx_forward,
    ("POST", "/api/pbx/mail"): Handler.api_pbx_mail,
    ("GET", "/api/backups"): Handler.api_backups,
    ("GET", "/api/backups/file"): Handler.api_backups_file,
    ("POST", "/api/backups/settings"): Handler.api_backups_settings,
    ("POST", "/api/backups/restore"): Handler.api_backups_restore,
    ("GET", "/api/networks"): Handler.api_networks,
    ("POST", "/api/networks"): Handler.api_networks_save,
    ("GET", "/api/system/network"): Handler.api_system_network,
    ("POST", "/api/system/network"): Handler.api_system_network_save,
    ("POST", "/api/system/network/confirm"): Handler.api_system_network_confirm,
    ("POST", "/api/pbx/secret"): Handler.api_pbx_secret,
    ("POST", "/api/pbx/dect-bases"): Handler.api_pbx_dect_base,
    ("POST", "/api/pbx/dect-bases/delete"): Handler.api_pbx_dect_base_delete,
    ("POST", "/api/pbx/dect-bases/sheet"): Handler.api_pbx_dect_base_sheet,
    ("POST", "/api/pbx/dect-bases/handsets"): Handler.api_pbx_dect_handsets,
    ("POST", "/api/pbx/dect-bases/from-extension"): Handler.api_pbx_dect_base_from_extension,
    ("GET", "/api/pbx/calls"): Handler.api_pbx_calls,
    ("GET", "/api/logs"): Handler.api_logs,
    ("GET", "/api/backup"): Handler.api_backup,
    ("POST", "/api/restore"): Handler.api_restore,
    ("POST", "/api/jobs"): Handler.api_jobs_submit,
    ("GET", "/api/audit"): Handler.api_audit,
    ("GET", "/api/alerts"): Handler.api_alerts,
    ("POST", "/api/alerts"): Handler.api_alerts_settings,
}
# Sauvegardes complètes (archive) et copie hors de l'appliance
ROUTES.update({
    ("GET", "/api/backups/archive"): Handler.api_backups_archive,
    ("GET", "/api/backups/copy"): Handler.api_backups_copy,
    ("POST", "/api/backups/copy"): Handler.api_backups_copy_save,
})
ARCHIVE_TYPES = ("application/gzip", "application/x-gzip", "application/octet-stream")
# Accueil vocal : menu « tapez 1 », annonces et musique d'attente
ROUTES.update({
    ("POST", "/api/pbx/ivr"): Handler.api_pbx_ivr,
    ("GET", "/api/sounds"): Handler.api_sounds,
    ("POST", "/api/sounds/upload"): Handler.api_sounds_upload,
    ("POST", "/api/sounds/delete"): Handler.api_sounds_delete,
})
# Comptes, rôles, double authentification et certificat HTTPS
ROUTES.update({
    ("POST", "/api/login/totp"): Handler.api_login_totp,
    ("GET", "/api/account"): Handler.api_account,
    ("POST", "/api/account/totp/setup"): Handler.api_totp_setup,
    ("POST", "/api/account/totp/enable"): Handler.api_totp_enable,
    ("POST", "/api/account/totp/disable"): Handler.api_totp_disable,
    ("POST", "/api/account/totp/recovery"): Handler.api_totp_recovery,
    ("GET", "/api/users"): Handler.api_users,
    ("POST", "/api/users"): Handler.api_users_create,
    ("POST", "/api/users/update"): Handler.api_users_update,
    ("POST", "/api/users/delete"): Handler.api_users_delete,
    ("POST", "/api/users/password"): Handler.api_users_password,
    ("GET", "/api/tls"): Handler.api_tls,
    ("POST", "/api/tls"): Handler.api_tls_import,
    ("POST", "/api/tls/reset"): Handler.api_tls_reset,
    ("POST", "/api/tls/refresh"): Handler.api_tls_refresh,
})

# Annuaire partagé, numéros abrégés et statistiques du journal des appels
ROUTES.update({
    ("GET", "/api/directory"): Handler.api_directory,
    ("POST", "/api/directory"): Handler.api_directory_save,
    ("POST", "/api/directory/delete"): Handler.api_directory_delete,
    ("POST", "/api/directory/import"): Handler.api_directory_import,
    ("GET", "/api/directory/export"): Handler.api_directory_export,
    ("POST", "/api/pbx/speed-dials"): Handler.api_pbx_speed_dials,
    ("GET", "/api/pbx/calls/stats"): Handler.api_pbx_calls_stats,
})
# Annuaire LDAP des téléphones : réglages, compte de lecture affiché une fois
ROUTES.update({
    ("GET", "/api/directory/ldap"): Handler.api_directory_ldap,
    ("POST", "/api/directory/ldap"): Handler.api_directory_ldap_save,
    ("POST", "/api/directory/ldap/password"): Handler.api_directory_ldap_password,
})

# Files d'attente, enregistrement des appels et diagnostic SIP (admin pour les écoutes et les captures)
ROUTES.update({
    ("POST", "/api/pbx/queues"): Handler.api_pbx_queues,
    ("POST", "/api/pbx/recording"): Handler.api_pbx_recording,
    ("GET", "/api/recordings"): Handler.api_recordings,
    ("GET", "/api/recordings/file"): Handler.api_recordings_file,
    ("GET", "/api/diagnostic"): Handler.api_diagnostic,
    ("POST", "/api/diagnostic/start"): Handler.api_diagnostic_start,
    ("POST", "/api/diagnostic/stop"): Handler.api_diagnostic_stop,
    ("GET", "/api/diagnostic/file"): Handler.api_diagnostic_file,
})

# Provisionnement automatique des téléphones SIP (Yealink, Snom, Grandstream, Fanvil)
ROUTES.update({
    ("GET", "/api/provisioning"): Handler.api_provisioning,
    ("POST", "/api/provisioning"): Handler.api_provisioning_save,
    ("POST", "/api/provisioning/delete"): Handler.api_provisioning_delete,
    ("POST", "/api/provisioning/renew"): Handler.api_provisioning_renew,
    ("POST", "/api/provisioning/settings"): Handler.api_provisioning_settings,
    ("GET", "/api/provisioning/log"): Handler.api_provisioning_log,
    ("POST", "/api/pbx/delete"): Handler.api_pbx_delete_provisioned,
    ("POST", "/api/pbx/discovered/ignore"): Handler.api_pbx_discovered_ignore,
})

# Maintenance : fenêtre planifiée, redémarrage planifié, archive de support (admin)
ROUTES.update({
    ("GET", "/api/maintenance"): Handler.api_maintenance,
    ("POST", "/api/maintenance"): Handler.api_maintenance_save,
    ("POST", "/api/maintenance/reboot"): Handler.api_maintenance_reboot,
    ("GET", "/api/support/file"): Handler.api_support_file,
})

# Active Directory : réglages, essai, synchronisation ; contacts AD et comptes AD protégés
ROUTES.update({
    ("GET", "/api/ad"): Handler.api_ad,
    ("POST", "/api/ad"): Handler.api_ad_save,
    ("POST", "/api/ad/test"): Handler.api_ad_test,
    ("POST", "/api/ad/sync"): Handler.api_ad_sync,
    ("POST", "/api/directory"): Handler.api_directory_save_ad,
    ("POST", "/api/directory/delete"): Handler.api_directory_delete_ad,
    ("POST", "/api/users/update"): Handler.api_users_update_ad,
    ("POST", "/api/users/password"): Handler.api_users_password_ad,
    ("POST", "/api/password"): Handler.api_password_ad,
})

# Supervision en direct : appels en cours, postes et files ; raccrocher (admin)
ROUTES.update({
    ("GET", "/api/live"): Handler.api_live,
    ("POST", "/api/live/hangup"): Handler.api_live_hangup,
})


class SdaHandlers:
    """Lot J : numéros directs, fermetures exceptionnelles, numéro présenté et codes de service."""

    # Messages des numéros directs, des fermetures et du parcage
    SDA_PBX_MESSAGES = (
        ("numéros directs : numéro invalide", "Numéro direct invalide : un numéro à 10 chiffres commençant par 0, ou au format international (+33…)."),
        ("numéros directs :", "Numéro direct invalide : chaque numéro une seule fois, vers un poste, un groupe, une file, une messagerie ou l'accueil."),
        ("numéro présenté :", "Le numéro présenté par un poste doit être un des numéros directs de la ligne."),
        ("fermetures : dates", "Dates de fermeture invalides (jour, mois, année)."),
        ("fermetures : la fin", "La fin d'une période de fermeture doit être après son début."),
        ("fermetures : une période", "Une période de fermeture dure un an au plus."),
        ("fermetures :", "Fermetures exceptionnelles invalides (trente périodes au plus)."),
        ("parcage :", "Les numéros 71 à 79 servent au parcage des appels : choisissez un autre numéro, ou désactivez le parcage."),
    )

    def sda_commit(self, state, session, event, key):
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        applied = self.pbx_commit(state, session["username"], event)
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, key: pbx.public(state)[key]})

    def api_pbx_dids(self):
        """Numéros directs (SDA) : la liste complète remplace l'ancienne. Le numéro présenté d'un poste
        qui n'est plus un numéro direct revient à celui de la ligne."""
        session = self.require_session(write=True)
        dids = self.read_json().get("dids")
        if not isinstance(dids, list):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Liste de numéros directs invalide.")
        state = self.pbx_load()
        state["dids"] = dids
        kept = {directory.normalize_number(d.get("number")) for d in dids if isinstance(d, dict)}
        for e in state["extensions"]:
            if e["caller_id"] and e["caller_id"] not in kept:
                e["caller_id"] = ""
        self.sda_commit(state, session, "pbx:dids:%d" % len(dids), "dids")

    def api_pbx_closures(self):
        """Fermetures exceptionnelles : jours fériés cochés et périodes de fermeture (congés)."""
        session = self.require_session(write=True)
        data = self.read_json()
        state = self.pbx_load()
        state["closures"] = {k: data.get(k) for k in ("holidays_enabled", "holidays", "periods")}
        for key, value in (("holidays", pbx.default_closures()["holidays"]), ("periods", [])):
            if state["closures"][key] is None:
                state["closures"][key] = value
        self.sda_commit(state, session, "pbx:closures:%s:%d" % ("on" if data.get("holidays_enabled") else "off",
                                                                 len(state["closures"]["periods"] or [])), "closures")

    def api_pbx_caller_ids(self):
        """Numéro présenté par poste ({poste: numéro direct ou ""}) et parcage (*70, places 71 à 79)."""
        session = self.require_session(write=True)
        data = self.read_json()
        cids = data.get("caller_ids", {})
        if not isinstance(cids, dict):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Numéros présentés invalides.")
        state = self.pbx_load()
        numbers = {e["number"]: e for e in state["extensions"]}
        if set(map(str, cids)) - set(numbers):
            raise ApiError(HTTPStatus.BAD_REQUEST, "Poste inconnu.")
        for number, value in cids.items():
            numbers[str(number)]["caller_id"] = str(value or "")
        if "parking" in data:
            state["services"] = {"parking": bool(data["parking"])}
        try:
            state = pbx.validate(state)
        except pbx.PbxError as exc:
            raise ApiError(HTTPStatus.BAD_REQUEST, self.pbx_message(exc)) from None
        applied = self.pbx_commit(state, session["username"], "pbx:caller-ids:%d" % sum(1 for e in state["extensions"] if e["caller_id"]))
        self.send_json(HTTPStatus.OK, {"ok": True, "applied": applied, "services": state["services"],
                                       "caller_ids": {e["number"]: e["caller_id"] for e in state["extensions"]}})


for _name, _func in vars(SdaHandlers).items():
    if _name.startswith(("api_", "sda_")):
        setattr(Handler, _name, _func)
Handler.PBX_MESSAGES = SdaHandlers.SDA_PBX_MESSAGES + Handler.PBX_MESSAGES  # cherchés avant les autres
ROUTES.update({
    ("POST", "/api/pbx/dids"): Handler.api_pbx_dids,
    ("POST", "/api/pbx/closures"): Handler.api_pbx_closures,
    ("POST", "/api/pbx/caller-ids"): Handler.api_pbx_caller_ids,
})


def _vtuple(value):
    m = re.match(r"^(\d+)\.(\d+)\.(\d+)", value or "")
    return tuple(int(x) for x in m.groups()) if m else (0, 0, 0)


def read_version(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            value = handle.read().strip()
    except OSError:
        return "0.0.0"
    return value if re.match(r"^\d+\.\d+\.\d+([.-][0-9A-Za-z.-]+)?$", value) else "0.0.0"


def make_server(args):
    db = Database(args.db)
    ctx = Context(db, args.static, read_version(args.version_file), WorkerClient(args.worker_socket),
                  args.data, trust_proxy=args.trust_proxy, secure_cookie=not args.insecure_cookie,
                  update_state=args.update_state, pbx_state=args.pbx_state,
                  networks_state=args.networks_state)
    ctx.appliance_conf = args.appliance_conf
    ctx.backup_dir, ctx.backup_settings = args.backup_dir, args.backup_settings
    ctx.backup_status = os.path.join(os.path.dirname(args.backup_settings), "backup-status.json")
    ctx.sounds_upload = os.path.join(os.path.dirname(args.pbx_state), "sounds-upload")
    ctx.sounds_status = os.path.join(os.path.dirname(args.pbx_state), "sounds.json")
    ctx.capture_request = os.path.join(os.path.dirname(args.pbx_state), "capture-request.json")
    # Alertes : à côté des réglages de sauvegarde (/var/lib/voipbuntu)
    ctx.alerts_settings = os.path.join(os.path.dirname(args.backup_settings), "alerts-settings.json")
    ctx.alerts_state = os.path.join(os.path.dirname(args.backup_settings), "alerts.json")
    ctx.sftp_public = os.path.join(os.path.dirname(args.backup_settings), "backup-sftp.pub")
    # Comptes et certificat HTTPS : clé des secrets, dépôt et état de voipbuntu-tls
    ctx.secrets_key = args.secrets_key
    ctx.tls_upload = os.path.join(os.path.dirname(args.pbx_state), "tls-upload")
    ctx.tls_status = os.path.join(os.path.dirname(args.pbx_state), "tls.json")
    # Annuaire LDAP des téléphones : réglages à côté de pbx.json
    ctx.ldap_settings = os.path.join(os.path.dirname(args.pbx_state), "ldap.json")
    # Maintenance : réglages (console) et état (root) à côté des réglages de sauvegarde
    ctx.maintenance_settings = os.path.join(os.path.dirname(args.backup_settings), "maintenance.json")
    ctx.maintenance_state = os.path.join(os.path.dirname(args.backup_settings), "maintenance-state.json")
    # Active Directory : réglages à côté de pbx.json, état écrit par root, chaîne du certificat importé
    ctx.ad_settings = os.path.join(os.path.dirname(args.pbx_state), "ad.json")
    ctx.ad_dir = adsync.STATE_DIR
    ctx.ad_chain = adsync.CA_EXPORT  # copie des autorités par root : /etc/voipbuntu/tls est réservé à root
    # Supervision en direct : instantané de voipbuntu-live, demande de raccrochage à côté de pbx.json
    ctx.live_snapshot = live.SNAPSHOT
    ctx.live_request = os.path.join(os.path.dirname(args.pbx_state), "live-hangup.json")
    handler = type("BoundHandler", (Handler,), {"ctx": ctx})
    server = ThreadingHTTPServer((args.listen, args.port), handler)
    server.daemon_threads = True
    return server, ctx


def parse_args(argv=None):
    base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    parser = argparse.ArgumentParser(description="Console web VOIPbuntu")
    parser.add_argument("--listen", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--db", default="/var/lib/voipbuntu/web.db")
    parser.add_argument("--static", default=os.path.join(base, "static"))
    parser.add_argument("--version-file", default="/opt/voipbuntu/VERSION")
    parser.add_argument("--worker-socket", default="/run/voipbuntu/worker.sock")
    parser.add_argument("--data", default="/srv/voipbuntu")
    parser.add_argument("--update-state", default="/var/lib/voipbuntu/update.json")
    parser.add_argument("--pbx-state", default=pbx.DEFAULT_STATE)
    parser.add_argument("--networks-state", default=networks.DEFAULT_STATE)
    parser.add_argument("--appliance-conf", default="/etc/voipbuntu/appliance.conf")
    parser.add_argument("--backup-dir", default=backup.DEFAULT_DIR)
    parser.add_argument("--backup-settings", default=backup.DEFAULT_SETTINGS)
    parser.add_argument("--secrets-key", default="/etc/voipbuntu/secrets.key")
    parser.add_argument("--trust-proxy", action="store_true")
    parser.add_argument("--insecure-cookie", action="store_true", help="tests uniquement")
    parser.add_argument("--no-sampler", action="store_true")
    return parser.parse_args(argv)


def main(argv=None):
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s", stream=sys.stderr)
    args = parse_args(argv)
    server, ctx = make_server(args)
    if not args.no_sampler:
        sysinfo.Sampler(ctx.db, args.data).start()
    LOG.info("console VOIPbuntu %s à l'écoute sur %s:%d", ctx.version, args.listen, args.port)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
