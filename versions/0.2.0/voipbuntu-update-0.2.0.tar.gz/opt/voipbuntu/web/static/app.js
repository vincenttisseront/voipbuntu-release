/* Console VOIPbuntu : navigation par onglets, API JSON, graphiques SVG.
   Aucun innerHTML : tout le contenu dynamique passe par textContent. */
(function () {
  "use strict";
  var t = function (s) { return window.I18N.t(s); };
  var state = { csrf: "", range: "1h", metric: "cpu", timer: null, series: null };
  var SCREENS = { tableau: ["indicateurs", "services"], telephonie: ["postes", "etat", "appels"], systeme: ["general", "maj", "taches", "sauvegarde", "journaux", "compte", "journal"] };
  var SVG = "http://www.w3.org/2000/svg";

  function $(id) { return document.getElementById(id); }
  function el(tag, text, cls) {
    var node = document.createElement(tag);
    if (text !== undefined && text !== null) { node.textContent = text; }
    if (cls) { node.className = cls; }
    return node;
  }
  function svg(tag, attrs) {
    var node = document.createElementNS(SVG, tag);
    Object.keys(attrs || {}).forEach(function (k) { node.setAttribute(k, attrs[k]); });
    return node;
  }

  function api(method, path, body) {
    var opts = { method: method, credentials: "same-origin", headers: { "Accept": "application/json" } };
    if (body !== undefined) {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(body);
    }
    if (method !== "GET") { opts.headers["X-CSRF-Token"] = state.csrf; }
    return fetch(path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (data) {
        if (r.status === 401 && path !== "/api/login") { showLogin(); }
        if (!r.ok) { var e = new Error(data.error || t("Erreur interne.")); e.status = r.status; throw e; }
        return data;
      });
    });
  }

  function toast(message) {
    var box = $("toast");
    box.textContent = message;
    box.hidden = false;
    clearTimeout(toast.timer);
    toast.timer = setTimeout(function () { box.hidden = true; }, 4000);
  }

  function confirmDialog(title, text) {
    var dialog = $("dialog");
    $("dialog-title").textContent = title;
    $("dialog-text").textContent = text;
    return new Promise(function (resolve) {
      dialog.addEventListener("close", function handler() {
        dialog.removeEventListener("close", handler);
        resolve(dialog.returnValue === "ok");
      });
      dialog.showModal();
    });
  }

  /* ---------------------------------------------------------- formats */
  function fmtBytes(v) {
    if (v === null || v === undefined) { return "–"; }
    var units = ["o", "Ko", "Mo", "Go", "To"];
    var i = 0;
    while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
    return (i ? v.toFixed(1) : Math.round(v)) + " " + t(units[i]);
  }
  function fmtDuration(s) {
    var d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
    return (d ? d + " " + t("j") + " " : "") + h + " h " + m + " min";
  }
  function fmtTime(ts) {
    return new Date(ts * 1000).toLocaleString(window.I18N.lang() === "en" ? "en-GB" : "fr-FR");
  }
  function last(values) {
    for (var i = values.length - 1; i >= 0; i--) { if (values[i] !== null) { return values[i]; } }
    return null;
  }

  /* ---------------------------------------------------------- navigation */
  function route() {
    var parts = (location.hash || "#tableau").slice(1).split("/");
    var screen = SCREENS[parts[0]] ? parts[0] : "tableau";
    var tab = SCREENS[screen].indexOf(parts[1]) >= 0 ? parts[1] : SCREENS[screen][0];
    document.querySelectorAll(".screen").forEach(function (s) { s.hidden = s.getAttribute("data-screen") !== screen; });
    document.querySelectorAll("nav a").forEach(function (a) {
      if (a.getAttribute("data-screen") === screen) { a.setAttribute("aria-current", "page"); }
      else { a.removeAttribute("aria-current"); }
    });
    var current = document.querySelector('.screen[data-screen="' + screen + '"]');
    current.querySelectorAll('[role="tab"]').forEach(function (b) {
      var on = b.getAttribute("data-tab") === tab;
      b.setAttribute("aria-selected", on ? "true" : "false");
      b.tabIndex = on ? 0 : -1;
    });
    current.querySelectorAll('[role="tabpanel"]').forEach(function (p) { p.hidden = p.getAttribute("data-tab") !== tab; });
    refresh(screen, tab);
  }

  function bindTabs() {
    document.querySelectorAll('[role="tablist"]').forEach(function (list) {
      var screen = list.closest(".screen").getAttribute("data-screen");
      list.addEventListener("click", function (ev) {
        var b = ev.target.closest('[role="tab"]');
        if (b) { location.hash = screen + "/" + b.getAttribute("data-tab"); }
      });
      list.addEventListener("keydown", function (ev) {
        if (ev.key !== "ArrowRight" && ev.key !== "ArrowLeft") { return; }
        var tabs = Array.prototype.slice.call(list.querySelectorAll('[role="tab"]'));
        var i = tabs.indexOf(document.activeElement);
        var next = tabs[(i + (ev.key === "ArrowRight" ? 1 : tabs.length - 1)) % tabs.length];
        next.focus();
        location.hash = screen + "/" + next.getAttribute("data-tab");
      });
    });
  }

  /* ---------------------------------------------------------- données */
  function refresh(screen, tab) {
    clearInterval(state.timer);
    var first = true;
    var run = function () {
      if (screen === "tableau") { loadStatus(); if (tab === "indicateurs") { loadMetrics(); } }
      if (screen === "telephonie") { if (tab === "appels") { loadCalls(); } else { loadPbx(); } }
      if (screen === "systeme") {
        if (tab === "journaux" && (first || $("log-follow").checked)) { loadLogs(); }
        if (tab === "general") { loadStatus(); }
        if (tab === "maj") { loadUpdate(); }
        if (tab === "taches") { loadJobs(); }
        if (tab === "journal") { loadAudit(); }
      }
    };
    run();
    first = false;
    state.timer = setInterval(run, screen === "systeme" && tab === "journaux" ? 5000 : 15000);
  }

  function loadStatus() {
    return api("GET", "/api/status").then(function (s) {
      $("kpi-mem").textContent = s.memory.percent + " %";
      $("kpi-disk").textContent = s.disk.percent + " %";
      $("kpi-uptime").textContent = fmtDuration(s.uptime);
      $("sys-hostname").textContent = s.hostname;
      $("sys-version").textContent = s.version;
      $("sys-os").textContent = s.os;
      $("sys-addresses").textContent = s.addresses.map(function (a) { return a.interface + " " + a.address; }).join(", ") || "–";
      var body = $("services-body");
      body.textContent = "";
      s.services.forEach(function (svc) {
        var tr = el("tr");
        tr.appendChild(el("td", svc.name));
        var td = el("td");
        var badge = el("span", t(svc.state === "active" ? "actif" : svc.state === "inactive" ? "inactif" : svc.state === "failed" ? "en échec" : "inconnu"),
          "state " + (svc.state === "active" ? "ok" : svc.state === "failed" ? "bad" : "warn"));
        td.appendChild(badge);
        tr.appendChild(td);
        body.appendChild(tr);
      });
    }).catch(function () {});
  }

  function loadPbx() {
    return api("GET", "/api/pbx").then(function (p) {
      var body = $("ext-body"), reg = $("reg-body"), count = 0;
      body.textContent = "";
      reg.textContent = "";
      $("ext-empty").hidden = p.extensions.length > 0;
      p.extensions.forEach(function (x) {
        var tr = el("tr");
        tr.appendChild(el("td", x.number));
        tr.appendChild(el("td", x.name));
        tr.appendChild(el("td", x.voicemail ? t("oui") : t("non")));
        var st = el("td");
        st.appendChild(el("span", x.registered ? t("enregistré") : t("non enregistré"), "state " + (x.registered ? "ok" : "warn")));
        tr.appendChild(st);
        var act = el("td");
        var show = el("button", t("Fiche"), "ghost small");
        show.type = "button";
        show.setAttribute("aria-label", t("Fiche du poste") + " " + x.number);
        show.addEventListener("click", function () { revealSecret(x.number, false); });
        var renew = el("button", t("Nouveau mot de passe"), "ghost small");
        renew.type = "button";
        renew.addEventListener("click", function () {
          confirmDialog(t("Nouveau mot de passe"), t("Le poste devra être reconfiguré avec le nouveau mot de passe SIP. Continuer ?")).then(function (ok) {
            if (ok) { revealSecret(x.number, true); }
          });
        });
        var del = el("button", t("Supprimer"), "danger small");
        del.type = "button";
        del.addEventListener("click", function () {
          confirmDialog(t("Supprimer"), t("Supprimer le poste") + " " + x.number + " ?").then(function (ok) {
            if (!ok) { return; }
            api("POST", "/api/pbx/delete", { number: x.number }).then(function () {
              toast(t("Poste supprimé."));
              loadPbx();
            }).catch(function (e) { toast(e.message); });
          });
        });
        act.appendChild(show); act.appendChild(renew); act.appendChild(del);
        tr.appendChild(act);
        body.appendChild(tr);
        if (x.registered) {
          count += 1;
          var r = el("tr");
          r.appendChild(el("td", x.number));
          r.appendChild(el("td", x.name));
          r.appendChild(el("td", x.address || "–"));
          r.appendChild(el("td", x.rtt ? Math.round(parseFloat(x.rtt)) + " ms" : "–"));
          reg.appendChild(r);
        }
      });
      var run = $("pbx-running");
      run.textContent = "";
      run.appendChild(el("span", p.running ? t("actif") : p.running === false ? t("arrêté") : t("inconnu"),
        "state " + (p.running ? "ok" : "bad")));
      $("pbx-count").textContent = count + " / " + p.extensions.length;
      $("pbx-calls").textContent = p.calls === null || p.calls === undefined ? "–" : String(p.calls);
    }).catch(function () {});
  }

  var DISPOSITIONS = { "ANSWERED": "répondu", "NO ANSWER": "sans réponse", "BUSY": "occupé", "FAILED": "échec", "CONGESTION": "échec" };

  function fmtCallDuration(s) {
    var m = Math.floor(s / 60), r = s % 60;
    return m + ":" + (r < 10 ? "0" : "") + r;
  }

  function loadCalls() {
    return api("GET", "/api/pbx/calls").then(function (d) {
      var body = $("calls-body");
      body.textContent = "";
      $("calls-empty").hidden = d.calls.length > 0;
      d.calls.forEach(function (c) {
        var tr = el("tr");
        tr.appendChild(el("td", c.start));
        tr.appendChild(el("td", c.src + (c.src_name ? " (" + c.src_name + ")" : "")));
        tr.appendChild(el("td", c.dst));
        tr.appendChild(el("td", c.disposition === "ANSWERED" ? fmtCallDuration(c.billsec) : "–"));
        var st = el("td");
        var label = c.voicemail ? t("messagerie") : t(DISPOSITIONS[c.disposition] || "échec");
        st.appendChild(el("span", label, "state " + (c.disposition === "ANSWERED" && !c.voicemail ? "ok" : c.voicemail ? "warn" : "bad")));
        tr.appendChild(st);
        body.appendChild(tr);
      });
    }).catch(function (e) { toast(e.message); });
  }

  function loadLogs() {
    var source = $("log-source").value;
    return api("GET", "/api/logs?source=" + encodeURIComponent(source)).then(function (d) {
      var box = $("log-lines");
      var atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 30;
      box.textContent = d.lines.length ? d.lines.join("\n") : t("Journal vide.");
      if (atBottom || box.dataset.source !== source) { box.scrollTop = box.scrollHeight; }
      box.dataset.source = source;
    }).catch(function (e) { toast(e.message); });
  }

  function bindOps() {
    $("log-source").addEventListener("change", loadLogs);
    $("restore-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("restore-message");
      msg.textContent = "";
      msg.className = "";
      var file = $("restore-file").files[0];
      if (!file) { msg.textContent = t("Choisissez un fichier de sauvegarde."); msg.className = "error"; return; }
      if (file.size > 60 * 1024) { msg.textContent = t("Ce fichier n'est pas une sauvegarde VOIPbuntu."); msg.className = "error"; return; }
      file.text().then(function (text) {
        var data;
        try { data = JSON.parse(text); } catch (e) { throw new Error(t("Ce fichier n'est pas une sauvegarde VOIPbuntu.")); }
        var count = data && data.pbx && Array.isArray(data.pbx.extensions) ? data.pbx.extensions.length : 0;
        return confirmDialog(t("Restaurer"), t("Remplacer la configuration actuelle par celle de la sauvegarde") + " (" + count + " " + (count === 1 ? t("poste") : t("postes")) + ") ?").then(function (ok) {
          if (!ok) { return; }
          return api("POST", "/api/restore", data).then(function (r) {
            ev.target.reset();
            msg.textContent = t("Configuration restaurée") + " : " + r.extensions + " " + (r.extensions === 1 ? t("poste") : t("postes")) + ".";
          });
        });
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  function showSheet(d, title) {
    $("sheet-title").textContent = title + " " + d.number;
    $("sheet-server").textContent = (d.servers && d.servers.length ? d.servers.join(t(" ou ")) : location.hostname);
    $("sheet-port").textContent = d.port + " / " + d.transport;
    $("sheet-user").textContent = d.number;
    $("sheet-auth").textContent = d.number;
    $("sheet-secret").textContent = d.secret;
    $("sheet-name").textContent = d.name;
    $("sheet-vm").textContent = d.voicemail ? d.voicemail_code + " · " + t("Code de messagerie") + " : " + d.pin : t("non");
    $("sheet").showModal();
  }

  function revealSecret(number, renew) {
    api("POST", "/api/pbx/secret", { number: number, renew: renew }).then(function (d) {
      showSheet(d, t("Fiche du poste"));
      if (renew) { loadPbx(); }
    }).catch(function (e) { toast(e.message); });
  }

  function bindPbx() {
    $("sheet-close").addEventListener("click", function () { $("sheet").close(); });
    $("sheet-print").addEventListener("click", function () { window.print(); });
    $("ext-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("ext-message");
      msg.textContent = "";
      api("POST", "/api/pbx/extensions", {
        number: $("ext-number").value.trim(), name: $("ext-name").value.trim(), voicemail: $("ext-voicemail").checked
      }).then(function (d) {
        $("ext-form").reset();
        loadPbx();
        showSheet(d, t("Poste créé"));
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });
  }

  function loadUpdate() {
    return api("GET", "/api/update").then(function (u) {
      $("upd-current").textContent = u.current || "–";
      $("upd-latest").textContent = u.latest || "–";
      $("upd-checked").textContent = u.checked ? fmtTime(u.checked) : t("jamais");
      var st = $("upd-state");
      st.textContent = "";
      var label = u.error ? t("vérification en échec") : u.available ? t("nouvelle version disponible") : u.latest ? t("à jour") : t("non vérifié");
      st.appendChild(el("span", label, "state " + (u.error ? "bad" : u.available ? "warn" : u.latest ? "ok" : "warn")));
      if (u.error) { st.appendChild(el("span", " " + u.error, "muted")); }
      $("upd-notes").textContent = u.notes || "–";
      $("upd-apply").disabled = !u.available;
    }).catch(function () {});
  }

  function loadMetrics() {
    return api("GET", "/api/metrics?range=" + encodeURIComponent(state.range)).then(function (m) {
      state.series = m;
      var cpu = last(m.cpu), rx = last(m.rx), tx = last(m.tx);
      $("kpi-cpu").textContent = cpu === null ? "–" : cpu + " %";
      $("kpi-net").textContent = rx === null ? "–" : "↓ " + fmtBytes(rx) + "/s ↑ " + fmtBytes(tx) + "/s";
      drawChart();
    }).catch(function () {});
  }

  function drawChart() {
    var m = state.series;
    var box = $("chart");
    box.textContent = "";
    if (!m) { return; }
    var lines = state.metric === "net" ? [["rx", t("Reçu")], ["tx", t("Émis")]] : [[state.metric, ""]];
    var W = 720, H = 220, L = 56, R = 12, T = 12, B = 28;
    var max = 0;
    lines.forEach(function (l) { m[l[0]].forEach(function (v) { if (v !== null && v > max) { max = v; } }); });
    if (state.metric === "cpu" || state.metric === "mem") { max = 100; }
    if (!max) { max = 1; }
    var n = m.t.length;
    var x = function (i) { return L + (W - L - R) * (i / (n - 1)); };
    var y = function (v) { return T + (H - T - B) * (1 - v / max); };
    var root = svg("svg", { viewBox: "0 0 " + W + " " + H, preserveAspectRatio: "none", "class": "chart-svg" });
    for (var g = 0; g <= 4; g++) {
      var gv = max * g / 4;
      root.appendChild(svg("line", { x1: L, x2: W - R, y1: y(gv), y2: y(gv), "class": "grid" }));
      var label = svg("text", { x: L - 6, y: y(gv) + 4, "text-anchor": "end", "class": "axis" });
      label.textContent = state.metric === "net" ? fmtBytes(gv) : (Math.round(gv * 10) / 10).toString();
      root.appendChild(label);
    }
    [0, Math.floor(n / 2), n - 1].forEach(function (i) {
      var tl = svg("text", { x: x(i), y: H - 8, "text-anchor": i === 0 ? "start" : i === n - 1 ? "end" : "middle", "class": "axis" });
      tl.textContent = new Date(m.t[i] * 1000).toLocaleTimeString(window.I18N.lang() === "en" ? "en-GB" : "fr-FR", { hour: "2-digit", minute: "2-digit" });
      root.appendChild(tl);
    });
    lines.forEach(function (l, li) {
      var values = m[l[0]], d = "", pen = false;
      values.forEach(function (v, i) {
        if (v === null) { pen = false; return; }
        d += (pen ? "L" : "M") + x(i).toFixed(1) + " " + y(v).toFixed(1);
        var isolated = (i === 0 || values[i - 1] === null) && (i === n - 1 || values[i + 1] === null);
        if (isolated) { root.appendChild(svg("circle", { cx: x(i), cy: y(v), r: 2.5, "class": "dot s" + li })); }
        pen = true;
      });
      if (d) { root.appendChild(svg("path", { d: d, "class": "line s" + li })); }
    });
    var cursor = svg("line", { x1: 0, x2: 0, y1: T, y2: H - B, "class": "cursor", visibility: "hidden" });
    root.appendChild(cursor);
    var tip = $("chart-tip");
    root.addEventListener("mousemove", function (ev) {
      var rect = root.getBoundingClientRect();
      var px = (ev.clientX - rect.left) / rect.width * W;
      var i = Math.max(0, Math.min(n - 1, Math.round((px - L) / (W - L - R) * (n - 1))));
      cursor.setAttribute("x1", x(i)); cursor.setAttribute("x2", x(i)); cursor.setAttribute("visibility", "visible");
      var parts = [new Date(m.t[i] * 1000).toLocaleTimeString(window.I18N.lang() === "en" ? "en-GB" : "fr-FR")];
      lines.forEach(function (l) {
        var v = m[l[0]][i];
        parts.push((l[1] ? l[1] + " : " : "") + (v === null ? "–" : state.metric === "net" ? fmtBytes(v) + "/s" : v));
      });
      tip.textContent = parts.join("  ·  ");
      tip.hidden = false;
    });
    root.addEventListener("mouseleave", function () { cursor.setAttribute("visibility", "hidden"); tip.hidden = true; });
    box.appendChild(root);
  }

  function loadJobs() {
    return api("GET", "/api/jobs").then(function (data) {
      var body = $("jobs-body");
      body.textContent = "";
      (data.jobs || []).forEach(function (j) {
        var tr = el("tr");
        tr.appendChild(el("td", String(j.id)));
        tr.appendChild(el("td", t(JOB_LABELS[j.action] || j.action)));
        tr.appendChild(el("td", j.user || "–"));
        var st = el("td");
        st.appendChild(el("span", t(JOB_STATES[j.state] || j.state), "state " + (j.state === "done" ? "ok" : j.state === "failed" ? "bad" : "warn")));
        tr.appendChild(st);
        tr.appendChild(el("td", j.started ? fmtTime(j.started) : "–"));
        tr.tabIndex = 0;
        tr.addEventListener("click", function () { var out = $("job-output"); out.textContent = j.output || ""; out.hidden = !j.output; });
        body.appendChild(tr);
      });
    }).catch(function (e) { toast(e.message); });
  }

  function loadAudit() {
    return api("GET", "/api/audit").then(function (data) {
      var body = $("audit-body");
      body.textContent = "";
      data.events.forEach(function (ev) {
        var tr = el("tr");
        tr.appendChild(el("td", fmtTime(ev.ts)));
        tr.appendChild(el("td", ev.user || "–"));
        tr.appendChild(el("td", ev.remote || "–"));
        tr.appendChild(el("td", ev.event, ev.event.indexOf("failed") >= 0 ? "error-text" : ""));
        body.appendChild(tr);
      });
    }).catch(function () {});
  }

  var JOB_LABELS = {
    "apt-refresh": "Rechercher les mises à jour Ubuntu",
    "update-check": "Rechercher une nouvelle version",
    "update-apply": "Installer la nouvelle version",
    "pbx-apply": "Appliquer la configuration téléphonique",
    "apt-security-upgrade": "Installer les correctifs de sécurité",
    "restart-web": "Redémarrer la console",
    "reboot": "Redémarrer l'appliance",
    "poweroff": "Arrêter l'appliance"
  };
  var JOB_STATES = { queued: "en attente", running: "en cours", done: "terminée", failed: "en échec" };

  function bindJobs() {
    document.querySelectorAll("[data-job]").forEach(function (b) {
      b.addEventListener("click", function () {
        var action = b.getAttribute("data-job");
        confirmDialog(t(JOB_LABELS[action]), t("Cette action est ajoutée à la file d'attente. Continuer ?")).then(function (ok) {
          if (!ok) { return; }
          api("POST", "/api/jobs", { action: action }).then(function () {
            toast(t("Tâche ajoutée à la file d'attente."));
            if (location.hash.indexOf("taches") >= 0) { loadJobs(); }
            if (location.hash.indexOf("maj") >= 0) { setTimeout(loadUpdate, 3000); }
          }).catch(function (e) { toast(e.message); });
        });
      });
    });
  }

  /* ---------------------------------------------------------- session */
  function showLogin() {
    clearInterval(state.timer);
    $("app-view").hidden = true;
    $("login-view").hidden = false;
    $("login-user").focus();
  }

  function showApp(session) {
    state.csrf = session.csrf;
    $("whoami").textContent = session.user;
    $("version").textContent = "v" + session.version;
    $("login-view").hidden = true;
    $("app-view").hidden = false;
    route();
  }

  function setLang(lang) {
    document.cookie = "pxb_lang=" + lang + "; Path=/; SameSite=Strict; Secure; Max-Age=31536000";
    return window.I18N.load(lang).then(function () {
      window.I18N.apply();
      $("lang-toggle").textContent = lang === "fr" ? "EN" : "FR";
      if (state.series) { drawChart(); }
    });
  }

  function setTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    try { localStorage.setItem("pxb_theme", theme); } catch (e) { /* stockage indisponible */ }
  }

  function init() {
    var saved = null;
    try { saved = localStorage.getItem("pxb_theme"); } catch (e) { saved = null; }
    if (saved) { setTheme(saved); }
    bindTabs();
    bindJobs();
    bindPbx();
    bindOps();
    window.addEventListener("hashchange", route);
    $("theme-toggle").addEventListener("click", function () {
      var dark = document.documentElement.getAttribute("data-theme") === "dark" ||
        (!document.documentElement.getAttribute("data-theme") && window.matchMedia("(prefers-color-scheme: dark)").matches);
      setTheme(dark ? "light" : "dark");
    });
    $("lang-toggle").addEventListener("click", function () { setLang(window.I18N.lang() === "fr" ? "en" : "fr"); });
    document.querySelectorAll("[data-range]").forEach(function (b) {
      b.addEventListener("click", function () {
        state.range = b.getAttribute("data-range");
        document.querySelectorAll("[data-range]").forEach(function (o) { o.setAttribute("aria-pressed", o === b ? "true" : "false"); });
        loadMetrics();
      });
    });
    $("chart-metric").addEventListener("change", function (ev) { state.metric = ev.target.value; drawChart(); });
    $("login-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      $("login-error").textContent = "";
      api("POST", "/api/login", { username: $("login-user").value.trim(), password: $("login-pass").value })
        .then(function (s) { $("login-pass").value = ""; return api("GET", "/api/session").then(showApp); })
        .catch(function (e) { $("login-error").textContent = e.message; });
    });
    $("logout").addEventListener("click", function () {
      api("POST", "/api/logout", {}).then(showLogin, showLogin);
    });
    $("password-form").addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("pw-message");
      msg.className = "";
      if ($("pw-new").value !== $("pw-confirm").value) {
        msg.textContent = t("Les deux mots de passe ne correspondent pas.");
        msg.className = "error";
        return;
      }
      api("POST", "/api/password", { current: $("pw-current").value, "new": $("pw-new").value }).then(function (r) {
        state.csrf = r.csrf;
        ev.target.reset();
        msg.textContent = t("Mot de passe modifié.");
      }).catch(function (e) { msg.textContent = e.message; msg.className = "error"; });
    });

    api("GET", "/api/session").then(function (s) {
      return setLang(s.lang).then(function () {
        $("login-unconfigured").hidden = s.configured;
        if (s.user) { showApp(s); } else { showLogin(); }
      });
    }).catch(showLogin);
  }

  document.addEventListener("DOMContentLoaded", init);
})();
