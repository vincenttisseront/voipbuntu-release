# VOIPbuntu : sur une console locale, l'assistant puis le menu s'ouvrent à la connexion.
case "$-" in *i*) ;; *) return 0 2>/dev/null || exit 0 ;; esac
case "$(tty 2>/dev/null)" in
    /dev/tty[1-6])
        if id -nG 2>/dev/null | grep -qw sudo && [ -z "${VOIPBUNTU_NO_MENU:-}" ]; then
            if [ ! -e /var/lib/voipbuntu/firstboot.done ]; then
                sudo /opt/voipbuntu/bin/voipbuntu-firstboot
            fi
            sudo /opt/voipbuntu/bin/voipbuntu-menu
        fi
        ;;
    *) [ -t 1 ] && echo "VOIPbuntu : tapez 'sudo voipbuntu-menu' pour le menu d'administration." ;;
esac
