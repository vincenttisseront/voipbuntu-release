/* Traducteur côté navigateur. Même normalisation des espaces que i18n.py. */
(function (global) {
  "use strict";
  var catalogs = { fr: {} };
  var current = "fr";

  function normalize(text) {
    return String(text).replace(/\s+/g, " ").trim();
  }

  function t(text) {
    if (current === "fr") { return text; }
    var table = catalogs[current] || {};
    var key = normalize(text);
    return Object.prototype.hasOwnProperty.call(table, key) ? table[key] : text;
  }

  function apply(root) {
    var scope = root || document;
    var nodes = scope.querySelectorAll("[data-i18n]");
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      if (!node.hasAttribute("data-fr")) { node.setAttribute("data-fr", normalize(node.textContent)); }
      node.textContent = t(node.getAttribute("data-fr"));
    }
    var attrs = scope.querySelectorAll("[data-i18n-attr]");
    for (var j = 0; j < attrs.length; j++) {
      var el = attrs[j];
      var names = el.getAttribute("data-i18n-attr").split(/\s+/);
      for (var k = 0; k < names.length; k++) {
        var name = names[k];
        var store = "data-fr-" + name;
        if (!el.hasAttribute(store)) { el.setAttribute(store, normalize(el.getAttribute(name) || "")); }
        el.setAttribute(name, t(el.getAttribute(store)));
      }
    }
    document.documentElement.lang = current;
  }

  function load(lang) {
    if (lang === "fr" || catalogs[lang]) {
      current = lang;
      return Promise.resolve();
    }
    return fetch("i18n/" + encodeURIComponent(lang) + ".json", { credentials: "same-origin" })
      .then(function (r) { if (!r.ok) { throw new Error("catalogue"); } return r.json(); })
      .then(function (raw) {
        var table = {};
        Object.keys(raw).forEach(function (k) { table[normalize(k)] = raw[k]; });
        catalogs[lang] = table;
        current = lang;
      });
  }

  global.I18N = {
    t: t,
    apply: apply,
    load: load,
    normalize: normalize,
    lang: function () { return current; }
  };
})(window);
